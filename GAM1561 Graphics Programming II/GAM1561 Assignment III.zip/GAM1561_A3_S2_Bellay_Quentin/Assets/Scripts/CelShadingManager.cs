﻿using UnityEngine;
using System.Collections;

public class CelShadingManager : MonoBehaviour 
{
	public Light m_DirectionalLight;

	// Update is called once per frame
	void Update () 
	{
		renderer.material.SetVector ("m_LightDirection", m_DirectionalLight.transform.forward);
		renderer.material.SetColor ("m_DiffuseColor", m_DirectionalLight.color * m_DirectionalLight.intensity); 
	}
}
