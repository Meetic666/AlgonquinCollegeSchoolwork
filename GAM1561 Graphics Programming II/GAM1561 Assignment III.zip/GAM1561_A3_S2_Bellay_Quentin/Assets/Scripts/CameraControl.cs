﻿using UnityEngine;
using System.Collections;

public class CameraControl : MonoBehaviour 
{
	public float m_Speed = 5.0f;
	
	// Update is called once per frame
	void Update () 
	{
		transform.Translate (Vector3.forward * m_Speed * Input.GetAxis ("Vertical") * Time.deltaTime);
	}
}
