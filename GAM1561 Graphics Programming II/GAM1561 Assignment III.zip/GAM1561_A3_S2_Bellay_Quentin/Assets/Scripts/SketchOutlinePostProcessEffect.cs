﻿using UnityEngine;
using System.Collections;

public class SketchOutlinePostProcessEffect : MonoBehaviour
{
	public Material m_PostProcessSketchMaterial;

	public GameObject m_NormalAndDepthCamera;

	public int m_SamplingPixelSize = 5;

	void Start()
	{
		int width = m_NormalAndDepthCamera.camera.targetTexture.width;
		int height = m_NormalAndDepthCamera.camera.targetTexture.height;

		m_PostProcessSketchMaterial.SetFloat ("m_SamplingSizeX", (float)m_SamplingPixelSize / (float)width);
		m_PostProcessSketchMaterial.SetFloat ("m_SamplingSizeY", (float)m_SamplingPixelSize / (float)height);
	}
	
	void OnRenderImage(RenderTexture source, RenderTexture destination)
	{
		m_NormalAndDepthCamera.camera.Render ();
		
		Graphics.Blit(source, destination, m_PostProcessSketchMaterial);
	}
}
