﻿using UnityEngine;
using System.Collections;

public class FogPostProcessEffect : MonoBehaviour 
{
	public Material m_PostProcessFogMaterial;

	bool m_IsRenderingFog;

	Vector3 m_FogCenter = new Vector3(306.0f, 271.12f, -1698.6f);
	float m_FogRadius = 100.0f;

	public GameObject m_FogCamera;

	float m_HorizontalFieldOfView;

	void Start()
	{
		m_PostProcessFogMaterial.SetTexture ("m_FogColorTexture", m_FogCamera.camera.targetTexture);

		m_HorizontalFieldOfView = camera.fieldOfView * camera.aspect / 2.0f * Mathf.Deg2Rad;
	}

	void Update()
	{
		float distance = Vector3.Distance (transform.position, m_FogCenter);

		float angleOfFog = Mathf.PI + m_HorizontalFieldOfView;

		m_IsRenderingFog = (Vector3.Dot ((m_FogCenter - transform.position).normalized, transform.forward) > Mathf.Cos (angleOfFog) || Vector3.Distance (transform.position, m_FogCenter) <= m_FogRadius);
	}

	void OnRenderImage(RenderTexture source, RenderTexture destination)
	{
		m_FogCamera.camera.Render ();
		
		Graphics.Blit(source, destination, m_PostProcessFogMaterial);
	}
}
