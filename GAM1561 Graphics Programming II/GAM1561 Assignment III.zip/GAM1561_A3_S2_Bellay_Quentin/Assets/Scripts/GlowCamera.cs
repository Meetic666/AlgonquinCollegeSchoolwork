﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class GlowCamera: MonoBehaviour 
{
	public RenderTexture m_GlowRenderTexture;
	public RenderTexture m_StencilRenderTexture;

	public Material m_FlatColourMaterial;
	public Material m_BlurMaterial;

	public LayerMask m_GlowLayerMask;

	public float m_GlowDistance = 10.0f;

	int m_NormalLayerMask;

	Dictionary<Renderer, Material> m_GlowOutlineObjectRenderers = new Dictionary<Renderer, Material>();

	Color m_NormalBackgroundColor;

	void Start()
	{
		m_NormalLayerMask = camera.cullingMask;

		GameObject[] glowOutlineObjects = GameObject.FindGameObjectsWithTag ("GlowOutline");
		
		foreach(GameObject gameObject in glowOutlineObjects)
		{
			foreach(Renderer objectRenderer in gameObject.GetComponentsInChildren<Renderer>())
			{
				m_GlowOutlineObjectRenderers.Add (objectRenderer, objectRenderer.material);
			}
		}

		m_NormalBackgroundColor = camera.backgroundColor;
	}

	public void RenderGlow()
	{
		camera.cullingMask = m_GlowLayerMask;
		camera.targetTexture = m_GlowRenderTexture;

		SetGlowOutlineObjects (true);
		
		camera.Render();
		
		camera.targetTexture = m_StencilRenderTexture;

		Color previousColor = m_FlatColourMaterial.GetColor ("m_GlowColour");
		m_FlatColourMaterial.SetColor ("m_GlowColour", Color.white);

		camera.Render ();
		
		m_FlatColourMaterial.SetColor ("m_GlowColour", previousColor);

		SetGlowOutlineObjects (false);

		camera.cullingMask = m_NormalLayerMask;
		camera.targetTexture = null;

		m_BlurMaterial.SetTexture ("m_GlowTexture", m_GlowRenderTexture);

		Graphics.Blit (m_GlowRenderTexture, m_GlowRenderTexture, m_BlurMaterial);
	}

	void SetGlowOutlineObjects(bool isGlowing)
	{
		foreach(Renderer glowRenderer in m_GlowOutlineObjectRenderers.Keys)
		{
			if((1 << glowRenderer.gameObject.layer & m_GlowLayerMask.value) != 0)
			{
				glowRenderer.material = isGlowing ? m_FlatColourMaterial : m_GlowOutlineObjectRenderers[glowRenderer];
			}
		}
	}
}
