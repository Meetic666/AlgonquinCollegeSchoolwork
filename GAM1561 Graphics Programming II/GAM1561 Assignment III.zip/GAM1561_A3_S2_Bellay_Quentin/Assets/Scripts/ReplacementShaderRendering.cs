﻿using UnityEngine;
using System.Collections;

public class ReplacementShaderRendering : MonoBehaviour 
{	
	public Shader m_ReplacementShader;

	void Start()
	{
		camera.SetReplacementShader (m_ReplacementShader, "");
	}
}
