﻿using UnityEngine;
using System.Collections;

public class FogAmountRendering : MonoBehaviour 
{	
	public Shader m_FogAmountRenderShader;

	void Start()
	{
		camera.SetReplacementShader (m_FogAmountRenderShader, "");
	}
}
