﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class GlowOutlineCamera : MonoBehaviour 
{
	public Material m_OutlineMaterial;

	RenderTexture m_GlowRenderTexture;
	RenderTexture m_StencilRenderTexture;

	GlowCamera m_GlowCamera;

	void Start()
	{
		m_GlowCamera = GetComponentInChildren<GlowCamera> ();

		m_GlowRenderTexture = m_GlowCamera.m_GlowRenderTexture;
		m_StencilRenderTexture = m_GlowCamera.m_StencilRenderTexture;
	}

	void OnRenderImage(RenderTexture sourceTexture, RenderTexture destinationTexture)
	{
		m_GlowCamera.RenderGlow ();

		m_OutlineMaterial.SetTexture ("m_GlowTexture", m_GlowRenderTexture);
		m_OutlineMaterial.SetTexture ("m_StencilTexture", m_StencilRenderTexture);

		Graphics.Blit (sourceTexture, destinationTexture, m_OutlineMaterial);
	}
}
