#include "InputListener.h"


void InputListener::mouseMovementEvent(float deltaX, float deltaY, float positionX, float positionY)
{
    
}

void InputListener::mouseLeftClickDownEvent(float positionX, float positionY)
{
    
}

void InputListener::mouseRightClickDownEvent(float positionX, float positionY)
{
    
}

void InputListener::mouseLeftClickUpEvent(float positionX, float positionY)
{
    
}

void InputListener::mouseRightClickUpEvent(float positionX, float positionY)
{
    
}

void InputListener::keyDownEvent(int keyCode)
{
	//Override this method to recieve key down events
}

void InputListener::keyUpEvent(int keyCode)
{
	//Override this method to recieve key up events
}