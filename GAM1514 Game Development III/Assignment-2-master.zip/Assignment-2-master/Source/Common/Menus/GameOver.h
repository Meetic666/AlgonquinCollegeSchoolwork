//
//  Student:        Quentin Bellay
//  Creation Date:  October 11th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the Game Over screen
//  Modified:       
//

#ifndef GAME_OVER_H
#define GAME_OVER_H

#include "BaseMenuScreenFiltered.h"
#include <vector>

// Classe GameOver represents the GameOver screen
class GameOver : public BaseMenuScreenFiltered
{
public:
    GameOver();
    ~GameOver();
    
    const char* getName();  
    
	void update(double deltaTime);

    void keyUpEvent(int keyCode);

protected:
	void buttonSelectedEvent(UIButton* buttonSelected);
};

#endif