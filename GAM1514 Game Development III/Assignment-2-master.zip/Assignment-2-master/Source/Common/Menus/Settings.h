//
//  Student:        Quentin Bellay
//  Creation Date:  October 14th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the Settings screen
//  Modified:       
//

#ifndef SETTINGS_H
#define SETTINGS_H

#include "BaseMenuScreenFiltered.h"
#include <vector>

// Settings represents the Game Settings screen
class Settings : public BaseMenuScreenFiltered
{
public:
    Settings();
    ~Settings();
    
    const char* getName();
    
    void keyUpEvent(int keyCode);

protected:
	void buttonSelectedEvent(UIButton* buttonSelected);
    
private:
	void setPlayer1Input();
	void setPlayer2IsGreyed(bool isGreyed);
	void setAIIsGreyed(bool isGreyed);
	void setGreyed();
	void setMaxScoreSelected();
	void setTimeLimitSelected();

	void resetButtons();
};

#endif
