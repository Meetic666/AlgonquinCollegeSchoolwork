//
//  Student:        Quentin Bellay
//  Creation Date:  October 11th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the Credits screen
//  Modified:       
//

#include "Credits.h"
#include "../Constants/Constants.h"
#include "../Screen Manager/ScreenManager.h"

Credits::Credits()
{
	UIButton* newButton = new UIButton(CREDITS_BACK_BUTTON, CREDITS_BACK_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * CREDITS_BACK_BUTTON_PERCENTAGE_X, getHeight() * CREDITS_BACK_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);

	UILabel* newLabel = new UILabel(CREDITS_LABEL, CREDITS_LABEL_ID);
	newLabel -> setCenterPosition(getWidth() * CREDITS_LABEL_PERCENTAGE_X, getHeight() * CREDITS_LABEL_PERCENTAGE_Y);
	addWidget(newLabel);

	newLabel = new UILabel(CREDITS_AUTHOR_NAME, CREDITS_AUTHOR_LABEL_ID);
	newLabel -> setCenterPosition(getWidth() * CREDITS_AUTHOR_LABEL_PERCENTAGE_X, getHeight() * CREDITS_AUTHOR_LABEL_PERCENTAGE_Y);
	addWidget(newLabel);

	newLabel = new UILabel(CREDITS_PROFESSOR_NAME, CREDITS_PROFESSOR_LABEL_ID);
	newLabel -> setCenterPosition(getWidth() * CREDITS_PROFESSOR_LABEL_PERCENTAGE_X, getHeight() * CREDITS_PROFESSOR_LABEL_PERCENTAGE_Y);
	addWidget(newLabel);

	newLabel = new UILabel(CREDITS_COURSE_NUMBER, CREDITS_COURSE_NUMBER_LABEL_ID);
	newLabel -> setCenterPosition(getWidth() * CREDITS_COURSE_NUMBER_LABEL_PERCENTAGE_X, getHeight() * CREDITS_COURSE_NUMBER_LABEL_PERCENTAGE_Y);
	addWidget(newLabel);

	newLabel = new UILabel(CREDITS_COURSE_NAME, CREDITS_COURSE_NAME_LABEL_ID);
	newLabel -> setCenterPosition(getWidth() * CREDITS_COURSE_NAME_LABEL_PERCENTAGE_X, getHeight() * CREDITS_COURSE_NAME_LABEL_PERCENTAGE_Y);
	addWidget(newLabel);

	newLabel = new UILabel(CREDITS_PROGRAM_NAME, CREDITS_PROGRAM_NAME_LABEL_ID);
	newLabel -> setCenterPosition(getWidth() * CREDITS_PROGRAM_NAME_LABEL_PERCENTAGE_X, getHeight() * CREDITS_PROGRAM_NAME_LABEL_PERCENTAGE_Y);
	addWidget(newLabel);

	newLabel = new UILabel(CREDITS_COLLEGE_NAME, CREDITS_COLLEGE_LABEL_ID);
	newLabel -> setCenterPosition(getWidth() * CREDITS_COLLEGE_LABEL_PERCENTAGE_X, getHeight() * CREDITS_COLLEGE_LABEL_PERCENTAGE_Y);
	addWidget(newLabel);

	m_CurrentButton = (UIButton*)getWidgetWithID(CREDITS_BACK_BUTTON_ID);	
	m_CurrentButton -> setIsHovered(true);

	newButton = NULL;
	newLabel = NULL;
}

Credits::~Credits()
{

}
    
const char* Credits::getName()
{
	return CREDITS_SCREEN_NAME;
}
    
void Credits::keyUpEvent(int keyCode)
{
	if(keyCode == KEYCODE_RETURN)
	{
		if(m_CurrentButton != NULL)
		{
			m_CurrentButton -> keyUpEvent(keyCode);
		}
	}
	else if(keyCode == KEYCODE_UP_ARROW || keyCode == KEYCODE_DOWN_ARROW)
	{
		if(m_CurrentButton != NULL)
		{
			m_CurrentButton -> setIsHovered(false);
		}

		m_CurrentButton = (UIButton*)getWidgetWithID(CREDITS_BACK_BUTTON_ID);

		m_CurrentButton -> setIsHovered(true);
	}
}

void Credits::buttonSelectedEvent(UIButton* buttonSelected)
{
	if(buttonSelected -> getID() == CREDITS_BACK_BUTTON_ID)
	{
		buttonSelected -> setIsSelected(false);
		ScreenManager::getInstance() -> goBack();
	}
}