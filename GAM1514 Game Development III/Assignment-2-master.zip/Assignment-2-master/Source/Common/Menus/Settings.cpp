//
//  Student:        Quentin Bellay
//  Creation Date:  October 14th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the Settings screen
//  Modified:       
//

#include "Settings.h"
#include "../Constants/Constants.h"
#include "../Input/Input.h"
#include "../Screen Manager/ScreenManager.h"
#include "../Game/GameData.h"

Settings::Settings()
{
	UIButton* newButton = new UIButton(SETTINGS_SINGLE_PLAYER, SETTINGS_SINGLE_PLAYER_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * SETTINGS_SINGLE_PLAYER_BUTTON_PERCENTAGE_X, getHeight() * SETTINGS_SINGLE_PLAYER_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);

	newButton = new UIButton(SETTINGS_TWO_PLAYERS, SETTINGS_TWO_PLAYERS_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * SETTINGS_TWO_PLAYERS_BUTTON_PERCENTAGE_X, getHeight() * SETTINGS_TWO_PLAYERS_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);

	UILabel* newLabel = new UILabel(SETTINGS_PLAYER1_LABEL, SETTINGS_PLAYER1_LABEL_ID);
	newLabel -> setCenterPosition(getWidth() * SETTINGS_PLAYER1_LABEL_PERCENTAGE_X, getHeight() * SETTINGS_PLAYER1_LABEL_PERCENTAGE_Y);
	addWidget(newLabel);

	newLabel = new UILabel(SETTINGS_PLAYER2_LABEL, SETTINGS_PLAYER2_LABEL_ID);
	newLabel -> setCenterPosition(getWidth() * SETTINGS_PLAYER2_LABEL_PERCENTAGE_X, getHeight() * SETTINGS_PLAYER2_LABEL_PERCENTAGE_Y);
	addWidget(newLabel);

	newLabel = new UILabel(SETTINGS_AIDIFFICULTY_LABEL, SETTINGS_AIDIFFICULTY_LABEL_ID);
	newLabel -> setCenterPosition(getWidth() * SETTINGS_AIDIFFICULTY_LABEL_PERCENTAGE_X, getHeight() * SETTINGS_AIDIFFICULTY_LABEL_PERCENTAGE_Y);
	addWidget(newLabel);

	newButton = new UIButton(SETTINGS_KEYBOARD_BUTTON, SETTINGS_PLAYER1_KEYBOARD_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * SETTINGS_PLAYER1_KEYBOARD_BUTTON_PERCENTAGE_X, getHeight() * SETTINGS_PLAYER1_KEYBOARD_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);
    
    UIToolTip* newToolTip = new UIToolTip(SETTINGS_PLAYER1_KEYBOARD_TOOL_TIP, SETTINGS_PLAYER1_TOOL_TIP_ID);
	newToolTip -> setCenterPosition(getWidth() * SETTINGS_PLAYER1_TOOL_TIP_PERCENTAGE_X, getHeight() * SETTINGS_PLAYER1_TOOL_TIP_PERCENTAGE_Y);
	newButton -> addToolTip(newToolTip);

	newButton = new UIButton(SETTINGS_MOUSE_BUTTON, SETTINGS_PLAYER1_MOUSE_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * SETTINGS_PLAYER1_MOUSE_BUTTON_PERCENTAGE_X, getHeight() * SETTINGS_PLAYER1_MOUSE_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);

	newButton = new UIButton(SETTINGS_AI_EASY_BUTTON, SETTINGS_AI_EASY_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * SETTINGS_AI_EASY_BUTTON_PERCENTAGE_X, getHeight() * SETTINGS_AI_EASY_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);

	newButton = new UIButton(SETTINGS_AI_NORMAL_BUTTON, SETTINGS_AI_NORMAL_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * SETTINGS_AI_NORMAL_BUTTON_PERCENTAGE_X, getHeight() * SETTINGS_AI_NORMAL_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);

	newButton = new UIButton(SETTINGS_AI_HARD_BUTTON, SETTINGS_AI_HARD_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * SETTINGS_AI_HARD_BUTTON_PERCENTAGE_X, getHeight() * SETTINGS_AI_HARD_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);

	newButton = new UIButton(SETTINGS_KEYBOARD_BUTTON, SETTINGS_PLAYER2_KEYBOARD_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * SETTINGS_PLAYER2_KEYBOARD_BUTTON_PERCENTAGE_X, getHeight() * SETTINGS_PLAYER2_KEYBOARD_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);
    
    newToolTip = new UIToolTip(SETTINGS_PLAYER2_KEYBOARD_TOOL_TIP, SETTINGS_PLAYER2_TOOL_TIP_ID);
	newToolTip -> setCenterPosition(getWidth() * SETTINGS_PLAYER2_TOOL_TIP_PERCENTAGE_X, getHeight() * SETTINGS_PLAYER2_TOOL_TIP_PERCENTAGE_Y);
	newButton -> addToolTip(newToolTip);

	newButton = new UIButton(SETTINGS_MOUSE_BUTTON, SETTINGS_PLAYER2_MOUSE_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * SETTINGS_PLAYER2_MOUSE_BUTTON_PERCENTAGE_X, getHeight() * SETTINGS_PLAYER2_MOUSE_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);

	newButton = new UIButton(SETTINGS_BACK_BUTTON, SETTINGS_BACK_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * SETTINGS_BACK_BUTTON_PERCENTAGE_X, getHeight() * SETTINGS_BACK_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);

	newButton = new UIButton(SETTINGS_START_GAME_BUTTON, SETTINGS_START_GAME_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * SETTINGS_START_GAME_BUTTON_PERCENTAGE_X, getHeight() * SETTINGS_START_GAME_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);

	newLabel = new UILabel(SETTINGS_TIME_LIMIT_LABEL, SETTINGS_TIME_LIMIT_LABEL_ID);
	newLabel -> setCenterPosition(getWidth() * SETTINGS_TIME_LIMIT_LABEL_PERCENTAGE_X, getHeight() * SETTINGS_TIME_LIMIT_LABEL_PERCENTAGE_Y);
	addWidget(newLabel);

	newButton = new UIButton(SETTINGS_UNLIMITED_BUTTON, SETTINGS_TIME_LIMIT_UNLIMITED_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * SETTINGS_TIME_LIMIT_UNLIMITED_BUTTON_PERCENTAGE_X, getHeight() * SETTINGS_TIME_LIMIT_UNLIMITED_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);

	newButton = new UIButton(SETTINGS_LOW_BUTTON, SETTINGS_TIME_LIMIT_LOW_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * SETTINGS_TIME_LIMIT_LOW_BUTTON_PERCENTAGE_X, getHeight() * SETTINGS_TIME_LIMIT_LOW_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);
    
    newToolTip = new UINumberToolTip(GAME_TIMER_SHORT, SETTINGS_LOW_TIMER_TOOL_TIP_ID, NUMBER_DISPLAY_TIME);
    newToolTip -> setCenterPosition(getWidth() * SETTINGS_LOW_TIMER_TOOL_TIP_PERCENTAGE_X, getHeight() * SETTINGS_LOW_TIMER_TOOL_TIP_PERCENTAGE_Y);
    newButton -> addToolTip(newToolTip);

	newButton = new UIButton(SETTINGS_MEDIUM_BUTTON, SETTINGS_TIME_LIMIT_NORMAL_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * SETTINGS_TIME_LIMIT_NORMAL_BUTTON_PERCENTAGE_X, getHeight() * SETTINGS_TIME_LIMIT_NORMAL_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);
    
    newToolTip = new UINumberToolTip(GAME_TIMER_AVERAGE, SETTINGS_MID_TIMER_TOOL_TIP_ID, NUMBER_DISPLAY_TIME);
    newToolTip -> setCenterPosition(getWidth() * SETTINGS_MID_TIMER_TOOL_TIP_PERCENTAGE_X, getHeight() * SETTINGS_MID_TIMER_TOOL_TIP_PERCENTAGE_Y);
    newButton -> addToolTip(newToolTip);

	newButton = new UIButton(SETTINGS_HIGH_BUTTON, SETTINGS_TIME_LIMIT_HIGH_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * SETTINGS_TIME_LIMIT_HIGH_BUTTON_PERCENTAGE_X, getHeight() * SETTINGS_TIME_LIMIT_HIGH_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);
    
    newToolTip = new UINumberToolTip(GAME_TIMER_LONG, SETTINGS_HIGH_TIMER_TOOL_TIP_ID, NUMBER_DISPLAY_TIME);
    newToolTip -> setCenterPosition(getWidth() * SETTINGS_HIGH_TIMER_TOOL_TIP_PERCENTAGE_X, getHeight() * SETTINGS_HIGH_TIMER_TOOL_TIP_PERCENTAGE_Y);
    newButton -> addToolTip(newToolTip);

	newLabel = new UILabel(SETTINGS_MAX_SCORE_LABEL, SETTINGS_MAX_SCORE_LABEL_ID);
	newLabel -> setCenterPosition(getWidth() * SETTINGS_MAX_SCORE_LABEL_PERCENTAGE_X, getHeight() * SETTINGS_MAX_SCORE_LABEL_PERCENTAGE_Y);
	addWidget(newLabel);

	newButton = new UIButton(SETTINGS_UNLIMITED_BUTTON, SETTINGS_MAX_SCORE_UNLIMITED_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * SETTINGS_MAX_SCORE_UNLIMITED_BUTTON_PERCENTAGE_X, getHeight() * SETTINGS_MAX_SCORE_UNLIMITED_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);

	newButton = new UIButton(SETTINGS_LOW_BUTTON, SETTINGS_MAX_SCORE_LOW_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * SETTINGS_MAX_SCORE_LOW_BUTTON_PERCENTAGE_X, getHeight() * SETTINGS_MAX_SCORE_LOW_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);
    
    newToolTip = new UINumberToolTip(GAME_MAX_SCORE_LOW, SETTINGS_LOW_SCORE_TOOL_TIP_ID);
    newToolTip -> setCenterPosition(getWidth() * SETTINGS_LOW_SCORE_TOOL_TIP_PERCENTAGE_X, getHeight() * SETTINGS_LOW_SCORE_TOOL_TIP_PERCENTAGE_Y);
    newButton -> addToolTip(newToolTip);

	newButton = new UIButton(SETTINGS_MEDIUM_BUTTON, SETTINGS_MAX_SCORE_NORMAL_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * SETTINGS_MAX_SCORE_NORMAL_BUTTON_PERCENTAGE_X, getHeight() * SETTINGS_MAX_SCORE_NORMAL_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);
    
    newToolTip = new UINumberToolTip(GAME_MAX_SCORE_MEDIUM, SETTINGS_MID_SCORE_TOOL_TIP_ID);
    newToolTip -> setCenterPosition(getWidth() * SETTINGS_MID_SCORE_TOOL_TIP_PERCENTAGE_X, getHeight() * SETTINGS_MID_SCORE_TOOL_TIP_PERCENTAGE_Y);
    newButton -> addToolTip(newToolTip);

	newButton = new UIButton(SETTINGS_HIGH_BUTTON, SETTINGS_MAX_SCORE_HIGH_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * SETTINGS_MAX_SCORE_HIGH_BUTTON_PERCENTAGE_X, getHeight() * SETTINGS_MAX_SCORE_HIGH_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);
	
    newToolTip = new UINumberToolTip(GAME_MAX_SCORE_HIGH, SETTINGS_HIGH_SCORE_TOOL_TIP_ID);
    newToolTip -> setCenterPosition(getWidth() * SETTINGS_HIGH_SCORE_TOOL_TIP_PERCENTAGE_X, getHeight() * SETTINGS_HIGH_SCORE_TOOL_TIP_PERCENTAGE_Y);
    newButton -> addToolTip(newToolTip);	
	
	m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_SINGLE_PLAYER_BUTTON_ID);
	m_CurrentButton -> setIsHovered(true);

	newButton = NULL;
	newLabel = NULL;
    newToolTip = NULL;

	resetButtons();
}

Settings::~Settings()
{
	
}

const char* Settings::getName()
{
    return SETTINGS_SCREEN_NAME;
}

void Settings::keyUpEvent(int aKeyCode)
{
	if(aKeyCode == KEYCODE_RETURN)
	{
		if(m_CurrentButton != NULL)
		{
			m_CurrentButton -> keyUpEvent(aKeyCode);
		}
	}
	else if(aKeyCode == KEYCODE_DOWN_ARROW)
	{
		if(m_CurrentButton != NULL)
		{
			m_CurrentButton -> setIsHovered(false);

			if(m_CurrentButton -> getID() == SETTINGS_SINGLE_PLAYER_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER1_KEYBOARD_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_PLAYER1_KEYBOARD_BUTTON_ID)
			{
				if(((UIButton*)getWidgetWithID(SETTINGS_PLAYER1_MOUSE_BUTTON_ID)) -> getIsGreyed())
				{
					m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_MAX_SCORE_UNLIMITED_BUTTON_ID);
				}
				else
				{
					m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER1_MOUSE_BUTTON_ID);
				}
			}
			else if(m_CurrentButton -> getID() == SETTINGS_PLAYER1_MOUSE_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_MAX_SCORE_UNLIMITED_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_MAX_SCORE_UNLIMITED_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_MAX_SCORE_LOW_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_MAX_SCORE_LOW_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_MAX_SCORE_NORMAL_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_MAX_SCORE_NORMAL_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_MAX_SCORE_HIGH_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_MAX_SCORE_HIGH_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_SINGLE_PLAYER_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_TWO_PLAYERS_BUTTON_ID)
			{
				if(GameData::getInstance() -> getNumberOfPlayers() == 1)
				{
					m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_AI_EASY_BUTTON_ID);
				}
				else
				{
					m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER2_KEYBOARD_BUTTON_ID);
				}
			}
			else if(m_CurrentButton -> getID() == SETTINGS_PLAYER2_KEYBOARD_BUTTON_ID)
			{
				if(((UIButton*)getWidgetWithID(SETTINGS_PLAYER2_MOUSE_BUTTON_ID)) -> getIsGreyed())
				{
					m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_TIME_LIMIT_UNLIMITED_BUTTON_ID);
				}
				else
				{
					m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER2_MOUSE_BUTTON_ID);
				}
			}
			else if(m_CurrentButton -> getID() == SETTINGS_PLAYER2_MOUSE_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_TIME_LIMIT_UNLIMITED_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_AI_EASY_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_AI_NORMAL_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_AI_NORMAL_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_AI_HARD_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_AI_HARD_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_TIME_LIMIT_UNLIMITED_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_TIME_LIMIT_UNLIMITED_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_TIME_LIMIT_LOW_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_TIME_LIMIT_LOW_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_TIME_LIMIT_NORMAL_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_TIME_LIMIT_NORMAL_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_TIME_LIMIT_HIGH_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_TIME_LIMIT_HIGH_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_SINGLE_PLAYER_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_START_GAME_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_BACK_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_BACK_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_TWO_PLAYERS_BUTTON_ID);
			}
		}
		else
		{
			m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_SINGLE_PLAYER_BUTTON_ID);
		}
		
		m_CurrentButton -> setIsHovered(true);
	}
	else if(aKeyCode == KEYCODE_UP_ARROW)
	{
		if(m_CurrentButton != NULL)
		{
			m_CurrentButton -> setIsHovered(false);

			if(m_CurrentButton -> getID() == SETTINGS_SINGLE_PLAYER_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_MAX_SCORE_HIGH_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_PLAYER1_KEYBOARD_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_SINGLE_PLAYER_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_PLAYER1_MOUSE_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER1_KEYBOARD_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_MAX_SCORE_UNLIMITED_BUTTON_ID)
			{
				if(((UIButton*)getWidgetWithID(SETTINGS_PLAYER1_MOUSE_BUTTON_ID)) ->getIsGreyed())
				{
					m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER1_KEYBOARD_BUTTON_ID);
				}
				else
				{
					m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER1_MOUSE_BUTTON_ID);
				}
			}
			else if(m_CurrentButton -> getID() == SETTINGS_MAX_SCORE_LOW_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_MAX_SCORE_UNLIMITED_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_MAX_SCORE_NORMAL_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_MAX_SCORE_LOW_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_MAX_SCORE_HIGH_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_MAX_SCORE_NORMAL_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_TWO_PLAYERS_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_BACK_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_PLAYER2_KEYBOARD_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_TWO_PLAYERS_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_PLAYER2_MOUSE_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER2_KEYBOARD_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_AI_EASY_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_TWO_PLAYERS_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_AI_NORMAL_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_AI_EASY_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_AI_HARD_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_AI_NORMAL_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_TIME_LIMIT_UNLIMITED_BUTTON_ID)
			{
				if(GameData::getInstance() -> getNumberOfPlayers() == 1)
				{
					m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_AI_HARD_BUTTON_ID);
				}
				else
				{
					if(((UIButton*)getWidgetWithID(SETTINGS_PLAYER2_MOUSE_BUTTON_ID)) -> getIsGreyed())
					{
						m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER2_KEYBOARD_BUTTON_ID);
					}
					else
					{
						m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER2_MOUSE_BUTTON_ID);
					}
				}
			}
			else if(m_CurrentButton -> getID() == SETTINGS_TIME_LIMIT_LOW_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_TIME_LIMIT_UNLIMITED_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_TIME_LIMIT_NORMAL_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_TIME_LIMIT_LOW_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_TIME_LIMIT_HIGH_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_TIME_LIMIT_NORMAL_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_START_GAME_BUTTON_ID)
			{
				if(GameData::getInstance() -> getNumberOfPlayers() == 1)
				{
					m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_AI_HARD_BUTTON_ID);
				}
				else
				{
					if(((UIButton*)getWidgetWithID(SETTINGS_PLAYER2_MOUSE_BUTTON_ID)) -> getIsGreyed())
					{
						m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER2_KEYBOARD_BUTTON_ID);
					}
					else
					{
						m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER2_MOUSE_BUTTON_ID);
					}
				}
			}
			else if(m_CurrentButton -> getID() == SETTINGS_BACK_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_START_GAME_BUTTON_ID);
			}
		}
		else
		{
			m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_SINGLE_PLAYER_BUTTON_ID);
		}
		
		m_CurrentButton -> setIsHovered(true);
	}
	else if(aKeyCode == KEYCODE_RIGHT_ARROW)
	{
		if(m_CurrentButton != NULL)
		{
			m_CurrentButton -> setIsHovered(false);

			if(m_CurrentButton -> getID() == SETTINGS_SINGLE_PLAYER_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_TWO_PLAYERS_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_PLAYER1_KEYBOARD_BUTTON_ID)
			{
				if(GameData::getInstance() -> getNumberOfPlayers() == 1)
				{
					m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_AI_EASY_BUTTON_ID);
				}
				else
				{
					m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER2_KEYBOARD_BUTTON_ID);
				}
			}
			else if(m_CurrentButton -> getID() == SETTINGS_PLAYER1_MOUSE_BUTTON_ID)
			{
				if(GameData::getInstance() -> getNumberOfPlayers() == 1)
				{
					m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_AI_NORMAL_BUTTON_ID);
				}
				else
				{
					if(((UIButton*)getWidgetWithID(SETTINGS_PLAYER2_MOUSE_BUTTON_ID)) -> getIsGreyed())
					{
						m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER2_KEYBOARD_BUTTON_ID);
					}
					else
					{
						m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER2_MOUSE_BUTTON_ID);
					}
				}
			}
			else if(m_CurrentButton -> getID() == SETTINGS_MAX_SCORE_UNLIMITED_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_TIME_LIMIT_UNLIMITED_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_MAX_SCORE_LOW_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_TIME_LIMIT_LOW_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_MAX_SCORE_NORMAL_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_TIME_LIMIT_NORMAL_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_MAX_SCORE_HIGH_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_TIME_LIMIT_HIGH_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_TWO_PLAYERS_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_SINGLE_PLAYER_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_PLAYER2_KEYBOARD_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER1_KEYBOARD_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_PLAYER2_MOUSE_BUTTON_ID)
			{
				if(((UIButton*)getWidgetWithID(SETTINGS_PLAYER1_MOUSE_BUTTON_ID)) -> getIsGreyed())
				{
					m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER1_KEYBOARD_BUTTON_ID);
				}
				else
				{
					m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER1_MOUSE_BUTTON_ID);
				}
			}
			else if(m_CurrentButton -> getID() == SETTINGS_AI_EASY_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER1_KEYBOARD_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_AI_NORMAL_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER1_MOUSE_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_AI_HARD_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER1_MOUSE_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_TIME_LIMIT_UNLIMITED_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_START_GAME_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_TIME_LIMIT_LOW_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_START_GAME_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_TIME_LIMIT_NORMAL_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_BACK_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_TIME_LIMIT_HIGH_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_BACK_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_START_GAME_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_MAX_SCORE_LOW_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_BACK_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_MAX_SCORE_HIGH_BUTTON_ID);
			}
		}
		else
		{
			m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_SINGLE_PLAYER_BUTTON_ID);
		}
		
		m_CurrentButton -> setIsHovered(true);
	}
	else if(aKeyCode == KEYCODE_LEFT_ARROW)
	{
		if(m_CurrentButton != NULL)
		{
			m_CurrentButton -> setIsHovered(false);

			if(m_CurrentButton -> getID() == SETTINGS_SINGLE_PLAYER_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_TWO_PLAYERS_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_PLAYER1_KEYBOARD_BUTTON_ID)
			{
				if(GameData::getInstance() -> getNumberOfPlayers() == 1)
				{
					m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_AI_EASY_BUTTON_ID);
				}
				else
				{
					m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER2_KEYBOARD_BUTTON_ID);
				}
			}
			else if(m_CurrentButton -> getID() == SETTINGS_PLAYER1_MOUSE_BUTTON_ID)
			{
				if(GameData::getInstance() -> getNumberOfPlayers() == 1)
				{
					m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_AI_NORMAL_BUTTON_ID);
				}
				else
				{
					if(((UIButton*)getWidgetWithID(SETTINGS_PLAYER2_MOUSE_BUTTON_ID)) -> getIsGreyed())
					{
						m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER2_KEYBOARD_BUTTON_ID);
					}
					else
					{
						m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER2_MOUSE_BUTTON_ID);
					}
				}
			}
			else if(m_CurrentButton -> getID() == SETTINGS_MAX_SCORE_UNLIMITED_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_START_GAME_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_MAX_SCORE_LOW_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_START_GAME_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_MAX_SCORE_NORMAL_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_BACK_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_MAX_SCORE_HIGH_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_BACK_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_TWO_PLAYERS_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_SINGLE_PLAYER_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_PLAYER2_KEYBOARD_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER1_KEYBOARD_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_PLAYER2_MOUSE_BUTTON_ID)
			{
				if(((UIButton*)getWidgetWithID(SETTINGS_PLAYER1_MOUSE_BUTTON_ID)) -> getIsGreyed())
				{
					m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER1_KEYBOARD_BUTTON_ID);
				}
				else
				{
					m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER1_MOUSE_BUTTON_ID);
				}
			}
			else if(m_CurrentButton -> getID() == SETTINGS_AI_EASY_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER1_KEYBOARD_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_AI_NORMAL_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER1_MOUSE_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_AI_HARD_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_PLAYER1_MOUSE_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_TIME_LIMIT_UNLIMITED_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_MAX_SCORE_UNLIMITED_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_TIME_LIMIT_LOW_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_MAX_SCORE_LOW_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_TIME_LIMIT_NORMAL_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_MAX_SCORE_NORMAL_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_TIME_LIMIT_HIGH_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_MAX_SCORE_HIGH_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_START_GAME_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_TIME_LIMIT_LOW_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == SETTINGS_BACK_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_TIME_LIMIT_HIGH_BUTTON_ID);
			}
		}
		else
		{
			m_CurrentButton = (UIButton*)getWidgetWithID(SETTINGS_SINGLE_PLAYER_BUTTON_ID);
		}
		
		m_CurrentButton -> setIsHovered(true);
	}
}

void Settings::buttonSelectedEvent(UIButton* buttonSelected)
{
	int selectedID = buttonSelected -> getID();

	if(selectedID == SETTINGS_SINGLE_PLAYER_BUTTON_ID)
	{
		GameData::getInstance() -> setNumberOfPlayers(1);
	}
	else if(selectedID == SETTINGS_TWO_PLAYERS_BUTTON_ID)
	{
		GameData::getInstance() -> setNumberOfPlayers(2);
	}
	else if(selectedID == SETTINGS_PLAYER1_KEYBOARD_BUTTON_ID)
	{
		GameData::getInstance() -> setPlayer1Input(GAME_KEYBOARD_INPUT);
	}
	else if(selectedID == SETTINGS_PLAYER1_MOUSE_BUTTON_ID)
	{
		GameData::getInstance() -> setPlayer1Input(GAME_MOUSE_INPUT);
	}
	else if(selectedID == SETTINGS_PLAYER2_KEYBOARD_BUTTON_ID)
	{
		GameData::getInstance() -> setPlayer2Input(GAME_KEYBOARD_INPUT);
	}
	else if(selectedID == SETTINGS_PLAYER2_MOUSE_BUTTON_ID)
	{
		GameData::getInstance() -> setPlayer2Input(GAME_MOUSE_INPUT);
	}
	else if(selectedID == SETTINGS_AI_EASY_BUTTON_ID)
	{
		GameData::getInstance() -> setAIDifficulty(GAME_AI_EASY);
	}
	else if(selectedID == SETTINGS_AI_NORMAL_BUTTON_ID)
	{
		GameData::getInstance() -> setAIDifficulty(GAME_AI_NORMAL);
	}
	else if(selectedID == SETTINGS_AI_HARD_BUTTON_ID)
	{
		GameData::getInstance() -> setAIDifficulty(GAME_AI_HARD);
	}
	else if(selectedID == SETTINGS_MAX_SCORE_UNLIMITED_BUTTON_ID)
	{
		GameData::getInstance() -> setGoalTarget(GAME_MAX_SCORE_UNLIMITED);
	}
	else if(selectedID == SETTINGS_MAX_SCORE_LOW_BUTTON_ID)
	{
		GameData::getInstance() -> setGoalTarget(GAME_MAX_SCORE_LOW);
	}
	else if(selectedID == SETTINGS_MAX_SCORE_NORMAL_BUTTON_ID)
	{
		GameData::getInstance() -> setGoalTarget(GAME_MAX_SCORE_MEDIUM);
	}
	else if(selectedID == SETTINGS_MAX_SCORE_HIGH_BUTTON_ID)
	{
		GameData::getInstance() -> setGoalTarget(GAME_MAX_SCORE_HIGH);
	}
	else if(selectedID == SETTINGS_TIME_LIMIT_UNLIMITED_BUTTON_ID)
	{
		GameData::getInstance() -> setGameTimer(GAME_TIMER_INFINITE);
		GameData::getInstance() -> setResetTimer(true);
	}
	else if(selectedID == SETTINGS_TIME_LIMIT_LOW_BUTTON_ID)
	{
		GameData::getInstance() -> setGameTimer(GAME_TIMER_SHORT);
		GameData::getInstance() -> setResetTimer(true);
	}
	else if(selectedID == SETTINGS_TIME_LIMIT_NORMAL_BUTTON_ID)
	{
		GameData::getInstance() -> setGameTimer(GAME_TIMER_AVERAGE);
		GameData::getInstance() -> setResetTimer(true);
	}
	else if(selectedID == SETTINGS_TIME_LIMIT_HIGH_BUTTON_ID)
	{
		GameData::getInstance() -> setGameTimer(GAME_TIMER_LONG);
		GameData::getInstance() -> setResetTimer(true);
	}
	else if(selectedID == SETTINGS_START_GAME_BUTTON_ID)
	{
		GameData::getInstance() -> setResetGame(true);
		buttonSelected -> setIsSelected(false);
		ScreenManager::getInstance() -> switchScreen(GAME_SCREEN_NAME);
	}
	else if(selectedID == SETTINGS_BACK_BUTTON_ID)
	{
		buttonSelected -> setIsSelected(false);
		ScreenManager::getInstance() -> goBack();
	}

	resetButtons();
}

void Settings::setPlayer1Input()
{
	if(GameData::getInstance() -> getPlayer1Input() == GAME_KEYBOARD_INPUT)
	{
		((UIButton*)getWidgetWithID(SETTINGS_PLAYER1_KEYBOARD_BUTTON_ID)) -> setIsSelected(true);
		((UIButton*)getWidgetWithID(SETTINGS_PLAYER1_MOUSE_BUTTON_ID)) -> setIsSelected(false);
	}
	else if(GameData::getInstance() -> getPlayer1Input() == GAME_MOUSE_INPUT)
	{
		((UIButton*)getWidgetWithID(SETTINGS_PLAYER1_KEYBOARD_BUTTON_ID)) -> setIsSelected(false);
		((UIButton*)getWidgetWithID(SETTINGS_PLAYER1_MOUSE_BUTTON_ID)) -> setIsSelected(true);
	}
}

void Settings::setPlayer2IsGreyed(bool isGreyed)
{	
	((UILabel*)getWidgetWithID(SETTINGS_PLAYER2_LABEL_ID)) -> setIsGreyed(isGreyed);
	((UIButton*)getWidgetWithID(SETTINGS_PLAYER2_KEYBOARD_BUTTON_ID)) -> setIsGreyed(isGreyed);
	((UIButton*)getWidgetWithID(SETTINGS_PLAYER2_MOUSE_BUTTON_ID)) -> setIsGreyed(isGreyed);	
	
	if(isGreyed)
	{
		((UIButton*)getWidgetWithID(SETTINGS_PLAYER1_MOUSE_BUTTON_ID)) -> setIsGreyed(false);
	}
	else
	{
		if(GameData::getInstance() -> getPlayer1Input() == GAME_MOUSE_INPUT)
		{
			((UIButton*)getWidgetWithID(SETTINGS_PLAYER2_MOUSE_BUTTON_ID)) -> setIsGreyed(true);
		}

		if(GameData::getInstance() -> getPlayer2Input() == GAME_KEYBOARD_INPUT)
		{
			((UIButton*)getWidgetWithID(SETTINGS_PLAYER2_MOUSE_BUTTON_ID)) -> setIsSelected(false);
			((UIButton*)getWidgetWithID(SETTINGS_PLAYER2_KEYBOARD_BUTTON_ID)) -> setIsSelected(true);
			((UIButton*)getWidgetWithID(SETTINGS_PLAYER1_MOUSE_BUTTON_ID)) -> setIsGreyed(false);
		}
		else if(GameData::getInstance() -> getPlayer2Input() == GAME_MOUSE_INPUT)
		{			
			((UIButton*)getWidgetWithID(SETTINGS_PLAYER2_KEYBOARD_BUTTON_ID)) -> setIsSelected(false);
			((UIButton*)getWidgetWithID(SETTINGS_PLAYER2_MOUSE_BUTTON_ID)) -> setIsSelected(true);
			((UIButton*)getWidgetWithID(SETTINGS_PLAYER1_MOUSE_BUTTON_ID)) -> setIsGreyed(true);
		}
	}
}

void Settings::setAIIsGreyed(bool isGreyed)
{	
	((UILabel*)getWidgetWithID(SETTINGS_AIDIFFICULTY_LABEL_ID)) -> setIsGreyed(isGreyed);
	((UIButton*)getWidgetWithID(SETTINGS_AI_EASY_BUTTON_ID)) -> setIsGreyed(isGreyed);
	((UIButton*)getWidgetWithID(SETTINGS_AI_NORMAL_BUTTON_ID)) -> setIsGreyed(isGreyed);
	((UIButton*)getWidgetWithID(SETTINGS_AI_HARD_BUTTON_ID)) -> setIsGreyed(isGreyed);	

	if(GameData::getInstance() -> getAIDifficulty() == GAME_AI_EASY)
	{
		((UIButton*)getWidgetWithID(SETTINGS_AI_EASY_BUTTON_ID)) -> setIsSelected(true);
	}
	else if(GameData::getInstance() -> getAIDifficulty() == GAME_AI_NORMAL)
	{
		((UIButton*)getWidgetWithID(SETTINGS_AI_NORMAL_BUTTON_ID)) -> setIsSelected(true);
	}
	else if(GameData::getInstance() -> getAIDifficulty() == GAME_AI_HARD)
	{
		((UIButton*)getWidgetWithID(SETTINGS_AI_HARD_BUTTON_ID)) -> setIsSelected(true);
	}
}

void Settings::setGreyed()
{
	if(GameData::getInstance() -> getNumberOfPlayers() == 1)
	{
		((UIButton*)getWidgetWithID(SETTINGS_SINGLE_PLAYER_BUTTON_ID)) -> setIsSelected(true);
		((UIButton*)getWidgetWithID(SETTINGS_TWO_PLAYERS_BUTTON_ID)) -> setIsSelected(false);

		setAIIsGreyed(false);
		setPlayer2IsGreyed(true);
	}
	else
	{
		((UIButton*)getWidgetWithID(SETTINGS_SINGLE_PLAYER_BUTTON_ID)) -> setIsSelected(false);
		((UIButton*)getWidgetWithID(SETTINGS_TWO_PLAYERS_BUTTON_ID)) -> setIsSelected(true);

		setAIIsGreyed(true);
		setPlayer2IsGreyed(false);
	}
}

void Settings::setMaxScoreSelected()
{
	if(GameData::getInstance() -> getGoalTarget() == GAME_MAX_SCORE_UNLIMITED)
	{
		((UIButton*)getWidgetWithID(SETTINGS_MAX_SCORE_UNLIMITED_BUTTON_ID)) -> setIsSelected(true);
	}
	else if(GameData::getInstance() -> getGoalTarget() == GAME_MAX_SCORE_LOW)
	{
		((UIButton*)getWidgetWithID(SETTINGS_MAX_SCORE_LOW_BUTTON_ID)) -> setIsSelected(true);
	}
	else if(GameData::getInstance() -> getGoalTarget() == GAME_MAX_SCORE_MEDIUM)
	{
		((UIButton*)getWidgetWithID(SETTINGS_MAX_SCORE_NORMAL_BUTTON_ID)) -> setIsSelected(true);
	}
	else if(GameData::getInstance() -> getGoalTarget() == GAME_MAX_SCORE_HIGH)
	{
		((UIButton*)getWidgetWithID(SETTINGS_MAX_SCORE_HIGH_BUTTON_ID)) -> setIsSelected(true);
	}
}

void Settings::setTimeLimitSelected()
{
	if(GameData::getInstance() -> getGameTimer() == GAME_TIMER_INFINITE)
	{
		((UIButton*)getWidgetWithID(SETTINGS_TIME_LIMIT_UNLIMITED_BUTTON_ID)) -> setIsSelected(true);
	}
	else if(GameData::getInstance() -> getGameTimer() == GAME_TIMER_SHORT)
	{
		((UIButton*)getWidgetWithID(SETTINGS_TIME_LIMIT_LOW_BUTTON_ID)) -> setIsSelected(true);
	}	
	else if(GameData::getInstance() -> getGameTimer() == GAME_TIMER_AVERAGE)
	{
		((UIButton*)getWidgetWithID(SETTINGS_TIME_LIMIT_NORMAL_BUTTON_ID)) -> setIsSelected(true);
	}
	else if(GameData::getInstance() -> getGameTimer() == GAME_TIMER_LONG)
	{
		((UIButton*)getWidgetWithID(SETTINGS_TIME_LIMIT_HIGH_BUTTON_ID)) -> setIsSelected(true);
	}
}

void Settings::resetButtons()
{
	for(int i = 0; i < getWidgets().size(); i++)
	{
		if(dynamic_cast<UIButton*>(getWidgets().at(i)) != NULL)
		{
			dynamic_cast<UIButton*>(getWidgets().at(i)) -> setIsSelected(false);
		}
	}
	
	setGreyed();

	setMaxScoreSelected();
	setTimeLimitSelected();

	setPlayer1Input();
}