//
//  Student:        Quentin Bellay
//  Creation Date:  October 11th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the Splash screen
//  Modified:       
//

#ifndef __GAM_1514_OSX_Game__Splash__
#define __GAM_1514_OSX_Game__Splash__

#include "BaseMenuScreen.h"

// Splash represents the splash screen, inherits BaseMenuScreen to display the unfiltered background
class Splash : public BaseMenuScreen
{
public:
    Splash();
    ~Splash();
    
    const char* getName();
    
    void update(double delta);
    void paint();    
    
    void keyUpEvent(int keyCode);

protected:
	void buttonSelectedEvent(UIButton* buttonSelected);
};

#endif /* defined(__GAM_1514_OSX_Game__Splash__) */
