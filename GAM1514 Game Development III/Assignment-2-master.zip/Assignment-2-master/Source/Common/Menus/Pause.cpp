//
//  Student:        Quentin Bellay
//  Creation Date:  October 14th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the Pause screen
//  Modified:       
//

#include "Pause.h"
#include "../Constants/Constants.h"
#include "../Screen Manager/ScreenManager.h"
#include "../Game/GameData.h"

Pause::Pause()
{
	UIButton* newButton = new UIButton(PAUSE_RESUME, PAUSE_RESUME_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * PAUSE_RESUME_BUTTON_PERCENTAGE_X, getHeight() * PAUSE_RESUME_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);

	newButton = new UIButton(PAUSE_RESTART, PAUSE_RESTART_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * PAUSE_RESTART_BUTTON_PERCENTAGE_X, getHeight() * PAUSE_RESTART_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);

	newButton = new UIButton(PAUSE_SETTINGS, PAUSE_SETTINGS_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * PAUSE_SETTINGS_BUTTON_PERCENTAGE_X, getHeight() * PAUSE_SETTINGS_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);

	newButton = new UIButton(PAUSE_MAIN_MENU, PAUSE_MAIN_MENU_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * PAUSE_MAIN_MENU_BUTTON_PERCENTAGE_X, getHeight() * PAUSE_MAIN_MENU_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);

	UILabel* newLabel = new UILabel(PAUSE_LABEL, PAUSE_LABEL_ID);
	newLabel -> setCenterPosition(getWidth() * PAUSE_LABEL_PERCENTAGE_X, getHeight() * PAUSE_LABEL_PERCENTAGE_Y);
	addWidget(newLabel);

	m_CurrentButton = (UIButton*)getWidgetWithID(PAUSE_RESUME_BUTTON_ID);
	m_CurrentButton -> setIsHovered(true);

	newButton = NULL;
	newLabel = NULL;
}

Pause::~Pause()
{
	
}
    
const char* Pause::getName()
{
	return PAUSE_SCREEN_NAME;
}
    
void Pause::keyUpEvent(int keyCode)
{
    if(keyCode == KEYCODE_ESCAPE)
    {
        ScreenManager::getInstance() -> switchScreen(GAME_SCREEN_NAME);
    }
	else if(keyCode == KEYCODE_RETURN)
	{
		if(m_CurrentButton != NULL)
		{
			m_CurrentButton -> keyUpEvent(keyCode);
		}
	}
	else if(keyCode == KEYCODE_DOWN_ARROW)
	{
		if(m_CurrentButton == NULL)
		{
			m_CurrentButton = (UIButton*)getWidgetWithID(PAUSE_RESUME_BUTTON_ID);
		}
		else
		{
			m_CurrentButton -> setIsHovered(false);

			if(m_CurrentButton -> getID() == PAUSE_RESUME_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(PAUSE_RESTART_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == PAUSE_RESTART_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(PAUSE_SETTINGS_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == PAUSE_SETTINGS_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(PAUSE_MAIN_MENU_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == PAUSE_MAIN_MENU_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(PAUSE_RESUME_BUTTON_ID);
			}
		}

		m_CurrentButton -> setIsHovered(true);
	}
	else if(keyCode == KEYCODE_UP_ARROW)
	{
		if(m_CurrentButton == NULL)
		{
			m_CurrentButton = (UIButton*)getWidgetWithID(PAUSE_RESUME_BUTTON_ID);
		}
		else
		{
			m_CurrentButton -> setIsHovered(false);

			if(m_CurrentButton -> getID() == PAUSE_RESUME_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(PAUSE_MAIN_MENU_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == PAUSE_RESTART_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(PAUSE_RESUME_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == PAUSE_SETTINGS_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(PAUSE_RESTART_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == PAUSE_MAIN_MENU_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(PAUSE_SETTINGS_BUTTON_ID);
			}
		}

		m_CurrentButton -> setIsHovered(true);
	}
}

void Pause::buttonSelectedEvent(UIButton* buttonSelected)
{
	if(buttonSelected -> getID() == PAUSE_RESUME_BUTTON_ID)
	{
		buttonSelected -> setIsSelected(false);
		ScreenManager::getInstance() ->switchScreen(GAME_SCREEN_NAME);
	}
	else if(buttonSelected -> getID() == PAUSE_RESTART_BUTTON_ID)
	{
		buttonSelected -> setIsSelected(false);
		GameData::getInstance() -> setResetGame(true);
		ScreenManager::getInstance() ->switchScreen(GAME_SCREEN_NAME);
	}
	else if(buttonSelected -> getID() == PAUSE_SETTINGS_BUTTON_ID)
	{
		buttonSelected -> setIsSelected(false);
		ScreenManager::getInstance() ->switchScreen(SETTINGS_SCREEN_NAME);
	}
	else if(buttonSelected -> getID() == PAUSE_MAIN_MENU_BUTTON_ID)
	{
		buttonSelected -> setIsSelected(false);
		GameData::getInstance() -> setResetGame(true);
		ScreenManager::getInstance() ->switchScreen(MAIN_MENU_SCREEN_NAME);
	}
}