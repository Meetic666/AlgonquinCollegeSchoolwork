//
//  Student:        Quentin Bellay
//  Creation Date:  October 11th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the Main Menu screen
//  Modified:       
//

#include "MainMenu.h"
#include "../Constants/Constants.h"
#include "../Screen Manager/ScreenManager.h"

MainMenu::MainMenu()
{
	UILabel* newLabel = new UILabel(MAIN_MENU_LABEL, MAIN_MENU_LABEL_ID);
	newLabel -> setCenterPosition(getWidth() * MAIN_MENU_LABEL_PERCENTAGE_X, getHeight() * MAIN_MENU_LABEL_PERCENTAGE_Y);
	addWidget(newLabel);

	UIButton* newButton = new UIButton(MAIN_MENU_NEW_GAME, MAIN_MENU_NEW_GAME_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * MAIN_MENU_NEW_GAME_BUTTON_PERCENTAGE_X, getHeight() * MAIN_MENU_NEW_GAME_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);

	newButton = new UIButton(MAIN_MENU_CREDITS, MAIN_MENU_CREDITS_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * MAIN_MENU_CREDITS_BUTTON_PERCENTAGE_X, getHeight() * MAIN_MENU_CREDITS_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);

	newButton = new UIButton(MAIN_MENU_EXIT, MAIN_MENU_EXIT_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * MAIN_MENU_EXIT_BUTTON_PERCENTAGE_X, getHeight() * MAIN_MENU_EXIT_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);

	m_CurrentButton = (UIButton*)getWidgetWithID(MAIN_MENU_NEW_GAME_BUTTON_ID);
	m_CurrentButton -> setIsHovered(true);

	newLabel = NULL;
	newButton = NULL;
}

MainMenu::~MainMenu()
{
	
}
    
const char* MainMenu::getName()
{
	return MAIN_MENU_SCREEN_NAME;
}
    
void MainMenu::keyUpEvent(int keyCode)
{
	if(keyCode == KEYCODE_RETURN)
	{
		if(m_CurrentButton != NULL)
		{
			m_CurrentButton -> keyUpEvent(keyCode);
		}
	}
	else if(keyCode == KEYCODE_DOWN_ARROW)
	{
		if(m_CurrentButton == NULL)
		{
			m_CurrentButton = (UIButton*)getWidgetWithID(MAIN_MENU_NEW_GAME_BUTTON_ID);
		}
		else
		{
			m_CurrentButton -> setIsHovered(false);

			if(m_CurrentButton -> getID() == MAIN_MENU_NEW_GAME_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(MAIN_MENU_CREDITS_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == MAIN_MENU_CREDITS_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(MAIN_MENU_EXIT_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == MAIN_MENU_EXIT_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(MAIN_MENU_NEW_GAME_BUTTON_ID);
			}
		}

		m_CurrentButton -> setIsHovered(true);
	}
	else if(keyCode == KEYCODE_UP_ARROW)
	{
		if(m_CurrentButton == NULL)
		{
			m_CurrentButton = (UIButton*)getWidgetWithID(MAIN_MENU_NEW_GAME_BUTTON_ID);
		}
		else
		{
			m_CurrentButton -> setIsHovered(false);

			if(m_CurrentButton -> getID() == MAIN_MENU_NEW_GAME_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(MAIN_MENU_EXIT_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == MAIN_MENU_CREDITS_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(MAIN_MENU_NEW_GAME_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == MAIN_MENU_EXIT_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(MAIN_MENU_CREDITS_BUTTON_ID);
			}
		}

		m_CurrentButton -> setIsHovered(true);
	}
}

void MainMenu::buttonSelectedEvent(UIButton* buttonSelected)
{
	if(buttonSelected -> getID() == MAIN_MENU_NEW_GAME_BUTTON_ID)
	{
		buttonSelected -> setIsSelected(false);
		ScreenManager::getInstance() -> switchScreen(SETTINGS_SCREEN_NAME);
	}
	else if(buttonSelected -> getID() == MAIN_MENU_CREDITS_BUTTON_ID)
	{
		buttonSelected -> setIsSelected(false);
		ScreenManager::getInstance() -> switchScreen(CREDITS_SCREEN_NAME);
	}
	else if(buttonSelected -> getID() == MAIN_MENU_EXIT_BUTTON_ID)
	{
        buttonSelected -> setIsSelected(false);
		exit(1);
	}
}