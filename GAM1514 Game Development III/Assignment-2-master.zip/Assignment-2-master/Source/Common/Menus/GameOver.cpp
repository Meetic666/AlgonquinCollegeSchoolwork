//
//  Student:        Quentin Bellay
//  Creation Date:  October 11th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the Game Over screen
//  Modified:       
//

#include "GameOver.h"
#include "../Constants/Constants.h"
#include "../Screen Manager/ScreenManager.h"
#include "../Game/GameData.h"

GameOver::GameOver()
{
	UIButton* newButton = new UIButton(GAME_OVER_RESTART, GAME_OVER_RESTART_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * GAME_OVER_RESTART_BUTTON_PERCENTAGE_X, getHeight() * GAME_OVER_RESTART_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);

	newButton = new UIButton(GAME_OVER_MAIN_MENU, GAME_OVER_MAIN_MENU_BUTTON_ID);
	newButton -> setCenterPosition(getWidth() * GAME_OVER_MAIN_MENU_BUTTON_PERCENTAGE_X, getHeight() * GAME_OVER_MAIN_MENU_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);

	UILabel* newLabel = new UILabel(GAME_OVER_LABEL, GAME_OVER_LABEL_ID);
	newLabel -> setCenterPosition(getWidth() * GAME_OVER_LABEL_PERCENTAGE_X, getHeight() * GAME_OVER_LABEL_PERCENTAGE_Y);
	addWidget(newLabel);
    
    UIToolTip* newToolTip = new UIToolTip(GAME_OVER_PLAYER1_WINS_LABEL, GAME_OVER_PLAYER1_WINS_LABEL_ID);
    newToolTip -> setCenterPosition(getWidth() * GAME_OVER_RESULT_LABEL_PERCENTAGE_X, getHeight() * GAME_OVER_RESULT_LABEL_PERCENTAGE_Y);
    newToolTip -> setIsVisible(false);
    addWidget(newToolTip);
    
    newToolTip = new UIToolTip(GAME_OVER_PLAYER2_WINS_LABEL, GAME_OVER_PLAYER2_WINS_LABEL_ID);
    newToolTip -> setCenterPosition(getWidth() * GAME_OVER_RESULT_LABEL_PERCENTAGE_X, getHeight() * GAME_OVER_RESULT_LABEL_PERCENTAGE_Y);
    newToolTip -> setIsVisible(false);
    addWidget(newToolTip);

	newToolTip = new UIToolTip(GAME_OVER_TIE_LABEL, GAME_OVER_TIE_LABEL_ID);
    newToolTip -> setCenterPosition(getWidth() * GAME_OVER_RESULT_LABEL_PERCENTAGE_X, getHeight() * GAME_OVER_RESULT_LABEL_PERCENTAGE_Y);
    newToolTip -> setIsVisible(false);
    addWidget(newToolTip);

	m_CurrentButton = (UIButton*)getWidgetWithID(GAME_OVER_MAIN_MENU_BUTTON_ID);
	m_CurrentButton -> setIsHovered(true);

	newButton = NULL;
	newLabel = NULL;
}

GameOver::~GameOver()
{
	
}
    
const char* GameOver::getName()
{
	return GAME_OVER_SCREEN_NAME;
}
    
void GameOver::update(double delta)
{
    if(GameData::getInstance() -> getSetWinner())
    {
        if(GameData::getInstance() -> getScoreLeft() > GameData::getInstance() -> getScoreRight())
        {
            ((UIToolTip*)getWidgetWithID(GAME_OVER_PLAYER1_WINS_LABEL_ID)) -> setIsVisible(true);
            ((UIToolTip*)getWidgetWithID(GAME_OVER_PLAYER2_WINS_LABEL_ID)) -> setIsVisible(false);
			((UIToolTip*)getWidgetWithID(GAME_OVER_TIE_LABEL_ID)) -> setIsVisible(false);
        }
        else if(GameData::getInstance() -> getScoreLeft() < GameData::getInstance() -> getScoreRight())
        {
            ((UIToolTip*)getWidgetWithID(GAME_OVER_PLAYER1_WINS_LABEL_ID)) -> setIsVisible(false);
            ((UIToolTip*)getWidgetWithID(GAME_OVER_PLAYER2_WINS_LABEL_ID)) -> setIsVisible(true);
			((UIToolTip*)getWidgetWithID(GAME_OVER_TIE_LABEL_ID)) -> setIsVisible(false);
        }
		else
		{
            ((UIToolTip*)getWidgetWithID(GAME_OVER_PLAYER1_WINS_LABEL_ID)) -> setIsVisible(false);
            ((UIToolTip*)getWidgetWithID(GAME_OVER_PLAYER2_WINS_LABEL_ID)) -> setIsVisible(false);
			((UIToolTip*)getWidgetWithID(GAME_OVER_TIE_LABEL_ID)) -> setIsVisible(true);
		}
        
        GameData::getInstance() -> setSetWinner(false);
    }
}
    
void GameOver::keyUpEvent(int keyCode)
{
	if(keyCode == KEYCODE_RETURN)
	{
		if(m_CurrentButton != NULL)
		{
			m_CurrentButton -> keyUpEvent(keyCode);
		}
	}
	else if(keyCode == KEYCODE_UP_ARROW)
	{
		if(m_CurrentButton == NULL)
		{
			m_CurrentButton = (UIButton*)getWidgetWithID(GAME_OVER_RESTART_BUTTON_ID);
		}
		else
		{
			m_CurrentButton -> setIsHovered(false);

			if(m_CurrentButton -> getID() == GAME_OVER_RESTART_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(GAME_OVER_MAIN_MENU_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == GAME_OVER_MAIN_MENU_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(GAME_OVER_RESTART_BUTTON_ID);
			}
		}

		m_CurrentButton -> setIsHovered(true);
	}
	else if(keyCode == KEYCODE_DOWN_ARROW)
	{
		if(m_CurrentButton == NULL)
		{
			m_CurrentButton = (UIButton*)getWidgetWithID(GAME_OVER_RESTART_BUTTON_ID);
		}
		else
		{
			m_CurrentButton -> setIsHovered(false);

			if(m_CurrentButton -> getID() == GAME_OVER_RESTART_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(GAME_OVER_MAIN_MENU_BUTTON_ID);
			}
			else if(m_CurrentButton -> getID() == GAME_OVER_MAIN_MENU_BUTTON_ID)
			{
				m_CurrentButton = (UIButton*)getWidgetWithID(GAME_OVER_RESTART_BUTTON_ID);
			}
		}

		m_CurrentButton -> setIsHovered(true);
	}
}

void GameOver::buttonSelectedEvent(UIButton* buttonSelected)
{
	if(buttonSelected -> getID() == GAME_OVER_RESTART_BUTTON_ID)
	{
		buttonSelected -> setIsSelected(false);
		GameData::getInstance() -> setResetGame(true);
		ScreenManager::getInstance() -> switchScreen(GAME_SCREEN_NAME);
	}
	else if(buttonSelected -> getID() == GAME_OVER_MAIN_MENU_BUTTON_ID)
	{
		buttonSelected -> setIsSelected(false);
		GameData::getInstance() -> setResetGame(true);
		ScreenManager::getInstance() -> switchScreen(MAIN_MENU_SCREEN_NAME);
	}
}