//
//  Student:        Quentin Bellay
//  Creation Date:  October 11th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the BaseMenuScreenFiltered
//  Modified:       
//

#ifndef BASE_MENU_SCREEN_FILTERED_H
#define BASE_MENU_SCREEN_FILTERED_H

#include "BaseMenuScreen.h"

class OpenGLTexture;

// The BaseMenuScreenFiltered adds a grey filter to the background, for menus needing more contrast between front and back
class BaseMenuScreenFiltered : public BaseMenuScreen
{	
public:
    BaseMenuScreenFiltered();
    ~BaseMenuScreenFiltered();
    
    virtual void paint();
};

#endif