//
//  Splash.cpp
//  GAM-1514 OSX Game
//
//  Created by Quentin Bellay on 2013-10-11.
//  Copyright (c) 2013 Algonquin College. All rights reserved.
//

#include "Splash.h"
#include "../Constants/Constants.h"
#include "../Input/Input.h"
#include "../Screen Manager/ScreenManager.h"

Splash::Splash()
{
    UIButton* newButton = new UIButton(SPLASH_PRESS_SPACE, SPLASH_PRESS_SPACE_BUTTON_ID, false);    
    newButton -> setCenterPosition(getWidth() * SPLASH_PRESS_SPACE_BUTTON_PERCENTAGE_X, getHeight() * SPLASH_PRESS_SPACE_BUTTON_PERCENTAGE_Y);
	newButton -> addListener(this);
	addWidget(newButton);
    
    UILabel* newLabel = new UILabel(SPLASH_GAME_TITLE, SPLASH_TITLE_LABEL_ID);
    newLabel -> setCenterPosition(getWidth() * SPLASH_TITLE_LABEL_PERCENTAGE_X, getHeight() * SPLASH_TITLE_LABEL_PERCENTAGE_Y);
    addWidget(newLabel);
    
	newButton = NULL;
    newLabel = NULL;
}

Splash::~Splash()
{
    
}

const char* Splash::getName()
{
    return SPLASH_SCREEN_NAME;
}

void Splash::update(double delta)
{
    
}

void Splash::paint()
{
    BaseMenuScreen::paint();
}

void Splash::keyUpEvent(int aKeyCode)
{
    if(aKeyCode == KEYCODE_SPACE)
    {
        ScreenManager::getInstance() -> switchScreen(MAIN_MENU_SCREEN_NAME);
    }
}

void Splash::buttonSelectedEvent(UIButton* buttonSelected)
{
	if(buttonSelected -> getID() == SPLASH_PRESS_SPACE_BUTTON_ID)
	{
		buttonSelected -> setIsSelected(false);
		ScreenManager::getInstance() -> switchScreen(MAIN_MENU_SCREEN_NAME);
	}
}