//
//  Student:        Quentin Bellay
//  Creation Date:  October 11th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the BaseMenuScreen
//  Modified:       
//

#include "BaseMenuScreen.h"
#include "../OpenGL/OpenGL.h"
#include "../Constants/Constants.h"

BaseMenuScreen::BaseMenuScreen() :
	m_CurrentButton(NULL)
{    
    TextureManager::getInstance() -> addTexture(GAME_MENU_BACKGROUND);
}

BaseMenuScreen::~BaseMenuScreen()
{
	for(int i = 0; i < m_Widgets.size(); i++)
	{
		delete m_Widgets.at(i);
	}

	m_Widgets.clear();
}

void BaseMenuScreen::update(double deltaTIme)
{

}

void BaseMenuScreen::paint()
{
    OpenGLRenderer::getInstance() -> drawTexture(TextureManager::getInstance() -> getTextureByName(GAME_MENU_BACKGROUND), 0.0f, 0.0f, getWidth(), getHeight());

	for(int i = 0; i < m_Widgets.size(); i++)
	{
		m_Widgets.at(i) -> paint();
	}
}

void BaseMenuScreen::buttonHoveredEnterEvent(UIButton* hoveredButton)
{
	if(m_CurrentButton != NULL)
	{
		m_CurrentButton -> setIsHovered(false);
	}	

	m_CurrentButton = hoveredButton;
}

void BaseMenuScreen::buttonHoveredExitEvent(UIButton* hoveredButton)
{
	m_CurrentButton = NULL;
}

void BaseMenuScreen::mouseMovementEvent(float deltaX, float deltaY, float positionX, float positionY)
{
	for(int i = 0; i < m_Widgets.size(); i++)
	{
		m_Widgets.at(i) -> mouseMovementEvent(positionX, positionY);
	}
}

void BaseMenuScreen::mouseLeftClickUpEvent(float positionX, float positionY)
{
    for(int i = 0; i < m_Widgets.size(); i++)
	{
		m_Widgets.at(i) -> mouseLeftClickUpEvent(positionX, positionY);
	}
}

void BaseMenuScreen::addWidget(UIWidget* widget)
{
	m_Widgets.push_back(widget);
}

std::vector<UIWidget*> BaseMenuScreen::getWidgets()
{
	return m_Widgets;
}

UIWidget* BaseMenuScreen::getWidgetWithID(int widgetID)
{
	UIWidget* result = NULL;

	for(int i = 0; i < m_Widgets.size(); i++)
	{
		if(m_Widgets.at(i) -> getID() == widgetID)
		{
			result = m_Widgets.at(i);
			break;
		}
	}

	return result;
}