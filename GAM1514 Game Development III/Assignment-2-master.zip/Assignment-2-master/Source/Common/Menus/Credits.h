//
//  Student:        Quentin Bellay
//  Creation Date:  October 11th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the Credits screen
//  Modified:       
//

#ifndef CREDITS_H
#define CREDITS_H

#include "BaseMenuScreenFiltered.h"
#include <vector>

// Class Credits represent the credits screen
class Credits : public BaseMenuScreenFiltered
{
public:
    Credits();
    ~Credits();
    
    const char* getName();
        
    void keyUpEvent(int keyCode);

protected:
	void buttonSelectedEvent(UIButton* buttonSelected);
};

#endif