//
//  Student:        Quentin Bellay
//  Creation Date:  October 11th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the BaseMenuScreenFiltered
//  Modified:       
//

#include "BaseMenuScreenFiltered.h"
#include "../OpenGL/OpenGL.h"
#include "../Constants/Constants.h"


BaseMenuScreenFiltered::BaseMenuScreenFiltered()
{
	TextureManager::getInstance() -> addTexture(GAME_MENU_BACKGROUND_FILTER);
}

BaseMenuScreenFiltered::~BaseMenuScreenFiltered()
{

}
    
void BaseMenuScreenFiltered::paint()
{
	BaseMenuScreen::paint();

	OpenGLRenderer::getInstance() -> drawTexture(TextureManager::getInstance() -> getTextureByName(GAME_MENU_BACKGROUND_FILTER), 0.0f, 0.0f, getWidth(), getHeight());
	 
	for(int i = 0; i < getWidgets().size(); i++)
	{
		getWidgets().at(i) -> paint();
	}
}