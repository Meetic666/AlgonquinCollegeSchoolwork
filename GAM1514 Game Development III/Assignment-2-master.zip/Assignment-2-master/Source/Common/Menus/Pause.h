//
//  Student:        Quentin Bellay
//  Creation Date:  October 14th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the Pause screen
//  Modified:       
//

#ifndef PAUSE_H
#define PAUSE_H

#include "BaseMenuScreenFiltered.h"
#include <vector>

// Pause represents the Pause menu screen
class Pause : public BaseMenuScreenFiltered
{
public:
    Pause();
    ~Pause();
    
    const char* getName();    
    
    void keyUpEvent(int keyCode);

protected:
	void buttonSelectedEvent(UIButton* buttonSelected);
};

#endif