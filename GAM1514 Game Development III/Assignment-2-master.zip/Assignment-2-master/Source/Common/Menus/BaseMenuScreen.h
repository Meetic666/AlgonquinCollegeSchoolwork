//
//  Student:        Quentin Bellay
//  Creation Date:  October 11th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the BaseMenuScreen
//  Modified:       
//

#ifndef __GAM_1514_OSX_Game__BaseMenuScreen__
#define __GAM_1514_OSX_Game__BaseMenuScreen__

#include "../Screen Manager/Screen.h"
#include "../UI/UI.h"
#include "../TextureManager/TextureManager.h"
#include <vector>

class OpenGLTexture;

// Class representing the BaseMenuScreen: displays the background and widgets that have been added to it.
// Other menu screens will inherit this one
class BaseMenuScreen : public Screen, public IButtonListener
{
public:
    BaseMenuScreen();
    ~BaseMenuScreen();
    
	virtual void update(double deltaTime);
    virtual void paint();

	void mouseMovementEvent(float deltaX, float deltaY, float positionX, float positionY);
	void mouseLeftClickUpEvent(float positionX, float positionY);
    
protected:
	virtual void buttonSelectedEvent(UIButton* selectedButton) = 0;
	virtual void buttonHoveredEnterEvent(UIButton* hoveredButton);
	virtual void buttonHoveredExitEvent(UIButton* hoveredButton);
    
	void addWidget(UIWidget* widget);

	std::vector<UIWidget*> getWidgets();

	UIWidget* getWidgetWithID(int buttonID);

	UIButton* m_CurrentButton;
    
private:
	std::vector<UIWidget*> m_Widgets;
};

#endif /* defined(__GAM_1514_OSX_Game__BaseMenuScreen__) */
