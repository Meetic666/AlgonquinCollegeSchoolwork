//
//  Student:        Quentin Bellay
//  Creation Date:  October 11th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        File including all menu files, for ease of use
//  Modified:       
//

#include "Credits.h"
#include "GameOver.h"
#include "MainMenu.h"
#include "Pause.h"
#include "Settings.h"
#include "Splash.h"