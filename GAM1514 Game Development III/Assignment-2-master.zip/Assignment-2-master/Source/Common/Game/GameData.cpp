//
//  GameData.cpp
//  GAM-1514 OSX Game
//
//  Created by Quentin Bellay on 2013-10-07.
//  Copyright (c) 2013 Algonquin College. All rights reserved.
//

#include "GameData.h"

GameData* GameData::s_Instance = NULL;

GameData::GameData() :
    m_Player1Input(GAME_KEYBOARD_INPUT),
    m_Player2Input(GAME_KEYBOARD_INPUT),
	m_AIDifficulty(GAME_AI_NORMAL),
	m_GoalTarget(GAME_MAX_SCORE_LOW),
	m_GameTimer(GAME_TIMER_SHORT),
	m_NumberOfPlayers(1),
	m_ResetTimer(false),
    m_ResetGame(false),
    m_Player1Score(0),
    m_Player2Score(0),
    m_SetWinner(false)
{

}

GameData* GameData::getInstance()
{
    if(s_Instance == NULL)
    {
        s_Instance = new GameData();
    }
    
    return s_Instance;
}

void GameData::cleanUpInstance()
{
	if(s_Instance != NULL)
	{
		delete s_Instance;
		s_Instance = NULL;
	}
}

int GameData::getPlayer1Input()
{
    return m_Player1Input;
}

int GameData::getPlayer2Input()
{
    return m_Player2Input;
}

void GameData::setPlayer1Input(int a_InputType)
{
    if(a_InputType == GAME_KEYBOARD_INPUT)
    {
        m_Player1Input = a_InputType;
    }
	else if(a_InputType == GAME_MOUSE_INPUT)
	{
		m_Player1Input = a_InputType;

		m_Player2Input = GAME_KEYBOARD_INPUT;
	}
}

void GameData::setPlayer2Input(int a_InputType)
{
    if(a_InputType == GAME_KEYBOARD_INPUT)
    {
        m_Player2Input = a_InputType;
    }
	else if(a_InputType == GAME_MOUSE_INPUT)
	{
		m_Player2Input = a_InputType;

		m_Player1Input = GAME_KEYBOARD_INPUT;
	}
}

int GameData::getAIDifficulty()
{
	return m_AIDifficulty;
}

void GameData::setAIDifficulty(int difficulty)
{
	m_AIDifficulty = difficulty;
}

void GameData::setGameTimer(double a_GameTimer)
{
	m_GameTimer = a_GameTimer;
}

double GameData::getGameTimer()
{
	return m_GameTimer;
}

void GameData::setGoalTarget(short a_GoalTarget)
{
	m_GoalTarget = a_GoalTarget;
}

short GameData::getGoalTarget()
{
	return m_GoalTarget;
}

void GameData::setNumberOfPlayers(short numberOfPlayers)
{
	m_NumberOfPlayers = numberOfPlayers;
}

short GameData::getNumberOfPlayers()
{
	return m_NumberOfPlayers;
}

void GameData::setResetTimer(bool resetTimer)
{
	m_ResetTimer = resetTimer;
}

bool GameData::getResetTimer()
{
	return m_ResetTimer;
}

void GameData::setResetGame(bool resetGame)
{
	m_ResetGame = resetGame;
}

bool GameData::getResetGame()
{
	return m_ResetGame;
}

void GameData::scoreLeft()
{
    m_Player1Score++;
    
    if(m_Player1Score == m_GoalTarget)
    {
        m_SetWinner = true;
    }
}

void GameData::scoreRight()
{
    m_Player2Score++;
    
    if(m_Player2Score == m_GoalTarget)
    {
        m_SetWinner = true;
    }
}

short GameData::getScoreLeft()
{
    return m_Player1Score;
}

short GameData::getScoreRight()
{
    return m_Player2Score;
}

void GameData::setScoreLeft(short score)
{
    m_Player1Score = score;
}
void GameData::setScoreRight(short score)
{
    m_Player2Score = score;
}

void GameData::setSetWinner(bool setWinner)
{
    m_SetWinner = setWinner;
}

bool GameData::getSetWinner()
{
    return m_SetWinner;
}