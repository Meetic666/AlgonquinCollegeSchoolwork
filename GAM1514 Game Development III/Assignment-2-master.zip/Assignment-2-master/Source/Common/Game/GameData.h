//
//  GameData.h
//  GAM-1514 OSX Game
//
//  Created by Quentin Bellay on 2013-10-07.
//  Copyright (c) 2013 Algonquin College. All rights reserved.
//

#ifndef __GAM_1514_OSX_Game__GameData__
#define __GAM_1514_OSX_Game__GameData__

#include <iostream>
#include "../Constants/Constants.h"

class GameData
{    
public:
    static GameData* getInstance();
	static void cleanUpInstance();
    
    int getPlayer1Input();
    int getPlayer2Input();
    
    void setPlayer1Input(int inputType);
    void setPlayer2Input(int inputType);

	int getAIDifficulty();
	void setAIDifficulty(int difficulty);

	void setGameTimer(double gameTimer);
	double getGameTimer();

	void setGoalTarget(short goalTarget);
	short getGoalTarget();

	void setNumberOfPlayers(short numberOfPlayers);
	short getNumberOfPlayers();

	void setResetTimer(bool resetTimer);
	bool getResetTimer();

	void setResetGame(bool resetGame);
	bool getResetGame();
    
    void scoreLeft();
    void scoreRight();
    
    short getScoreLeft();
    short getScoreRight();
    
    void setScoreLeft(short score);
    void setScoreRight(short score);
    
    void setSetWinner(bool setWinner);
    bool getSetWinner();
    
private:
    static GameData* s_Instance;
    
    int m_Player1Input;
    int m_Player2Input;
	int m_AIDifficulty;

	double m_GameTimer;
	bool m_ResetTimer;

	bool m_ResetGame;

	short m_GoalTarget;

	short m_NumberOfPlayers;
    
    short m_Player1Score;
    short m_Player2Score;
    
    bool m_SetWinner;
    
    GameData();
};

#endif /* defined(__GAM_1514_OSX_Game__GameData__) */
