#include "GameConstants.h"


//Game Constants
const char* GAME_SCREEN_NAME = "Game";
const double GAME_OVER_TIMER = 2.0;
const double GAME_SCORE_INFO_TIMER = 2.0;
const double GAME_SCORE_INFO_FADE_OUT_TIME = 0.5;
const short GAME_MAX_SCORE_LOW = 9;
const short GAME_MAX_SCORE_MEDIUM = 20;
const short GAME_MAX_SCORE_HIGH = 50;
const short GAME_MAX_SCORE_UNLIMITED = -1;
const float GAME_TIMER_PERCENTAGE_X = 0.5f;
const float GAME_TIMER_PERCENTAGE_Y = 0.05f;

//Ball Constants
const float GAME_BALL_RADIUS_PERCENTAGE = 0.012f;
const float GAME_BALL_DEFAULT_SPEED = 250.0f;
const float GAME_BALL_SPEED_INCREMENT = 50.0f;
const char* GAME_BALL_TYPE = "Ball";

//Paddle Constants
const float GAME_PADDLE_WIDTH_PERCENTAGE = 0.025f;
const float GAME_PADDLE_HEIGHT_PERCENTAGE = 0.2f;
const float GAME_LEFT_PADDLE_X_PERCENTAGE = 0.05f;
const float GAME_RIGHT_PADDLE_X_PERCENTAGE = 0.95f;
const float GAME_PADDLE_Y_PERCENTAGE = 0.5f;
const float GAME_PADDLE_ACCELERATION = 50.0f;
const float GAME_PADDLE_MAX_SPEED = 200.0f;
const float GAME_PADDLE_MAX_SPEED_AI_EASY = 25.0f;
const float GAME_PADDLE_MAX_SPEED_AI_NORMAL = 50.0f;
const float GAME_PADDLE_MAX_SPEED_AI_HARD = 100.0f;
const char* GAME_PADDLE_TYPE = "Paddle";

//AI Constants
const short GAME_AI_EASY = 1;
const short GAME_AI_NORMAL = 2;
const short GAME_AI_HARD = 3;

//Input Constants
const int GAME_KEYBOARD_INPUT = 0;
const int GAME_MOUSE_INPUT = 1;

//Players Constants
const int GAME_PLAYER1 = 1;
const int GAME_PLAYER2 = 2;

//Timer Constants
const double GAME_TIMER_INFINITE = -1.0;
const double GAME_TIMER_SHORT = 90.0;
const double GAME_TIMER_AVERAGE = 180.0;
const double GAME_TIMER_LONG = 360.0;