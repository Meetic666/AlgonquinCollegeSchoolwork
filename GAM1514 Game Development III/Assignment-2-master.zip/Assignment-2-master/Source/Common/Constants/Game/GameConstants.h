#ifndef GAME_CONSTANTS_H
#define GAME_CONSTANTS_H

//Game Constants
extern const char* GAME_SCREEN_NAME;
extern const double GAME_OVER_TIMER;
extern const double GAME_SCORE_INFO_TIMER;
extern const double GAME_SCORE_INFO_FADE_OUT_TIME;
extern const short GAME_MAX_SCORE_LOW;
extern const short GAME_MAX_SCORE_MEDIUM;
extern const short GAME_MAX_SCORE_HIGH;
extern const short GAME_MAX_SCORE_UNLIMITED;
extern const float GAME_TIMER_PERCENTAGE_X;
extern const float GAME_TIMER_PERCENTAGE_Y;

//Ball Constants
extern const float GAME_BALL_RADIUS_PERCENTAGE;
extern const float GAME_BALL_DEFAULT_SPEED;
extern const float GAME_BALL_SPEED_INCREMENT;
extern const char* GAME_BALL_TYPE;

//Paddle Constants
extern const float GAME_PADDLE_WIDTH_PERCENTAGE;
extern const float GAME_PADDLE_HEIGHT_PERCENTAGE;
extern const float GAME_LEFT_PADDLE_X_PERCENTAGE;
extern const float GAME_RIGHT_PADDLE_X_PERCENTAGE;
extern const float GAME_PADDLE_Y_PERCENTAGE;
extern const float GAME_PADDLE_ACCELERATION;
extern const float GAME_PADDLE_MAX_SPEED;
extern const float GAME_PADDLE_MAX_SPEED_AI_EASY;
extern const float GAME_PADDLE_MAX_SPEED_AI_NORMAL;
extern const float GAME_PADDLE_MAX_SPEED_AI_HARD;
extern const char* GAME_PADDLE_TYPE;

//AI Constants
extern const short GAME_AI_EASY;
extern const short GAME_AI_NORMAL;
extern const short GAME_AI_HARD;

//Input Constants
extern const int GAME_KEYBOARD_INPUT;
extern const int GAME_MOUSE_INPUT;

//Players Constants
extern const int GAME_PLAYER1;
extern const int GAME_PLAYER2;

//Timer Constants
extern const double GAME_TIMER_INFINITE;
extern const double GAME_TIMER_SHORT;
extern const double GAME_TIMER_AVERAGE;
extern const double GAME_TIMER_LONG;

#endif 