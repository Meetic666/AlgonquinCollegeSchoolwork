#include "ResourceConstants.h"

//Menu Title Resources
const char* GAME_OVER_MENU_TITLE = "GameOverTitle";
const char* PAUSE_MENU_TITLE = "PausedTitle";

//Menu Selection Resources
const char* MENU_SELECTION_BOX = "MenuSelectionBox";
const char* MENU_OPTION_RESUME = "MenuResumeOption";
const char* MENU_OPTION_RESTART = "MenuRestartOption";
const char* MENU_OPTION_QUIT = "MenuQuitOption";
const char* MENU_OPTION_PLAY_AGAIN = "MenuPlayAgainOption";

//Menu Resources
const char* GAME_MENU_BACKGROUND = "MenuBackground";
const char* GAME_MENU_BACKGROUND_FILTER = "MenuBackgroundFilter";

//Splash Resources
const char* SPLASH_PRESS_SPACE = "PressSpace";
const char* SPLASH_GAME_TITLE = "GameTitle";

//Main Menu Resources
const char* MAIN_MENU_LABEL = "MainMenu";
const char* MAIN_MENU_NEW_GAME = "NewGame";
const char* MAIN_MENU_CREDITS = "Credits";
const char* MAIN_MENU_EXIT = "Exit";

//Credits Resources
const char* CREDITS_LABEL = "Credits";
const char* CREDITS_AUTHOR_NAME = "Author";
const char* CREDITS_PROFESSOR_NAME = "Professor";
const char* CREDITS_COURSE_NUMBER = "CourseNumber";
const char* CREDITS_COURSE_NAME = "CourseName";
const char* CREDITS_PROGRAM_NAME = "ProgramName";
const char* CREDITS_COLLEGE_NAME = "CollegeName";
const char* CREDITS_BACK_BUTTON = "Back";

// Settings Resources
const char* SETTINGS_SINGLE_PLAYER = "SinglePlayer";
const char* SETTINGS_TWO_PLAYERS = "TwoPlayers";
const char* SETTINGS_PLAYER1_LABEL = "Player1Input";
const char* SETTINGS_PLAYER2_LABEL = "Player2Input";
const char* SETTINGS_AIDIFFICULTY_LABEL = "AIDifficulty";
const char* SETTINGS_KEYBOARD_BUTTON = "Keyboard";
const char* SETTINGS_MOUSE_BUTTON = "Mouse";
const char* SETTINGS_AI_EASY_BUTTON = "Easy";
const char* SETTINGS_AI_NORMAL_BUTTON = "Normal";
const char* SETTINGS_AI_HARD_BUTTON = "Hard";
const char* SETTINGS_MAX_SCORE_LABEL = "MaxScore";
const char* SETTINGS_TIME_LIMIT_LABEL = "TimeLimit";
const char* SETTINGS_UNLIMITED_BUTTON = "Unlimited";
const char* SETTINGS_LOW_BUTTON = "Low";
const char* SETTINGS_MEDIUM_BUTTON = "Medium";
const char* SETTINGS_HIGH_BUTTON = "High";
const char* SETTINGS_BACK_BUTTON = "Back";
const char* SETTINGS_START_GAME_BUTTON = "StartGame";
const char* SETTINGS_PLAYER1_KEYBOARD_TOOL_TIP = "Player1ToolTip";
const char* SETTINGS_PLAYER2_KEYBOARD_TOOL_TIP = "Player2ToolTip";

//Pause Resources
const char* PAUSE_LABEL = "Pause";
const char* PAUSE_RESTART = "Restart";
const char* PAUSE_RESUME = "Resume";
const char* PAUSE_SETTINGS = "Settings";
const char* PAUSE_MAIN_MENU = "MainMenu";

//Game Over Resources
const char* GAME_OVER_LABEL = "GameOver";
const char* GAME_OVER_RESTART = "Restart";
const char* GAME_OVER_MAIN_MENU = "MainMenu";
const char* GAME_OVER_PLAYER1_WINS_LABEL = "Player1Wins";
const char* GAME_OVER_PLAYER2_WINS_LABEL = "Player2Wins";
const char* GAME_OVER_TIE_LABEL = "Tie";

//Game Resources
const char* GAME_ALGONQUIN_LOGO = "AC_Logo";
const char* GAME_SCORE_INFO_BACKGROUND = "ScoreInfoBackground";
const char* GAME_SCORE_INFO_GOAL = "ScoreInfoGoal";
const char* GAME_SCORE_INFO_LEFT = "ScoreInfoLeft";
const char* GAME_SCORE_INFO_RIGHT = "ScoreInfoRight";
const char* GAME_SCORE_INFO_NUMBERS[] = {"ScoreInfo0", "ScoreInfo1", "ScoreInfo2", "ScoreInfo3", "ScoreInfo4", "ScoreInfo5", "ScoreInfo6", "ScoreInfo7", "ScoreInfo8", "ScoreInfo9"};
const int GAME_SCORE_INFO_NUMBER_OF_NUMBERS = 10;
const char* GAME_TIME_INFO_NUMBERS[] = {"TimeInfo0", "TimeInfo1", "TimeInfo2", "TimeInfo3", "TimeInfo4", "TimeInfo5", "TimeInfo6", "TimeInfo7", "TimeInfo8", "TimeInfo9"};
const char* GAME_TIME_NUMBERS_ATLAS = "TimeNumbers";
const char* GAME_SCORE_INFO_NUMBERS_ATLAS = "ScoreInfoNumbers";

//Button Resources
const char* UI_BUTTON_BACKGROUND = "ButtonBackground";