#ifndef RESOURCE_CONSTANTS_H
#define RESOURCE_CONSTANTS_H

//Menu Title Resources
extern const char* GAME_OVER_MENU_TITLE;
extern const char* PAUSE_MENU_TITLE;

//Menu Selection Resources
extern const char* MENU_SELECTION_BOX;
extern const char* MENU_OPTION_RESUME;
extern const char* MENU_OPTION_RESTART;
extern const char* MENU_OPTION_QUIT;
extern const char* MENU_OPTION_PLAY_AGAIN;

//Menu Resources
extern const char* GAME_MENU_BACKGROUND;
extern const char* GAME_MENU_BACKGROUND_FILTER;

//Splash Resources
extern const char* SPLASH_PRESS_SPACE;
extern const char* SPLASH_GAME_TITLE;

//Main Menu Resources
extern const char* MAIN_MENU_LABEL;
extern const char* MAIN_MENU_NEW_GAME;
extern const char* MAIN_MENU_CREDITS;
extern const char* MAIN_MENU_EXIT;

//Credits Resources
extern const char* CREDITS_LABEL;
extern const char* CREDITS_AUTHOR_NAME;
extern const char* CREDITS_PROFESSOR_NAME;
extern const char* CREDITS_COURSE_NUMBER;
extern const char* CREDITS_COURSE_NAME;
extern const char* CREDITS_PROGRAM_NAME;
extern const char* CREDITS_COLLEGE_NAME;
extern const char* CREDITS_BACK_BUTTON;

// Settings Resources
extern const char* SETTINGS_SINGLE_PLAYER;
extern const char* SETTINGS_TWO_PLAYERS;
extern const char* SETTINGS_PLAYER1_LABEL;
extern const char* SETTINGS_PLAYER2_LABEL;
extern const char* SETTINGS_AIDIFFICULTY_LABEL;
extern const char* SETTINGS_KEYBOARD_BUTTON;
extern const char* SETTINGS_MOUSE_BUTTON;
extern const char* SETTINGS_AI_EASY_BUTTON;
extern const char* SETTINGS_AI_NORMAL_BUTTON;
extern const char* SETTINGS_AI_HARD_BUTTON;
extern const char* SETTINGS_MAX_SCORE_LABEL;
extern const char* SETTINGS_TIME_LIMIT_LABEL;
extern const char* SETTINGS_UNLIMITED_BUTTON;
extern const char* SETTINGS_LOW_BUTTON;
extern const char* SETTINGS_MEDIUM_BUTTON;
extern const char* SETTINGS_HIGH_BUTTON;
extern const char* SETTINGS_BACK_BUTTON;
extern const char* SETTINGS_START_GAME_BUTTON;
extern const char* SETTINGS_PLAYER1_KEYBOARD_TOOL_TIP;
extern const char* SETTINGS_PLAYER2_KEYBOARD_TOOL_TIP;

//Pause Resources
extern const char* PAUSE_LABEL;
extern const char* PAUSE_RESTART;
extern const char* PAUSE_RESUME;
extern const char* PAUSE_SETTINGS;
extern const char* PAUSE_MAIN_MENU;

//Game Over Resources
extern const char* GAME_OVER_LABEL;
extern const char* GAME_OVER_RESTART;
extern const char* GAME_OVER_MAIN_MENU;
extern const char* GAME_OVER_PLAYER1_WINS_LABEL;
extern const char* GAME_OVER_PLAYER2_WINS_LABEL;
extern const char* GAME_OVER_TIE_LABEL;

//Game Resources
extern const char* GAME_ALGONQUIN_LOGO;
extern const char* GAME_SCORE_INFO_BACKGROUND;
extern const char* GAME_SCORE_INFO_GOAL;
extern const char* GAME_SCORE_INFO_LEFT;
extern const char* GAME_SCORE_INFO_RIGHT;
extern const char* GAME_SCORE_INFO_NUMBERS[];
extern const int GAME_SCORE_INFO_NUMBER_OF_NUMBERS;
extern const char* GAME_TIME_INFO_NUMBERS[];
extern const char* GAME_TIME_NUMBERS_ATLAS;
extern const char* GAME_SCORE_INFO_NUMBERS_ATLAS;

//Button Resources
extern const char* UI_BUTTON_BACKGROUND;

#endif 