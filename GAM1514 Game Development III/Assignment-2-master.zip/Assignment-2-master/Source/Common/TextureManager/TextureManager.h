//
//  Student:        Quentin Bellay
//  Creation Date:  October 21th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the Texture Manager
//  Modified:       
//

#ifndef __GAM_1514_OSX_Game__TextureManager__
#define __GAM_1514_OSX_Game__TextureManager__

#include <vector>

class OpenGLTexture;

// Class representing the Texture Manager, to keep textures in the same place, for ease of use, and mostly ease of clean up
class TextureManager
{
public:
    static TextureManager* getInstance();
    static void cleanUpInstance();
    
    OpenGLTexture* getTextureByName(const char* name);
    void addTexture(const char* filename);
    
private:
    TextureManager();
    ~TextureManager();
    
    static TextureManager* s_Instance;
    
    std::vector<OpenGLTexture*> m_Textures;
    
};

#endif /* defined(__GAM_1514_OSX_Game__TextureManager__) */
