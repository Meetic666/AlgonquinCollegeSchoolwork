//
//  Student:        Quentin Bellay
//  Creation Date:  October 21th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the Texture Manager
//  Modified:       
//

#include "TextureManager.h"
#include "../OpenGL/OpenGL.h"

TextureManager* TextureManager::s_Instance = NULL;

TextureManager* TextureManager::getInstance()
{
    if(s_Instance == NULL)
    {
        s_Instance = new TextureManager();
    }
    
    return s_Instance;
}

void TextureManager::cleanUpInstance()
{
    if(s_Instance != NULL)
    {
        delete s_Instance;
        s_Instance = NULL;
    }
}

TextureManager::TextureManager()
{
    
}

TextureManager::~TextureManager()
{
    for(int i = 0; i < m_Textures.size(); i++)
    {
        if(m_Textures[i] != NULL)
        {
            delete m_Textures[i];
            m_Textures[i] = NULL;
        }
    }
}

OpenGLTexture* TextureManager::getTextureByName(const char* name)
{
    OpenGLTexture* result = NULL;
    
    for(int i = 0; i < m_Textures.size(); i++)
    {
        if(m_Textures[i] != NULL && std::strcmp(m_Textures[i] ->getFilename().c_str(), name) == 0)
        {
            result = m_Textures[i];
            break;
        }
    }
    
    return result;
}

void TextureManager::addTexture(const char* filename)
{
    bool alreadyExists = false;
    
    for(int i = 0; i < m_Textures.size(); i++)
    {
        if(m_Textures[i] != NULL && std::strcmp(m_Textures[i] ->getFilename().c_str(), filename) == 0)
        {
            alreadyExists = true;
            break;
        }
    }
    
    if(!alreadyExists)
    {
        m_Textures.push_back(new OpenGLTexture(filename));
    }
}