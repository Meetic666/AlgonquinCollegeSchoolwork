//
//  Student:        Quentin Bellay
//  Creation Date:  October 14th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the UIWidget
//  Modified:       
//

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <vector>
#include "../TextureManager/TextureManager.h"

// Class UIWidget represents the basic widget class, that any other widget will inherit (Button, Label, etc)
class UIWidget
{
public:
    UIWidget(int widgetID);
    virtual ~UIWidget();
    
    virtual void paint() = 0;
    
    virtual void mouseMovementEvent(float positionX, float positionY);
    virtual void mouseLeftClickUpEvent(float positionX, float positionY);

	virtual void keyUpEvent(int aKeyCode);
    
    void setCenterPosition(float centerX, float centerY);

	int getID();

protected:
    float m_CenterPositionX;
    float m_CenterPositionY;

private:
	int m_WidgetID;
};

#endif