//
//  Student:        Quentin Bellay
//  Creation Date:  October 18th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the UIToolTip
//  Modified:       
//

#ifndef UI_TOOL_TIP_H
#define UI_TOOL_TIP_H

#include "UILabel.h"

// Class UIToolTip represents the Tool Tip widget: label that can be set visible or not
class UIToolTip : public UILabel
{
public:
	UIToolTip(const char* textureFile, int toolTipID);
	~UIToolTip();

	virtual void paint();

	void setIsVisible(bool isVisible);

protected:
	bool m_IsVisible;
};

#endif