//
//  Student:        Quentin Bellay
//  Creation Date:  October 11th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the IButtonListener
//  Modified:       
//

#ifndef I_BUTTON_LISTENER_H
#define I_BUTTON_LISTENER_H

class UIButton;

// Class IButtonListener is the interface used for listening to basic button events
// Menus will inherit that interface
class IButtonListener
{
public:
	virtual void buttonSelectedEvent(UIButton* buttonSelected) = 0;
	virtual void buttonHoveredEnterEvent(UIButton* buttonHovered) = 0;
	virtual void buttonHoveredExitEvent(UIButton* buttonHovered) = 0;
};

#endif