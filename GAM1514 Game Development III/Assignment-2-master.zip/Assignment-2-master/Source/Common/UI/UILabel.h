//
//  Student:        Quentin Bellay
//  Creation Date:  October 14th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the UILabel
//  Modified:       
//

#ifndef UILABEL_H
#define UILABEL_H

#include "UIWidget.h"
#include <string>

class OpenGLTexture;

// Class UILabel represent the label widget: texture that can be greyed or not, but unselectable
class UILabel : public UIWidget
{
public:
	UILabel(const char* textureFile, int labelID);
	~UILabel();

	virtual void paint();

	void setIsGreyed(bool isGreyed);
    bool getIsGreyed();

protected:
	bool m_IsGreyed;
    std::string m_TextureName;
    std::string m_GreyedTextureName;
};

#endif