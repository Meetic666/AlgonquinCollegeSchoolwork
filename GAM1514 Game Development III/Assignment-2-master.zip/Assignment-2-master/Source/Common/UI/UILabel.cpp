//
//  Student:        Quentin Bellay
//  Creation Date:  October 14th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the UILabel
//  Modified:       
//

#include "UILabel.h"
#include "../OpenGL/OpenGL.h"
#include "../Constants/Constants.h"

UILabel::UILabel(const char* textureFile, int labelID) : UIWidget(labelID),
m_IsGreyed(false),
m_TextureName(""),
m_GreyedTextureName("")
{
    m_TextureName = std::string(textureFile);
    
    TextureManager::getInstance() -> addTexture(m_TextureName.c_str());
    
    m_GreyedTextureName = std::string(textureFile) + "-Greyed";
	TextureManager::getInstance() -> addTexture(m_GreyedTextureName.c_str());
}

UILabel::~UILabel()
{
	
}

void UILabel::paint()
{
    OpenGLTexture* texture = NULL;
    
	if(m_IsGreyed)
	{
        texture = TextureManager::getInstance() -> getTextureByName(m_GreyedTextureName.c_str());
	}
	else
	{
        texture = TextureManager::getInstance() -> getTextureByName(m_TextureName.c_str());        
	}
    
    if(texture != NULL)
    {
        float x = m_CenterPositionX - texture -> getSourceWidth() / 2.0f;
        float y = m_CenterPositionY - texture -> getSourceHeight() / 2.0f;
        
        OpenGLRenderer::getInstance() -> drawTexture(texture, x, y);
    }
    
    texture = NULL;
}

void UILabel::setIsGreyed(bool isGreyed)
{
	m_IsGreyed = isGreyed;
}

bool UILabel::getIsGreyed()
{
    return m_IsGreyed;
}