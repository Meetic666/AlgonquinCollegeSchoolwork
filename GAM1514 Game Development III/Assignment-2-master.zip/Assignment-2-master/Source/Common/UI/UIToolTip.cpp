//
//  Student:        Quentin Bellay
//  Creation Date:  October 18th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the UIToolTip
//  Modified:       
//

#include "UIToolTip.h"

UIToolTip::UIToolTip(const char* textureFile, int toolTipID) : UILabel(textureFile, toolTipID),
	m_IsVisible(false)
{

}

UIToolTip::~UIToolTip()
{

}

void UIToolTip::paint()
{
	if(m_IsVisible)
	{
		UILabel::paint();
	}
}

void UIToolTip::setIsVisible(bool isVisible)
{
	m_IsVisible = isVisible;
}