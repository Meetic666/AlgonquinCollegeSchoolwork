//  Student:        Quentin Bellay
//  Creation Date:  October 26th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the UINumberToolTip
//  Modified:
//

#include "UINumberToolTip.h"
#include "../TextureManager/TextureManager.h"
#include "../OpenGL/OpenGL.h"

UINumberToolTip::UINumberToolTip(int number, int toolTipID, int typeOfDisplay) : UIToolTip("", toolTipID)
{
    setNumberDisplay(number, typeOfDisplay);
}

UINumberToolTip::~UINumberToolTip()
{
    
}

void UINumberToolTip::paint()
{
    if(m_IsVisible)
    {
        float x = m_CenterPositionX;
        
        for(int i = m_NumberTextureNames.size() - 1; i >= 0; i--)
        {
            
            OpenGLTexture* texture = TextureManager::getInstance() -> getTextureByName(m_NumberTextureNames.at(i).c_str());
            OpenGLRenderer::getInstance() -> drawTexture(texture, x, m_CenterPositionY - texture -> getSourceHeight() / 2.0f);
            
            x += texture -> getSourceWidth();
        }
    }
}

void UINumberToolTip::setNumberDisplay(int number, int typeOfDisplay)
{
    if(typeOfDisplay == NUMBER_DISPLAY_TIME)
    {
        if(number % 60 < 10)
        {
            setNumberDisplay(number % 60, NUMBER_DISPLAY_DECIMAL);
            setNumberDisplay(0, NUMBER_DISPLAY_DECIMAL);
        }
        else
        {
            setNumberDisplay(number % 60, NUMBER_DISPLAY_DECIMAL);
        }
        
        TextureManager::getInstance() -> addTexture("Colon");
        m_NumberTextureNames.push_back("Colon");
        
		if(number / 60 >= 60)
		{
			setNumberDisplay(number / 60, NUMBER_DISPLAY_TIME);
		}
		else
		{
			setNumberDisplay(number / 60, NUMBER_DISPLAY_DECIMAL);
		}
    }
    else
    {
        char buffer[2] = "";
        sprintf(buffer, "%d", number % 10);
        TextureManager::getInstance() -> addTexture(buffer);
        m_NumberTextureNames.push_back(buffer);
        
        if(number >= 10)
        {
            setNumberDisplay(number / 10, NUMBER_DISPLAY_DECIMAL);
        }
    }
}