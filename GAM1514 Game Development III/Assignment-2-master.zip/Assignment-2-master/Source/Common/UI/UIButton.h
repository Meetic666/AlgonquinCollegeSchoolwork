//
//  Student:        Quentin Bellay
//  Creation Date:  October 11th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the UIButton
//  Modified:       
//

#ifndef __GAM_1514_OSX_Game__UIButton__
#define __GAM_1514_OSX_Game__UIButton__

class OpenGLTexture;
class IButtonListener;

#include "UILabel.h"

class UIToolTip;

// Class UIButton represents the button widget: can be greyed, hovered and selected
class UIButton : public UILabel
{
public:
    UIButton(const char* textureFile, int buttonID, bool hasBackground = true, bool isToggleable = false);
    ~UIButton();
    
    virtual void paint();
    
    void mouseMovementEvent(float positionX, float positionY);
    void mouseLeftClickUpEvent(float positionX, float positionY);

	void keyUpEvent(int aKeyCode);
    
    void setIsSelected(bool isSelected);
	void setIsHovered(bool isHovered);

	void addListener(IButtonListener* buttonListener);
    
    void addToolTip(UIToolTip* toolTip);
    
protected:
    std::string m_SelectedTextureName;
    std::string m_HoveredTextureName;
	std::string m_ButtonBackground;
	std::string m_ButtonBackgroundSelected;
    bool m_IsSelected;
	bool m_IsHovered;
	bool m_IsToggleable;
	bool m_HasBackground;

	std::vector<IButtonListener*> m_ButtonListeners;
    std::vector<UIToolTip*> m_ToolTips;
};

#endif /* defined(__GAM_1514_OSX_Game__UIButton__) */
