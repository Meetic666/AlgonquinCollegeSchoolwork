//
//  Student:        Quentin Bellay
//  Creation Date:  October 26th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the UINumberToolTip
//  Modified:
//

#ifndef __GAM_1514_OSX_Game__UINumberToolTip__
#define __GAM_1514_OSX_Game__UINumberToolTip__

#include "UIToolTip.h"
#include "../Constants/Constants.h"
#include <vector>

// Class UINumberToolTip is used to display numbers, but acts as a tool tip (can be set visible or not)
class UINumberToolTip : public UIToolTip
{
public:
    UINumberToolTip(int number, int toolTipID, int typeOfDisplay = NUMBER_DISPLAY_DECIMAL);
    ~UINumberToolTip();
    
    void paint();
    
private:
    void setNumberDisplay(int number, int typeOfDisplay);
    
    std::vector<std::string> m_NumberTextureNames;
};

#endif /* defined(__GAM_1514_OSX_Game__UINumberToolTip__) */
