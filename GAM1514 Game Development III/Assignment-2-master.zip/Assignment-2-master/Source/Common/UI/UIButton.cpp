//
//  Student:        Quentin Bellay
//  Creation Date:  October 11th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the UIButton
//  Modified:       
//

#include "UIButton.h"
#include "../OpenGL/OpenGL.h"
#include "../Screen Manager/ScreenManager.h"
#include "../Constants/Constants.h"
#include "IButtonListener.h"
#include "UIToolTip.h"

UIButton::UIButton(const char* textureFile, int buttonID, bool hasBackground, bool isToggleable) : UILabel(textureFile, buttonID),
m_SelectedTextureName(""),
m_HoveredTextureName(""),
m_ButtonBackground(""),
m_ButtonBackgroundSelected(""),
m_IsSelected(false),
m_IsHovered(false),
m_IsToggleable(isToggleable),
m_HasBackground(hasBackground)

{
    m_SelectedTextureName = std::string(textureFile) + "-Selected";
    TextureManager::getInstance() -> addTexture(m_SelectedTextureName.c_str());
    
    m_HoveredTextureName = std::string(textureFile) + "-Hovered";
	TextureManager::getInstance() -> addTexture(m_HoveredTextureName.c_str());

	m_ButtonBackground = std::string(UI_BUTTON_BACKGROUND);
	TextureManager::getInstance() ->addTexture(m_ButtonBackground.c_str());

	m_ButtonBackgroundSelected = m_ButtonBackground + "-Selected";
	TextureManager::getInstance() ->addTexture(m_ButtonBackgroundSelected.c_str());
}

UIButton::~UIButton()
{
    for(int i = 0; i < m_ToolTips.size(); i++)
    {
        delete m_ToolTips.at(i);
    }
    
    m_ToolTips.clear();
    
	m_ButtonListeners.clear();
}

void UIButton::paint()
{
    OpenGLTexture* texture = NULL;
	OpenGLTexture* backTexture = NULL;

	if(m_HasBackground)
	{
		if(m_IsSelected && !m_IsGreyed)
		{
			backTexture = TextureManager::getInstance() -> getTextureByName(m_ButtonBackgroundSelected.c_str());
		}
		else
		{
			backTexture = TextureManager::getInstance() -> getTextureByName(m_ButtonBackground.c_str());
		}
	}
    
    if(m_IsGreyed)
	{
        texture = TextureManager::getInstance() -> getTextureByName(m_GreyedTextureName.c_str());
	}
	else if(m_IsHovered)
	{
        texture = TextureManager::getInstance() -> getTextureByName(m_HoveredTextureName.c_str());
	}
	else if(m_IsSelected)
    {
        texture = TextureManager::getInstance() -> getTextureByName(m_SelectedTextureName.c_str());
    }
    else
    {
        texture = TextureManager::getInstance() -> getTextureByName(m_TextureName.c_str());
    }
    
	if(backTexture != NULL)
    {
        float x = m_CenterPositionX - backTexture -> getSourceWidth() / 2.0f;
        float y = m_CenterPositionY - backTexture -> getSourceHeight() / 2.0f;
        
        OpenGLRenderer::getInstance() -> drawTexture(backTexture, x, y);
    }

    if(texture != NULL)
    {
        float x = m_CenterPositionX - texture -> getSourceWidth() / 2.0f;
        float y = m_CenterPositionY - texture -> getSourceHeight() / 2.0f;
        
        OpenGLRenderer::getInstance() -> drawTexture(texture, x, y);
    }
    
    texture = NULL;
    
    for(int i = 0; i < m_ToolTips.size(); i++)
    {
        m_ToolTips.at(i) -> paint();
    }
}

void UIButton::mouseMovementEvent(float positionX, float positionY)
{
	if(!m_IsGreyed)
	{
        OpenGLTexture* textureSelected = TextureManager::getInstance() -> getTextureByName(m_SelectedTextureName.c_str());
        
		float left = m_CenterPositionX - textureSelected -> getSourceWidth() / 2.0f;
		float right = m_CenterPositionX + textureSelected -> getSourceWidth() / 2.0f;
		float up = m_CenterPositionY - textureSelected -> getSourceHeight() / 2.0f;
		float down = m_CenterPositionY + textureSelected -> getSourceHeight() / 2.0f;
        
		bool previousHovered = m_IsHovered;
        
		if(positionX >= left && positionX <= right && positionY >= up && positionY <= down)
		{
			setIsHovered(true);
            
			if(!previousHovered)
			{
				for(int i = 0; i < m_ButtonListeners.size(); i++)
				{
					m_ButtonListeners.at(i) -> buttonHoveredEnterEvent(this);
				}
			}
		}
		else
		{
			setIsHovered(false);
            
			if(previousHovered)
			{
				for(int i = 0; i < m_ButtonListeners.size(); i++)
				{
					m_ButtonListeners.at(i) -> buttonHoveredExitEvent(this);
				} 
			}
		}
	}
}

void UIButton::mouseLeftClickUpEvent(float positionX, float positionY)
{
    if(m_IsHovered)
    {
		if(m_IsToggleable)
		{
			setIsSelected(!m_IsSelected);
		}
		else
		{
			setIsSelected(true);
		}
        
		for(int i = 0; i < m_ButtonListeners.size(); i++)
		{
			m_ButtonListeners.at(i) -> buttonSelectedEvent(this);
		}
    }
}

void UIButton::keyUpEvent(int aKeyCode)
{
	if(m_IsHovered)
    {
		if(m_IsToggleable)
		{
			setIsSelected(!m_IsSelected);
		}
		else
		{
			setIsSelected(true);
		}
        
		for(int i = 0; i < m_ButtonListeners.size(); i++)
		{
			m_ButtonListeners.at(i) -> buttonSelectedEvent(this);
		}
    }
}

void UIButton::setIsSelected(bool isSelected)
{
    m_IsSelected = isSelected;
}

void UIButton::setIsHovered(bool isHovered)
{
	m_IsHovered = isHovered;
    
    for(int i = 0; i < m_ToolTips.size(); i++)
    {
        m_ToolTips.at(i) -> setIsVisible(isHovered);
    }
}

void UIButton::addListener(IButtonListener* buttonListener)
{
	m_ButtonListeners.push_back(buttonListener);
}

void UIButton::addToolTip(UIToolTip* toolTip)
{
    m_ToolTips.push_back(toolTip);
}