//
//  Student:        Quentin Bellay
//  Creation Date:  October 14th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the UIWidget
//  Modified:       
//

#include "UIWidget.h"

UIWidget::UIWidget(int widgetID) :
    m_CenterPositionX(0.0f),
    m_CenterPositionY(0.0f),
	m_WidgetID(widgetID)
{

}

UIWidget::~UIWidget()
{

}
    
void UIWidget::mouseMovementEvent(float positionX, float positionY)
{

}

void UIWidget::mouseLeftClickUpEvent(float positionX, float positionY)
{

}

void UIWidget::keyUpEvent(int aKeyCode)
{

}
    
void UIWidget::setCenterPosition(float centerX, float centerY)
{
	m_CenterPositionX = centerX;
	m_CenterPositionY = centerY;
}

int UIWidget::getID()
{
	return m_WidgetID;
}