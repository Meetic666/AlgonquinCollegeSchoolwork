#ifndef GAME_CONSTANTS_H
#define GAME_CONSTANTS_H

//Game Constants
extern const char* GAME_SCREEN_NAME;
extern const double GAME_OVER_TIMER;
extern const double GAME_RECAP_TIMER;
extern const int GAME_NUMBER_OF_BRICK_ROWS;
extern const int GAME_MAX_LEVEL;

//Ball Constants
extern const float GAME_BALL_RADIUS_PERCENTAGE;
extern const float GAME_BALL_DEFAULT_SPEED;
extern const float GAME_BALL_SPEED_INCREASE;
extern const char* GAME_BALL_TYPE;

//Paddle Constants
extern const float GAME_PADDLE_WIDTH_PERCENTAGE;
extern const float GAME_PADDLE_HEIGHT_PERCENTAGE;
extern const float GAME_PADDLE_Y_PERCENTAGE;
extern const char* GAME_PADDLE_TYPE;

//Brick Constants
extern const float GAME_BRICK_LEVEL1_WIDTH_PERCENTAGE;
extern const float GAME_BRICK_LEVEL2_WIDTH_PERCENTAGE;
extern const float GAME_BRICK_LEVEL3_WIDTH_PERCENTAGE;
extern const float GAME_BRICK_LEVEL4_WIDTH_PERCENTAGE;
extern const float GAME_BRICK_LEVEL5_WIDTH_PERCENTAGE;
extern const float GAME_BRICK_HEIGHT_PERCENTAGE;
extern const char* GAME_BRICK_TYPE;

//GameOver Constants
extern const float GAME_OVER_WIDTH_PERCENTAGE;
extern const float GAME_OVER_HEIGHT_PERCENTAGE;
extern const float GAME_OVER_Y_PERCENTAGE;
extern const char* GAME_OVER_TYPE;

//Recap Constants
extern const float GAME_RECAP_WIDTH_PERCENTAGE;
extern const float GAME_RECAP_HEIGHT_PERCENTAGE;
extern const float GAME_RECAP_Y_PERCENTAGE;
extern const char* GAME_RECAP_TYPE;

//Win Constants
extern const float GAME_WIN_WIDTH_PERCENTAGE;
extern const float GAME_WIN_HEIGHT_PERCENTAGE;
extern const float GAME_WIN_Y_PERCENTAGE;
extern const char* GAME_WIN_TYPE;

//PlayerData Constants
extern const int GAME_PLAYER_DATA_LIVES;

#endif 