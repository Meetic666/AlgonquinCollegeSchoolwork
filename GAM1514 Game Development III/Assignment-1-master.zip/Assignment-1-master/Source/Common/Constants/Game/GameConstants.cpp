#include "GameConstants.h"


//Game Constants
const char* GAME_SCREEN_NAME = "Game";
const double GAME_OVER_TIMER = 2.5;
const double GAME_RECAP_TIMER = 1.5;
const int GAME_NUMBER_OF_BRICK_ROWS = 5;
const int GAME_MAX_LEVEL = 30; // Up to 99 because the game can't display three digits of level

//Ball Constants
const float GAME_BALL_RADIUS_PERCENTAGE = 0.02f;
const float GAME_BALL_DEFAULT_SPEED = 250.0f;
const float GAME_BALL_SPEED_INCREASE = 50.0f;
const char* GAME_BALL_TYPE = "Ball";

//Paddle Constants
const float GAME_PADDLE_WIDTH_PERCENTAGE = 0.2f;
const float GAME_PADDLE_HEIGHT_PERCENTAGE = 0.025f;
const float GAME_PADDLE_Y_PERCENTAGE = 0.9f;
const char* GAME_PADDLE_TYPE = "Paddle";

//Brick Constants
const float GAME_BRICK_LEVEL1_WIDTH_PERCENTAGE = 1.0f/4.0f; // 4 bricks on a row
const float GAME_BRICK_LEVEL2_WIDTH_PERCENTAGE = 1.0f/5.f; // 5 bricks on a row
const float GAME_BRICK_LEVEL3_WIDTH_PERCENTAGE = 1.0f/7.0f; // 7 bricks on a row
const float GAME_BRICK_LEVEL4_WIDTH_PERCENTAGE = 1.0f/8.0f; // 8 bricks on a row
const float GAME_BRICK_LEVEL5_WIDTH_PERCENTAGE = 1.0f/10.0f; // 10 bricks on a row
const float GAME_BRICK_HEIGHT_PERCENTAGE = 0.05f;
const char* GAME_BRICK_TYPE = "Brick";

//GameOver Constants
const float GAME_OVER_WIDTH_PERCENTAGE = 0.5f;
const float GAME_OVER_HEIGHT_PERCENTAGE = 0.5f;
const float GAME_OVER_Y_PERCENTAGE = 0.5f;
const char* GAME_OVER_TYPE = "GameOver";

//Recap Constants
const float GAME_RECAP_WIDTH_PERCENTAGE = 0.5f;
const float GAME_RECAP_HEIGHT_PERCENTAGE = 0.5f;
const float GAME_RECAP_Y_PERCENTAGE = 0.5f;
const char* GAME_RECAP_TYPE = "Recap";

//Win Constants
const float GAME_WIN_WIDTH_PERCENTAGE = 0.5f;
const float GAME_WIN_HEIGHT_PERCENTAGE = 0.5f;
const float GAME_WIN_Y_PERCENTAGE = 0.5f;
const char* GAME_WIN_TYPE = "Win";

//PlayerData Constants
const int GAME_PLAYER_DATA_LIVES = 3;