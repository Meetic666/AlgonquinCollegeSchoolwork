//
//  Student:        Quentin Bellay
//  Creation Date:  September 16th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the Paddle game object
//  Modified:       September 21st, 2013
//                      Added Texture behavior
//

#include "Paddle.h"
#include "../Constants/Constants.h"
#include "../Screen Manager/ScreenManager.h"
#include "../OpenGL/OpenGL.h"


Paddle::Paddle() : GameObject()
{
    
}

Paddle::~Paddle()
{
    
}

void Paddle::update(double aDelta)
{
    
}

void Paddle::paint()
{
    OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("Paddle"), getX(), getY(), getWidth(), getHeight());
}

void Paddle::reset()
{
    //Get the screen width and height
    float screenWidth = ScreenManager::getInstance()->getScreenWidth();
    float screenHeight = ScreenManager::getInstance()->getScreenHeight();
    
    //Reset the paddle's width and height
    setWidth(screenWidth * GAME_PADDLE_WIDTH_PERCENTAGE);
    setHeight(screenHeight * GAME_PADDLE_HEIGHT_PERCENTAGE);
    
    //Reset the x and y position
    setX((screenWidth - getWidth()) / 2.0f);
    setY(screenHeight * GAME_PADDLE_Y_PERCENTAGE);
    
    //Reset the paddle to active
    setIsActive(true);
}

const char* Paddle::getType()
{
    return GAME_PADDLE_TYPE;
}

void Paddle::setSize(float aWidth, float aHeight)
{
    setWidth(aWidth);
    setHeight(aHeight);
}

void Paddle::setWidth(float aWidth)
{
    m_Width = aWidth;
}

void Paddle::setHeight(float aHeight)
{
    m_Height = aHeight;
}

void Paddle::getSize(float &aWidth, float &aHeight)
{
    aWidth = getWidth();
    aHeight = getHeight();
}

float Paddle::getWidth()
{
    return m_Width;
}

float Paddle::getHeight()
{
    return m_Height;
}
