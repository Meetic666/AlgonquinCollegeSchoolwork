//
//  Student:        Quentin Bellay
//  Creation Date:  September 16th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the Brick game object
//  Modified:       September 21st, 2013
//                      Added Texture behavior
//

#include "Brick.h"
#include "GameData.h"
#include "../Constants/Constants.h"
#include "../Screen Manager/ScreenManager.h"
#include "../OpenGL/OpenGL.h"


Brick::Brick() : GameObject()
{
    
}

Brick::Brick(float  aX, float aY) : GameObject()
{
    setX(aX);
    setY(aY);
}

Brick::~Brick()
{
    
}

void Brick::update(double aDelta)
{
    
}

void Brick::paint()
{
    OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("Brick"), getX(), getY(), getWidth(), getHeight());
}

void Brick::reset()
{
    //Get the screen width and height
    float screenWidth = ScreenManager::getInstance()->getScreenWidth();
    float screenHeight = ScreenManager::getInstance()->getScreenHeight();
    
    //Reset the brick's width and height
    float brickWidth = 0.0f;
    
    switch(GameData::getInstance() -> getLevel() % 5)
    {
        case 0:
            brickWidth = screenWidth * GAME_BRICK_LEVEL5_WIDTH_PERCENTAGE;
            break;
            
        case 1:
            brickWidth = screenWidth * GAME_BRICK_LEVEL1_WIDTH_PERCENTAGE;
            break;
            
        case 2:
            brickWidth = screenWidth * GAME_BRICK_LEVEL2_WIDTH_PERCENTAGE;
            break;
            
        case 3:
            brickWidth = screenWidth * GAME_BRICK_LEVEL3_WIDTH_PERCENTAGE;
            break;
            
        case 4:
            brickWidth = screenWidth * GAME_BRICK_LEVEL4_WIDTH_PERCENTAGE;
            break;
    }
    
    setWidth(brickWidth);
    setHeight(screenHeight * GAME_BRICK_HEIGHT_PERCENTAGE);
    
    //Reset the brick to active
    setIsActive(true);
}

const char* Brick::getType()
{
    return GAME_BRICK_TYPE;
}

void Brick::setSize(float aWidth, float aHeight)
{
    setWidth(aWidth);
    setHeight(aHeight);
}

void Brick::setWidth(float aWidth)
{
    m_Width = aWidth;
}

void Brick::setHeight(float aHeight)
{
    m_Height = aHeight;
}

void Brick::getSize(float &aWidth, float &aHeight)
{
    aWidth = getWidth();
    aHeight = getHeight();
}

float Brick::getWidth()
{
    return m_Width;
}

float Brick::getHeight()
{
    return m_Height;
}
