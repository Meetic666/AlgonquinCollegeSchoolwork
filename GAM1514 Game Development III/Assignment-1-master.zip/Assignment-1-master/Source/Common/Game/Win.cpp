//
//  Student:        Quentin Bellay
//  Creation Date:  September 17th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the Win screen
//                  shown when the player has beaten the max number of levels.
//  Modified:
//

#include "Win.h"
#include "../Constants/Constants.h"
#include "../Screen Manager/ScreenManager.h"
#include "../OpenGL/OpenGL.h"


Win::Win() : GameObject()
{
    
}

Win::~Win()
{
    
}

void Win::update(double aDelta)
{
    
}

void Win::paint()
{
	OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("WinBackground"), getX(), getY(), getWidth(), getHeight());
    OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("WinText"), getX(), getY(), getWidth(), getHeight());
    OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("PressRText"), getX(), getY(), getWidth(), getHeight());
    OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("LevelText"), getX(), getY(), getWidth(), getHeight());
    
    switch(GameData::getInstance() -> getLevel() / 10)
    {
        case 0:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("FirstDigit0"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 1:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("FirstDigit1"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 2:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("FirstDigit2"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 3:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("FirstDigit3"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 4:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("FirstDigit4"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 5:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("FirstDigit5"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 6:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("FirstDigit6"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 7:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("FirstDigit7"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 8:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("FirstDigit8"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 9:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("FirstDigit9"), getX(), getY(), getWidth(), getHeight());
            break;
    }
    
    switch(GameData::getInstance() -> getLevel() % 10)
    {
        case 0:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("SecondDigit0"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 1:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("SecondDigit1"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 2:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("SecondDigit2"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 3:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("SecondDigit3"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 4:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("SecondDigit4"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 5:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("SecondDigit5"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 6:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("SecondDigit6"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 7:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("SecondDigit7"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 8:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("SecondDigit8"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 9:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("SecondDigit9"), getX(), getY(), getWidth(), getHeight());
            break;
    }
}

void Win::reset()
{
    //Get the screen width and height
    float screenWidth = ScreenManager::getInstance()->getScreenWidth();
    float screenHeight = ScreenManager::getInstance()->getScreenHeight();
    
    //Reset the Win's width and height
    setWidth(screenWidth * GAME_WIN_WIDTH_PERCENTAGE);
    setHeight(screenHeight * GAME_WIN_HEIGHT_PERCENTAGE);
    
    //Reset the x and y position
    setX((screenWidth - getWidth()) / 2.0f);
    setY(screenHeight * GAME_WIN_Y_PERCENTAGE - getHeight() / 2.0f);
    
    //Reset the Win to active
    setIsActive(false);
}

const char* Win::getType()
{
    return GAME_WIN_TYPE;
}

void Win::setSize(float aWidth, float aHeight)
{
    setWidth(aWidth);
    setHeight(aHeight);
}

void Win::setWidth(float aWidth)
{
    m_Width = aWidth;
}

void Win::setHeight(float aHeight)
{
    m_Height = aHeight;
}

void Win::getSize(float &aWidth, float &aHeight)
{
    aWidth = getWidth();
    aHeight = getHeight();
}

float Win::getWidth()
{
    return m_Width;
}

float Win::getHeight()
{
    return m_Height;
}
