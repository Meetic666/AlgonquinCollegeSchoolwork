//
//  Student:        Quentin Bellay
//  Creation Date:  September 16th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the TextureManager Simpleton
//                  used to store all textures at launch time so that
//                  they are available at any time
//  Modified:
//

#include "TextureManager.h"

TextureManager* TextureManager::s_Instance = NULL;

TextureManager* TextureManager::getInstance()
{
    if(s_Instance == NULL)
    {
        s_Instance = new TextureManager();
    }
    
    return s_Instance;
}

void TextureManager::cleanUpInstance()
{
    if(s_Instance != NULL)
    {
        delete s_Instance;
        s_Instance = NULL;
    }
}

TextureManager::TextureManager()
{
    
}

TextureManager::~TextureManager()
{
    for(int i = 0; i < m_Textures.size(); i++)
    {
        if(m_Textures[i] != NULL)
        {
            delete m_Textures[i];
            m_Textures[i] = NULL;
        }
    }
}

void TextureManager::addTexture(std::string filename)
{
    if(getTextureWithName(filename) == NULL)
        m_Textures.push_back(new OpenGLTexture(filename.c_str()));
}

OpenGLTexture* TextureManager::getTextureAt(int index)
{
    if(index < m_Textures.size() && m_Textures[index] != NULL)
    {
        return m_Textures[index];
    }
    else
    {
        return NULL;
    }
}

OpenGLTexture* TextureManager::getTextureWithName(std::string name)
{
    int i = 0;
    bool found = false;
    OpenGLTexture* result = NULL;
    
    while(!found && i < m_Textures.size())
    {
        if(m_Textures[i] -> getFilename() == name)
        {
            found = true;
            result = m_Textures[i];
        }
        
        i++;
    }
    
    return result;
}