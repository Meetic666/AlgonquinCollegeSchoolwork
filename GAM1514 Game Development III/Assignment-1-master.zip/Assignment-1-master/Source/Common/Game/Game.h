//
//  Student:        Quentin Bellay
//  Creation Date:  September 16th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Main game class
//  Modified:
//

#ifndef GAME_H
#define GAME_H

#include <vector>
#include "../Screen Manager/Screen.h"
#include "IBrickListener.h"

class GameObject;
class OpenGLTexture;

//Main game class, which contains all the game behavior and objects
class Game : public Screen, public IBrickListener
{
public:
    Game();
    ~Game();
    
    //Game lifecycle methods
    void update(double delta);
    void paint();
    void reset();
    
    //Game Over method, call this when to end the game
    void gameOver();
    
    //Win method, call this whenthe player won
    void win();
    
    //Screen name, must be implemented, it's a pure
    //virtual method in the Screen class
    const char* getName();
    
    //Screen event method, inherited from the screen class
    void screenWillAppear();
    
    //GameObject Methods
    void addGameObject(GameObject* gameObject);
    GameObject* getGameObjectByType(const char* type);
    
    //Losing life method
    void loseLife();

	//Brick destroyed event
	void bricksDestroyedEvent();
    
private:
    //Mouse Events
    void mouseMovementEvent(float deltaX, float deltaY, float positionX, float positionY);
    
    //Key Events
    void keyUpEvent(int keyCode);
    void keyDownEvent(int keyCode);
    
    //Loading level method
    void loadLevel();
    
    //Changing level method
    void changeLevel();
    
    //Loading textures methods
    void loadTextures();
    
    //Removing bricks method
    void removeBricks();
    
    //Vector to hold the GameObjects
    std::vector<GameObject*> m_GameObjects;
    
    //Timer variable to delay resetting the game has ended
    double m_GameOverTimer;
    
    //Timer variable to delay the game when the player died or changed level
    double m_RecapTimer;
};

#endif