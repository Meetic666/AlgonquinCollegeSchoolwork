//
//  Student:        Quentin Bellay
//  Creation Date:  September 17th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the GameData
//                  stores the number of brick displayed and the level number
//  Modified:
//

#ifndef GAME_DATA_H
#define GAME_DATA_H

#include <stdio.h>
#include <vector>

class IBrickListener;

// GameData is the class that will take care of the attributes of the game
// (mostly the level we're in)
class GameData
{
public:
    static GameData* getInstance();
    static void cleanUpInstance();
    
    void changeLevel();
    
    int getLevel();
    void setLevel(int level);
    
    void addBrick();
    void removeBrick();
    
    int getNumberOfBricks();
    void resetNumberOfBricks();

	//Add brick listener
	void addBrickListener(IBrickListener* listener);
    
private:
    GameData();
    ~GameData();
    
    int m_Level;
    int m_NumberOfBricks;
    
    static GameData* s_Instance;

	//Brick listeners
	std::vector<IBrickListener*> m_BrickListeners;
};

#endif