//
//  Student:        Quentin Bellay
//  Creation Date:  September 16th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the Paddle game object
//  Modified:       September 21st, 2013
//                      Added Texture behavior
//

#ifndef PADDLE_H
#define PADDLE_H

#include "GameObject.h"

//Paddle class, inherits from GameObject, is controlled by the
//mouse input on the x-axis.
class Paddle : public GameObject
{
public:
  Paddle();
  ~Paddle();
  
  //Implementing the pure virtual lifecycle methods from GameObject
  void update(double delta);
  void paint();
  
  //Overriding the virtual reset method from GameObject
  void reset();
  
  //Implementing the pure virtual type method from GameObject
  const char* getType();
  
  //Setter size methods
  void setSize(float width, float height);
  void setWidth(float width);
  void setHeight(float height);
  
  //Getter size methods
  void getSize(float &width, float &height);
  float getWidth();
  float getHeight();
  
protected:
  float m_Width;
  float m_Height;
};

#endif
