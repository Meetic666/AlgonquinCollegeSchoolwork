//
//  Student:        Quentin Bellay
//  Creation Date:  September 16th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the TextureManager Simpleton
//                  used to store all textures at launch time so that
//                  they are available at any time
//  Modified:
//

#ifndef __GAM_1514_OSX_Game__TextureManager__
#define __GAM_1514_OSX_Game__TextureManager__

#include <stdio.h>
#include <vector>
#include "../OpenGL/OpenGL.h"

class TextureManager
{
public:
    static TextureManager* getInstance();
    static void cleanUpInstance();
    
    TextureManager();
    ~TextureManager();
    
    void addTexture(std::string filename);
    
    OpenGLTexture* getTextureAt(int index);
    
    OpenGLTexture* getTextureWithName(std::string name);
    
private:
    static TextureManager* s_Instance;
    
    std::vector<OpenGLTexture*> m_Textures;
};

#endif /* defined(__GAM_1514_OSX_Game__TextureManager__) */
