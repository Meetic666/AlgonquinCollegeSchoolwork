//
//  Student:        Quentin Bellay
//  Creation Date:  September 17th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the Player Data
//                  stores the number of lives
//                  PlayerData is a Simpleton
//  Modified:
//

#ifndef PLAYER_DATA_H
#define PLAYER_DATA_H

#include <stdio.h>

// PlayerData is the class that will take care of the attributes of the player
// (here, it is just for the number of lives)
class PlayerData
{
public:
    static PlayerData* getInstance();
    static void cleanUpInstance();
    
    void gainLife();
    void loseLife();
    void setLife(int life);
    
    int getLife();
    
private:
    PlayerData();
    ~PlayerData();
    
    int m_Life;
    
    static PlayerData* s_Instance;
};

#endif