//
//  Student:        Quentin Bellay
//  Creation Date:  September 17th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing Game Over screen
//                  displayed when the player has no more lives
//  Modified:
//

#ifndef GAME_OVER_H
#define GAME_OVER_H

#include "GameObject.h"

//GameOver class, inherits from GameObject, displays the game over message when dying
class GameOver : public GameObject
{
public:
    GameOver();
    ~GameOver();
    
    //Implementing the pure virtual lifecycle methods from GameObject
    void update(double delta);
    void paint();
    
    //Overriding the virtual reset method from GameObject
    void reset();
    
    //Implementing the pure virtual type method from GameObject
    const char* getType();
    
    //Setter size methods
    void setSize(float width, float height);
    void setWidth(float width);
    void setHeight(float height);
    
    //Getter size methods
    void getSize(float &width, float &height);
    float getWidth();
    float getHeight();
    
protected:
    float m_Width;
    float m_Height;
};

#endif
