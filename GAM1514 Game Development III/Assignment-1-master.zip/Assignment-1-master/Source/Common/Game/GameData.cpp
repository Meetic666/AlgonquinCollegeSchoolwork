//
//  Student:        Quentin Bellay
//  Creation Date:  September 17th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the GameData
//                  stores the number of brick displayed and the level number
//  Modified:
//

#include "GameData.h"
#include "../Constants/Constants.h"
#include "IBrickListener.h"

GameData* GameData::s_Instance = NULL;

GameData::GameData() :
    m_Level(1),
    m_NumberOfBricks(0)
{
    
}

GameData::~GameData()
{
    
}

void GameData::changeLevel()
{
    m_Level++;
}

int GameData::getLevel()
{
    return m_Level;
}

void GameData::setLevel(int aLevel)
{
    m_Level = aLevel;
}

GameData* GameData::getInstance()
{
    if(s_Instance == NULL)
    {
        s_Instance = new GameData();
    }
    
    return s_Instance;
}

void GameData::cleanUpInstance()
{
    if(s_Instance != NULL)
    {
        delete s_Instance;
        s_Instance = NULL;
    }
}

void GameData::addBrick()
{
    m_NumberOfBricks++;
}

void GameData::removeBrick()
{
    m_NumberOfBricks--;

	if(m_NumberOfBricks == 0)
	{
		for(int i = 0; i < m_BrickListeners.size(); i++)
		{
			m_BrickListeners[i] -> bricksDestroyedEvent();
		}
	}
}

int GameData::getNumberOfBricks()
{
    return m_NumberOfBricks;
}

void GameData::resetNumberOfBricks()
{
    m_NumberOfBricks = 0;
}

void GameData::addBrickListener(IBrickListener* listener)
{
	m_BrickListeners.push_back(listener);
}