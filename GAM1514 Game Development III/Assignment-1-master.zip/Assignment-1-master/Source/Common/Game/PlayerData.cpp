//
//  Student:        Quentin Bellay
//  Creation Date:  September 17th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the Player Data
//                  stores the number of lives
//                  PlayerData is a Simpleton
//  Modified:
//

#include "PlayerData.h"
#include "../Constants/Constants.h"

PlayerData* PlayerData::s_Instance = NULL;

PlayerData::PlayerData() :
    m_Life(GAME_PLAYER_DATA_LIVES)
{
    
}

PlayerData::~PlayerData()
{
    
}

void PlayerData::gainLife()
{
    if(m_Life < 27)
        m_Life++;
}

void PlayerData::loseLife()
{
    if(m_Life > 0)
    {
        m_Life--;
    }
}

int PlayerData::getLife()
{
    return m_Life;
}

void PlayerData::setLife(int aLife)
{
    m_Life = aLife;
}

PlayerData* PlayerData::getInstance()
{
    if(s_Instance == NULL)
    {
        s_Instance = new PlayerData();
    }
    
    return s_Instance;
}

void PlayerData::cleanUpInstance()
{
    if(s_Instance != NULL)
    {
        delete s_Instance;
        s_Instance = NULL;
    }
}