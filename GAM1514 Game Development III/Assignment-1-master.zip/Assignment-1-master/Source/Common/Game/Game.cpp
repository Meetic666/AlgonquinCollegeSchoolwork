//
//  Student:        Quentin Bellay
//  Creation Date:  September 16th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Main game class
//  Modified:
//

#include "Game.h"
#include "GameObject.h"
#include "Paddle.h"
#include "Ball.h"
#include "Brick.h"
#include "GameOver.h"
#include "PlayerData.h"
#include "GameData.h"
#include "Recap.h"
#include "Win.h"
#include "TextureManager.h"
#include "IBrickListener.h"
#include "../OpenGL/OpenGL.h"
#include "../Constants/Constants.h"
#include "..//Utils/Utils.h"
#include "../Screen Manager/ScreenManager.h"


Game::Game()
{    
    //Create a new paddle and ball
    addGameObject(new Paddle());
    addGameObject(new Ball());
    
    addGameObject(new GameOver());
    addGameObject(new Recap());
    addGameObject(new Win());
    
    loadLevel();
    
    reset();
    
    getGameObjectByType(GAME_RECAP_TYPE) -> setIsActive(true);
    
    m_RecapTimer = GAME_RECAP_TIMER;
    
    loadTextures();

	GameData::getInstance() -> addBrickListener(this);
}

Game::~Game()
{
    //Delete all the GameObject's in the vector
    for(int i = 0; i < m_GameObjects.size(); i++)
    {
        delete m_GameObjects.at(i);
        m_GameObjects.at(i) = NULL;
    }
    
    //Clear the pointers from the vector
    m_GameObjects.clear();
    
    //Delete PlayerData
    PlayerData::cleanUpInstance();
    
    //Delete GameData
    GameData::cleanUpInstance();
    
    //Delete TextureManager
    TextureManager::cleanUpInstance();
}

void Game::update(double aDelta)
{
    //If the GameOver Timer is greater that zero, countdown
    if(m_GameOverTimer > 0.0)
    {
        m_GameOverTimer -= aDelta;
        if(m_GameOverTimer < 0.0)
        {
            m_GameOverTimer = 0.0;
            
            GameData::getInstance() -> setLevel(1);
            PlayerData::getInstance() -> setLife(3);
            
            loadLevel();
            reset();
            
            m_RecapTimer = GAME_RECAP_TIMER;
            
            getGameObjectByType(GAME_RECAP_TYPE) -> setIsActive(true);
        }
        return;
    }
    
    //If the Recap Timer is greater that zero, countdown
    if(m_RecapTimer > 0.0)
    {
        m_RecapTimer -= aDelta;
        if(m_RecapTimer < 0.0)
        {
            m_RecapTimer = 0.0;
            
            getGameObjectByType(GAME_RECAP_TYPE) -> setIsActive(false);
        }
        return;
    }
    
    if(getGameObjectByType(GAME_OVER_TYPE) -> getIsActive() == false && getGameObjectByType(GAME_RECAP_TYPE) -> getIsActive() == false
       && getGameObjectByType(GAME_WIN_TYPE) -> getIsActive() == false)
    {
        //Get the ball GameObject, we'll use this for collision detection
        Ball* ball = (Ball*)getGameObjectByType(GAME_BALL_TYPE);
        
        //Cycle through all the game objects update them and check their collision detection
        for(int i = 0; i < m_GameObjects.size(); i++)
        {
            //Make sure the GameObject is active
            if(m_GameObjects.at(i)->getIsActive() == true)
            {
                //Update the GameObject
                m_GameObjects.at(i)->update(aDelta);
                
                //Check collision detection against the ball
                if(m_GameObjects.at(i) != ball)
                {
                    ball->checkCollision(m_GameObjects.at(i));
                }
            }
        }
    }
}

void Game::paint()
{
    OpenGLRenderer::getInstance() -> drawTexture(TextureManager::getInstance() -> getTextureWithName("Background"), 0.0f, 0.0f, ScreenManager::getInstance() -> getScreenWidth(), ScreenManager::getInstance() -> getScreenHeight());
    
    //Cycle through and draw all the game objects
    for(int i = 0; i < m_GameObjects.size(); i++)
    {
        if(m_GameObjects.at(i)->getIsActive() == true && strcmp(m_GameObjects.at(i) -> getType(), GAME_OVER_TYPE) != 0
           && strcmp(m_GameObjects.at(i) -> getType(), GAME_RECAP_TYPE) != 0)
        {
            m_GameObjects.at(i)->paint();
        }
    }
    
    if(getGameObjectByType(GAME_OVER_TYPE) -> getIsActive())
    {
        getGameObjectByType(GAME_OVER_TYPE) -> paint();
    }
    
    if(getGameObjectByType(GAME_RECAP_TYPE) -> getIsActive())
    {
        getGameObjectByType(GAME_RECAP_TYPE) -> paint();
    }
    
    //Draw the outer gray walls
    OpenGLRenderer::getInstance()->setForegroundColor(OpenGLColorGray());
    OpenGLRenderer::getInstance()->setLineWidth(4.0f);
    OpenGLRenderer::getInstance()->drawLine(1.0f, 0.0f, 1.0f, getHeight());
    OpenGLRenderer::getInstance()->drawLine(0.0f, 1.0f, getWidth(), 1.0f);
    OpenGLRenderer::getInstance()->drawLine(getWidth() - 1, 0.0f, getWidth() - 1, getHeight());
    OpenGLRenderer::getInstance()->setLineWidth(1.0f);
}

void Game::reset()
{
    //Cycle through and reset all the game objects
    for(int i = 0; i < m_GameObjects.size(); i++)
    {
        m_GameObjects.at(i)->reset();
    }
    
    //Reset the game over timer to zero
    m_GameOverTimer = 0.0;
    
    // Reset the Recap timer to zero
    m_RecapTimer = 0.0;
}

void Game::gameOver()
{
    getGameObjectByType(GAME_OVER_TYPE) -> setIsActive(true);
}

void Game::win()
{
    getGameObjectByType(GAME_WIN_TYPE) -> setIsActive(true);
}

const char* Game::getName()
{
	return GAME_SCREEN_NAME;
}

void Game::screenWillAppear()
{
    OpenGLRenderer::getInstance()->setBackgroundColor(OpenGLColorCornflowerBlue());
}

void Game::addGameObject(GameObject* aGameObject)
{
    if(aGameObject != NULL)
    {
        m_GameObjects.push_back(aGameObject);
    }
}

GameObject* Game::getGameObjectByType(const char* aType)
{
    //Cycle through a find the game object (if it exists)
    for(unsigned int i = 0; i < m_GameObjects.size(); i++)
    {
        if(strcmp(m_GameObjects.at(i)->getType(), aType) == 0)
        {
            return m_GameObjects.at(i);
        }
    }
    return NULL;
}

void Game::mouseMovementEvent(float aDeltaX, float aDeltaY, float aPositionX, float aPositionY)
{
    //Set the paddle to the x position of the mouse
    Paddle* paddle = (Paddle*)getGameObjectByType(GAME_PADDLE_TYPE);
    
    //Safety check, paddle could be NULL
    if(paddle != NULL)
    {
        paddle->setX(aPositionX - (paddle->getWidth() / 2.0f));
    }
}

void Game::keyUpEvent(int aKeyCode)
{
    
}

void Game::keyDownEvent(int aKeyCode)
{
    if(((getGameObjectByType(GAME_OVER_TYPE) -> getIsActive() == true) || (getGameObjectByType(GAME_WIN_TYPE) -> getIsActive() == true)) && (aKeyCode == KEYCODE_R))
    {
        m_GameOverTimer = GAME_OVER_TIMER;
    }
}

void Game::loseLife()
{
    PlayerData::getInstance() -> loseLife();
    
    if(PlayerData::getInstance() -> getLife() == 0)
    {
        gameOver();
    }
    else
    {
        getGameObjectByType(GAME_RECAP_TYPE) -> setIsActive(true);
        
        m_RecapTimer = GAME_RECAP_TIMER;
    }
}

void Game::loadLevel()
{
    removeBricks();
    
    float screenWidth = ScreenManager::getInstance() -> getScreenWidth();
    
    float brickWidth = 0.0f;
    float brickHeight = ScreenManager::getInstance() -> getScreenHeight() * GAME_BRICK_HEIGHT_PERCENTAGE;
    float brickNumber = 0;
    
    int numberOfRows = 0;
    
    int startRow = 0;
    int endRow = 0;
    
    switch(GameData::getInstance() -> getLevel() % 5)
    {
        case 0:
            brickWidth = screenWidth * GAME_BRICK_LEVEL5_WIDTH_PERCENTAGE;
            brickNumber = 1 / GAME_BRICK_LEVEL5_WIDTH_PERCENTAGE;
            
            for(int i=0; i < brickNumber; i++)
            {
                if(i == 0 || i == (int)brickNumber - 1 || i == (int)(brickNumber / 2.0f) || i == (int)(brickNumber / 2.0f) - 1)
                {
                    numberOfRows = GAME_NUMBER_OF_BRICK_ROWS - 4;
                }
                else if(i == (int)(brickNumber / 4.0f) || i == (int)(3.0f * brickNumber / 4.0f))
                {
                    numberOfRows = GAME_NUMBER_OF_BRICK_ROWS - 2;
                }
                else
                {
                    numberOfRows = GAME_NUMBER_OF_BRICK_ROWS - 3;
                }
                
                for(int j=0; j < numberOfRows; j++)
                {
                    addGameObject(new Brick(i * brickWidth, (j+1) * brickHeight));
                    
                    GameData::getInstance() -> addBrick();
                }
            }
            
            for(int i=(int)(brickNumber / 2.0f) - 2; i < (int)(brickNumber / 2.0f) + 2; i++)
            {
                if(i == (int)(brickNumber / 2.0f) || i == (int)(brickNumber / 2.0f) - 1)
                {
                    startRow = GAME_NUMBER_OF_BRICK_ROWS - 2;
                }
                else
                {
                    startRow = GAME_NUMBER_OF_BRICK_ROWS - 1;
                }
                
                for(int j=startRow; j < GAME_NUMBER_OF_BRICK_ROWS; j++)
                {
                    addGameObject(new Brick(i * brickWidth, (j+1) * brickHeight));
                    
                    GameData::getInstance() -> addBrick();
                }
            }
            
            break;
            
        case 1:
            brickWidth = screenWidth * GAME_BRICK_LEVEL1_WIDTH_PERCENTAGE;
            brickNumber = 1 / GAME_BRICK_LEVEL1_WIDTH_PERCENTAGE;
            
            for(int i=0; i < brickNumber; i++)
            {
                for(int j=0; j < GAME_NUMBER_OF_BRICK_ROWS; j++)
                {
                    addGameObject(new Brick(i * brickWidth, (j+1) * brickHeight));
                    
                    GameData::getInstance() -> addBrick();
                }
            }
            
            break;
            
        case 2:
            brickWidth = screenWidth * GAME_BRICK_LEVEL2_WIDTH_PERCENTAGE;
            brickNumber = 1 / GAME_BRICK_LEVEL2_WIDTH_PERCENTAGE;
            
            for(int i=0; i < brickNumber; i++)
            {
                if(i == 0 || i == brickNumber - 1)
                {
                    numberOfRows = GAME_NUMBER_OF_BRICK_ROWS - 4;
                }
                else if(i == (int)(brickNumber / 2.0f))
                {
                    numberOfRows = GAME_NUMBER_OF_BRICK_ROWS;
                }
                else
                {
                    numberOfRows = GAME_NUMBER_OF_BRICK_ROWS - 2;
                }
                
                for(int j=0; j < numberOfRows; j++)
                {
                    addGameObject(new Brick(i * brickWidth, (j+1) * brickHeight));
                    
                    GameData::getInstance() -> addBrick();
                }
            }
            
            break;
            
        case 3:
            brickWidth = screenWidth * GAME_BRICK_LEVEL3_WIDTH_PERCENTAGE;
            brickNumber = 1 / GAME_BRICK_LEVEL3_WIDTH_PERCENTAGE;
            
            for(int i=0; i < brickNumber; i++)
            {
                if(i == 0 || i == (int)brickNumber)
                {
                    numberOfRows = GAME_NUMBER_OF_BRICK_ROWS - 1;
                }
                else if(i == (int)(brickNumber / 2.0f))
                {
                    numberOfRows = GAME_NUMBER_OF_BRICK_ROWS;
                }
                else if(i == (int)(brickNumber / 2.0f) - 1 || i == (int)(brickNumber / 2.0f) + 1)
                {
                    numberOfRows = GAME_NUMBER_OF_BRICK_ROWS - 2;
                }
                else
                {
                    numberOfRows = GAME_NUMBER_OF_BRICK_ROWS - 3;
                }
                
                for(int j=0; j < numberOfRows; j++)
                {
                    addGameObject(new Brick(i * brickWidth, (j+1) * brickHeight));
                    
                    GameData::getInstance() -> addBrick();
                }
            }
            
            break;
            
        case 4:
            brickWidth = screenWidth * GAME_BRICK_LEVEL4_WIDTH_PERCENTAGE;
            brickNumber = 1 / GAME_BRICK_LEVEL4_WIDTH_PERCENTAGE;
            
            startRow = 0;
            endRow = 0;
            
            for(int i = 1; i < brickNumber - 1; i++)
            {
                if(i == 1 || i == brickNumber - 2)
                {
                    startRow = GAME_NUMBER_OF_BRICK_ROWS - 3;
                    endRow = GAME_NUMBER_OF_BRICK_ROWS - 2;
                }
                else if(i == 2 || i == brickNumber - 3)
                {
                    startRow = GAME_NUMBER_OF_BRICK_ROWS - 4;
                    endRow = GAME_NUMBER_OF_BRICK_ROWS - 1;
                }
                else
                {
                    startRow = 0;
                    endRow = GAME_NUMBER_OF_BRICK_ROWS;
                }
                
                for(int j=startRow; j < endRow; j++)
                {
                    addGameObject(new Brick(i * brickWidth, (j+1) * brickHeight));
                    
                    GameData::getInstance() -> addBrick();
                }
            }
            
            break;
    }
}

void Game::changeLevel()
{
    GameData::getInstance() -> changeLevel();
    PlayerData::getInstance() -> gainLife();
    
    loadLevel();
    
    reset();
    
    getGameObjectByType(GAME_RECAP_TYPE) -> setIsActive(true);
    
    m_RecapTimer = GAME_RECAP_TIMER;
}

void Game::loadTextures()
{
    TextureManager::getInstance() -> addTexture("FirstDigit0");
    TextureManager::getInstance() -> addTexture("FirstDigit1");
    TextureManager::getInstance() -> addTexture("FirstDigit2");
    TextureManager::getInstance() -> addTexture("FirstDigit3");
    TextureManager::getInstance() -> addTexture("FirstDigit4");
    TextureManager::getInstance() -> addTexture("FirstDigit5");
    TextureManager::getInstance() -> addTexture("FirstDigit6");
    TextureManager::getInstance() -> addTexture("FirstDigit7");
    TextureManager::getInstance() -> addTexture("FirstDigit8");
    TextureManager::getInstance() -> addTexture("FirstDigit9");
    
    TextureManager::getInstance() -> addTexture("SecondDigit0");
    TextureManager::getInstance() -> addTexture("SecondDigit1");
    TextureManager::getInstance() -> addTexture("SecondDigit2");
    TextureManager::getInstance() -> addTexture("SecondDigit3");
    TextureManager::getInstance() -> addTexture("SecondDigit4");
    TextureManager::getInstance() -> addTexture("SecondDigit5");
    TextureManager::getInstance() -> addTexture("SecondDigit6");
    TextureManager::getInstance() -> addTexture("SecondDigit7");
    TextureManager::getInstance() -> addTexture("SecondDigit8");
    TextureManager::getInstance() -> addTexture("SecondDigit9");
    
    TextureManager::getInstance() -> addTexture("LevelText");
    TextureManager::getInstance() -> addTexture("LivesText");
    TextureManager::getInstance() -> addTexture("PressRText");
    TextureManager::getInstance() -> addTexture("WinText");
    TextureManager::getInstance() -> addTexture("GameOverText");
    
    TextureManager::getInstance() -> addTexture("GameOverBackground");
    TextureManager::getInstance() -> addTexture("RecapBackground");
    TextureManager::getInstance() -> addTexture("WinBackground");
    
    TextureManager::getInstance() -> addTexture("Ball");
    TextureManager::getInstance() -> addTexture("Paddle");
    TextureManager::getInstance() -> addTexture("Brick");
    
    TextureManager::getInstance() -> addTexture("Background");
}

void Game::removeBricks()
{
    int numberOfBricksRemoved = 0;
    GameObject* buffer = NULL;
    
    GameData::getInstance() -> resetNumberOfBricks();
    
    //Cycle through and deletes the bricks
    for(unsigned int i = 0; i < m_GameObjects.size(); i++)
    {
        if(m_GameObjects.at(i) != NULL && strcmp(m_GameObjects.at(i)->getType(), GAME_BRICK_TYPE) == 0)
        {
            delete m_GameObjects.at(i);
            m_GameObjects.at(i) = NULL;
            
            numberOfBricksRemoved++;
            
            buffer = m_GameObjects.at(m_GameObjects.size() - numberOfBricksRemoved);
            m_GameObjects.at(m_GameObjects.size() - numberOfBricksRemoved) = m_GameObjects.at(i);
            m_GameObjects.at(i) = buffer;
            
            i--;
        }
    }
    
    if(numberOfBricksRemoved > 0)
    {
        for(unsigned int i = 0; i < numberOfBricksRemoved; i++)
        {
            m_GameObjects.pop_back();
        }
    }
    
    getGameObjectByType(GAME_BRICK_TYPE);
}

void Game::bricksDestroyedEvent()
{
	if(GameData::getInstance() -> getLevel() < GAME_MAX_LEVEL)
        changeLevel();
    else
        win();
}
