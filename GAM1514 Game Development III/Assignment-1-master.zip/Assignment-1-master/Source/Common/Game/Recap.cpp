//
//  Student:        Quentin Bellay
//  Creation Date:  September 17th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the Recap screen
//                  displayed when the player dies or changes level
//  Modified:
//

#include "Recap.h"
#include "PlayerData.h"
#include "../Constants/Constants.h"
#include "../Screen Manager/ScreenManager.h"
#include "../OpenGL/OpenGL.h"


Recap::Recap() : GameObject()
{
    
}

Recap::~Recap()
{
    
}

void Recap::update(double aDelta)
{
    
}

void Recap::paint()
{
    OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("RecapBackground"), getX(), getY(), getWidth(), getHeight());
    OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("LivesText"), getX(), getY(), getWidth(), getHeight());
    OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("LevelText"), getX(), getY(), getWidth(), getHeight());
    
    switch(GameData::getInstance() -> getLevel() / 10)
    {
        case 0:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("FirstDigit0"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 1:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("FirstDigit1"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 2:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("FirstDigit2"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 3:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("FirstDigit3"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 4:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("FirstDigit4"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 5:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("FirstDigit5"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 6:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("FirstDigit6"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 7:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("FirstDigit7"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 8:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("FirstDigit8"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 9:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("FirstDigit9"), getX(), getY(), getWidth(), getHeight());
            break;
    }
    
    switch(GameData::getInstance() -> getLevel() % 10)
    {
        case 0:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("SecondDigit0"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 1:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("SecondDigit1"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 2:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("SecondDigit2"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 3:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("SecondDigit3"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 4:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("SecondDigit4"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 5:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("SecondDigit5"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 6:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("SecondDigit6"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 7:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("SecondDigit7"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 8:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("SecondDigit8"), getX(), getY(), getWidth(), getHeight());
            break;
            
        case 9:
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("SecondDigit9"), getX(), getY(), getWidth(), getHeight());
            break;
    }
    
    int endOfLine = 9;
    int drawnBalls = 0;
    
    bool end = false;
    
    float startY = getY() + getHeight() / 2.0f + 75.0f;
    
    float ballWidth = ScreenManager::getInstance() -> getScreenWidth() * GAME_BALL_RADIUS_PERCENTAGE;
    
    if(PlayerData::getInstance() -> getLife() > 9)
    {
        startY -= ballWidth * 5.0f/4.0f;
        
        if(PlayerData::getInstance() -> getLife() > 18)
        {
            startY -= ballWidth * 5.0f/4.0f;
        }
    }
    
    while(!end)
    {
        if(PlayerData::getInstance() -> getLife() > endOfLine + drawnBalls)
        {
            endOfLine = 9;
        }
        else
        {
            endOfLine = PlayerData::getInstance() -> getLife() - drawnBalls;
            
            end = true;
        }
        
        float startX = getX() + getWidth() / 2.0f - (endOfLine - 1) * ballWidth * 5.0f/4.0f;
        
        for(int i = 0; i < endOfLine; i++)
        {
            OpenGLRenderer::getInstance()->drawTexture(TextureManager::getInstance() -> getTextureWithName("Ball"), startX + i * ballWidth * 2.5f - ballWidth, startY - ballWidth, 2.0f * ballWidth, 2.0f * ballWidth);
            
            drawnBalls++;
        }
        
        startY += 2.5f * ballWidth;
    }
}

void Recap::reset()
{
    //Get the screen width and height
    float screenWidth = ScreenManager::getInstance()->getScreenWidth();
    float screenHeight = ScreenManager::getInstance()->getScreenHeight();
    
    //Reset the GameOver's width and height
    setWidth(screenWidth * GAME_OVER_WIDTH_PERCENTAGE);
    setHeight(screenHeight * GAME_OVER_HEIGHT_PERCENTAGE);
    
    //Reset the x and y position
    setX((screenWidth - getWidth()) / 2.0f);
    setY(screenHeight * GAME_OVER_Y_PERCENTAGE - getHeight() / 2.0f);
    
    //Reset the GameOver to active
    setIsActive(false);
}

const char* Recap::getType()
{
    return GAME_RECAP_TYPE;
}

void Recap::setSize(float aWidth, float aHeight)
{
    setWidth(aWidth);
    setHeight(aHeight);
}

void Recap::setWidth(float aWidth)
{
    m_Width = aWidth;
}

void Recap::setHeight(float aHeight)
{
    m_Height = aHeight;
}

void Recap::getSize(float &aWidth, float &aHeight)
{
    aWidth = getWidth();
    aHeight = getHeight();
}

float Recap::getWidth()
{
    return m_Width;
}

float Recap::getHeight()
{
    return m_Height;
}
