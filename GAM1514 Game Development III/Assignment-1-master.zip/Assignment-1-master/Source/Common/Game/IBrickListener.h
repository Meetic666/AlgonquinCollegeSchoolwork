//
//  Student:        Quentin Bellay
//  Creation Date:  September 26th, 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Interface for listening to the event of a brick being destroyed
//  Modified:
//

#ifndef I_BRICK_LISTENER_H
#define I_BRICK_LISTENER_H

//IBrickListener class takes care of event concerning the bricks
class IBrickListener
{
public:
	virtual ~IBrickListener();

    virtual void bricksDestroyedEvent() = 0;
};

#endif