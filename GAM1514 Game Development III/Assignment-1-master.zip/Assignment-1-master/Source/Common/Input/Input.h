//
//  Input.h
//  GAM-1532 OSX Game
//
//  Created by Bradley Flood on 2013-01-07.
//  Copyright (c) 2013 Algonquin College. All rights reserved.
//

#ifndef INPUT_H
#define INPUT_H

#include "InputManager.h"
#include "InputListener.h"
#include "InputConstants.h"

#endif
