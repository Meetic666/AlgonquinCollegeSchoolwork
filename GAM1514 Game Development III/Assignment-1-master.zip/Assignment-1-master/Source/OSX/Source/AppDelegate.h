//
//  AppDelegate.h
//  GAM-1532 OSX Game
//
//  Created by Bradley Flood on 2012-12-19.
//  Copyright (c) 2012 Algonquin College. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
