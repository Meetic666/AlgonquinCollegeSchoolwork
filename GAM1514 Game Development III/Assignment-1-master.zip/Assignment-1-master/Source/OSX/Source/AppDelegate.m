//
//  AppDelegate.m
//  GAM-1532 OSX Game
//
//  Created by Bradley Flood on 2012-12-19.
//  Copyright (c) 2012 Algonquin College. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

- (void)dealloc
{
  [super dealloc];
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{

}

@end
