#include "GameConstants.h"


//Game Constants
const char* GAME_SCREEN_NAME = "Game";
const float INTEREST_PER_ITERATION = 0.01f;
const float FEDERAL_RESERVE_ALLOWANCE = 1000;
const double INTEREST_TIMER = 1.0;
const float SCORE_PERCENTAGE_X = 0.01f;
const float TIME_PERCENTAGE_X = 0.5f;
const float GOLD_PERCENTAGE_X = 0.99f;
const float LEVEL_PERCENTAGE_X = 0.05f;
const float WAVE_PERCENTAGE_X = 0.95f;
const float HUD_PERCENTAGE_Y = 0.01f;

//Tiles Constants
const char* TILE_BUSH_TYPE = "BushTile";
const char* TILE_RIVER_TYPE = "RiverTile";
const char* TILE_DESERT_TYPE = "DesertTile";
const char* TILE_BRIDGE_TYPE = "BridgeTile";
const char* TILE_ROAD_TYPE = "RoadTile";
const char* TILE_FENCE_TYPE = "FenceTile";
const char* TILE_EXPLODED_TYPE = "ExplodedTile";
const char* TILE_RESERVE_TYPE = "GoldReserveType";
const int TILE_PADDING = 2;

//Player Constants
const int PLAYER_SIZE = 24;
const float PLAYER_SPEED = 150.0f;
const OpenGLColor PLAYER_INSIDE_COLOR = OpenGLColor(0.0f, 0.0f, 0.0f, 1.0f);
const OpenGLColor PLAYER_OUTLINE_COLOR = OpenGLColor(1.0f, 1.0f, 1.0f, 1.0f);
const int PLAYER_HEALTH = 100;
const int BASIC_DAMAGE = 100;
const float BASIC_PROJECTILE_SPEED = 100.0f;

//Hero constants
const char* HERO_TYPE = "Hero";

//Enemy constants
const char* ENEMY_TYPE = "Enemy";
const OpenGLColor ENEMY_INSIDE_COLOR = OpenGLColor(1.0f, 0.0f, 0.0f, 1.0f);
const OpenGLColor ENEMY_OUTLINE_COLOR = OpenGLColor(1.0f, 1.0f, 1.0f, 1.0f);
const int ENEMY_COUNT = 100;
const int ENEMY_COUNT_WAVE = 10;
const double WAVE_TIME = 2.0;
const double TIME_BETWEEN_WAVES = 10.0;
const float BULLDOZER_SPEED = 25.0f;
const char* BULLDOZER_TYPE = "Bulldozer";
const float BOMBER_SPEED = 75.0f;
const char* BOMBER_TYPE = "Bomber";
const int STOLEN_GOLD_AMOUNT_PER_ITERATION = 100;
const double STEALING_TIMER = 1.0;
const int ENEMY_SCORE_AMOUNT = 100;
const int BOMBER_SCORE_AMOUNT = 500;
const int BULLDOZER_SCORE_AMOUNT = 1000;
const int ENEMY_HEALTH = 50;
const int BOMBER_HEALTH = 100;
const int BULLDOZER_HEALTH = 1000;

//Towers constants
const float MACHINE_GUN_FIRING_RATE = 10.0f;
const int MACHINE_GUN_RANGE = 100;
const float MACHINE_GUN_PROJECTILE_SPEED = 200.0f;
const int MACHINE_GUN_DAMAGE = 10;
const char* MACHINE_GUN_TYPE = "Machine Gun";
const int MACHINE_GUN_PRICE = 100;
const float SNIPER_FIRING_RATE = 1.0f;
const int SNIPER_RANGE = 400;
const float SNIPER_PROJECTILE_SPEED = 400;
const int SNIPER_DAMAGE = 50;
const char* SNIPER_TYPE = "Sniper";
const int SNIPER_PRICE = 1000;
const int SNIPER_UNLOCK_PRICE = 50000;
const float ROCKET_LAUNCHER_FIRING_RATE = 1.0f/4.0f;
const int ROCKET_LAUNCHER_RANGE = 100;
const float ROCKET_LAUNCHER_PROJECTILE_SPEED = 50.0f;
const int ROCKET_LAUNCHER_DAMAGE = 100;
const char* ROCKET_LAUNCHER_TYPE = "Rocket Launcher";
const int ROCKET_LAUNCHER_PRICE = 10000;
const int ROCKET_LAUNCHER_UNLOCK_PRICE = 500000;
const float TOWER_SNIPER_FIRING_RATE = 2.0f;
const int TOWER_SNIPER_RANGE = 600;
const float TOWER_SNIPER_PROJECTILE_SPEED = 400;
const int TOWER_SNIPER_DAMAGE = 50;
const char* TOWER_SNIPER_TYPE = "Tower Sniper";
const int TOWER_SNIPER_PRICE = 500;
const float TOWER_GATLING_GUN_FIRING_RATE = 50.0f;
const int TOWER_GATLING_GUN_RANGE = 200;
const float TOWER_GATLING_GUN_PROJECTILE_SPEED = 400;
const int TOWER_GATLING_GUN_DAMAGE = 20;
const char* TOWER_GATLING_GUN_TYPE = "Tower Gatling Gun";
const int TOWER_GATLING_GUN_PRICE = 5000;
const int TOWER_GATLING_GUN_UNLOCK_PRICE = 100000;
const float TOWER_CARPET_BOMBING_FIRING_RATE = 1.0f/10.0f;
const int TOWER_CARPET_BOMBING_RANGE = 600;
const float TOWER_CARPET_BOMBING_PROJECTILE_SPEED = 10.0f;
const int TOWER_CARPET_BOMBING_DAMAGE = 1000;
const char* TOWER_CARPET_BOMBING_TYPE = "Tower Carpet Bombing";
const int TOWER_CARPET_BOMBING_PRICE = 50000;
const int TOWER_CARPET_BOMBING_UNLOCK_PRICE = 1000000;
const int OFFICER_RANGE_UPGRADE = 50;
const int OFFICER_RANGE_UPGRADE_PRICE = 5000;
const int OFFICER_DAMAGE_UPGRADE = 5;
const int OFFICER_DAMAGE_UPGRADE_PRICE = 5000;
const int OFFICER_FIRING_RATE_UPGRADE = 1.5f;
const int OFFICER_FIRING_RATE_UPGRADE_PRICE = 5000;
const int TOWER_RANGE_UPGRADE = 100;
const int TOWER_RANGE_UPGRADE_PRICE = 10000;
const int TOWER_DAMAGE_UPGRADE = 10;
const int TOWER_DAMAGE_UPGRADE_PRICE = 10000;
const int TOWER_FIRING_RATE_UPGRADE = 2.0f;
const int TOWER_FIRING_RATE_UPGRADE_PRICE = 10000;
const int OBSTACLE_PATH_WEIGHT = 10;

//Spawn Point constants
const OpenGLColor SPAWNPOINT_OUTLINE_COLOR = OpenGLColor(0.0f, 0.0f, 1.0f, 1.0f);

//Game Data constants
const int NUMBER_OF_HIGHSCORES = 10;
const unsigned char EASY_DIFFICULTY = 1;
const unsigned char MEDIUM_DIFFICULTY = 2;
const unsigned char HARD_DIFFICULTY = 3;
const double SHORT_TIME = 90.0;
const double MEDIUM_TIME = 180.0;
const double LONG_TIME = 360.0;
const unsigned int STARTING_GOLD_RESERVE_LOW = 10000;
const unsigned int STARTING_GOLD_RESERVE_MEDIUM = 20000;
const unsigned int STARTING_GOLD_RESERVE_LARGE = 30000;
const unsigned int STARTING_AMMO_AMOUNT = 100;
const int SPEED_MULTIPLIER_SLOW = 1;
const int SPEED_MULTIPLIER_MEDIUM = 2;
const int SPEED_MULTIPLIER_FAST = 5;

// Pick Up constants
const char* AMMO_PICK_UP_TYPE = "Ammo Pick Up";

// Projectile constants
const char* PROJECTILE_TYPE = "Projectile";

// Particles constants
const char* PARTICLE_TYPE = "Particle";