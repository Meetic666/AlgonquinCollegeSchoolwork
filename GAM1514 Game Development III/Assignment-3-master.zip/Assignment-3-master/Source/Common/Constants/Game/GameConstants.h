#ifndef GAME_CONSTANTS_H
#define GAME_CONSTANTS_H

#include "../../OpenGL/OpenGLColor.h"

//Game Constants
extern const char* GAME_SCREEN_NAME;
extern const float INTEREST_PER_ITERATION;
extern const float FEDERAL_RESERVE_ALLOWANCE;
extern const double INTEREST_TIMER;
extern const float SCORE_PERCENTAGE_X;
extern const float TIME_PERCENTAGE_X;
extern const float GOLD_PERCENTAGE_X;
extern const float LEVEL_PERCENTAGE_X;
extern const float WAVE_PERCENTAGE_X;
extern const float HUD_PERCENTAGE_Y;

//Tile Constants
extern const char* TILE_BUSH_TYPE;
extern const char* TILE_RIVER_TYPE;
extern const char* TILE_DESERT_TYPE;
extern const char* TILE_BRIDGE_TYPE;
extern const char* TILE_ROAD_TYPE;
extern const char* TILE_FENCE_TYPE;
extern const char* TILE_EXPLODED_TYPE;
extern const char* TILE_RESERVE_TYPE;
extern const int TILE_PADDING;

//Player Constants
extern const int PLAYER_SIZE;
extern const float PLAYER_SPEED;
extern const OpenGLColor PLAYER_INSIDE_COLOR;
extern const OpenGLColor PLAYER_OUTLINE_COLOR;
extern const int PLAYER_HEALTH;
extern const int BASIC_DAMAGE;
extern const float BASIC_PROJECTILE_SPEED;

//Hero constants
extern const char* HERO_TYPE;

//Enemy constants
extern const char* ENEMY_TYPE;
extern const OpenGLColor ENEMY_INSIDE_COLOR;
extern const OpenGLColor ENEMY_OUTLINE_COLOR;
extern const int ENEMY_COUNT;
extern const int ENEMY_COUNT_WAVE;
extern const double WAVE_TIME;
extern const double TIME_BETWEEN_WAVES;
extern const float BULLDOZER_SPEED;
extern const char* BULLDOZER_TYPE;
extern const float BOMBER_SPEED;
extern const char* BOMBER_TYPE;
extern const int STOLEN_GOLD_AMOUNT_PER_ITERATION;
extern const double STEALING_TIMER;
extern const int ENEMY_SCORE_AMOUNT;
extern const int BOMBER_SCORE_AMOUNT;
extern const int BULLDOZER_SCORE_AMOUNT;
extern const int ENEMY_HEALTH;
extern const int BOMBER_HEALTH;
extern const int BULLDOZER_HEALTH;

//Towers constants
extern const float MACHINE_GUN_FIRING_RATE;
extern const int MACHINE_GUN_RANGE;
extern const float MACHINE_GUN_PROJECTILE_SPEED;
extern const int MACHINE_GUN_DAMAGE;
extern const char* MACHINE_GUN_TYPE;
extern const int MACHINE_GUN_PRICE;
extern const float SNIPER_FIRING_RATE;
extern const int SNIPER_RANGE;
extern const float SNIPER_PROJECTILE_SPEED;
extern const int SNIPER_DAMAGE;
extern const char* SNIPER_TYPE;
extern const int SNIPER_PRICE;
extern const int SNIPER_UNLOCK_PRICE;
extern const float ROCKET_LAUNCHER_FIRING_RATE;
extern const int ROCKET_LAUNCHER_RANGE;
extern const float ROCKET_LAUNCHER_PROJECTILE_SPEED;
extern const int ROCKET_LAUNCHER_DAMAGE;
extern const char* ROCKET_LAUNCHER_TYPE;
extern const int ROCKET_LAUNCHER_PRICE;
extern const int ROCKET_LAUNCHER_UNLOCK_PRICE;
extern const float TOWER_SNIPER_FIRING_RATE;
extern const int TOWER_SNIPER_RANGE;
extern const float TOWER_SNIPER_PROJECTILE_SPEED;
extern const int TOWER_SNIPER_DAMAGE;
extern const char* TOWER_SNIPER_TYPE;
extern const int TOWER_SNIPER_PRICE;
extern const float TOWER_GATLING_GUN_FIRING_RATE;
extern const int TOWER_GATLING_GUN_RANGE;
extern const float TOWER_GATLING_GUN_PROJECTILE_SPEED;
extern const int TOWER_GATLING_GUN_DAMAGE;
extern const char* TOWER_GATLING_GUN_TYPE;
extern const int TOWER_GATLING_GUN_PRICE;
extern const int TOWER_GATLING_GUN_UNLOCK_PRICE;
extern const float TOWER_CARPET_BOMBING_FIRING_RATE;
extern const int TOWER_CARPET_BOMBING_RANGE;
extern const float TOWER_CARPET_BOMBING_PROJECTILE_SPEED;
extern const int TOWER_CARPET_BOMBING_DAMAGE;
extern const char* TOWER_CARPET_BOMBING_TYPE;
extern const int TOWER_CARPET_BOMBING_PRICE;
extern const int TOWER_CARPET_BOMBING_UNLOCK_PRICE;
extern const int OFFICER_RANGE_UPGRADE;
extern const int OFFICER_RANGE_UPGRADE_PRICE;
extern const int OFFICER_DAMAGE_UPGRADE;
extern const int OFFICER_DAMAGE_UPGRADE_PRICE;
extern const int OFFICER_FIRING_RATE_UPGRADE;
extern const int OFFICER_FIRING_RATE_UPGRADE_PRICE;
extern const int TOWER_RANGE_UPGRADE;
extern const int TOWER_RANGE_UPGRADE_PRICE;
extern const int TOWER_DAMAGE_UPGRADE;
extern const int TOWER_DAMAGE_UPGRADE_PRICE;
extern const int TOWER_FIRING_RATE_UPGRADE;
extern const int TOWER_FIRING_RATE_UPGRADE_PRICE;
extern const int OBSTACLE_PATH_WEIGHT;

//Spawn Point constants
extern const OpenGLColor SPAWNPOINT_OUTLINE_COLOR;

//Game Data constants
extern const int NUMBER_OF_HIGHSCORES;
extern const unsigned char EASY_DIFFICULTY;
extern const unsigned char MEDIUM_DIFFICULTY;
extern const unsigned char HARD_DIFFICULTY;
extern const double SHORT_TIME;
extern const double MEDIUM_TIME;
extern const double LONG_TIME;
extern const unsigned int STARTING_GOLD_RESERVE_LOW;
extern const unsigned int STARTING_GOLD_RESERVE_MEDIUM;
extern const unsigned int STARTING_GOLD_RESERVE_LARGE;
extern const unsigned int STARTING_AMMO_AMOUNT;
extern const int SPEED_MULTIPLIER_SLOW;
extern const int SPEED_MULTIPLIER_MEDIUM;
extern const int SPEED_MULTIPLIER_FAST;

// Pick Up constants
extern const char* AMMO_PICK_UP_TYPE;

// Projectile constants
extern const char* PROJECTILE_TYPE;

// Particles constants
extern const char* PARTICLE_TYPE;

#endif 