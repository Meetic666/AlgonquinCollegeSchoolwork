#include "ResourceConstants.h"


//Tile textures
const char* RES_SELECTED_TILE = "SelectedTile";
const char* RES_TILE_INDEX_NUMBERS[] = {"Tile0", "Tile1", "Tile2", "Tile3", "Tile4", "Tile5", "Tile6", "Tile7", "Tile8", "Tile9"};
const int RES_TILE_INDEX_NUMBERS_COUNT = 10;

//Tile number textures;
const char* RES_TILE_SCORE_NUMBERS[] = {"Numbers0", "Numbers1", "Numbers2", "Numbers3", "Numbers4", "Numbers5", "Numbers6", "Numbers7", "Numbers8", "Numbers9"};
const int RES_TILE_SCORE_NUMBERS_COUNT = 10;

//Tiles
const char* RES_TILE_BUSH = "TileBush";
const char* RES_TILE_RIVER = "TileRiver";
const char* RES_TILE_DESERT = "TileDesert";
const char* RES_TILE_BRIDGE = "TileBridge";
const char* RES_TILE_FENCE = "TileFence";
const char* RES_TILE_ROAD = "TileRoad";
const char* RES_TILE_EXPLODED = "TileExploded";
const char* RES_TILE_RESERVE = "TileGoldReserve";

//Menus
const char* RES_LOCK_OVERLAY = "LockOverlay";
const char* RES_UNTITLED_LABEL = "UntitledLabel";
const char* RES_LEVEL1_LABEL = "Level1Label";
const char* RES_LEVEL2_LABEL = "Level2Label";
const char* RES_LEVEL3_LABEL = "Level3Label";
const char* RES_LEVEL4_LABEL = "Level4Label";
const char* RES_LEVEL5_LABEL = "Level5Label";
const char* RES_LEVEL6_LABEL = "Level6Label";
const char* RES_ASTERISK_LABEL = "Asterisk";
const char* RES_MENU_BACKGROUND = "MenuFiltered";
const char* RES_SPLASH_BACKGROUND = "MainMenu";
const char* RES_PRESS_ANY_KEY_BUTTON = "PressAnyKey";
const char* RES_MAIN_MENU_LABEL = "MainMenuLabel";
const char* RES_RESUME_BUTTON = "ResumeButton";
const char* RES_START_GAME_BUTTON = "StartGameButton";
const char* RES_HIGHSCORES_BUTTON = "HighScoresButton";
const char* RES_LEVEL_EDITOR_BUTTON = "LevelEditorButton";
const char* RES_CHANGE_PROFILE_BUTTON = "ChangeProfileButton";
const char* RES_SETTINGS_BUTTON = "SettingsButton";
const char* RES_EXIT_BUTTON = "LargeExitButton";
const char* RES_HIGH_SCORES_LABEL = "HighscoresLabel";
const char* RES_TEXT_BOX_TEXTURE = "TextBoxBackground";
const char* RES_PROFILE_MENU_LABEL = "ProfileMenuLabel";
const char* RES_SETTINGS_MENU_LABEL = "SettingsLabel";
const char* RES_DIFFICULTY_BUTTON = "DifficultyButton";
const char* RES_TIME_LIMIT_BUTTON = "TimeLimitButton";
const char* RES_START_GOLD_BUTTON = "StartGoldButton";
const char* RES_GAME_OVER_MENU_LABEL = "GameOverLabel";
const char* RES_NEXT_LEVEL_BUTTON = "NextLevelButton";
const char* RES_LOAD_MENU_LABEL = "LoadLevelLabel";
const char* RES_LEVEL_WIN_MENU_LABEL = "LevelCompleteLabel";
const char* RES_GAME_WIN_MENU_LABEL = "WinLabel";
const char* RES_NEW_GAME_PLUS_BUTTON = "NewGamePlusButton";
const char* RES_RESTART_BUTTON = "RestartButton";

//Font constants
const char* RES_BITMAP_FONT = "BitmapFont";

// Game settings
const char* RES_GAME_DATA_FILENAME = "GameData";
const char* RES_HIGH_SCORES_FILE = "HighScores";

//Profiles constants
const char* RES_PROFILES_FILE_NAME = "Profiles";

//Speed multiplier
const char* RES_SPEED_MULTIPLIER_SLOW = "SpeedMultiplierSlow";
const char* RES_SPEED_MULTIPLIER_MEDIUM = "SpeedMultiplierMedium";
const char* RES_SPEED_MULTIPLIER_FAST = "SpeedMultiplierFast";

//Unit constants
const char* RES_BULLDOZER = "MexicanBulldozer";
const char* RES_WALKER = "MexicanWalker";
const char* RES_BOMBER = "MexicanBomber";
const char* RES_HERO = "Hero";
const char* RES_OFFICER_SNIPER = "OfficerSniper";
const char* RES_OFFICER_ROCKET_LAUNCHER = "OfficerRocketLauncher";
const char* RES_TOWER_SNIPER = "TowerSniper";
const char* RES_TOWER_GATLING_GUN = "TowerGatlingGun";
const char* RES_TOWER_CARPET_BOMBING = "TowerCarpetBombing";

//Pick Up Constants
const char* RES_PICK_UP_AMMO = "PowerUpAmmo";

//Particles constants
const char* RES_EXPLOSION = "Explosion";
const char* RES_SMOKE = "Smoke";

