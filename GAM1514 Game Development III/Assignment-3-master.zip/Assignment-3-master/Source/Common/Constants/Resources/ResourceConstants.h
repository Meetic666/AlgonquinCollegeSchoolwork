#ifndef RESOURCE_CONSTANTS_H
#define RESOURCE_CONSTANTS_H

//Tile textures
extern const char* RES_SELECTED_TILE;
extern const char* RES_TILE_INDEX_NUMBERS[];
extern const int RES_TILE_INDEX_NUMBERS_COUNT;

//Tile number textures;
extern const char* RES_TILE_SCORE_NUMBERS[];
extern const int RES_TILE_SCORE_NUMBERS_COUNT;

//Tiles
extern const char* RES_TILE_BUSH;
extern const char* RES_TILE_RIVER;
extern const char* RES_TILE_DESERT;
extern const char* RES_TILE_BRIDGE;
extern const char* RES_TILE_FENCE;
extern const char* RES_TILE_ROAD;
extern const char* RES_TILE_EXPLODED;
extern const char* RES_TILE_RESERVE;

//Menus
extern const char* RES_LOCK_OVERLAY;
extern const char* RES_UNTITLED_LABEL;
extern const char* RES_LEVEL1_LABEL;
extern const char* RES_LEVEL2_LABEL;
extern const char* RES_LEVEL3_LABEL;
extern const char* RES_LEVEL4_LABEL;
extern const char* RES_LEVEL5_LABEL;
extern const char* RES_LEVEL6_LABEL;
extern const char* RES_ASTERISK_LABEL;
extern const char* RES_MENU_BACKGROUND;
extern const char* RES_SPLASH_BACKGROUND;
extern const char* RES_PRESS_ANY_KEY_BUTTON;
extern const char* RES_MAIN_MENU_LABEL;
extern const char* RES_RESUME_BUTTON;
extern const char* RES_START_GAME_BUTTON;
extern const char* RES_HIGHSCORES_BUTTON;
extern const char* RES_LEVEL_EDITOR_BUTTON;
extern const char* RES_CHANGE_PROFILE_BUTTON;
extern const char* RES_SETTINGS_BUTTON;
extern const char* RES_EXIT_BUTTON;
extern const char* RES_HIGH_SCORES_LABEL;
extern const char* RES_TEXT_BOX_TEXTURE;
extern const char* RES_PROFILE_MENU_LABEL;
extern const char* RES_SETTINGS_MENU_LABEL;
extern const char* RES_DIFFICULTY_BUTTON;
extern const char* RES_TIME_LIMIT_BUTTON;
extern const char* RES_START_GOLD_BUTTON;
extern const char* RES_GAME_OVER_MENU_LABEL;
extern const char* RES_NEXT_LEVEL_BUTTON;
extern const char* RES_LOAD_MENU_LABEL;
extern const char* RES_LEVEL_WIN_MENU_LABEL;
extern const char* RES_GAME_WIN_MENU_LABEL;
extern const char* RES_NEW_GAME_PLUS_BUTTON;
extern const char* RES_RESTART_BUTTON;

//Font constants
extern const char* RES_BITMAP_FONT;

// Game settings
extern const char* RES_GAME_DATA_FILENAME;
extern const char* RES_HIGH_SCORES_FILE;

//Profiles constants
extern const char* RES_PROFILES_FILE_NAME;

//Speed multiplier
extern const char* RES_SPEED_MULTIPLIER_SLOW;
extern const char* RES_SPEED_MULTIPLIER_MEDIUM;
extern const char* RES_SPEED_MULTIPLIER_FAST;

//Unit constants
extern const char* RES_BULLDOZER;
extern const char* RES_WALKER;
extern const char* RES_BOMBER;
extern const char* RES_HERO;
extern const char* RES_OFFICER_SNIPER;
extern const char* RES_OFFICER_ROCKET_LAUNCHER;
extern const char* RES_TOWER_SNIPER;
extern const char* RES_TOWER_GATLING_GUN;
extern const char* RES_TOWER_CARPET_BOMBING;

//Pick Up Constants
extern const char* RES_PICK_UP_AMMO;

//Particles constants
extern const char* RES_EXPLOSION;
extern const char* RES_SMOKE;

#endif 