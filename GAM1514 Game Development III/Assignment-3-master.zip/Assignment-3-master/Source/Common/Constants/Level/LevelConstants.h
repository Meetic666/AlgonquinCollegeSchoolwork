//
//  LevelConstants.h
//  GAM-1532 OSX Game
//
//  Created by Bradley Flood on 2013-03-07.
//  Copyright (c) 2013 Algonquin College. All rights reserved.
//

#ifndef LEVEL_CONSTANTS_H
#define LEVEL_CONSTANTS_H

//Global enum for the Level's tile types,
//add additional tile types in this enum
enum TileType
{
    TileTypeDesert = 1,
    TileTypeBush = 2,
    TileTypeRiver = 4,
    TileTypeBridge = 8,
    TileTypeRoad = 16,
    TileTypeFence = 32,
	TileTypeExploded = 64,
	TileTypeReserve = 128,
    TileTypeCount = 8,
    TileTypeUnknown = -1
};

enum TileStyle
{
	Straight,
	Angled,
	TShaped,
	Cross
};

enum PickUpType
{
    PickUpTypeAmmo = 256,
    PickUpTypeCount = 1,
    PickUpTypeUnknown
};

enum TowerType
{
	OfficerMachineGunType,
	OfficerSniperType,
	OfficerRocketLauncherType,
	TowerSniperType,
	TowerGatlingGunType,
	TowerCarpetBombingType,
	TowerTypeCount,
	TowerTypeUnknown
};

//Level editor screen name
extern const char* LEVEL_EDITOR_SCREEN_NAME;

//Empty Level Constants
extern const int EMPTY_LEVEL_TILE_SIZE;
extern const int EMPTY_LEVEL_STARTING_PLAYER_TILE_INDEX;

//Save Slots
extern const char* LEVEL_SLOTS[6];

#endif
