//
//  MenuConstants.cpp
//  GAM-1514 OSX Game
//
//  Created by Bradley Flood on 2013-10-08.
//  Copyright (c) 2013 Algonquin College. All rights reserved.
//

#include "MenuConstants.h"


const float UI_SIDE_MENU_SPEED = 750.0f;

const float MENU_TITLE_Y_PERCENTAGE = 0.078125f;
const float MENU_ITEMS_STARTING_Y_PERCENTAGE = 0.3527f;
const float MENU_ITEMS_SPACER_PERCENTAGE = 0.1171875f;

const float LEVEL_LABEL_PERCENTAGE_X = 0.5f;
const float LEVEL_LABEL_PERCENTAGE_Y = 0.01f;
const float SPLASH_LABEL_PERCENTAGE_X = 0.5f;
const float SPLASH_LABEL_PERCENTAGE_Y = 0.9f;
const float SETTINGS_LABEL_PERCENTAGE_X = 0.8f;

const char* MAIN_MENU_SCREEN_NAME = "MainMenu";
const char* FILE_IO_SCREEN_NAME = "FileIOScreen";
const char* SPLASH_SCREEN_NAME = "SplashScreen";
const char* HIGHSCORE_SCREEN_NAME = "HighscoreMenu";
const char* PROFILE_SCREEN_NAME = "ProfileMenu";
const char* SETTINGS_SCREEN_NAME = "SettingsMenu";
const char* LEVEL_COMPLETE_SCREEN_NAME = "LevelCompleteMenu";
const char* GAME_OVER_SCREEN_NAME = "GameOverMenu";
const char* GAME_COMPLETE_SCREEN_NAME = "GameCompleteMenu";

const char* MENU_TILE_DESERT = "MenuTileDesert";
const char* MENU_TILE_BUSH = "MenuTileBush";
const char* MENU_TILE_RIVER = "MenuTileRiver";
const char* MENU_TILE_BRIDGE = "MenuTileBridge";
const char* MENU_TILE_ROAD = "MenuTileRoad";
const char* MENU_TILE_FENCE = "MenuTileFence";
const char* MENU_CLEAR_BUTTON = "ClearButton";
const char* MENU_LOAD_BUTTON = "LoadButton";
const char* MENU_SAVE_BUTTON = "SaveButton";
const char* MENU_EXIT_BUTTON = "ExitButton";
const char* MENU_SLOT1_BUTTON = "Slot1Button";
const char* MENU_SLOT2_BUTTON = "Slot2Button";
const char* MENU_SLOT3_BUTTON = "Slot3Button";
const char* MENU_SLOT4_BUTTON = "Slot4Button";
const char* MENU_SLOT5_BUTTON = "Slot5Button";
const char* MENU_SLOT6_BUTTON = "Slot6Button";
const char* MENU_SAVE_LABEL = "SaveLabel";
const char* MENU_YES_BUTTON = "YesButton";
const char* MENU_NO_BUTTON = "NoButton";
const char* MENU_BACK_BUTTON = "BackButton";
const char* MENU_LONG_BUTTON = "LongButton";
const char* MENU_NEW_BUTTON = "NewButton";
const char* MENU_TOWER_BUTTON = "MenuTowerButton";
const char* MENU_OFFICER_BUTTON = "MenuOfficerButton";
const char* MENU_GAME_RESUME_BUTTON = "MenuResumeButton";
const char* MENU_GAME_EXIT_BUTTON = "MenuExitButton";

const char* MENU_OFFICER_ROCKET_LAUNCHER = "MenuOfficerRocketLauncher";
const char* MENU_OFFICER_MACHINE_GUN = "MenuOfficerMachineGun";
const char* MENU_OFFICER_SNIPER = "MenuOfficerSniper";
const char* MENU_TOWER_SNIPER = "MenuTowerSniper";
const char* MENU_TOWER_GATLING_GUN = "MenuTowerGatlingGun";
const char* MENU_TOWER_CARPET_BOMBING = "MenuTowerCarpetBombing";
const char* MENU_LOCK_OVERLAY = "MenuLock";
const char* MENU_RANGE_UPGRADE = "MenuRange";
const char* MENU_DAMAGE_UPGRADE = "MenuDamage";
const char* MENU_FIRING_RATE_UPGRADE = "MenuFiringRate";

const int MAX_TEXT_BOX_LENGTH = 10;