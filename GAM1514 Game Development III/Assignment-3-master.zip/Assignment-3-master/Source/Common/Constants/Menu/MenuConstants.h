//
//  MenuConstants.h
//  GAM-1514 OSX Game
//
//  Created by Bradley Flood on 2013-10-08.
//  Copyright (c) 2013 Algonquin College. All rights reserved.
//

#ifndef __GAM_1514_OSX_Game__MenuConstants__
#define __GAM_1514_OSX_Game__MenuConstants__

extern const float UI_SIDE_MENU_SPEED;

extern const float MENU_TITLE_Y_PERCENTAGE;
extern const float MENU_ITEMS_STARTING_Y_PERCENTAGE;
extern const float MENU_ITEMS_SPACER_PERCENTAGE;

extern const float LEVEL_LABEL_PERCENTAGE_X;
extern const float LEVEL_LABEL_PERCENTAGE_Y;
extern const float SPLASH_LABEL_PERCENTAGE_X;
extern const float SPLASH_LABEL_PERCENTAGE_Y;
extern const float SETTINGS_LABEL_PERCENTAGE_X;

extern const char* MAIN_MENU_SCREEN_NAME;
extern const char* FILE_IO_SCREEN_NAME;
extern const char* SPLASH_SCREEN_NAME;
extern const char* HIGHSCORE_SCREEN_NAME;
extern const char* PROFILE_SCREEN_NAME;
extern const char* SETTINGS_SCREEN_NAME;
extern const char* LEVEL_COMPLETE_SCREEN_NAME;
extern const char* GAME_OVER_SCREEN_NAME;
extern const char* GAME_COMPLETE_SCREEN_NAME;

extern const char* MENU_TILE_DESERT;
extern const char* MENU_TILE_BUSH;
extern const char* MENU_TILE_RIVER;
extern const char* MENU_TILE_BRIDGE;
extern const char* MENU_TILE_ROAD;
extern const char* MENU_TILE_FENCE;
extern const char* MENU_CLEAR_BUTTON;
extern const char* MENU_LOAD_BUTTON;
extern const char* MENU_SAVE_BUTTON;
extern const char* MENU_EXIT_BUTTON;
extern const char* MENU_SLOT1_BUTTON;
extern const char* MENU_SLOT2_BUTTON;
extern const char* MENU_SLOT3_BUTTON;
extern const char* MENU_SLOT4_BUTTON;
extern const char* MENU_SLOT5_BUTTON;
extern const char* MENU_SLOT6_BUTTON;
extern const char* MENU_SAVE_LABEL;
extern const char* MENU_YES_BUTTON;
extern const char* MENU_NO_BUTTON;
extern const char* MENU_BACK_BUTTON;
extern const char* MENU_LONG_BUTTON;
extern const char* MENU_NEW_BUTTON;
extern const char* MENU_TOWER_BUTTON;
extern const char* MENU_OFFICER_BUTTON;
extern const char* MENU_GAME_RESUME_BUTTON;
extern const char* MENU_GAME_EXIT_BUTTON;

extern const char* MENU_OFFICER_ROCKET_LAUNCHER;
extern const char* MENU_OFFICER_MACHINE_GUN;
extern const char* MENU_OFFICER_SNIPER;
extern const char* MENU_TOWER_SNIPER;
extern const char* MENU_TOWER_GATLING_GUN;
extern const char* MENU_TOWER_CARPET_BOMBING;
extern const char* MENU_LOCK_OVERLAY;
extern const char* MENU_RANGE_UPGRADE;
extern const char* MENU_DAMAGE_UPGRADE;
extern const char* MENU_FIRING_RATE_UPGRADE;

extern const int MAX_TEXT_BOX_LENGTH;

#endif /* defined(__GAM_1514_OSX_Game__MenuConstants__) */
