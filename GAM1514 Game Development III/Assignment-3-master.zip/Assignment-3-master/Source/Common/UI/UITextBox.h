//
//  Student:        Quentin Bellay
//  Creation Date:  December 3rd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the text box widget
//  Modified:       
//

#ifndef UITEXTBOX_H
#define UITEXTBOX_H

#include "UIWidgets.h"

class UITextBox : public UIButton
{
public:
	UITextBox();
	~UITextBox();

	void mouseMovementEvent(float positionX, float positionY);
    void mouseLeftClickUpEvent(float positionX, float positionY);
    
    void keyUpEvent(int keyCode);

	const char* getText();

private:
    char getMatchingCharacter(int keyCode);
    
	int m_Length;
};

#endif