//
//  Student:        Quentin Bellay
//  Creation Date:  November 28th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the font
//  Modified:       
//

#ifndef UIFONT_H
#define UIFONT_H

#include <string>
#include <map>

class OpenGLTexture;

class UIFont
{
public:
	UIFont(const char* fontName, float spaceAmount = 10.0f);
	~UIFont();

	void draw(float x, float y);

	void setText(const char* text);
	const char* getText();

	float getWidth();
	float getHeight();

private:
	void parseFontData(const char* fontName);
	void calculateSize();

	struct UIFontFrame
	{
		unsigned int x;
		unsigned int y;
		unsigned int width;
		unsigned int height;
	};

	UIFontFrame* getFontFrame(std::string character);

	OpenGLTexture* m_Font;
	std::map<std::string, UIFontFrame*> m_FontData;
	std::string m_Text;
	float m_Width;
	float m_Height;
	float m_SpaceAmount;
};

#endif