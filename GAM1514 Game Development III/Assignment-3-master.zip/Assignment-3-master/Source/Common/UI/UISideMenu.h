//
//  UISideMenu.h
//  GAM-1514 OSX Game
//
//  Created by Bradley Flood on 2013-10-25.
//  Copyright (c) 2013 Algonquin College. All rights reserved.
//

#ifndef __GAM_1514_OSX_Game__UISideMenu__
#define __GAM_1514_OSX_Game__UISideMenu__

#include "UIToggle.h"
#include "../OpenGL/OpenGL.h"
#include <stdlib.h>
#include <vector>

enum SideMenuOrientation
{
    SideMenuLeft = 0,
    SideMenuRight
};

enum SideMenuState
{
    SideMenuClosed = 0,
    SideMenuClosing,
    SideMenuOpen,
    SideMenuOpening
};

class UISideMenuListener;

class UISideMenu : public UIToggleListener
{
public:
    UISideMenu(UISideMenuListener* listener, SideMenuOrientation orientation);
    ~UISideMenu();
    
    void update(double delta);
    void paint();
    
    void mouseMovementEvent(float deltaX, float deltaY, float positionX, float positionY);
    bool mouseLeftClickUpEvent(float positionX, float positionY); // Returns wether the menu caught the click
	bool mouseLeftClickDownEvent(float positionX, float positionY); // Returns wether the menu caught the click
    void keyUpEvent(int keyCode);
    
    void show();
    void hide();
    bool isShowing();
    
    void addButton(UIButton* button);
    int getIndexForButton(UIButton* button);
    UIButton* getButtonForIndex(int index);
    void clearButtons();

	SideMenuState getState();
    
private:
    void setState(SideMenuState state);
    
    void buttonAction(UIButton* button);
    void buttonIsSelected(UIButton* button);
    bool buttonShouldBeDeselectedOnExit(UIButton* button);
    void buttonWasToggled(UIToggle* button);
    
    UISideMenuListener* m_Listener;
    
    SideMenuState m_State;
    SideMenuOrientation m_Orientation;
    
    OpenGLColor m_BackgroundColor;
    
    float m_TargetX;
    float m_X;
    float m_Y;
    float m_Width;
    float m_Height;
    
    std::vector<UIButton*> m_Buttons;
    int m_SelectedButtonIndex;
};


class UISideMenuListener
{
public:
    virtual void sideMenuButtonAction(UISideMenu* sideMenu, UIButton* button, int buttonIndex) {};
    virtual void sideMenuToggleAction(UISideMenu* sideMenu, UIToggle* toggle, int toggleIndex) {};
};

#endif /* defined(__GAM_1514_OSX_Game__UISideMenu__) */
