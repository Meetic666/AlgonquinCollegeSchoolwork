//
//  Student:        Quentin Bellay
//  Creation Date:  December 3rd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the text box widget
//  Modified:       
//

#include "UITextBox.h"
#include "../Constants/Constants.h"
#include "../Input/Input.h"

UITextBox::UITextBox() : UIButton(RES_TEXT_BOX_TEXTURE)
{
	m_Length = 10;
}

UITextBox::~UITextBox()
{

}

void UITextBox::mouseMovementEvent(float positionX, float positionY)
{
	UIButton::mouseMovementEvent(positionX, positionY);
}

void UITextBox::mouseLeftClickUpEvent(float positionX, float positionY)
{
	UIButton::mouseLeftClickUpEvent(positionX, positionY);
}
    
void UITextBox::keyUpEvent(int keyCode)
{
	if(m_IsSelected)
	{
		if(keyCode == KEYCODE_DELETE)
		{
			std::string text = std::string(m_UIFont -> getText());
			text = text.substr(0, text.size() - 1);
			m_UIFont -> setText(text.c_str());
		}
		else if(keyCode >= KEYCODE_A && (keyCode <= KEYCODE_Z || keyCode <= KEYCODE_M))
		{
			std::string text = std::string(m_UIFont -> getText());
				
			if(text.size() < MAX_TEXT_BOX_LENGTH)
			{
                if(getMatchingCharacter(keyCode) != '@')
                {
                    text += getMatchingCharacter(keyCode);
                }
			}

			m_UIFont -> setText(text.c_str());
		}
	}
}

const char* UITextBox::getText()
{
	return m_UIFont -> getText();
}

char UITextBox::getMatchingCharacter(int keyCode)
{
    char result = (char) keyCode;
    
#ifdef __APPLE__
    
    switch(keyCode)
    {
        case kVK_ANSI_A:
            result = 'A';
            break;
            
        case kVK_ANSI_B:
            result = 'B';
            break;
            
        case kVK_ANSI_C:
            result = 'C';
            break;
            
        case kVK_ANSI_D:
            result = 'D';
            break;
            
        case kVK_ANSI_E:
            result = 'E';
            break;
            
        case kVK_ANSI_F:
            result = 'F';
            break;
            
        case kVK_ANSI_G:
            result = 'G';
            break;
            
        case kVK_ANSI_H:
            result = 'H';
            break;
            
        case kVK_ANSI_I:
            result = 'I';
            break;
            
        case kVK_ANSI_J:
            result = 'J';
            break;
            
        case kVK_ANSI_K:
            result = 'K';
            break;
            
        case kVK_ANSI_L:
            result = 'L';
            break;
            
        case kVK_ANSI_M:
            result = 'M';
            break;
            
        case kVK_ANSI_N:
            result = 'N';
            break;
            
        case kVK_ANSI_O:
            result = 'O';
            break;
            
        case kVK_ANSI_P:
            result = 'P';
            break;
            
        case kVK_ANSI_Q:
            result = 'Q';
            break;
            
        case kVK_ANSI_R:
            result = 'R';
            break;
            
        case kVK_ANSI_S:
            result = 'S';
            break;
            
        case kVK_ANSI_T:
            result = 'T';
            break;
            
        case kVK_ANSI_U:
            result = 'U';
            break;
            
        case kVK_ANSI_V:
            result = 'V';
            break;
            
        case kVK_ANSI_W:
            result = 'W';
            break;
            
        case kVK_ANSI_X:
            result = 'X';
            break;
            
        case kVK_ANSI_Y:
            result = 'Y';
            break;
            
        case kVK_ANSI_Z:
            result = 'Z';
            break;
            
        default:
			result = '@'; // Used for non letters character codes
            break;
    }
    
#endif
    
    return result;
}