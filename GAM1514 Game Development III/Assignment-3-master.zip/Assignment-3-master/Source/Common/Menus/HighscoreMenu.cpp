//
//  Student:        Quentin Bellay
//  Creation Date:  December 3rd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the highscore screen
//  Modified:       
//

#include "HighscoreMenu.h"
#include "../Screen Manager/ScreenManager.h"

HighscoreMenu::HighscoreMenu() : Menu(RES_MENU_BACKGROUND, RES_HIGH_SCORES_LABEL),
	m_UIFont(NULL)
{
	m_UIFont = new UIFont(RES_BITMAP_FONT);

	addButton(new UIButton(RES_EXIT_BUTTON));
}

HighscoreMenu::~HighscoreMenu()
{
	if(m_UIFont != NULL)
	{
		delete m_UIFont;
		m_UIFont = NULL;
	}
}

void HighscoreMenu::paint()
{
	Menu::paint();

	std::vector<unsigned int> highscores = GameData::getInstance() -> getHighScore();
	std::vector<std::string> names = GameData::getInstance() -> getNames();

	float centerX = getWidth() / 4.0f;
	float topHeight = getHeight() * 0.2f;
	float x = 0.0f;
	float y = topHeight;

	char text[20];
	std::string buffer;

	for(int i = 0; i < highscores.size(); i++)
	{
		if(highscores[i] > 0)
		{
			buffer = names[i];
			sprintf(text, "%u", highscores[i]);
			buffer += ": " + std::string(text);
			m_UIFont -> setText(buffer.c_str());
			x = centerX - m_UIFont -> getWidth() / 2.0f;
			m_UIFont -> draw(x, y);

			y += m_UIFont -> getHeight();

			if(i == 4)
			{
				centerX += getWidth() / 2.0f;
				y = topHeight;
			}
		}
	}
}

void HighscoreMenu::keyUpEvent(int keyCode)
{
	Menu::keyUpEvent(keyCode);

	if(keyCode == KEYCODE_ESCAPE)
	{
		ScreenManager::getInstance() -> switchScreen(MAIN_MENU_SCREEN_NAME);
	}
}
    
const char* HighscoreMenu::getName()
{
	return HIGHSCORE_SCREEN_NAME;
}

bool HighscoreMenu::buttonShouldBeDeselectedOnExit(UIButton* button)
{
	return true;
}

void HighscoreMenu::buttonAction(UIButton* button)
{
	int index = getIndexForButton(button);
	if(index == 0)
	{
		ScreenManager::getInstance() -> switchScreen(MAIN_MENU_SCREEN_NAME);
	}
}