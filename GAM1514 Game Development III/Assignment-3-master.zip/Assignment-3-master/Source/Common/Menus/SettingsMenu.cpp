//
//  Student:        Quentin Bellay
//  Creation Date:  December 4th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the settings screen
//  Modified:       
//

#include "SettingsMenu.h"
#include "../Screen Manager/ScreenManager.h"

SettingsMenu::SettingsMenu() : Menu(RES_MENU_BACKGROUND, RES_SETTINGS_MENU_LABEL),
	m_UIFont(NULL)
{
	m_UIFont = new UIFont(RES_BITMAP_FONT);

	addButton(new UIButton(RES_DIFFICULTY_BUTTON));
	addButton(new UIButton(RES_TIME_LIMIT_BUTTON));
	addButton(new UIButton(RES_START_GOLD_BUTTON));
	addButton(new UIButton(RES_EXIT_BUTTON));
}

SettingsMenu::~SettingsMenu()
{
	if(m_UIFont != NULL)
	{
		delete m_UIFont;
		m_UIFont = NULL;
	}
}

void SettingsMenu::paint()
{
	Menu::paint();

	float centerX = getWidth() * SETTINGS_LABEL_PERCENTAGE_X;
	float x = 0.0f;
	float y = 0.0f;

	char text[20];

	if(GameData::getInstance() -> getDifficulty() == EASY_DIFFICULTY)
	{
		sprintf(text, "Easy");
	}
	else if(GameData::getInstance() -> getDifficulty() == MEDIUM_DIFFICULTY)
	{
		sprintf(text, "Medium");
	}
	else if(GameData::getInstance() -> getDifficulty() == HARD_DIFFICULTY)
	{
		sprintf(text, "Hard");
	}

	m_UIFont -> setText(text);
	x = centerX - m_UIFont -> getWidth() / 2.0f;
	y = m_Buttons.at(0) -> getCenterY() - m_UIFont -> getHeight() / 2.0f;
	m_UIFont -> draw(x, y);


	int timeLimit = GameData::getInstance() -> getTimeLimit();

	if(timeLimit % 60 >= 10)
	{
		sprintf(text, "%u:%u", timeLimit / 60, timeLimit % 60);
	}
	else
	{
		sprintf(text, "%u:0%u", timeLimit / 60, timeLimit % 60);
	}

	m_UIFont -> setText(text);
	x = centerX - m_UIFont -> getWidth() / 2.0f;
	y = m_Buttons.at(1) -> getCenterY() - m_UIFont -> getHeight() / 2.0f;
	m_UIFont -> draw(x, y);


	sprintf(text, "%u Gold", GameData::getInstance() -> getStartingGold());
	m_UIFont -> setText(text);
	x = centerX - m_UIFont -> getWidth() / 2.0f;
	y = m_Buttons.at(2) -> getCenterY() - m_UIFont -> getHeight() / 2.0f;
	m_UIFont -> draw(x, y);
}

void SettingsMenu::keyUpEvent(int keyCode)
{
	Menu::keyUpEvent(keyCode);

	if(keyCode == KEYCODE_ESCAPE)
	{
		ScreenManager::getInstance() -> switchScreen(MAIN_MENU_SCREEN_NAME);
		
		GameData::getInstance() -> saveGame();
	}
}
    
const char* SettingsMenu::getName()
{
	return SETTINGS_SCREEN_NAME;
}

bool SettingsMenu::buttonShouldBeDeselectedOnExit(UIButton* button)
{
	return true;
}

void SettingsMenu::buttonAction(UIButton* button)
{
	int index = getIndexForButton(button);
	if(index == 0)
	{
		if(GameData::getInstance() -> getDifficulty() == EASY_DIFFICULTY)
		{
			GameData::getInstance() -> setDifficulty(MEDIUM_DIFFICULTY);
		}
		else if(GameData::getInstance() -> getDifficulty() == MEDIUM_DIFFICULTY)
		{
			GameData::getInstance() -> setDifficulty(HARD_DIFFICULTY);
		}
		else if(GameData::getInstance() -> getDifficulty() == HARD_DIFFICULTY)
		{
			GameData::getInstance() -> setDifficulty(EASY_DIFFICULTY);
		}
	}
	else if(index == 1)
	{
		if(GameData::getInstance() -> getTimeLimit() == SHORT_TIME)
		{
			GameData::getInstance() -> setTimeLimit(MEDIUM_TIME);
		}
		else if(GameData::getInstance() -> getTimeLimit() == MEDIUM_TIME)
		{
			GameData::getInstance() -> setTimeLimit(LONG_TIME);
		}
		else if(GameData::getInstance() -> getTimeLimit() == LONG_TIME)
		{
			GameData::getInstance() -> setTimeLimit(SHORT_TIME);
		}
	}
	else if(index == 2)
	{
		if(GameData::getInstance() -> getStartingGold() == STARTING_GOLD_RESERVE_LOW)
		{
			GameData::getInstance() -> setStartingGold(STARTING_GOLD_RESERVE_MEDIUM);
		}
		else if(GameData::getInstance() -> getStartingGold() == STARTING_GOLD_RESERVE_MEDIUM)
		{
			GameData::getInstance() -> setStartingGold(STARTING_GOLD_RESERVE_LARGE);
		}
		else if(GameData::getInstance() -> getStartingGold() == STARTING_GOLD_RESERVE_LARGE)
		{
			GameData::getInstance() -> setStartingGold(STARTING_GOLD_RESERVE_LOW);
		}
	}
	else if(index == 3)
	{
		ScreenManager::getInstance() -> switchScreen(MAIN_MENU_SCREEN_NAME);

		GameData::getInstance() -> saveGame();
	}
}