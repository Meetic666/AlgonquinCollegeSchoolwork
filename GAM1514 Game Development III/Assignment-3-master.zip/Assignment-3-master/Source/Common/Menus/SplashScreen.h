//
//  Student:        Quentin Bellay
//  Creation Date:  December 2nd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the splash screen
//  Modified:       
//

#ifndef __GAM_1514_OSX_Game__SplashScreen__
#define __GAM_1514_OSX_Game__SplashScreen__

#include "Menu.h"

// Class representing the splash screen
class SplashScreen : public Menu
{
public:
    SplashScreen();
    ~SplashScreen();
    
    const char* getName();
    
    virtual void mouseLeftClickUpEvent(float positionX, float positionY);
    
    virtual void keyUpEvent(int keyCode);
    
private:
    void buttonAction(UIButton* button);
};

#endif /* defined(__GAM_1514_OSX_Game__SplashScreen__) */
