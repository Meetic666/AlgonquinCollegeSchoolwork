//
//  Student:        Quentin Bellay
//  Creation Date:  December 3rd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the highscore screen
//  Modified:       
//

#ifndef __GAM_1514_OSX_Game__HighscoreMenu__
#define __GAM_1514_OSX_Game__HighscoreMenu__

#include "Menu.h"

// Class representing the highscore screen
class HighscoreMenu : public Menu
{
public:
    HighscoreMenu();
    ~HighscoreMenu();

	void paint();
    
    const char* getName();

	void keyUpEvent(int keyCode);

private:
    bool buttonShouldBeDeselectedOnExit(UIButton* button);
    void buttonAction(UIButton* button);

	UIFont* m_UIFont;
};

#endif /* defined(__GAM_1514_OSX_Game__MainMenu__) */