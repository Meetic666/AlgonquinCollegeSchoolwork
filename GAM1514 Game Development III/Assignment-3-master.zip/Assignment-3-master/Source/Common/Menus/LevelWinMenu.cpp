//
//  Student:        Quentin Bellay
//  Creation Date:  December 11th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the level complete screen
//  Modified:       
//

#include "LevelWinMenu.h"
#include "../UI/UIButton.h"
#include "../Game/Game.h"
#include "../Game/Level.h"
#include "../Screen Manager/ScreenManager.h"
#include "../Level Editor/LevelEditor.h"
#include "../Game/GameData.h"


LevelWinMenu::LevelWinMenu() : Menu(RES_MENU_BACKGROUND, RES_LEVEL_WIN_MENU_LABEL)
{
    addButton(new UIButton(RES_NEXT_LEVEL_BUTTON));
	addButton(new UIButton(RES_EXIT_BUTTON));
}

LevelWinMenu::~LevelWinMenu()
{

}

const char* LevelWinMenu::getName()
{
    return LEVEL_COMPLETE_SCREEN_NAME;
}

void LevelWinMenu::buttonAction(UIButton* button)
{
	Game* game = (Game*)ScreenManager::getInstance()->getScreenForName(GAME_SCREEN_NAME);

    int index = getIndexForButton(button);

	if(index == 0)
	{
		game -> getLevel() -> loadJSON(LEVEL_SLOTS[GameData::getInstance() -> getCurrentLevel() - 1]);

		game -> getLevel() -> setNumberOfWaves(GameData::getInstance() -> getCurrentWave());

		game -> setLevelTimer(GameData::getInstance() -> getTimeLimit());

		if(GameData::getInstance() -> getAmmo() == 0)
		{
			GameData::getInstance() -> setAmmo(STARTING_AMMO_AMOUNT);
		}
	
		ScreenManager::getInstance()->switchScreen(GAME_SCREEN_NAME);
	}
	else if(index == 1)
	{
		ScreenManager::getInstance()->switchScreen(MAIN_MENU_SCREEN_NAME);
	}
}