//
//  Student:        Quentin Bellay
//  Creation Date:  December 3rd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the profiles screen
//  Modified:       
//

#ifndef PROFILE_MENU_H
#define PROFILE_MENU_H

#include "Menu.h"

// Class representing the profiles screen
class ProfileMenu : public Menu
{
public:
    ProfileMenu();
    ~ProfileMenu();
    
	void keyUpEvent(int keyCode);

    const char* getName();

private:
    bool buttonShouldBeDeselectedOnExit(UIButton* button);
    void buttonAction(UIButton* button);

	UITextBox* m_UITextBox;
};

#endif