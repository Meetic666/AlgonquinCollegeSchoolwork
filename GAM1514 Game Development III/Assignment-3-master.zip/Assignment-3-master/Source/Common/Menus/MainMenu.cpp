//
//  Student:        Quentin Bellay
//  Creation Date:  October 7th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the main menu screen
//  Modified:       
//

#include "MainMenu.h"
#include "../UI/UIButton.h"
#include "../Game/Game.h"
#include "../Game/Level.h"
#include "../Screen Manager/ScreenManager.h"
#include "../Level Editor/LevelEditor.h"
#include "../Game/GameData.h"
#include "../Game/ProfileManager.h"


MainMenu::MainMenu() : Menu(RES_MENU_BACKGROUND, RES_MAIN_MENU_LABEL),
m_IsPlaying(false)
{
    addButton(new UIButton(RES_RESUME_BUTTON));
    addButton(new UIButton(RES_START_GAME_BUTTON));
    addButton(new UIButton(RES_HIGHSCORES_BUTTON));
    addButton(new UIButton(RES_LEVEL_EDITOR_BUTTON));
    addButton(new UIButton(RES_CHANGE_PROFILE_BUTTON));
    addButton(new UIButton(RES_SETTINGS_BUTTON));
    addButton(new UIButton(RES_EXIT_BUTTON));
}

MainMenu::~MainMenu()
{

}

const char* MainMenu::getName()
{
    return MAIN_MENU_SCREEN_NAME;
}

bool MainMenu::buttonShouldBeDeselectedOnExit(UIButton* button)
{
	return true;
}

void MainMenu::buttonAction(UIButton* button)
{
    int index = getIndexForButton(button);

	if(index == 0)
	{
		Game* game = (Game*)ScreenManager::getInstance()->getScreenForName(GAME_SCREEN_NAME);

		int levelNumber = GameData::getInstance() -> getCurrentLevel() - 1;

		if(levelNumber < GameData::getInstance() -> getNumberOfUnlockedLevels())
		{
            if(!m_IsPlaying)
            {
                game -> getLevel() -> loadJSON(LEVEL_SLOTS[levelNumber]);

                game -> getLevel() -> setNumberOfWaves(GameData::getInstance() -> getCurrentWave());

				if(GameData::getInstance() -> getAmmo() == 0)
				{
					GameData::getInstance() -> setAmmo(STARTING_AMMO_AMOUNT);
				}

				if(GameData::getInstance() -> getGoldReserve() == 0)
				{
					GameData::getInstance() -> setGoldReserve(FEDERAL_RESERVE_ALLOWANCE);
				}

				game -> setLevelTimer(GameData::getInstance() -> getTimeLimit());
            }
	
			ScreenManager::getInstance()->switchScreen(GAME_SCREEN_NAME);
		}
	}
    else if(index == 1)
    {
        ScreenManager::getInstance()->switchScreen(FILE_IO_SCREEN_NAME);
    }
    else if(index == 2)
    {
        ScreenManager::getInstance()->switchScreen(HIGHSCORE_SCREEN_NAME);
    }
    else if(index == 3)
    {
		LevelEditor* editor = (LevelEditor*) ScreenManager::getInstance()->getScreenForName(LEVEL_EDITOR_SCREEN_NAME);
		editor->openLatestLevel();

        ScreenManager::getInstance()->switchScreen(LEVEL_EDITOR_SCREEN_NAME);
    }
    else if(index == 4)
    {
        ScreenManager::getInstance()->switchScreen(PROFILE_SCREEN_NAME);
    }
    else if(index == 5)
    {
        ScreenManager::getInstance()->switchScreen(SETTINGS_SCREEN_NAME);
    }
    else if (index == 6)
    {
		GameData::getInstance() -> saveGame();
		GameData::getInstance() -> saveHighScores();
		ProfileManager::getInstance() -> saveProfiles();

        exit(1);
    }
}

void MainMenu::setIsPlaying(bool isPlaying)
{
    m_IsPlaying = isPlaying;
}
