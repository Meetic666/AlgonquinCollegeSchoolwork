//
//  Student:        Quentin Bellay
//  Creation Date:  December 4th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the settings screen
//  Modified:       
//

#ifndef __GAM_1514_OSX_Game__SettingsMenu__
#define __GAM_1514_OSX_Game__SettingsMenu__

#include "Menu.h"

// Class representing the settings screen
class SettingsMenu : public Menu
{
public:
    SettingsMenu();
    ~SettingsMenu();

	void paint();
    
    const char* getName();

	void keyUpEvent(int keyCode);

private:
    bool buttonShouldBeDeselectedOnExit(UIButton* button);
    void buttonAction(UIButton* button);

	UIFont* m_UIFont;
};

#endif /* defined(__GAM_1514_OSX_Game__MainMenu__) */