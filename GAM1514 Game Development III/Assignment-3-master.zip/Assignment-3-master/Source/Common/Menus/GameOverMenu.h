//
//  Student:        Quentin Bellay
//  Creation Date:  December 11th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the game over screen
//  Modified:       
//

#ifndef __GAM_1514_OSX_Game__GameOverMenu__
#define __GAM_1514_OSX_Game__GameOverMenu__

#include "Menu.h"

// Class representing the game over screen when losing a level
class GameOverMenu : public Menu
{
public:
    GameOverMenu();
    ~GameOverMenu();

    const char* getName();

private:
    void buttonAction(UIButton* button);
};

#endif /* defined(__GAM_1514_OSX_Game__GameOverMenu__) */