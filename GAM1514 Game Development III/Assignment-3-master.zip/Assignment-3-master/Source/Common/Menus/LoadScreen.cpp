//
//  Student:        Quentin Bellay
//  Creation Date:  November 6th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the loading screen when starting a new game
//  Modified:       
//

#include "LoadScreen.h"
#include "../UI/UIButton.h"
#include "../Game/Game.h"
#include "../Game/Level.h"
#include "../Screen Manager/ScreenManager.h"
#include "../Level Editor/LevelEditor.h"
#include "../Game/GameData.h"


LoadScreen::LoadScreen() : Menu(RES_MENU_BACKGROUND, RES_LOAD_MENU_LABEL)
{
    addButton(new UIButton(MENU_SLOT1_BUTTON, RES_LOCK_OVERLAY));
    addButton(new UIButton(MENU_SLOT2_BUTTON, RES_LOCK_OVERLAY));
    addButton(new UIButton(MENU_SLOT3_BUTTON, RES_LOCK_OVERLAY));
    addButton(new UIButton(MENU_SLOT4_BUTTON, RES_LOCK_OVERLAY));
    addButton(new UIButton(MENU_SLOT5_BUTTON, RES_LOCK_OVERLAY));
    addButton(new UIButton(MENU_SLOT6_BUTTON, RES_LOCK_OVERLAY));
	addButton(new UIButton(RES_EXIT_BUTTON));
}

LoadScreen::~LoadScreen()
{

}

void LoadScreen::update(double delta)
{
	for(int i = 0; i < m_Buttons.size() - 1; i++)
	{
		if(i < GameData::getInstance() ->getNumberOfUnlockedLevels())
		{
			m_Buttons.at(i) ->swapOverlay("");
		}
		else
		{
			m_Buttons.at(i) ->swapOverlay(RES_LOCK_OVERLAY);
		}
	}
}

const char* LoadScreen::getName()
{
    return FILE_IO_SCREEN_NAME;
}

void LoadScreen::buttonAction(UIButton* button)
{
	Game* game = (Game*)ScreenManager::getInstance()->getScreenForName(GAME_SCREEN_NAME);

    int index = getIndexForButton(button);

	if(index < GameData::getInstance() -> getNumberOfUnlockedLevels())
	{
		GameData::getInstance() -> setAmmo(STARTING_AMMO_AMOUNT);
		GameData::getInstance() -> setCurrentWave(1);
		GameData::getInstance() -> setGoldReserve(GameData::getInstance() -> getStartingGold());
		GameData::getInstance() -> setCurrentLevel(index + 1);
		GameData::getInstance() -> setScore(0);
		GameData::getInstance() -> setTowerTiersUnlocked(1);
		GameData::getInstance() -> setOfficerTiersUnlocked(1);
		GameData::getInstance() -> setTowerDamageUpgrade(0);
		GameData::getInstance() -> setTowerRangeUpgrade(0);
		GameData::getInstance() -> setTowerFiringRateUpgrade(0);
		GameData::getInstance() -> setOfficerDamageUpgrade(0);
		GameData::getInstance() -> setOfficerRangeUpgrade(0);
		GameData::getInstance() -> setOfficerFiringRateUpgrade(0);

		game -> getLevel() -> loadJSON(LEVEL_SLOTS[index]);

		game -> getLevel() -> setNumberOfWaves(GameData::getInstance() -> getCurrentWave());
		
		game -> setLevelTimer(GameData::getInstance() -> getTimeLimit());
	
		ScreenManager::getInstance()->switchScreen(GAME_SCREEN_NAME);
	}
	else if(index == 6)
	{
		ScreenManager::getInstance()->switchScreen(MAIN_MENU_SCREEN_NAME);
	}
}
