//
//  Student:        Quentin Bellay
//  Creation Date:  December 2nd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the splash screen
//  Modified:       
//

#include "SplashScreen.h"
#include "../UI/UIButton.h"
#include "../Game/Game.h"
#include "../Game/Level.h"
#include "../Screen Manager/ScreenManager.h"
#include "../Level Editor/LevelEditor.h"
#include "../Game/GameData.h"


SplashScreen::SplashScreen() : Menu(RES_SPLASH_BACKGROUND, NULL)
{
    
}

SplashScreen::~SplashScreen()
{
    
}

const char* SplashScreen::getName()
{
    return SPLASH_SCREEN_NAME;
}

void SplashScreen::mouseLeftClickUpEvent(float positionX, float positionY)
{
    ScreenManager::getInstance()->switchScreen(PROFILE_SCREEN_NAME);
}

void SplashScreen::keyUpEvent(int keyCode)
{
    ScreenManager::getInstance()->switchScreen(PROFILE_SCREEN_NAME);

	GameData::getInstance() -> setSaveFileName("GameData");

	GameData::getInstance() -> loadGame();
	GameData::getInstance() -> loadHighScores();
}

void SplashScreen::buttonAction(UIButton* button)
{
    
}