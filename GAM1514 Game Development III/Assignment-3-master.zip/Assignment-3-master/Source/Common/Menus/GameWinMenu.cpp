//
//  Student:        Quentin Bellay
//  Creation Date:  December 11th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the game win screen
//  Modified:       
//

#include "GameWinMenu.h"
#include "../UI/UIButton.h"
#include "../Game/Game.h"
#include "../Game/Level.h"
#include "../Screen Manager/ScreenManager.h"
#include "../Level Editor/LevelEditor.h"
#include "../Game/GameData.h"


GameWinMenu::GameWinMenu() : Menu(RES_MENU_BACKGROUND, RES_GAME_WIN_MENU_LABEL)
{
    addButton(new UIButton(RES_NEW_GAME_PLUS_BUTTON));
	addButton(new UIButton(RES_EXIT_BUTTON));
}

GameWinMenu::~GameWinMenu()
{

}

const char* GameWinMenu::getName()
{
    return GAME_COMPLETE_SCREEN_NAME;
}

void GameWinMenu::buttonAction(UIButton* button)
{
	Game* game = (Game*)ScreenManager::getInstance()->getScreenForName(GAME_SCREEN_NAME);

    int index = getIndexForButton(button);

	if(index == 0)
	{
		GameData::getInstance() -> setCurrentLevel(1);
		GameData::getInstance() -> setCurrentWave(1);

		game -> getLevel() -> loadJSON(LEVEL_SLOTS[GameData::getInstance() -> getCurrentLevel() - 1]);
		game -> getLevel() -> setNumberOfWaves(GameData::getInstance() -> getCurrentWave());
		game -> setLevelTimer(GameData::getInstance() -> getTimeLimit());

		if(GameData::getInstance() -> getAmmo() == 0)
		{
			GameData::getInstance() -> setAmmo(STARTING_AMMO_AMOUNT);
		}
	
		ScreenManager::getInstance()->switchScreen(GAME_SCREEN_NAME);
	}
	else if(index == 1)
	{
		ScreenManager::getInstance()->switchScreen(MAIN_MENU_SCREEN_NAME);
	}
}