//
//  Student:        Quentin Bellay
//  Creation Date:  December 11th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the game win screen
//  Modified:       
//

#ifndef __GAM_1514_OSX_Game__GameWinMenu__
#define __GAM_1514_OSX_Game__GameWinMenu__

#include "Menu.h"

// Class representing the game win screen when winning the last level
class GameWinMenu : public Menu
{
public:
    GameWinMenu();
    ~GameWinMenu();

    const char* getName();

private:
    void buttonAction(UIButton* button);
};

#endif /* defined(__GAM_1514_OSX_Game__GameWinMenu__) */