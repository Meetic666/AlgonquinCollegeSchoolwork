//
//  Student:        Quentin Bellay
//  Creation Date:  October 7th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the main menu screen
//  Modified:       
//

#ifndef __GAM_1514_OSX_Game__MainMenu__
#define __GAM_1514_OSX_Game__MainMenu__

#include "Menu.h"


class MainMenu : public Menu
{
public:
    MainMenu();
    ~MainMenu();
    
    const char* getName();
    
    void setIsPlaying(bool isPlaying);

private:
    bool buttonShouldBeDeselectedOnExit(UIButton* button);
    void buttonAction(UIButton* button);
    
    bool m_IsPlaying;
};

#endif /* defined(__GAM_1514_OSX_Game__MainMenu__) */
