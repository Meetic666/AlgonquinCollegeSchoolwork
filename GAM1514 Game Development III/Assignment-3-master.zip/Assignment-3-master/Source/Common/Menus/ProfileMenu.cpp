//
//  Student:        Quentin Bellay
//  Creation Date:  December 3rd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the profiles screen
//  Modified:       
//

#include "ProfileMenu.h"
#include "../Constants/Constants.h"
#include "../Game/ProfileManager.h"
#include "../Screen Manager/ScreenManager.h"
#include <map>

ProfileMenu::ProfileMenu() : Menu(RES_MENU_BACKGROUND, RES_PROFILE_MENU_LABEL),
	m_UITextBox(NULL)
{
	m_UITextBox = new UITextBox();

	addButton(m_UITextBox);

	addButton(new UIButton(MENU_NEW_BUTTON));

	ProfileManager::getInstance() -> loadProfiles();

	std::map<std::string, std::string> profiles = ProfileManager::getInstance() -> getProfiles();

	UIButton* newButton = NULL;

	for(std::map<std::string, std::string>::iterator it = profiles.begin(); it != profiles.end(); it++)
	{
		newButton = new UIButton(MENU_LONG_BUTTON);
		newButton -> setText(it -> first.c_str());

		addButton(newButton);
	}
}

ProfileMenu::~ProfileMenu()
{
	if(m_UITextBox != NULL)
	{
		m_UITextBox = NULL;
	}
}

void ProfileMenu::keyUpEvent(int keyCode)
{
	Menu::keyUpEvent(keyCode);
}

const char* ProfileMenu::getName()
{
	return PROFILE_SCREEN_NAME;
}

bool ProfileMenu::buttonShouldBeDeselectedOnExit(UIButton* button)
{
	return false;
}

void ProfileMenu::buttonAction(UIButton* button)
{
	int index = getIndexForButton(button);

	if(index == 0)
	{

	}
	else if(index == 1)
	{
		std::string profileName = std::string(m_UITextBox -> getText());

		if(profileName != "")
		{
			std::string gameDataName = profileName + "GameData";
			ProfileManager::getInstance() ->addProfile(profileName.c_str(), gameDataName.c_str());

			UIButton* newButton = new UIButton(MENU_LONG_BUTTON);
			newButton -> setText(profileName.c_str());
			addButton(newButton);
		}
	}
	else
	{
		if(strcmp(GameData::getInstance() -> getProfileName(), button -> getText()) != 0)
		{
			if(strcmp(GameData::getInstance() -> getProfileName(), "") != 0)
			{
				GameData::getInstance() -> saveGame();
			}

			GameData::getInstance() -> setProfileName(button -> getText());
			GameData::getInstance() -> setSaveFileName(ProfileManager::getInstance() -> getProfileGameData(button -> getText()));
			GameData::getInstance() -> loadGame();
			GameData::getInstance() -> loadHighScores();
			GameData::getInstance() -> saveGame();
		}
        
        ProfileManager::getInstance() -> saveProfiles();

		ScreenManager::getInstance() -> switchScreen(MAIN_MENU_SCREEN_NAME);
	}
}
