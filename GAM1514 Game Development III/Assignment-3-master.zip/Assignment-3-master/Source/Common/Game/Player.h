//
//  Player.h
//  GAM-1532 OSX Game
//
//  Created by Bradley Flood on 2013-03-07.
//  Copyright (c) 2013 Algonquin College. All rights reserved.
//

#ifndef PLAYER_H
#define PLAYER_H

#include "GameObject.h"
#include <vector>
#include "PathFinder.h"
#include "GameData.h"
#include "Projectile.h"

class Level;
class Tile;
class PathFinder;
class PickUp;
class Particle;

class Player : public GameObject, public PathFinderListener, public ProjectileListener
{
public:
	Player(Level* level, int maxHealth = PLAYER_HEALTH);
	virtual ~Player();
    
    //Update, paint and reset methods
	void update(double delta);
	void paint();
    void reset();
    
    //Keep it pure virtual to make it easier to know what function is left to implement
    virtual const char* getType() = 0;
    
    //Setter methods for the current and destination tiles
	void setCurrentTileIndex(int tileIndex);
	void setDestinationTileIndex(int tileIndex);
	void recalculatePath();
    
    virtual bool isAffectedByTileSpeed();

	void getWalkableTiles(std::vector<TileType> &walkableTiles);
    
	virtual int getHealth();
	virtual void setHealth(int health);

	virtual void kill();
    
    void fireProjectile(float x, float y);
    void applyDamage(int damage);

	bool getDestroyTower();
    
protected:    
    virtual void handlePlayerCollision(Projectile* projectile) = 0;
    virtual void handleBoundsCollision(Projectile* projectile);
    
    virtual bool handlePickUp(PickUp* pickUp);
    
    //Pathfinder listener method
    void pathFinderFinishedSearching(PathFinder* pathFinder, bool pathWasFound);
    
    //PathFinder methods
    PathFinder* getPathFinder();
    void findPath();
    
    //Animation methods
    float animate(float current, float target, double delta);
	void startAnimating();
	void stopAnimating();
    bool isAnimating();
    
    // Friend class Level so that it can access protected members
    friend class Level;
    
	int m_CurrentTileIndex;
	int m_DestinationTileIndex;
	bool m_CanAnimate;
    bool m_AbortAnimation;
	int m_AnimationPathNodeIndex;
    PathFinder* m_PathFinder;
    float m_Speed;
	Level* m_Level;
	int m_MaxDamage;
	int m_DamageUpgrade;
	int m_Health;
	int m_MaxHealth;
	float m_ProjectileSpeed;
    std::vector<Projectile*> m_Projectiles;
	bool m_DestroyTower;

	std::vector<TileType> m_WalkableTiles;

	bool m_IsEnemy;

	Particle* m_FiringParticle;
};

#endif