//
//  Student:        Quentin Bellay
//  Creation Date:  November 22nd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the hero
//  Modified:       
//

#include "Hero.h"
#include "Level.h"
#include "Tiles/Tile.h"
#include "../Constants/Constants.h"
#include "../Input/Input.h"
#include "../Utils/Utils.h"
#include "Enemies/Enemies.h"
#include "Pick Ups/PickUps.h"

Hero::Hero(Level* aLevel) : Player(aLevel)
{
    m_Texture = OpenGLTextureCache::getInstance() -> getTexture(RES_HERO);
}

Hero::~Hero()
{
    
}

const char* Hero::getType()
{
    return HERO_TYPE;
}

void Hero::mouseMovementEvent(float deltaX, float deltaY, float positionX, float positionY)
{
    Tile* tile = m_Level -> getTileForPosition(positionX, positionY);
    
    if(tile != NULL && tile -> isWalkableTile())
    {
        m_Level -> setSelectedTileIndex(m_Level -> getTileIndexForTile(tile));
    }
	else
	{
		m_Level -> setSelectedTileIndex(-1);
	}
}

void Hero::mouseLeftClickUpEvent(float positionX, float positionY)
{
    Tile* tile = m_Level -> getTileForPosition(positionX, positionY);
    
    if(tile != NULL && tile -> isWalkableTile())
    {
        setDestinationTileIndex(m_Level -> getTileIndexForTile(tile));
    }
}

void Hero::keyUpEvent(int keyCode)
{
    
}

void Hero::handlePlayerCollision(Projectile* projectile)
{
    Tile* tile = m_Level -> getTileForPosition(projectile -> getX(), projectile -> getY());
    
    for(int i = 0; i < m_Level -> getEnemies().size(); i++)
    {
        Enemy* enemy = m_Level -> getEnemies().at(i);
        
        if(enemy != NULL && enemy -> getIsActive())
        {
            Tile* enemyTile = m_Level -> getTileForPlayer(enemy);
            
            if(tile == enemyTile)
            {
                enemy -> applyDamage(projectile -> getDamage());
                projectile -> setIsActive(false);
                return;
            }
        }
    }
}

bool Hero::handlePickUp(PickUp* pickUp)
{
    switch(pickUp -> getPickUpType())
    {
        case PickUpTypeAmmo:
            GameData::getInstance() -> setAmmo(GameData::getInstance() -> getAmmo() + ((AmmoPickUp*)pickUp) -> getAmmoCount());
            break;
            
        default:
            break;
    }

	return true;
}