//
//  Student:        Quentin Bellay
//  Creation Date:  December 3rd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the profile manager
//  Modified:       
//

#ifndef PROFILE_MANAGER_H
#define PROFILE_MANAGER_H

#include <string>
#include <map>

// Class representing the profile manager, handling existing player profiles
class ProfileManager
{
public:
	static ProfileManager* getInstance();
	static void cleanUpInstance();

	void loadProfiles();
	void saveProfiles();

	void addProfile(const char* profileName, const char* gameDataFileName);
	void removeProfile(const char* profileName);

	std::map<std::string, std::string> getProfiles();

	const char* getProfileGameData(const char* profileName);

private:
	ProfileManager();
	~ProfileManager();

	static ProfileManager* s_Instance;

	std::map<std::string, std::string> m_Profiles;
};

#endif