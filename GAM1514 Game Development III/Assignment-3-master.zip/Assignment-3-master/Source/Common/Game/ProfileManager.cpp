//
//  Student:        Quentin Bellay
//  Creation Date:  December 3rd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the profile manager
//  Modified:       
//

#include "ProfileManager.h"
#include "../Constants/Constants.h"
#include <stdlib.h>
#include "../Libraries/jsoncpp/json.h"
#include <fstream>

ProfileManager* ProfileManager::s_Instance = NULL;

ProfileManager* ProfileManager::getInstance()
{
	if(s_Instance == NULL)
	{
		s_Instance = new ProfileManager();
	}

	return s_Instance;
}

void ProfileManager::cleanUpInstance()
{
	if(s_Instance != NULL)
	{
		delete s_Instance;
		s_Instance = NULL;
	}
}

void ProfileManager::loadProfiles()
{
	std::string jsonFile = std::string(RES_PROFILES_FILE_NAME) + ".json";
    
    std::ifstream inputStream;
    inputStream.open(jsonFile.c_str());
    
    if(inputStream.is_open())
    {
        Json::Value root;
        Json::Reader reader;
        
        if(reader.parse(inputStream, root) == true)
        {
			Json::Value profiles = root["Profiles"];

			for(int i = 0; i < profiles.size(); i++)
			{
				addProfile(profiles[i]["ProfileName"].asCString(), profiles[i]["GameDataFileName"].asCString());
			}
        }
        
        inputStream.close();
    }
}

void ProfileManager::saveProfiles()
{
	std::string saveFileName = std::string(RES_PROFILES_FILE_NAME) + ".json";
    
	Json::Value root;

	Json::Value profile;

	for(std::map<std::string, std::string>::iterator it = m_Profiles.begin(); it != m_Profiles.end(); it++)
	{
		profile["ProfileName"] = it -> first;
		profile["GameDataFileName"] = it -> second;

		root["Profiles"].append(profile);
	}	
    
	std::ofstream outputStream;
	outputStream.open(saveFileName.c_str(), std::ofstream::out);
    
	if(outputStream.is_open())
	{
		Json::StyledStreamWriter writer;
		writer.write(outputStream, root);
        
		outputStream.close();
	}
}

void ProfileManager::addProfile(const char* profileName, const char* gameDataFileName)
{
	m_Profiles[std::string(profileName)] =  std::string(gameDataFileName);
}

void ProfileManager::removeProfile(const char* profileName)
{
	m_Profiles.erase(std::string(profileName));
}

std::map<std::string, std::string> ProfileManager::getProfiles()
{
	return m_Profiles;
}

const char* ProfileManager::getProfileGameData(const char* profileName)
{
	return m_Profiles[std::string(profileName)].c_str();
}

ProfileManager::ProfileManager()
{

}

ProfileManager::~ProfileManager()
{
	m_Profiles.clear();
}