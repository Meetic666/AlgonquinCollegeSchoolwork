//
//  Student:        Quentin Bellay
//  Creation Date:  November 25th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the ammo pick up
//  Modified:       
//

#ifndef __GAM_1514_OSX_Game__AmmoPickUp__
#define __GAM_1514_OSX_Game__AmmoPickUp__

#include "PickUp.h"

// Class representing the ammo pick up
class AmmoPickUp : public PickUp
{
public:
    AmmoPickUp(int ammoCount);
    ~AmmoPickUp();
    
    void paint();
    
    const char* getType();
    
    int getAmmoCount();
    
private:
    int m_AmmoCount;
};

#endif /* defined(__GAM_1514_OSX_Game__AmmoPickUp__) */
