//
//  Student:        Quentin Bellay
//  Creation Date:  November 25th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the pick up base class
//  Modified:       
//

#include "PickUp.h"

PickUp::PickUp(PickUpType pickUpType) :
m_PickUpType(pickUpType)
{
    
}

PickUp::~PickUp()
{
    
}

void PickUp::update(double delta)
{
    
}

void PickUp::reset()
{
    
}

PickUpType PickUp::getPickUpType()
{
    return m_PickUpType;
}