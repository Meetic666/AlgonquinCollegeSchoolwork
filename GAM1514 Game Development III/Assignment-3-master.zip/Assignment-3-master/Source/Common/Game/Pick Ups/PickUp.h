//
//  Student:        Quentin Bellay
//  Creation Date:  November 25th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the pick up base class
//  Modified:       
//

#ifndef __GAM_1514_OSX_Game__PickUp__
#define __GAM_1514_OSX_Game__PickUp__

#include "../GameObject.h"
#include "../../Constants/Constants.h"

// Class representing the pick up base class
class PickUp : public GameObject
{
public:
    PickUp(PickUpType pickUpType);
    virtual ~PickUp();
    
    virtual void update(double delta);
    virtual void paint() = 0;
    virtual void reset();
    
    virtual const char* getType() = 0;
    
    virtual PickUpType getPickUpType();
    
protected:
    PickUpType m_PickUpType;
};

#endif /* defined(__GAM_1514_OSX_Game__PickUp__) */
