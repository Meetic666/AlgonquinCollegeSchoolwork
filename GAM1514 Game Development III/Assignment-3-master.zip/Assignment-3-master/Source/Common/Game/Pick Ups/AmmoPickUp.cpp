//
//  Student:        Quentin Bellay
//  Creation Date:  November 25th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the ammo pick up
//  Modified:       
//

#include "AmmoPickUp.h"

AmmoPickUp::AmmoPickUp(int ammoCount) : PickUp(PickUpTypeAmmo),
m_AmmoCount(ammoCount)
{
	m_Texture = OpenGLTextureCache::getInstance() -> getTexture(RES_PICK_UP_AMMO);
}

AmmoPickUp::~AmmoPickUp()
{
    
}

void AmmoPickUp::paint()
{
    if(m_Texture != NULL)
	{
		OpenGLRenderer::getInstance() ->drawTexture(m_Texture, getX(), getY(), getWidth(), getHeight());
	}
}

const char* AmmoPickUp::getType()
{
    return AMMO_PICK_UP_TYPE;
}

int AmmoPickUp::getAmmoCount()
{
    return m_AmmoCount;
}