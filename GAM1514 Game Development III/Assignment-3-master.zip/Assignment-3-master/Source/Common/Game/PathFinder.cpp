//
//  Student:        Quentin Bellay
//  Creation Date:  November 8th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing a path finding object
//  Modified:		November 10th 2013: Added values to tiles so that some are faster
//

#include "PathFinder.h"
#include "PathNode.h"
#include "Level.h"
#include "Player.h"
#include "Tiles/Tile.h"
#include "../Constants/Constants.h"
#include <stdlib.h>
#include <algorithm>
#include <math.h>



PathFinder::PathFinder(Level* level, Player* player) :
m_Level(level),
m_Player(player),
m_Listener((PathFinderListener*) player),
m_State(StateIdle),
m_DestinationTileIndex(-1),
m_SearchDelay(0.0),
m_EnableSearchDelay(false),
m_AffectedByTileSpeed(false)
{
}

PathFinder::~PathFinder()
{
    clearPathNodes();
}

void PathFinder::findPath(int aCurrentTileIndex, int aDestinationTileIndex, bool affectedByTileSpeed)
{
    setWalkableTiles(m_Player);

    m_AffectedByTileSpeed = affectedByTileSpeed;
    
    if(m_State != StateIdle)
    {
        return;
    }
    
    for(int i = 0; i < m_Level->getNumberOfTiles(); i++)
    {
        Tile* tile = m_Level->getTileForIndex(i);
        
        if(tile != NULL && isTileWalkable(tile) && tile -> getTower() == NULL)
        {
            tile->setIsPath(false);
        }
    }
    
    clearPathNodes();
    
    m_DestinationTileIndex = aDestinationTileIndex;
    
    if(aCurrentTileIndex == m_DestinationTileIndex)
    {
        return;
    }
    
    if(isTileWalkable(m_Level -> getTileForIndex(aDestinationTileIndex)) == false || m_Level -> getTileForIndex(aDestinationTileIndex) -> getTower() != NULL)
    {
        return;
    }
    
    PathNode* pathNode = new PathNode(aCurrentTileIndex);
    addPathNodeToOpenList(pathNode);
    
    m_State = StateSearchingPath;
    
    m_SearchDelay = 0.0f;
}

void PathFinder::update(double aDelta)
{
    if(m_SearchDelay > 0.0)
    {
        m_SearchDelay -= aDelta;
        if(m_SearchDelay <= 0.0)
        {
            m_SearchDelay = 0.0;
        }
        return;
    }
    
    
    while(isSearchingPath() && m_DestinationTileIndex != -1)
    {
        if(m_PathNodeOpen.size() == 0)
        {
            m_State = StateError;
            
            if(m_Listener != NULL)
            {
                m_Listener->pathFinderFinishedSearching(this, false);
            }
            
            return;
        }
        
        PathNode* currentNode = m_PathNodeOpen.front();
        
        m_PathNodeClosed.push_back(currentNode);
        m_PathNodeOpen.erase(m_PathNodeOpen.begin());
        
        int currentNodeTileIndex = currentNode->getTileIndex();
        
        if(currentNodeTileIndex == m_DestinationTileIndex)
        {
            buildFinalNodePath(currentNode);
            
            m_State = StateFoundPath;
            
            if(m_Listener != NULL)
            {
                m_Listener->pathFinderFinishedSearching(this, true);
            }
            
            return;
        }
        
        std::vector<int> adjacentTiles;
        
        addAdjacentTile(adjacentTiles, currentNode->getTileIndex(), 0, -1);
        addAdjacentTile(adjacentTiles, currentNode->getTileIndex(), 0, 1);
        addAdjacentTile(adjacentTiles, currentNode->getTileIndex(), -1, 0);
        addAdjacentTile(adjacentTiles, currentNode->getTileIndex(), 1, 0);
        
        for(int i = 0; i < adjacentTiles.size(); i++)
        {
            int adjacentTile = adjacentTiles.at(i);
            
            float increment = 1.0f;

			if(m_AffectedByTileSpeed)
			{
				if(m_Level ->getTileForIndex(adjacentTile)->getTower() == NULL)
				{
					if(m_Level ->getTileForIndex(adjacentTile)->getTileType() != TileTypeFence)
					{
						increment = m_Level->getTileForIndex(adjacentTile)->getPathValue();
					}
					else
					{
						increment = OBSTACLE_PATH_WEIGHT;
					}
				}
				else
				{
					increment = OBSTACLE_PATH_WEIGHT;
				}
			}
            
            if(doesTileExistInClosedList(adjacentTile))
            {
                continue;
            }
            
            if(doesTileExistInOpenList(adjacentTile) == false)
            {
                PathNode* adjacentNode = new PathNode(adjacentTile);
                
                adjacentNode->setParentNode(currentNode);
                
                adjacentNode->setGScore(currentNode->getGScore() + increment);
                
                int scoreH = getManhattanDistanceCost(adjacentTile, m_DestinationTileIndex);
                
                adjacentNode->setHScore(scoreH);
                
                addPathNodeToOpenList(adjacentNode);
            }
            else
            {
                PathNode* existingNode = getOpenPathNodeForTileIndex(adjacentTile);
                
                if(currentNode->getGScore() + increment < existingNode->getGScore())
                {
                    existingNode->setGScore(currentNode->getGScore() + increment);
                    
                    existingNode->setParentNode(currentNode);
                    
                    sortOpenList();
                }
            }
        }
    }
    
    
    //If the search delay is enabled, set the delay timer
    if(m_EnableSearchDelay == true)
    {
        m_SearchDelay = PATH_FINDING_DELAY;
    }
}

void PathFinder::paint()
{

}

void PathFinder::reset()
{
    m_State = StateIdle;
}

void PathFinder::addAdjacentTile(std::vector<int>& aAdjacentTiles, int aCurrentTileIndex, int aDeltaX, int aDeltaY)
{
	Tile* currentTile = m_Level -> getTileForIndex(aCurrentTileIndex);

    int adjacentCoordinateX = m_Level->getTileCoordinateForPosition(currentTile->getX()) + aDeltaX;
    int adjacentCoordinateY = m_Level->getTileCoordinateForPosition(currentTile->getY()) + aDeltaY;
    
    Tile* adjacentTile = m_Level->getTileForCoordinates(adjacentCoordinateX, adjacentCoordinateY);
    
    if(adjacentTile!=NULL)
    {
        bool isWalkable = isTileWalkable(adjacentTile) && ((m_Player -> getDestroyTower()) || (adjacentTile -> getTower() == NULL));
        bool isValid = m_Level->validateTileCoordinates(adjacentCoordinateX, adjacentCoordinateY);

		bool isDoubleRiver = false;

		if(((currentTile -> getTileType() == TileTypeRiver || currentTile -> getTileType() == TileTypeBridge)
			&& (adjacentTile -> getTileType() == TileTypeRiver || adjacentTile -> getTileType() == TileTypeBridge))
			|| (adjacentTile -> getTileType() == TileTypeRiver && (adjacentTile -> getTileStyle() == Angled || adjacentTile -> getTileStyle() == TShaped)))
		{
			isDoubleRiver = true;
		}
        
        if(isValid && isWalkable && !isDoubleRiver)
        {
            aAdjacentTiles.push_back(m_Level -> getTileIndexForTile(adjacentTile));
        }
    }
}

bool PathFinder::doesTileExistInClosedList(int aTileIndex)
{    
    //Cycle through the closed list and compare the tile indexes
    for(int i = 0; i < m_PathNodeClosed.size(); i++)
    {
        PathNode* pathNode = m_PathNodeClosed.at(i);
        if(pathNode->getTileIndex() == aTileIndex)
        {
            return true;
        }
    }
    
    //The tile doesn't exist in the closed list
    return false;
}

bool PathFinder::doesTileExistInOpenList(int aTileIndex)
{
    return getOpenPathNodeForTileIndex(aTileIndex) != NULL;
}

PathNode* PathFinder::getOpenPathNodeForTileIndex(int aTileIndex)
{    
    //Cycle through the open list and compare the tile indexes
    for(int i = 0; i < m_PathNodeOpen.size(); i++)
    {
        PathNode* pathNode = m_PathNodeOpen.at(i);
        if(pathNode->getTileIndex() == aTileIndex)
        {
            return pathNode;
        }
    }
    
    //The tile doesn't exist in the open list, return NULL
    return NULL;
}

bool PathFinder::isSearchingPath()
{
    return m_State == StateSearchingPath;
}

int PathFinder::getPathSize()
{
    return m_PathNodeFinal.size();
}

void PathFinder::sortOpenList()
{
    std::sort(m_PathNodeOpen.begin(), m_PathNodeOpen.end(), PathNode::compareNodes);
}

PathNode* PathFinder::getPathNodeAtIndex(int aIndex)
{
    if(aIndex >= 0 && aIndex < getPathSize())
    {
        return m_PathNodeFinal.at(aIndex);
    }
    return NULL;
}

void PathFinder::addPathNodeToOpenList(PathNode* aPathNode)
{
	//Insert the Path node into the Open path node vector
	m_PathNodeOpen.push_back(aPathNode);
    
    //Sort the open list
    sortOpenList();
}

void PathFinder::buildFinalNodePath(PathNode* aPathNode)
{
	do
	{
        //Safety check the parentNode
		if(aPathNode->getParentNode() != NULL)
		{
			m_PathNodeFinal.insert(m_PathNodeFinal.begin(), aPathNode);
		}
        
		//Set the tile path flag to true
		m_Level->getTileForIndex(aPathNode->getTileIndex())->setIsPath(true);
        
		//Set the path node's pointer to it's parent
		aPathNode = aPathNode->getParentNode();
	}
	while (aPathNode != NULL);
}

void PathFinder::clearPathNodes()
{
	//Now cycle through the Open node path vector, and delete all the path node
	while(m_PathNodeOpen.size() > 0)
	{
		//Get the last element in the vector
		PathNode* node = m_PathNodeOpen.back();
        
		//Delete the path node
		delete node;
        
		//Remove the last element in the vector
		m_PathNodeOpen.pop_back();
	}
    
	//Lastly cycle through the Closed node path vector, and delete all the path node
	while(m_PathNodeClosed.size() > 0)
	{
		//Get the last element in the vector
		PathNode* node = m_PathNodeClosed.back();
        
		//Delete the path node
		delete node;
        
		//Remove the last element in the vector
		m_PathNodeClosed.pop_back();
	}
    
    //Clear the final path node list
    m_PathNodeFinal.clear();
    
    //Reset the destination tile index
    m_DestinationTileIndex = -1;
}

void PathFinder::togglePathFindingDelay()
{
    m_EnableSearchDelay = !m_EnableSearchDelay;
}

void PathFinder::setWalkableTiles(Player* player)
{
	player -> getWalkableTiles(m_WalkableTiles);
}

int PathFinder::getManhattanDistanceCost(int aStartTileIndex, int aDestinationTileIndex)
{
	Tile* destinationTile = m_Level -> getTileForIndex(aDestinationTileIndex);
	Tile* startTile = m_Level -> getTileForIndex(aStartTileIndex);

	//Here we use the Manhattan method, which calculates the total number of step moved horizontally and vertically to reach the
	//final desired step from the current step, ignoring any obstacles that may be in the way
	int distance = abs(m_Level->getTileCoordinateForPosition(destinationTile->getX()) - m_Level->getTileCoordinateForPosition(startTile->getX()))
    + abs(m_Level->getTileCoordinateForPosition(destinationTile->getY()) - m_Level->getTileCoordinateForPosition(startTile->getY()));
    
    //Return the distance between the two tiles
	return distance;
}

bool PathFinder::isTileWalkable(Tile* tile)
{
	if(std::find(m_WalkableTiles.begin(), m_WalkableTiles.end(), tile -> getTileType()) != m_WalkableTiles.end())
	{
		return true;
	}
	else
	{
		return false;
	}
}