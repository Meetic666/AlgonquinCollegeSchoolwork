//
//  Student:        Quentin Bellay
//  Creation Date:  November 24th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the game data
//  Modified:       
//

#include "GameData.h"
#include "../Constants/Constants.h"
#include <stdlib.h>
#include "../Libraries/jsoncpp/json.h"
#include <fstream>
#include <string>

GameData* GameData::s_Instance = NULL;

GameData* GameData::getInstance()
{
	if(s_Instance == NULL)
	{
		s_Instance = new GameData();
	}

	return s_Instance;
}

void GameData::cleanUpInstance()
{
	if(s_Instance != NULL)
	{
		delete s_Instance;
		s_Instance = NULL;
	}
}

void GameData::reset()
{
	m_Score = 0;
	m_GoldReserve = m_StartingGold;
	m_CurrentWave = 1;
	m_OfficerTiersUnlocked = 1;
	m_OfficerRangeUpgrade = 0;
	m_OfficerFiringRateUpgrade = 0;
	m_OfficerDamageUpgrade = 0;
	m_TowerTiersUnlocked = 1;
	m_TowerRangeUpgrade = 0;
	m_TowerFiringRateUpgrade = 0;
	m_TowerDamageUpgrade = 0;
	m_SpeedMultiplier = 1;
	m_Ammo = STARTING_AMMO_AMOUNT;
}

void GameData::saveGame()
{
	if(m_CurrentSaveGame != "")
	{
		std::string saveFileName = m_CurrentSaveGame + ".json";
    
		Json::Value root;
		Json::Value gameSettings;
		
		gameSettings["Difficulty"] = m_Difficulty;
		gameSettings["TimeLimit"] = m_TimeLimit;
		gameSettings["StartingGold"] = m_StartingGold;

		root["GameSettings"] = gameSettings;
			
		Json::Value saveGame;
		saveGame["ProfileName"] = m_ProfileName;
		saveGame["Score"] = m_Score;
		saveGame["GoldReserve"] = m_GoldReserve;
		saveGame["Ammo"] = m_Ammo;
		saveGame["CurrentLevel"] = m_CurrentLevel;
		saveGame["NumberOfUnlockedLevels"] = m_NumberOfUnlockedLevels;
		saveGame["TowerTiersUnlocked"] = m_TowerTiersUnlocked;
		saveGame["TowerRangeUpgrade"] = m_TowerRangeUpgrade;
		saveGame["TowerFiringRateUpgrade"] = m_TowerFiringRateUpgrade;
		saveGame["TowerDamageUpgrade"] = m_TowerDamageUpgrade;
		saveGame["OfficerTiersUnlocked"] = m_OfficerTiersUnlocked;
		saveGame["OfficerRangeUpgrade"] = m_OfficerRangeUpgrade;
		saveGame["OfficerFiringRateUpgrade"] = m_OfficerFiringRateUpgrade;
		saveGame["OfficerDamageUpgrade"] = m_OfficerDamageUpgrade;

		root["SaveGame"] = saveGame;
    
		std::ofstream outputStream;
		outputStream.open(saveFileName.c_str(), std::ofstream::out);
    
		if(outputStream.is_open())
		{
			Json::StyledStreamWriter writer;
			writer.write(outputStream, root);
        
			outputStream.close();
		}
	}
}

void GameData::loadGame()
{
	std::string jsonFile = m_CurrentSaveGame + ".json";
    
    std::ifstream inputStream;
    inputStream.open(jsonFile.c_str());
    
    if(inputStream.is_open())
    {
        Json::Value root;
        Json::Reader reader;
        
        if(reader.parse(inputStream, root) == true)
        {
			Json::Value gameSettings = root["GameSettings"];

            m_Difficulty = gameSettings["Difficulty"].asInt();
			m_TimeLimit = gameSettings["TimeLimit"].asDouble();
			m_StartingGold = gameSettings["StartingGold"].asUInt();

			Json::Value saveGame = root["SaveGame"];

			m_Score = saveGame["Score"].asUInt();
			m_GoldReserve = saveGame["GoldReserve"].asUInt();
			m_Ammo = saveGame["Ammo"].asUInt();
			m_CurrentLevel = saveGame["CurrentLevel"].asInt();
			m_NumberOfUnlockedLevels = saveGame["NumberOfUnlockedLevels"].asInt();
			m_TowerTiersUnlocked = saveGame["TowerTiersUnlocked"].asInt();
			m_TowerRangeUpgrade = saveGame["TowerRangeUpgrade"].asInt();
			m_TowerFiringRateUpgrade = saveGame["TowerFiringRateUpgrade"].asInt();
			m_TowerDamageUpgrade = saveGame["TowerDamageUpgrade"].asInt();
			m_OfficerTiersUnlocked = saveGame["OfficerTiersUnlocked"].asInt();
			m_OfficerRangeUpgrade = saveGame["OfficerRangeUpgrade"].asInt();
			m_OfficerFiringRateUpgrade = saveGame["OfficerFiringRateUpgrade"].asInt();
			m_OfficerDamageUpgrade = saveGame["OfficerDamageUpgrade"].asInt();
        }
        
        inputStream.close();
    }
	else
	{
		// Set the game to default values

		m_Difficulty = MEDIUM_DIFFICULTY;
		m_TimeLimit = MEDIUM_TIME;

		m_Score = 0;
		m_GoldReserve = STARTING_GOLD_RESERVE_MEDIUM;
		m_CurrentLevel = 1;
		m_NumberOfUnlockedLevels = 1;
		m_TowerTiersUnlocked = 1;
		m_TowerRangeUpgrade = 0;
		m_TowerFiringRateUpgrade = 0;
		m_TowerDamageUpgrade = 0;
		m_OfficerTiersUnlocked = 1;
		m_OfficerRangeUpgrade = 0;
		m_OfficerFiringRateUpgrade = 0;
		m_OfficerDamageUpgrade = 0;
	}
}

void GameData::saveHighScores()
{
	Json::Value root;
	Json::Value highscore;

	for(int i = 0; i < getNumberOfHighScores(); i++)
	{
		highscore["Name"] = m_HighScoreNames[i];
		highscore["Score"] = m_HighScores[i];

		root["Highscores"].append(highscore);
	}

	std::string highScoresFile = std::string(RES_HIGH_SCORES_FILE) + ".json";

	std::ofstream outputStream;
	outputStream.open(highScoresFile.c_str(), std::ofstream::out);
    
	if(outputStream.is_open())
	{
		Json::StyledStreamWriter writer;
		writer.write(outputStream, root);
        
		outputStream.close();
	}
}

void GameData::loadHighScores()
{
	std::string highScoresFile = std::string(RES_HIGH_SCORES_FILE) + ".json";
    
	std::ifstream inputStream;
	inputStream.open(highScoresFile.c_str());

	m_NumberOfHighScores = NUMBER_OF_HIGHSCORES;
	m_HighScores.clear();
	m_HighScoreNames.clear();
    
	if(inputStream.is_open())
	{
		Json::Value root;
		Json::Reader reader;
        
		if(reader.parse(inputStream, root) == true)
		{
			Json::Value highScores = root["Highscores"];

			for(int i = 0; i < NUMBER_OF_HIGHSCORES; i++)
			{
				if(i < highScores.size())
				{
					m_HighScores.push_back(highScores[i]["Score"].asUInt());
					m_HighScoreNames.push_back(highScores[i]["Name"].asString());
				}
				else
				{
					m_HighScores.push_back(0);
					m_HighScoreNames.push_back("");
				}
			}
		}
	}
	else
	{
		for(int i = 0; i < NUMBER_OF_HIGHSCORES; i++)
		{			
			m_HighScores.push_back(0);
			m_HighScoreNames.push_back("");
		}
	}
}

void GameData::setSaveFileName(std::string saveFileName)
{
	m_CurrentSaveGame = saveFileName;
}

void GameData::setDifficulty(unsigned char difficulty)
{
	m_Difficulty = difficulty;
}

void GameData::setScore(unsigned int score)
{
	m_Score = score;
}

void GameData::setStartingGold(unsigned int startingGold)
{
	m_StartingGold = startingGold;
}

void GameData::setHighScore()
{
	for(int i = 0; i < getNumberOfHighScores();  i++)
	{
		if(m_HighScores[i] < getScore())
		{
			for(int j = getNumberOfHighScores() - 1; j > i; j--)
			{
				m_HighScores[j] = m_HighScores[j - 1];
				m_HighScoreNames[j] = m_HighScoreNames[j - 1];
			}

			m_HighScores[i] = getScore();
			m_HighScoreNames[i] = getProfileName();

			break;
		}
	}
}
	
void GameData::setTimeLimit(double timeLimit)
{
	m_TimeLimit = timeLimit;
}

void GameData::setGoldReserve(unsigned int goldReserve)
{
	if(goldReserve > 0)
	{
		m_GoldReserve = goldReserve;
	}
	else
	{
		m_GoldReserve = 0;
	}
}

void GameData::setCurrentLevel(unsigned char currentLevel)
{
	m_CurrentLevel = currentLevel;
}

void GameData::setCurrentWave(unsigned char currentWave)
{
	m_CurrentWave = currentWave;
}

void GameData::setNumberOfUnlockedLevels(unsigned char numberOfUnlockedLevels)
{
	m_NumberOfUnlockedLevels = numberOfUnlockedLevels;
}

void GameData::setOfficerTiersUnlocked(unsigned char numberOfTiersUnlocked)
{
	m_OfficerTiersUnlocked = numberOfTiersUnlocked;
}

void GameData::setOfficerRangeUpgrade(unsigned char officerRangeUpgrade)
{
	m_OfficerRangeUpgrade = officerRangeUpgrade;
}

void GameData::setOfficerFiringRateUpgrade(unsigned char officerFiringRateUpgrade)
{
	m_OfficerFiringRateUpgrade = officerFiringRateUpgrade;
}

void GameData::setOfficerDamageUpgrade(unsigned char officerDamageUpgrade)
{
	m_OfficerDamageUpgrade = officerDamageUpgrade;
}

void GameData::setTowerTiersUnlocked(unsigned char numberOfTiersUnlocked)
{
	m_TowerTiersUnlocked = numberOfTiersUnlocked;
}

void GameData::setTowerRangeUpgrade(unsigned char towerRangeUpgrade)
{
	m_TowerRangeUpgrade = towerRangeUpgrade;
}

void GameData::setTowerFiringRateUpgrade(unsigned char towerFiringRateUpgrade)
{
	m_TowerFiringRateUpgrade = towerFiringRateUpgrade;
}

void GameData::setTowerDamageUpgrade(unsigned char towerDamageUpgrade)
{
	m_TowerDamageUpgrade = towerDamageUpgrade;
}

void GameData::setSpeedMultiplier(unsigned char multiplier)
{
	m_SpeedMultiplier = multiplier;
}

void GameData::setAmmo(unsigned int ammo)
{
    m_Ammo = ammo;
}

void GameData::setProfileName(const char* profileName)
{
	m_ProfileName = std::string(profileName);
}

unsigned char GameData::getDifficulty()
{
	return m_Difficulty;
}

unsigned int GameData::getScore()
{
	return m_Score;
}

unsigned int GameData::getStartingGold()
{
	return m_StartingGold;
}

std::vector<unsigned int> GameData::getHighScore()
{
	return m_HighScores;
}

std::vector<std::string> GameData::getNames()
{
	return m_HighScoreNames;
}

unsigned char GameData::getNumberOfHighScores()
{
	return m_NumberOfHighScores;
}

double GameData::getTimeLimit()
{
	return m_TimeLimit;
}

unsigned int GameData::getGoldReserve()
{
	return m_GoldReserve;
}

unsigned char GameData::getCurrentLevel()
{
	return m_CurrentLevel;
}

unsigned char GameData::getCurrentWave()
{
	return m_CurrentWave;
}

unsigned char GameData::getNumberOfUnlockedLevels()
{
	return m_NumberOfUnlockedLevels;
}

unsigned char GameData::getOfficerTiersUnlocked()
{
	return m_OfficerTiersUnlocked;
}

unsigned char GameData::getOfficerRangeUpgrade()
{
	return m_OfficerRangeUpgrade;
}

unsigned char GameData::getOfficerFiringRateUpgrade()
{
	return m_OfficerFiringRateUpgrade;
}

unsigned char GameData::getOfficerDamageUpgrade()
{
	return m_OfficerDamageUpgrade;
}

unsigned char GameData::getTowerTiersUnlocked()
{
	return m_TowerTiersUnlocked;
}

unsigned char GameData::getTowerRangeUpgrade()
{
	return m_TowerRangeUpgrade;
}

unsigned char GameData::getTowerFiringRateUpgrade()
{
	return m_TowerFiringRateUpgrade;
}

unsigned char GameData::getTowerDamageUpgrade()
{
	return m_TowerDamageUpgrade;
}

unsigned char GameData::getSpeedMultiplier()
{
	return m_SpeedMultiplier;
}

unsigned int GameData::getAmmo()
{
    return m_Ammo;
}

const char* GameData::getProfileName()
{
	return m_ProfileName.c_str();
}

void GameData::stealGold(int amount)
{
	if(amount < getGoldReserve())
	{
		setGoldReserve(getGoldReserve() - amount);
	}
	else
	{
		setGoldReserve(0);
	}
}

GameData::GameData() :
m_Difficulty(0),
m_Score(0),
m_NumberOfHighScores(NUMBER_OF_HIGHSCORES),
m_TimeLimit(MEDIUM_TIME),
m_GoldReserve(STARTING_GOLD_RESERVE_MEDIUM),
m_StartingGold(STARTING_GOLD_RESERVE_MEDIUM),
m_CurrentLevel(1),
m_CurrentWave(1),
m_NumberOfUnlockedLevels(1),
m_OfficerTiersUnlocked(1),
m_OfficerRangeUpgrade(0),
m_OfficerFiringRateUpgrade(0),
m_OfficerDamageUpgrade(0),
m_TowerTiersUnlocked(1),
m_TowerRangeUpgrade(0),
m_TowerFiringRateUpgrade(0),
m_TowerDamageUpgrade(0),
m_SpeedMultiplier(1),
m_CurrentSaveGame(""),
m_Ammo(STARTING_AMMO_AMOUNT),
m_ProfileName("")
{
	loadHighScores();
}

GameData::~GameData()
{
    saveHighScores();
}
