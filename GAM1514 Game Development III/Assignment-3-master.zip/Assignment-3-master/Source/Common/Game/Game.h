#ifndef GAME_H
#define GAME_H

#include <vector>
#include "../Screen Manager/Screen.h"
#include "../UI/UISideMenu.h"
#include "../Constants/Constants.h"

class GameObject;
class Level;
class UIFont;

class Game : public Screen, public UISideMenuListener
{
public:
    Game();
    ~Game();
    
    //Game lifecycle methods
    void update(double delta);
    void paint();
    void reset();
    
    //Screen name, must be implemented, it's a pure
    //virtual method in the Screen class
    const char* getName();
    
    Level* getLevel();

	void setLevelTimer(double timer);
    
private:
    //Mouse Events
    void mouseMovementEvent(float deltaX, float deltaY, float positionX, float positionY);
    void mouseLeftClickUpEvent(float positionX, float positionY);
	void mouseRightClickUpEvent(float positionX, float positionY);
    void keyUpEvent(int keyCode);

    void sideMenuButtonAction(UISideMenu* sideMenu, UIButton* button, int buttonIndex);
    void sideMenuToggleAction(UISideMenu* sideMenu, UIToggle* toggle, int toggleIndex);

	void clampX(UISideMenu* menu, float &x);
    
    //Level pointer
    Level* m_Level;
	double m_InterestTimer;
	double m_LevelTimer;
	double m_BetweenWaveTimer;
	UIFont* m_UIFont;

	UISideMenu* m_TowerMenu;
    UISideMenu* m_UpgradeMenu;
    UISideMenu* m_UpgradeChoiceMenu;
	UISideMenu* m_PauseMenu;
    
    bool m_UpgradingOfficer;

	int m_SelectedTowerType;
	std::vector<TileType> m_AllowedTilesForTower;

	OpenGLTexture* m_SpeedMultiplierSlow;
	OpenGLTexture* m_SpeedMultiplierMedium;
	OpenGLTexture* m_SpeedMultiplierFast;
};

#endif