//
//  Student:        Quentin Bellay
//  Creation Date:  November 8th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing a path node
//  Modified:
//

#include "PathNode.h"
#include "Tiles/Tile.h"

PathNode::PathNode(int tileIndex) :
m_GScore(0),
m_HScore(0),
m_ParentNode(NULL),
m_TileIndex(tileIndex)
{
    
}

PathNode::~PathNode()
{
    m_ParentNode = NULL;
}

float PathNode::getGScore()
{
    return m_GScore;
}

float PathNode::getHScore()
{
    return m_HScore;
}

float PathNode::getFinalScore()
{
    return getHScore() + getGScore();
}

void PathNode::setGScore(float gScore)
{
    m_GScore = gScore;
}

void PathNode::setHScore(float hScore)
{
    m_HScore = hScore;
}

void PathNode::setParentNode(PathNode* parentNode)
{
    m_ParentNode = parentNode;
}

PathNode* PathNode::getParentNode()
{
    return m_ParentNode;
}

int PathNode::getTileIndex()
{
    return m_TileIndex;
}

bool PathNode::compareNodes(PathNode* nodeA, PathNode* nodeB)
{
    return nodeA->getFinalScore() < nodeB->getFinalScore();
}