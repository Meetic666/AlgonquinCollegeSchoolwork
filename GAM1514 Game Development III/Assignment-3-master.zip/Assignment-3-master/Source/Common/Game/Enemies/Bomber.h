//
//  Student:        Quentin Bellay
//  Creation Date:  November 24th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the bomber enemy (destroys fences)
//  Modified:       
//

#ifndef BOMBER_H
#define BOMBER_H

#include "Enemy.h"

// Class representing the bomber enemy (destroys fences), inherits Enemy
class Bomber : public Enemy
{
public:
	Bomber(Level* aLevel);
	~Bomber();

	virtual const char* getType();
    
    virtual void update(double delta);

	bool isAffectedByTileSpeed();
};

#endif