//
//  Student:        Quentin Bellay
//  Creation Date:  November 23rd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the bulldozer enemy (creates roads)
//  Modified:       
//

#include "Bulldozer.h"
#include "../Level.h"
#include "../Tiles/Tile.h"
#include "../../Constants/Constants.h"

Bulldozer::Bulldozer(Level* aLevel) : Enemy(aLevel, BULLDOZER_SCORE_AMOUNT, BULLDOZER_HEALTH)	
{
	m_Speed = BULLDOZER_SPEED;
    
    m_Texture = OpenGLTextureCache::getInstance() -> getTexture(RES_BULLDOZER);

	m_PathFinder -> setWalkableTiles(this);

	m_WalkableTiles.push_back(TileTypeRiver);
}

Bulldozer::~Bulldozer()
{

}

const char* Bulldozer::getType()
{
	return BULLDOZER_TYPE;
}

void Bulldozer::update(double delta)
{
	if(m_Level -> getTileForPlayer(this) -> getTileType() != TileTypeRoad 
		&& m_Level -> getTileForPlayer(this) -> getTileType() != TileTypeBridge
		&& m_Level -> getTileForPlayer(this) -> getTileType() != TileTypeReserve)
	{
		m_Level -> setTileTypeAtIndex(TileTypeRoad, m_Level -> getTileIndexForPlayer(this));
	}

	Enemy::update(delta);
}

bool Bulldozer::isAffectedByTileSpeed()
{
    return false;
}