//
//  Student:        Quentin Bellay
//  Creation Date:  November 22nd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the enemy
//  Modified:       
//

#ifndef __GAM_1514_OSX_Game__Enemy__
#define __GAM_1514_OSX_Game__Enemy__

#include "../Player.h"

// Class representing the enemy
class Enemy : public Player
{
public:
    Enemy(Level* aLevel, int scoreAmount = ENEMY_SCORE_AMOUNT, int maxHealth = ENEMY_HEALTH);
    virtual ~Enemy();
    
    virtual const char* getType();
    
    virtual void update(double delta);
    void reset();

	void kill();

protected:
    void handlePlayerCollision(Projectile* projectile);
    
	double m_StealingTimer;

	int m_ScoreAmount;
};

#endif /* defined(__GAM_1514_OSX_Game__Enemy__) */
