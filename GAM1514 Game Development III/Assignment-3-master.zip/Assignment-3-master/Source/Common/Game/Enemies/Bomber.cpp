//
//  Student:        Quentin Bellay
//  Creation Date:  November 24th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the bomber enemy (destroys fences)
//  Modified:       
//

#include "Bomber.h"
#include "../Level.h"
#include "../Tiles/Tile.h"
#include "../../Constants/Constants.h"

Bomber::Bomber(Level* aLevel) : Enemy(aLevel, BOMBER_SCORE_AMOUNT, BOMBER_HEALTH)	
{
	m_Speed = BOMBER_SPEED;
    
    m_Texture = OpenGLTextureCache::getInstance() -> getTexture(RES_BOMBER);

	m_PathFinder -> setWalkableTiles(this);

	m_WalkableTiles.push_back(TileTypeFence);
}

Bomber::~Bomber()
{

}

const char* Bomber::getType()
{
	return BOMBER_TYPE;
}

void Bomber::update(double delta)
{
	Enemy::update(delta);
}

bool Bomber::isAffectedByTileSpeed()
{
    return true;
}