//
//  Student:        Quentin Bellay
//  Creation Date:  November 22nd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the enemy
//  Modified:       
//

#include "Enemy.h"
#include "../Hero.h"
#include "../Level.h"
#include "../Tiles/Tiles.h"
#include "../Pick Ups/PickUps.h"

Enemy::Enemy(Level* aLevel, int scoreAmount, int maxHealth) : Player(aLevel, maxHealth),
m_StealingTimer(0.0),
m_ScoreAmount(scoreAmount)
{
    setIsActive(false);
    
    m_Texture = OpenGLTextureCache::getInstance() -> getTexture(RES_WALKER);

	m_IsEnemy = true;
}

Enemy::~Enemy()
{
    
}

const char* Enemy::getType()
{
    return ENEMY_TYPE;
}

void Enemy::update(double delta)
{
    Player::update(delta);
    
	if(m_Level -> getTileForPosition(getX() + getWidth() / 2.0f, getY() + getHeight() / 2.0f) -> getTileType() == TileTypeReserve)
	{
		if(m_StealingTimer > 0.0)
		{
			m_StealingTimer -= delta;
		}
		else
		{
			GameData::getInstance() -> stealGold(STOLEN_GOLD_AMOUNT_PER_ITERATION);
            
			m_StealingTimer = STEALING_TIMER;
		}
	}
	else if((m_DestroyTower && m_Level -> getTileForPosition(getX() + getWidth() / 2.0f, getY() + getHeight() / 2.0f) -> getTower() != NULL) || m_Level -> getTileForPosition(getX() + getWidth() / 2.0f, getY() + getHeight() / 2.0f) -> getTileType() == TileTypeFence)
	{
		m_Level -> setTileTypeAtPosition(TileTypeExploded, getX() + getWidth() / 2.0f, getY() + getHeight() / 2.0f);

		setIsActive(false);
	}
}

void Enemy::reset()
{
    Player::reset();
    
    setDestinationTileIndex(m_Level -> getGoldReserveIndex());
}

void Enemy::kill()
{
	setIsActive(false);
    
    m_Level -> setPickUpTypeAtPosition(PickUpTypeAmmo, getX(), getY());
    
	GameData::getInstance() -> setScore(GameData::getInstance() -> getScore() + m_ScoreAmount);
}

void Enemy::handlePlayerCollision(Projectile* projectile)
{
    
}