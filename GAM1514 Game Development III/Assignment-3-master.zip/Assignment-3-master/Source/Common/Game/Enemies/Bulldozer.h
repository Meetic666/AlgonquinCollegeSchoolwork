//
//  Student:        Quentin Bellay
//  Creation Date:  November 23rd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the bulldozer enemy (creates roads)
//  Modified:       
//

#ifndef BULLDOZER_H
#define BULLDOZER_H

#include "Enemy.h"

// Class representing the bulldozer enemy (creates roads), inherits Enemy
class Bulldozer : public Enemy
{
public:
	Bulldozer(Level* aLevel);
	~Bulldozer();

	virtual const char* getType();
    
    virtual void update(double delta);

	bool isAffectedByTileSpeed();
};

#endif