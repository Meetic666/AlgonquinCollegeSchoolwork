//
//  Student:        Quentin Bellay
//  Creation Date:  November 29th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the projectile base object
//  Modified:       
//

#include "Projectile.h"
#include "../Utils/Utils.h"
#include <math.h>
#include "../Constants/Constants.h"
#include "Tiles/Tile.h"

Projectile::Projectile(ProjectileListener* listener, int damage, float velocity) : GameObject(),
m_Listener(listener),
m_PreviousTile(NULL),
m_Damage(damage),
m_Velocity(velocity),
m_Angle(0.0f),
m_TargetX(0.0f),
m_TargetY(0.0f)
{
    
}

Projectile::~Projectile()
{
    
}

void Projectile::update(double delta)
{
    float x = getX() + m_Velocity * delta * cosf(m_Angle);
    float y = getY() + m_Velocity * delta * sinf(m_Angle);
    setPosition(x, y);
    
    if(m_Listener != NULL)
    {
        m_Listener -> handlePlayerCollision(this);
        m_Listener -> handleBoundsCollision(this);
    }
}

void Projectile::paint()
{
    OpenGLRenderer::getInstance() -> setForegroundColor(OpenGLColorGray());
    OpenGLRenderer::getInstance() -> setPointSize(3.0f);
    OpenGLRenderer::getInstance() -> drawPoint(getX(), getY());
    OpenGLRenderer::getInstance() -> setPointSize(1.0f);
}

void Projectile::reset()
{
    
}

const char* Projectile::getType()
{
    return PROJECTILE_TYPE;
}

void Projectile::setTarget(float x, float y)
{
    m_TargetX = x;
    m_TargetY = y;
    
    float deltaX = m_TargetX - getX();
    float deltaY = m_TargetY - getY();
    m_Angle = atan2f(deltaY, deltaX);
}

int Projectile::getDamage()
{
    return m_Damage;
}

Tile* Projectile::getPreviousTile()
{
	return m_PreviousTile;
}

void Projectile::setPreviousTile(Tile* tile)
{
	m_PreviousTile = tile;
}