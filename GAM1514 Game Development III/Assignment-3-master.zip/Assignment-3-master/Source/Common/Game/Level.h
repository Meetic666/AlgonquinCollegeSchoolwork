//
//  Student:        Quentin Bellay
//  Creation Date:  March 7th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the Level
//  Modified:       November 1st 2013: Added saving/loading option
//					November 5th 2013: Added connecting algorithm for tiles
//

#ifndef LEVEL_H
#define LEVEL_H

#include "../Constants/Constants.h"
#include <vector>


class Tile;
class Player;
class Hero;
class Enemy;
class GDRandom;
class PickUp;

// Level represents the tile set and player location
class Level
{
public:
	Level(bool isEditingLevel = false);
	~Level();
    
	//Update, paint and reset methods
	void update(double delta);
    void paint();
    void reset();
    
    //File IO
    void load(const char* levelName);
    void save(const char* levelName);
    void saveJSON(const char* levelName);
    void loadJSON(const char* levelName);
    
    //Input methods
    void mouseMovementEvent(float deltaX, float deltaY, float positionX, float positionY);
    void mouseLeftClickUpEvent(float positionX, float positionY);
    void mouseRightClickUpEvent(float positionX, float positionY);
    void keyUpEvent(int keyCode);
	
	//
    TileType getTileTypeForIndex(int index);
    
	//Tile count methods
    unsigned int getNumberOfTiles();
	unsigned int getNumberOfHorizontalTiles();
	unsigned int getNumberOfVerticalTiles();
    
	//Validate that the tile coordinates passed in are valid
	bool validateTileCoordinates(int coordinatesX, int coordinatesY);
    
	//Converts a position in screen space into a position in coordinate space
	int getTileCoordinateForPosition(int position);
    
	//Index methods
	int getTileIndexForPosition(int positionX, int positionY);
	int getTileIndexForCoordinates(int coordinatesX, int coordinatesY);
	int getTileIndexForTile(Tile* tile);
    int getTileIndexForPlayer(Player* player);
    
	//Tile methods
	Tile* getTileForPosition(int positionX, int positionY);
	Tile* getTileForCoordinates(int coordinatesX, int coordinatesY);
	Tile* getTileForIndex(int index);
    Tile* getTileForPlayer(Player* player);
    
    //
    void setTileTypeAtPosition(TileType tileType, int positionX, int positionY);
    void setTileTypeAtCoordinates(TileType tileType, int coordinatesX, int coordinatesY);
    void setTileTypeAtIndex(TileType tileType, int index, bool setSurroundingTiles = true, bool adaptRoadTiles = true);
    
    //
    void setPickUpTypeAtPosition(PickUpType pickUpType, int positionX, int positionY);
    void setPickUpTypeAtCoordinates(PickUpType pickUpType, int coordinatesX, int coordinatesY);
    void setPickUpTypeAtIndex(PickUpType pickUpType, int index);

	//
    void setTowerTypeAtPosition(TowerType towerType, int positionX, int positionY);
    void setTowerTypeAtCoordinates(TowerType towerType, int coordinatesX, int coordinatesY);
    void setTowerTypeAtIndex(TowerType towerType, int index);
    
    //Coveniance methods to toggle debug paint methods
    void togglePaintTileScoring();
    void togglePaintTileIndexes();

	bool isModified();
    
	//Disables the old tiles selection (if ground tile) and
	//enables the newly selected tiles selection (if ground tile)
	void setSelectedTileIndex(int selectedIndex);
    int getSelectedTileIndex();
    
    void setSpawnPointAtPosition(int positionX, int positionY);
    
    // Getter for the hero
    Hero* getHero();
    std::vector<Enemy*> getEnemies();

	int getGoldReserveIndex();

	int getNumberOfActiveEnemies();

	void startWave();

	void setNumberOfWaves(int numberOfWaves);
	int getNumberOfWavesRemaining();

	void killEnemy();
    
protected:    
    void clearEnemies();
    
	void setSurroundingTiles(int index, TileType tileType, TileType previousTileType);
    
	//Protected Member variables
	Hero* m_Hero;
    std::vector<Enemy*> m_Enemies;
	Tile** m_Tiles;
	unsigned int m_HorizontalTiles;
	unsigned int m_VerticalTiles;
	unsigned int m_TileSize;
    unsigned int m_PlayerStartingTileIndex;
	int m_SelectedTileIndex;
    bool m_PaintTileScoring;
    bool m_PaintTileIndexes;
    GDRandom* m_Rand;

	bool m_HasBeenModified;
    
    std::vector<int> m_SpawnPointIndexes;

	int m_NumberOfWavesToSpawn;
	double m_WaveTimer;
};

#endif
