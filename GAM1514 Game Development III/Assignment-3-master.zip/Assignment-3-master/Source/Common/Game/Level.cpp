//
//  Student:        Quentin Bellay
//  Creation Date:  March 7th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the Level
//  Modified:       November 1st 2013: Added saving/loading option
//					November 5th 2013: Added connecting algorithm for tiles
//

#include "Level.h"
#include "Player.h"
#include "Hero.h"
#include "Enemies/Enemies.h"
#include "Tiles/Tiles.h"
#include "../Constants/Constants.h"
#include "../Input/Input.h"
#include "../Screen Manager/ScreenManager.h"
#include <stdlib.h>
#include <fstream>
#include "../Utils/Logger/Logger.h"
#include "../Libraries/jsoncpp/json.h"
#include "../Math/GDRandom.h"
#include "PathFinder.h"
#include "Pick Ups/PickUps.h"
#include "Towers/Towers.h"
#include "Particles/Particles.h"


Level::Level(bool isEditingLevel) :
m_HorizontalTiles(0),
m_VerticalTiles(0),
m_TileSize(EMPTY_LEVEL_TILE_SIZE),
m_PlayerStartingTileIndex(EMPTY_LEVEL_STARTING_PLAYER_TILE_INDEX),
m_Hero(NULL),
m_Tiles(NULL),
m_SelectedTileIndex(-1),
m_PaintTileScoring(false),
m_PaintTileIndexes(false),
m_HasBeenModified(false),
m_NumberOfWavesToSpawn(1),
m_WaveTimer(0.0)
{
    m_Rand = new GDRandom();
    m_Rand -> randomizeSeed();
    
    //Create the player object
    if(isEditingLevel == false)
    {
        m_Hero = new Hero(this);
        
        for(int i = 0; i < ENEMY_COUNT; i++)
        {
			Enemy* enemy = NULL;
            
			int random = m_Rand -> random(10);
            
			if(random >= 5)
			{
				enemy = new Enemy(this);
			}
			else if (random >= 1)
			{
				enemy = new Bomber(this);
			}
			else
			{
				enemy = new Bulldozer(this);
			}
            
            m_Enemies.push_back(enemy);
        }
    }
    
    //Calculate the number of horizontal and vertical tiles
    m_HorizontalTiles = ScreenManager::getInstance()->getScreenWidth() / m_TileSize;
    m_VerticalTiles = ScreenManager::getInstance()->getScreenHeight() / m_TileSize;
    
    //Allocate the tiles array, the inheriting class will populate this array with Tile objects
	m_Tiles = new Tile*[m_HorizontalTiles * m_VerticalTiles];
    
    //Initialize all the tiles to NULL
    for(int i = 0; i < m_HorizontalTiles * m_VerticalTiles; i++)
    {
        m_Tiles[i] = NULL;
    }
    
    //Load an empty level
    load(NULL);
}

Level::~Level()
{
    //Delete the player object
	if(m_Hero != NULL)
	{
		delete m_Hero;
		m_Hero = NULL;
	}
    
    for(int i = 0; i < m_Enemies.size(); i++)
    {
        delete m_Enemies[i];
    }
    
    m_Enemies.clear();
    
    //Delete the tiles array, the inheriting class
    //must delete the object in this array itself
	if(m_Tiles != NULL)
	{
        //Cycle through and delete all the tile objects in the array
        for(int i = 0; i < getNumberOfTiles(); i++)
        {
            if(m_Tiles[i] != NULL)
            {
				m_Tiles[i] -> setParticle(NULL);

                delete m_Tiles[i];
                m_Tiles[i] = NULL;
            }
        }
        
		delete[] m_Tiles;
		m_Tiles = NULL;
	}
}

void Level::update(double aDelta)
{
	//Update all the game tiles
	for(int i = 0; i < getNumberOfTiles(); i++)
	{
		if(m_Tiles[i] != NULL)
		{
			m_Tiles[i]->update(aDelta);
		}
	}
    
	//Update the Player
	if(m_Hero != NULL && m_Hero -> getIsActive())
	{
		m_Hero->update(aDelta);
	}
    
    for(int i = 0; i < m_Enemies.size(); i++)
    {
		if(m_Enemies[i] -> getIsActive())
		{
			m_Enemies[i] -> update(aDelta);
		}
    }
    
	if(m_WaveTimer > 0.0)
	{
		m_WaveTimer -= aDelta;
	}
	else
	{
		startWave();
	}
}

void Level::paint()
{
	std::vector<Tower*> towers;

	//Cycle through and paint all the tiles
	for(int i = 0; i < getNumberOfTiles(); i++)
	{
        //Safety check the tile
		if(m_Tiles[i] != NULL)
		{
            //Paint the tile
            m_Tiles[i]->paint();

			if(m_Tiles[i] -> getTower() != NULL)
			{
				towers.push_back(m_Tiles[i] -> getTower());
			}
            
            //If the paint tile indexes flag is set to true,
            //draw the index number on the tiles
            if(m_PaintTileIndexes == true)
            {
                m_Tiles[i]->paintIndex(i);
            }
		}
	}

	for(int i = 0; i < towers.size(); i++)
	{
		towers.at(i) -> paint();
	}

	towers.clear();
    
	//Paint the Player
	if(m_Hero != NULL && m_Hero -> getIsActive())
	{
        //If paint tile scoring flag is set to true,
        //draw the path scoring
        if(m_PaintTileScoring == true)
        {
            m_Hero->getPathFinder()->paint();
        }
        
        //Paint the player
		m_Hero->paint();
	}
    
    for(int i = 0; i < m_Enemies.size(); i++)
    {
		if(m_Enemies[i] -> getIsActive())
		{
			m_Enemies[i] -> paint();
		}
    }
}

void Level::reset()
{
	//Cycle through and reset all the tiles
	for(int i = 0; i < getNumberOfTiles(); i++)
	{
		if(m_Tiles[i] != NULL)
		{
			m_Tiles[i]->reset();
		}
	}
    
	if(m_Hero != NULL)
	{
		m_Hero -> setCurrentTileIndex(m_PlayerStartingTileIndex);
	}
}

void Level::mouseMovementEvent(float deltaX, float deltaY, float positionX, float positionY)
{
    if(m_Hero != NULL)
    {
        m_Hero -> mouseMovementEvent(deltaX, deltaY, positionX, positionY);
    }
}

void Level::mouseLeftClickUpEvent(float aPositionX, float aPositionY)
{
	if(m_Hero != NULL)
    {
        m_Hero -> mouseLeftClickUpEvent(aPositionX, aPositionY);
    }
}

void Level::mouseRightClickUpEvent(float positionX, float positionY)
{
	
}

void Level::keyUpEvent(int keyCode)
{
    if(keyCode == KEYCODE_R)
    {
        reset();
    }
    else if(keyCode == KEYCODE_S)
    {
        togglePaintTileScoring();
    }
    else if(keyCode == KEYCODE_I)
    {
        togglePaintTileIndexes();
    }
    else if(keyCode == KEYCODE_D)
    {
        if(m_Hero != NULL)
        {
            m_Hero->getPathFinder()->togglePathFindingDelay();
        }
    }
	else if(keyCode == KEYCODE_K)
	{
		killEnemy();
	}
    else
    {
        if(m_Hero != NULL)
        {
            m_Hero -> keyUpEvent(keyCode);
        }
    }
}

void Level::load(const char* levelName)
{
    //If the level name isn't NULL load the level from the filesystem,
    //if it is NULL load an empty level with just ground tiles
    if(levelName != NULL)
    {        
        FILE* inputFile;
        
        inputFile = fopen(levelName, "rb");
        
        if(inputFile != NULL)
        {
            fseek(inputFile, 0, SEEK_END);
            size_t bufferSize = ftell(inputFile);
            size_t elementSize = sizeof(short);
            size_t bufferCount = bufferSize / elementSize;
            
            rewind(inputFile);
            
            short* buffer = new short[bufferCount];
            
            size_t bytesRead = fread(buffer, elementSize, bufferCount, inputFile);
            
            if(bytesRead == bufferCount)
            {
                for(int i = 0; i < bufferCount; i++)
                {
					m_Tiles[i] -> clearPickUps();

					if(m_Tiles[i] != NULL && m_Tiles[i] -> getTower() != NULL)
					{
						setTowerTypeAtIndex(TowerTypeUnknown, i);
					}

                    PickUpType pickUpType = PickUpTypeUnknown;
                    
                    if((buffer[i] & PickUpTypeAmmo) > 0)
                    {
                        pickUpType = PickUpTypeAmmo;
                        
                        buffer[i] &= ~PickUpTypeAmmo;
                    }
                    
                    setTileTypeAtIndex((TileType)buffer[i], i, true, false);
                    
                    setPickUpTypeAtIndex(pickUpType, i);
                }
            }
            
            fclose(inputFile);
            
            delete[] buffer;
            buffer = NULL;
        }
    }
    else
    {
		int tileType = -1;

        // Randomizing the tiles (desert or bush)
        for(int i = 0; i < getNumberOfTiles(); i++)
        {		
			tileType = m_Rand -> random(2);

            setTileTypeAtIndex((TileType)(1 << tileType), i, false);
        }
    }
}

void Level::save(const char* levelName)
{
    FILE* outputFile;
    
    outputFile = fopen(levelName, "wb");
    
    if(outputFile != NULL)
    {
        size_t bufferSize = getNumberOfTiles();
        short* buffer = new short[bufferSize];
        size_t elementSize = sizeof(short);
        
        for(int i = 0; i < bufferSize; i++)
        {
            buffer[i] = (int) m_Tiles[i] -> getTileType();
        }
        
        fwrite(buffer, bufferSize, elementSize, outputFile);
        
        fclose(outputFile);
        
        delete[] buffer;
        buffer = NULL;
    }
}

void Level::saveJSON(const char* levelName)
{
    std::string jsonFile = std::string(levelName);
    jsonFile += ".json";
    
    std::string binFile = std::string(levelName);
    binFile += ".bin";
    
    Json::Value root;
    root["TileSize"] = m_TileSize;
    root["HorizontalTiles"] = m_HorizontalTiles;
    root["VerticalTiles"] = m_VerticalTiles;
    root["PlayerStartingIndex"] = m_SelectedTileIndex;
    root["TilesBinFile"] = binFile;
    
    for(int i = 0; i < getNumberOfTiles(); i++)
    {
        if(m_Tiles[i] -> isSpawnPoint())
        {
            root["SpawnPoints"].append(i);
        }
    }
    
    std::ofstream outputStream;
    outputStream.open(jsonFile.c_str(), std::ofstream::out);
    
    if(outputStream.is_open())
    {
        Json::StyledStreamWriter writer;
        writer.write(outputStream, root);
        
        outputStream.close();
        
        save(binFile.c_str());
        
		m_HasBeenModified = false;
    }
}

void Level::loadJSON(const char* levelName)
{
    std::string jsonFile = std::string(levelName);
    jsonFile += ".json";
    
    std::ifstream inputStream;
    inputStream.open(jsonFile.c_str());
    
    if(inputStream.is_open())
    {
        Json::Value root;
        Json::Reader reader;
        
        if(reader.parse(inputStream, root) == true)
        {
            m_TileSize = root["TileSize"].asUInt();
            m_HorizontalTiles = root["HorizontalTiles"].asUInt();
            m_VerticalTiles = root["VerticalTiles"].asUInt();
            m_PlayerStartingTileIndex = root["PlayerStartingIndex"].asInt();
            
            std::string binFile = root["TilesBinFile"].asString();
            
            load(binFile.c_str());
            
			setSelectedTileIndex(m_PlayerStartingTileIndex);
            
            Json::Value spawnPoints = root["SpawnPoints"];
            int numberOfSpawnPoints = spawnPoints.size();
            
			for(int i = 0; i < m_SpawnPointIndexes.size(); i++)
            {
                m_Tiles[m_SpawnPointIndexes[i]] -> setIsSpawnPoint(false);
            }
            
            m_SpawnPointIndexes.clear();
            
            for(int i = 0; i < numberOfSpawnPoints; i++)
            {
                m_Tiles[spawnPoints[i].asInt()] -> setIsSpawnPoint(true);
                
                m_SpawnPointIndexes.push_back(spawnPoints[i].asInt());
            }
            
			setTileTypeAtIndex(TileTypeReserve, m_PlayerStartingTileIndex);
            
            //The level is loaded, reset everything
            reset();
        }
        
        inputStream.close();
        
		m_HasBeenModified = false;
        
        clearEnemies();
    }
}

TileType Level::getTileTypeForIndex(int index)
{
    if(index >= 0 && index < getNumberOfTiles())
    {
        return m_Tiles[index] -> getTileType();
    }
    
    return TileTypeUnknown;
}

unsigned int Level::getNumberOfTiles()
{
    return getNumberOfHorizontalTiles() * getNumberOfVerticalTiles();
}

unsigned int Level::getNumberOfHorizontalTiles()
{
	return m_HorizontalTiles;
}

unsigned int Level::getNumberOfVerticalTiles()
{
	return m_VerticalTiles;
}

bool Level::validateTileCoordinates(int aCoordinatesX, int aCoordinatesY)
{
    if(aCoordinatesX < 0 || aCoordinatesY < 0 || aCoordinatesX >= getNumberOfHorizontalTiles() || aCoordinatesY >= getNumberOfVerticalTiles())
	{
        return false;
    }
    return true;
}

int Level::getTileCoordinateForPosition(int aPosition)
{
	return (aPosition / m_TileSize);
}

int Level::getTileIndexForPosition(int aPositionX, int aPositionY)
{
	int coordinatesX = getTileCoordinateForPosition(aPositionX);
	int coordinatesY = getTileCoordinateForPosition(aPositionY);
	return getTileIndexForCoordinates(coordinatesX, coordinatesY);
}

int Level::getTileIndexForCoordinates(int aCoordinatesX, int aCoordinatesY)
{
	//Validate the coordinates, then calculate the array index
	if(validateTileCoordinates(aCoordinatesX, aCoordinatesY) == true)
	{
		return aCoordinatesX + (aCoordinatesY * getNumberOfHorizontalTiles());
	}
    
	return -1;
}

int Level::getTileIndexForTile(Tile* aTile)
{
	return getTileIndexForPosition(aTile->getX(), aTile->getY());
}

int Level::getTileIndexForPlayer(Player* player)
{
    return getTileIndexForPosition(player -> getX(), player -> getY());
}

Tile* Level::getTileForPosition(int aPositionX, int aPositionY)
{
	return getTileForIndex(getTileIndexForPosition(aPositionX, aPositionY));
}

Tile* Level::getTileForCoordinates(int aCoordinatesX, int aCoordinatesY)
{
	return getTileForIndex(getTileIndexForCoordinates(aCoordinatesX, aCoordinatesY));
}

Tile* Level::getTileForIndex(int aIndex)
{
    //Safety check the index bounds
	if(aIndex >= 0 && aIndex < getNumberOfTiles())
	{
		return m_Tiles[aIndex];
	}
    
    //If we got here, it means the index passed in was out of bounds
	return NULL;
}

Tile* Level::getTileForPlayer(Player* player)
{
    return getTileForPosition(player -> getX(), player -> getY());
}

void Level::setTileTypeAtPosition(TileType tileType, int positionX, int positionY)
{
    setTileTypeAtIndex(tileType, getTileIndexForPosition(positionX, positionY));
}

void Level::setTileTypeAtCoordinates(TileType tileType, int coordinatesX, int coordinatesY)
{
    setTileTypeAtIndex(tileType, getTileIndexForCoordinates(coordinatesX, coordinatesY));
}

void Level::setTileTypeAtIndex(TileType tileType, int index, bool setSurroundingTiles, bool adaptRoadTiles)
{
    //Safety check the index
    if(index >= 0 && index < getNumberOfTiles())
	{
        //Don't replace the tile if its the same type of tile that already exists
        if(m_Tiles[index] != NULL && m_Tiles[index]->getTileType() == tileType)
        {
            return;
        }
        
		m_HasBeenModified = true;
        
		TileType previousTileType = TileTypeUnknown;
        bool previousIsSpawnPoint = false;

		Particle* previousParticle = NULL;
        
        //Delete the tile at the index, if one exists
        if(m_Tiles[index] != NULL)
        {
            previousTileType = m_Tiles[index]->getTileType();
			previousIsSpawnPoint = m_Tiles[index] -> isSpawnPoint();
			previousParticle = m_Tiles[index] -> getParticle();
            
            delete m_Tiles[index];
            m_Tiles[index] = NULL;
        }

		if(adaptRoadTiles && tileType == TileTypeRoad && previousTileType == TileTypeRiver)
		{
			tileType = TileTypeBridge;
		}
        
        //Create the new tile based on the TileType
        switch (tileType)
        {
            case TileTypeBridge:
                m_Tiles[index] = new BridgeTile();
                break;
                
			case TileTypeRiver:
				m_Tiles[index] = new RiverTile();
				break;
                
			case TileTypeDesert:
				m_Tiles[index] = new DesertTile();
				break;
                
			case TileTypeRoad:
                m_Tiles[index] = new RoadTile();
                break;
                
			case TileTypeFence:
				m_Tiles[index] = new FenceTile();
				break;
                
			case TileTypeBush:
				m_Tiles[index] = new BushTile();
				break;
                
			case TileTypeExploded:
				m_Tiles[index] = new ExplodedTile();
				m_Tiles[index] -> setParticle(new Explosion());
				break;
                
			case TileTypeReserve:
				m_Tiles[index] = new ReserveTile();
				break;
                
            case TileTypeUnknown:
            default:
                m_Tiles[index] = NULL;
                break;
        }
        
		m_Tiles[index] ->setIsSpawnPoint(previousIsSpawnPoint);
        
		if(setSurroundingTiles)
		{
			if(getTileForIndex(index - 1) != NULL)
				getTileForIndex(index - 1) -> setIsTileStyleSet(false);
            
			if(getTileForIndex(index + 1) != NULL)
				getTileForIndex(index + 1) -> setIsTileStyleSet(false);
            
			if(getTileForIndex(index - getNumberOfHorizontalTiles()) != NULL)
				getTileForIndex(index - getNumberOfHorizontalTiles()) -> setIsTileStyleSet(false);
            
			if(getTileForIndex(index + getNumberOfHorizontalTiles()) != NULL)
				getTileForIndex(index + getNumberOfHorizontalTiles()) -> setIsTileStyleSet(false);
            
			Level::setSurroundingTiles(index, tileType, previousTileType);
		}
		
        
        //Calculate the coordinates and set the tile position and size
        int coordinateX = (index % getNumberOfHorizontalTiles());
        int coordinateY = ((index - coordinateX) / getNumberOfHorizontalTiles());
        m_Tiles[index]->setPosition(coordinateX  * m_TileSize, coordinateY * m_TileSize);
        m_Tiles[index]->setSize(m_TileSize, m_TileSize);

		if(previousParticle != NULL)
		{
			m_Tiles[index] -> setParticle(previousParticle);
		}
		
		if(m_Tiles[index] -> getParticle() != NULL)
		{
			m_Tiles[index] -> getParticle() -> setSize(m_Tiles[index]->getWidth(), m_Tiles[index]->getHeight());
			m_Tiles[index] -> getParticle() -> setPosition(m_Tiles[index]->getX(), m_Tiles[index]->getY());

			if(m_Tiles[index] -> getParticle() != previousParticle)
			{
				m_Tiles[index] -> getParticle() -> reset();
			}
		}
        
		if(m_Hero != NULL)
		{
			m_Hero -> recalculatePath();
		}
        
		for(int i = 0; i < m_Enemies.size(); i++)
		{
			m_Enemies.at(i) -> recalculatePath();
		}
	}
}

void Level::setPickUpTypeAtPosition(PickUpType pickUpType, int positionX, int positionY)
{
    setPickUpTypeAtIndex(pickUpType, getTileIndexForPosition(positionX, positionY));
}

void Level::setPickUpTypeAtCoordinates(PickUpType pickUpType, int coordinatesX, int coordinatesY)
{
    setPickUpTypeAtIndex(pickUpType, getTileIndexForCoordinates(coordinatesX, coordinatesY));
}

void Level::setPickUpTypeAtIndex(PickUpType pickUpType, int index)
{
    if(index >= 0 && index < getNumberOfTiles())
    {        
        if(m_Tiles[index] != NULL)
        {         
			PickUp* newPickUp = NULL;

            switch(pickUpType)
            {
                case PickUpTypeAmmo:
                {
                    GDRandom random;
                    random.randomizeSeed();
                    
                    int min = 20;
                    int max = 100;
                    int ammo = min + random.random(max - min);
                    
                    newPickUp = new AmmoPickUp(ammo);
                    
                    break;
                }
                    
                case PickUpTypeUnknown:
                default:
                    break;
            }
            
            if(newPickUp != NULL)
            {
                int coordinateX = (index % getNumberOfHorizontalTiles());
                int coordinateY = ((index - coordinateX) / getNumberOfHorizontalTiles());
                
				newPickUp -> setSize(m_Tiles[index] -> getWidth(), m_Tiles[index] -> getHeight());

                float x = (coordinateX * m_TileSize) + (m_TileSize - newPickUp -> getWidth()) / 2.0f;
                float y = (coordinateY * m_TileSize) + (m_TileSize - newPickUp -> getHeight()) / 2.0f;
                newPickUp -> setPosition(x, y);

				m_Tiles[index] -> setPickUp(newPickUp);

				newPickUp = NULL;
            }
        }
    }
}

void Level::setTowerTypeAtPosition(TowerType towerType, int positionX, int positionY)
{
	setTowerTypeAtIndex(towerType, getTileIndexForPosition(positionX, positionY));
}

void Level::setTowerTypeAtCoordinates(TowerType towerType, int coordinatesX, int coordinatesY)
{
	setTowerTypeAtIndex(towerType, getTileIndexForCoordinates(coordinatesX, coordinatesY));
}

void Level::setTowerTypeAtIndex(TowerType towerType, int index)
{
	if(index >= 0 && index < getNumberOfTiles())
    {
        if(m_Tiles[index] != NULL && m_Tiles[index] -> getTower() != NULL)
        {
            if(m_Tiles[index] -> getTower() -> getTowerType() == towerType)
            {
                return;
            }
        }
        
        if(m_Tiles[index] != NULL)
        {
            if(m_Tiles[index] -> getTower() != NULL)
            {
                m_Tiles[index] -> setTower(NULL);
            }
            
            switch(towerType)
            {
                case OfficerMachineGunType:
                {                    
                    m_Tiles[index] -> setTower(new OfficerMachineGun(this));                    
                    break;
                }

				case OfficerSniperType:
                {                    
                    m_Tiles[index] -> setTower(new OfficerSniper(this));                    
                    break;
                }

				case OfficerRocketLauncherType:
                {                    
                    m_Tiles[index] -> setTower(new OfficerRocketLauncher(this));                    
                    break;
                }

				case TowerSniperType:
                {                    
                    m_Tiles[index] -> setTower(new TowerSniper(this));                    
                    break;
                }

				case TowerGatlingGunType:
                {                    
                    m_Tiles[index] -> setTower(new TowerGatlingGun(this));                    
                    break;
                }

				case TowerCarpetBombingType:
                {                    
                    m_Tiles[index] -> setTower(new TowerCarpetBombing(this));                    
                    break;
                }
                    
                case TowerTypeUnknown:
                default:
                    break;
            }
            
            if(m_Tiles[index] -> getTower() != NULL)
            {
                int coordinateX = (index % getNumberOfHorizontalTiles());
                int coordinateY = ((index - coordinateX) / getNumberOfHorizontalTiles());
                
                Tower* tower = m_Tiles[index] -> getTower();
                float x = (coordinateX * m_TileSize) + (m_TileSize - tower -> getWidth()) / 2.0f;
                float y = (coordinateY * m_TileSize) + (m_TileSize - tower -> getHeight()) / 2.0f;
                tower -> setPosition(x, y);

				if(m_Hero != NULL)
				{
					m_Hero -> recalculatePath();
				}
        
				for(int i = 0; i < m_Enemies.size(); i++)
				{
					m_Enemies.at(i) -> recalculatePath();
				}
            }
        }
    }
}

void Level::togglePaintTileScoring()
{
    m_PaintTileScoring = !m_PaintTileScoring;
}

void Level::togglePaintTileIndexes()
{
    m_PaintTileIndexes = !m_PaintTileIndexes;
}

bool Level::isModified()
{
	return m_HasBeenModified;
}

void Level::setSelectedTileIndex(int aSelectedIndex)
{
	//Deselect the previously selected tile
	if(m_SelectedTileIndex >= 0 && m_SelectedTileIndex < getNumberOfTiles())
	{
		m_Tiles[m_SelectedTileIndex]->setIsSelected(false);
	}
    
	//Set the new tile index
	m_SelectedTileIndex = aSelectedIndex;
    
	m_HasBeenModified = true;
    
	//Selected the newly selected tile
	if(m_SelectedTileIndex >= 0 && m_SelectedTileIndex < getNumberOfTiles())
	{
		m_Tiles[m_SelectedTileIndex]->setIsSelected(true);
	}
}

int Level::getSelectedTileIndex()
{
    return m_SelectedTileIndex;
}

void Level::setSpawnPointAtPosition(int positionX, int positionY)
{
    Tile* tile = getTileForPosition(positionX, positionY);
    
    tile -> setIsSpawnPoint(!tile -> isSpawnPoint());
    
    m_HasBeenModified = true;
}

Hero* Level::getHero()
{
    return m_Hero;
}


std::vector<Enemy*> Level::getEnemies()
{
    return m_Enemies;
}

int Level::getGoldReserveIndex()
{
	return m_PlayerStartingTileIndex;
}

int Level::getNumberOfActiveEnemies()
{
	int result = 0;
    
	for(int i = 0; i < m_Enemies.size(); i++)
	{
		if(m_Enemies.at(i) -> getIsActive())
		{
			result++;
		}
	}
    
	return result;
}

void Level::startWave()
{
	if(m_NumberOfWavesToSpawn > 0)
	{
		m_WaveTimer = WAVE_TIME;
        
		m_NumberOfWavesToSpawn--;
        
		// Make a Player* vector to hold the Hero and Enemies
		std::vector<Player*> players;
        
		int numberToSpawn = ENEMY_COUNT_WAVE;
        
		for(int i = 0; i < m_Enemies.size(); i++)
		{
			players.push_back(m_Enemies[i]);
		}
        
		//Random number generator for the spawn indexes
		GDRandom random;
		random.randomizeSeed();
		int tileIndex = -1;
		std::vector<int> usedTileIndexes;
        
		for(int i = 0; i < players.size(); i++)
		{
			if(numberToSpawn > 0 && players.at(i) -> getIsActive() == false)
			{
				players.at(i) -> setIsActive(true);
                
				tileIndex = -1;
                
				while(tileIndex == -1)
				{
					if(m_SpawnPointIndexes.size() > 0)
					{
						tileIndex = m_SpawnPointIndexes.at(random.random(m_SpawnPointIndexes.size()));
					}
					else
					{
						tileIndex = random.random(getNumberOfTiles());
					}
                    
					Tile* tile = getTileForIndex(tileIndex);
                    
					if(tile -> isWalkableTile() == false)
					{
						tileIndex = -1;
					}
					else
					{
						for(int j = 0; j < usedTileIndexes.size(); j++)
						{
							if(usedTileIndexes.at(j) == tileIndex)
							{
								tileIndex = -1;
								break;
							}
						}
                        
						if(tileIndex != -1)
						{
							players.at(i) -> setCurrentTileIndex(tileIndex);
							players.at(i) -> reset();
							usedTileIndexes.push_back(tileIndex);
                            
							numberToSpawn--;
						}
					}
				}
			}
		}
	}
}

void Level::setNumberOfWaves(int numberOfWaves)
{
	m_NumberOfWavesToSpawn = numberOfWaves;
}

int Level::getNumberOfWavesRemaining()
{
	return m_NumberOfWavesToSpawn;
}

void Level::killEnemy()
{
	for(int i = 0; i < m_Enemies.size(); i++)
	{
		if(m_Enemies.at(i) -> getIsActive())
		{
			m_Enemies.at(i) -> applyDamage(BASIC_DAMAGE);
			return;
		}
	}
}

void Level::clearEnemies()
{
    for(int i = 0; i < m_Enemies.size(); i++)
    {
        m_Enemies.at(i) -> setIsActive(false);
    }
}

void Level::setSurroundingTiles(int index, TileType tileType, TileType previousTileType)
{
	Tile* tileUp = NULL;
    
	if(index >= getNumberOfHorizontalTiles())
		tileUp = getTileForIndex(index - getNumberOfHorizontalTiles());
    
	Tile* tileDown = NULL;
    
	if(index < getNumberOfTiles() - getNumberOfHorizontalTiles())
		tileDown = getTileForIndex(index + getNumberOfHorizontalTiles());
    
	Tile* tileLeft = NULL;
    
	if(index % getNumberOfHorizontalTiles() != 0)
		tileLeft = getTileForIndex(index - 1);
    
	Tile* tileRight = NULL;
    
	if(index % getNumberOfHorizontalTiles() !=  getNumberOfHorizontalTiles() - 1)
		tileRight = getTileForIndex(index + 1);
    
	bool connectsWithTileUp = false;
	bool connectsWithTileDown = false;
	bool connectsWithTileRight = false;
	bool connectsWithTileLeft = false;
    
	std::vector<int> connectsWith;
	getTileForIndex(index)->connectsWith(&connectsWith);
    
	for(int i = 0; i < connectsWith.size(); i++)
	{
		if(tileRight != NULL && tileRight->getTileType() == (TileType)connectsWith.at(i))
			connectsWithTileRight = true;
        
		if(tileLeft != NULL && tileLeft->getTileType() == (TileType)connectsWith.at(i))
			connectsWithTileLeft = true;
        
		if(tileUp != NULL && tileUp->getTileType() == (TileType)connectsWith.at(i))
			connectsWithTileUp = true;
        
		if(tileDown != NULL && tileDown->getTileType() == (TileType)connectsWith.at(i))
			connectsWithTileDown = true;
	}
    
	bool tileChanged = false;
    
	switch (tileType)
    {
        case TileTypeBridge:
            
			if(connectsWithTileLeft
               || connectsWithTileRight)
			{
				m_Tiles[index]->setRotation(90.0f);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(connectsWithTileUp
					|| connectsWithTileDown)
			{
				m_Tiles[index]->setRotation(0.0f);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
            
            break;
            
		case TileTypeRiver:
            
			if(connectsWithTileUp
               && connectsWithTileDown
               && connectsWithTileRight
               && connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(0.0f);
				m_Tiles[index]->setTileStyle(Cross);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(connectsWithTileUp
                    && !connectsWithTileDown
                    && connectsWithTileRight
                    && connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(0.0f);
				m_Tiles[index]->setTileStyle(TShaped);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(connectsWithTileUp
                    && connectsWithTileDown
                    && connectsWithTileRight
                    && !connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(90.0f);
				m_Tiles[index]->setTileStyle(TShaped);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(!connectsWithTileUp
                    && connectsWithTileDown
                    && connectsWithTileRight
                    && connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(180.0f);
				m_Tiles[index]->setTileStyle(TShaped);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(connectsWithTileUp
                    && connectsWithTileDown
                    && !connectsWithTileRight
                    && connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(-90.0f);
				m_Tiles[index]->setTileStyle(TShaped);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(connectsWithTileUp
                    && !connectsWithTileDown
                    && !connectsWithTileRight
                    && connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(0.0f);
				m_Tiles[index]->setTileStyle(Angled);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(!connectsWithTileUp
                    && connectsWithTileDown
                    && !connectsWithTileRight
                    && connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(-90.0f);
				m_Tiles[index]->setTileStyle(Angled);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(connectsWithTileUp
                    && !connectsWithTileDown
                    && connectsWithTileRight
                    && !connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(90.0f);
				m_Tiles[index]->setTileStyle(Angled);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(!connectsWithTileUp
                    && connectsWithTileDown
                    && connectsWithTileRight
                    && !connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(180.0f);
				m_Tiles[index]->setTileStyle(Angled);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(!connectsWithTileUp
                    && !connectsWithTileDown
                    && (connectsWithTileRight
                        || connectsWithTileLeft))
			{
				m_Tiles[index]->setRotation(0.0f);
				m_Tiles[index]->setTileStyle(Straight);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if((connectsWithTileUp
                     || connectsWithTileDown)
                    && !connectsWithTileRight
                    && !connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(90.0f);
				m_Tiles[index]->setTileStyle(Straight);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
            
			break;
            
		case TileTypeDesert:
            
			if(previousTileType == TileTypeRiver || previousTileType == TileTypeRoad || previousTileType == TileTypeBridge || previousTileType == TileTypeFence)
			{
				tileChanged = true;
			}
            
			break;
            
		case TileTypeRoad:
            
			if(connectsWithTileUp
               && connectsWithTileDown
               && connectsWithTileRight
               && connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(0.0f);
				m_Tiles[index]->setTileStyle(Cross);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(connectsWithTileUp
                    && !connectsWithTileDown
                    && connectsWithTileRight
                    && connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(0.0f);
				m_Tiles[index]->setTileStyle(TShaped);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(connectsWithTileUp
                    && connectsWithTileDown
                    && connectsWithTileRight
                    && !connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(90.0f);
				m_Tiles[index]->setTileStyle(TShaped);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(!connectsWithTileUp
                    && connectsWithTileDown
                    && connectsWithTileRight
                    && connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(180.0f);
				m_Tiles[index]->setTileStyle(TShaped);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(connectsWithTileUp
                    && connectsWithTileDown
                    && !connectsWithTileRight
                    && connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(-90.0f);
				m_Tiles[index]->setTileStyle(TShaped);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(connectsWithTileUp
                    && !connectsWithTileDown
                    && !connectsWithTileRight
                    && connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(0.0f);
				m_Tiles[index]->setTileStyle(Angled);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(!connectsWithTileUp
                    && connectsWithTileDown
                    && !connectsWithTileRight
                    && connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(-90.0f);
				m_Tiles[index]->setTileStyle(Angled);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(connectsWithTileUp
                    && !connectsWithTileDown
                    && connectsWithTileRight
                    && !connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(90.0f);
				m_Tiles[index]->setTileStyle(Angled);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(!connectsWithTileUp
                    && connectsWithTileDown
                    && connectsWithTileRight
                    && !connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(180.0f);
				m_Tiles[index]->setTileStyle(Angled);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(!connectsWithTileUp
                    && !connectsWithTileDown
                    && (connectsWithTileRight
                        || connectsWithTileLeft))
			{
				m_Tiles[index]->setRotation(0.0f);
				m_Tiles[index]->setTileStyle(Straight);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if((connectsWithTileUp
                     || connectsWithTileDown)
                    && !connectsWithTileRight
                    && !connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(90.0f);
				m_Tiles[index]->setTileStyle(Straight);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
            
            break;
            
		case TileTypeFence:
            
			if(connectsWithTileUp
               && connectsWithTileDown
               && connectsWithTileRight
               && connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(0.0f);
				m_Tiles[index]->setTileStyle(Cross);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(connectsWithTileUp
                    && !connectsWithTileDown
                    && connectsWithTileRight
                    && connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(0.0f);
				m_Tiles[index]->setTileStyle(TShaped);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(connectsWithTileUp
                    && connectsWithTileDown
                    && connectsWithTileRight
                    && !connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(90.0f);
				m_Tiles[index]->setTileStyle(TShaped);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(!connectsWithTileUp
                    && connectsWithTileDown
                    && connectsWithTileRight
                    && connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(180.0f);
				m_Tiles[index]->setTileStyle(TShaped);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(connectsWithTileUp
                    && connectsWithTileDown
                    && !connectsWithTileRight
                    && connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(-90.0f);
				m_Tiles[index]->setTileStyle(TShaped);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(connectsWithTileUp
                    && !connectsWithTileDown
                    && !connectsWithTileRight
                    && connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(0.0f);
				m_Tiles[index]->setTileStyle(Angled);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(!connectsWithTileUp
                    && connectsWithTileDown
                    && !connectsWithTileRight
                    && connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(-90.0f);
				m_Tiles[index]->setTileStyle(Angled);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(connectsWithTileUp
                    && !connectsWithTileDown
                    && connectsWithTileRight
                    && !connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(90.0f);
				m_Tiles[index]->setTileStyle(Angled);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(!connectsWithTileUp
                    && connectsWithTileDown
                    && connectsWithTileRight
                    && !connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(180.0f);
				m_Tiles[index]->setTileStyle(Angled);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if(!connectsWithTileUp
                    && !connectsWithTileDown
                    && (connectsWithTileRight
                        || connectsWithTileLeft))
			{
				m_Tiles[index]->setRotation(0.0f);
				m_Tiles[index]->setTileStyle(Straight);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
			else if((connectsWithTileUp
                     || connectsWithTileDown)
                    && !connectsWithTileRight
                    && !connectsWithTileLeft)
			{
				m_Tiles[index]->setRotation(90.0f);
				m_Tiles[index]->setTileStyle(Straight);
				m_Tiles[index]->setIsTileStyleSet(true);
                
				tileChanged = true;
			}
            
			break;
            
		case TileTypeBush:
            
			if(previousTileType == TileTypeRiver || previousTileType == TileTypeRoad || previousTileType == TileTypeBridge || previousTileType == TileTypeFence)
			{
				tileChanged = true;
			}
            
			break;
            
		case TileTypeReserve:
		case TileTypeExploded:
            
			break;
            
        case TileTypeUnknown:
        default:
            m_Tiles[index] = NULL;
            break;
    }
    
	if(tileChanged)
	{
		if(tileLeft != NULL && !tileLeft -> getIsTileStyleSet())
			setSurroundingTiles(index - 1, tileLeft->getTileType(), tileLeft->getTileType());
        
		if(tileRight != NULL && !tileRight -> getIsTileStyleSet())
			setSurroundingTiles(index + 1, tileRight->getTileType(), tileRight->getTileType());
        
		if(tileUp != NULL && !tileUp -> getIsTileStyleSet())
			setSurroundingTiles(index - getNumberOfHorizontalTiles(), tileUp->getTileType(), tileUp->getTileType());
        
		if(tileDown != NULL && !tileDown -> getIsTileStyleSet())
			setSurroundingTiles(index + getNumberOfHorizontalTiles(), tileDown->getTileType(), tileDown->getTileType());
	}
}
