#include "Game.h"
#include "GameObject.h"
#include "Level.h"
#include "../OpenGL/OpenGL.h"
#include "../Constants/Constants.h"
#include "../Utils/Utils.h"
#include "../Screen Manager/ScreenManager.h"
#include "GameData.h"
#include "../UI/UIWidgets.h"
#include "Hero.h"
#include "Towers/Towers.h"
#include <stdlib.h>
#include <algorithm>
#include "Tiles/Tile.h"
#include "../Menus/Menus.h"
#include "ProfileManager.h"


Game::Game() :
m_UIFont(NULL),
m_TowerMenu(NULL),
m_UpgradeMenu(NULL),
m_UpgradeChoiceMenu(NULL),
m_PauseMenu(NULL),
m_InterestTimer(INTEREST_TIMER),
m_SelectedTowerType(-1),
m_UpgradingOfficer(false)
{
    //Create the level object
    m_Level = new Level();
	m_LevelTimer = GameData::getInstance() -> getTimeLimit();
    
	m_BetweenWaveTimer = 0.0;
    
	m_UIFont = new UIFont(RES_BITMAP_FONT);
    
	// Uses slot button for now, has to change to actual tower buttons...
	m_TowerMenu = new UISideMenu(this, SideMenuRight);
	m_TowerMenu->addButton(new UIToggle(MENU_OFFICER_MACHINE_GUN));
	m_TowerMenu->addButton(new UIToggle(MENU_OFFICER_SNIPER));
	m_TowerMenu->addButton(new UIToggle(MENU_OFFICER_ROCKET_LAUNCHER));
    m_TowerMenu->addButton(new UIToggle(MENU_TOWER_SNIPER));
    m_TowerMenu->addButton(new UIToggle(MENU_TOWER_GATLING_GUN));
	m_TowerMenu->addButton(new UIToggle(MENU_TOWER_CARPET_BOMBING));
    
    m_UpgradeMenu = new UISideMenu(this, SideMenuRight);
	m_UpgradeMenu->addButton(new UIButton(MENU_RANGE_UPGRADE));
	m_UpgradeMenu->addButton(new UIButton(MENU_DAMAGE_UPGRADE));
	m_UpgradeMenu->addButton(new UIButton(MENU_FIRING_RATE_UPGRADE));
    
    m_UpgradeChoiceMenu = new UISideMenu(this, SideMenuRight);
	m_UpgradeChoiceMenu ->addButton(new UIButton(MENU_TOWER_BUTTON));
	m_UpgradeChoiceMenu ->addButton(new UIButton(MENU_OFFICER_BUTTON));
    
	m_PauseMenu = new UISideMenu(this, SideMenuLeft);
	m_PauseMenu ->addButton(new UIButton(MENU_GAME_RESUME_BUTTON));
	m_PauseMenu ->addButton(new UIButton(MENU_GAME_EXIT_BUTTON));
    
	m_SpeedMultiplierSlow = OpenGLTextureCache::getInstance() ->getTexture(RES_SPEED_MULTIPLIER_SLOW);
	m_SpeedMultiplierMedium = OpenGLTextureCache::getInstance() ->getTexture(RES_SPEED_MULTIPLIER_MEDIUM);
	m_SpeedMultiplierFast = OpenGLTextureCache::getInstance() ->getTexture(RES_SPEED_MULTIPLIER_FAST);
    
    //Reset everything
    reset();
}

Game::~Game()
{
    //Delete the level object
    if(m_Level != NULL)
    {
        delete m_Level;
        m_Level = NULL;
    }
    
	if(m_UIFont != NULL)
	{
		delete m_UIFont;
		m_UIFont = NULL;
	}
    
	if(m_TowerMenu != NULL)
	{
		delete m_TowerMenu;
		m_TowerMenu = NULL;
	}
    
	if(m_PauseMenu != NULL)
	{
		delete m_PauseMenu;
		m_PauseMenu = NULL;
	}
    
    if(m_UpgradeMenu != NULL)
	{
		delete m_UpgradeMenu;
		m_UpgradeMenu = NULL;
	}
    
    if(m_UpgradeChoiceMenu != NULL)
	{
		delete m_UpgradeChoiceMenu;
		m_UpgradeChoiceMenu = NULL;
	}
	
	GameData::getInstance() -> saveGame();
	GameData::getInstance() -> saveHighScores();
	ProfileManager::getInstance() -> saveProfiles();

	GameData::cleanUpInstance();	
	ProfileManager::cleanUpInstance();
}

void Game::update(double delta)
{    
	if(m_PauseMenu != NULL)
	{
		m_PauseMenu -> update(delta);
	}
    
    if(m_UpgradeMenu != NULL)
	{
		m_UpgradeMenu -> update(delta);
	}
    
    if(m_UpgradeChoiceMenu != NULL)
	{
		m_UpgradeChoiceMenu -> update(delta);
	}
    
	if(m_TowerMenu != NULL)
	{
		m_TowerMenu -> update(delta);
        
		for(int i = 0; i < 6; i++)
		{
			if(((i < 3) && (i < GameData::getInstance() -> getOfficerTiersUnlocked()))
               || ((i >= 3) && (i < 3 + GameData::getInstance() -> getTowerTiersUnlocked())))
			{
				m_TowerMenu -> getButtonForIndex(i) ->swapOverlay("");
			}
			else
			{
				m_TowerMenu -> getButtonForIndex(i) ->swapOverlay(MENU_LOCK_OVERLAY);
			}
		}
	}
    
    if(m_PauseMenu -> isShowing())
    {
        return;
    }
    
	delta *= GameData::getInstance() -> getSpeedMultiplier();
    
	if(m_BetweenWaveTimer > 0.0)
	{
		m_BetweenWaveTimer -= delta;
        
		if(m_BetweenWaveTimer <= 0.0)
		{
			m_BetweenWaveTimer = 0.0;
            
			if(m_Level != NULL)
			{
				GameData::getInstance() -> setCurrentWave(GameData::getInstance() -> getCurrentWave() + 1);
                
				m_Level -> setNumberOfWaves(GameData::getInstance() -> getCurrentWave());
                
				m_Level -> startWave();
			}
		}
	}
    
    if(m_Level != NULL)
    {
        m_Level->update(delta);
        
		if(m_BetweenWaveTimer <= 0.0 && m_Level -> getNumberOfWavesRemaining() == 0 && m_Level -> getNumberOfActiveEnemies() == 0)
		{
			m_BetweenWaveTimer = TIME_BETWEEN_WAVES;
		}
    }
    
	if(m_InterestTimer > 0.0)
	{
		m_InterestTimer -= delta;
	}
	else
	{
		if(GameData::getInstance() -> getGoldReserve() != 0)
		{
			GameData::getInstance() -> setGoldReserve(GameData::getInstance() -> getGoldReserve() * (1 + INTEREST_PER_ITERATION));
		}
		else if(m_Level -> getNumberOfActiveEnemies() == 0)
		{
			GameData::getInstance() -> setGoldReserve(FEDERAL_RESERVE_ALLOWANCE);
		}
        
		m_InterestTimer = INTEREST_TIMER;
	}
    
	if(m_LevelTimer > 0.0)
	{
		m_LevelTimer -= delta;
	}
	else
	{
		if(GameData::getInstance() -> getGoldReserve() > 0)
		{            
			m_LevelTimer = GameData::getInstance() -> getTimeLimit();

			GameData::getInstance() -> setHighScore();
            
			GameData::getInstance() -> setCurrentWave(1);
            
			if(GameData::getInstance() -> getCurrentLevel() < 6)
			{
				GameData::getInstance() -> setCurrentLevel(GameData::getInstance() -> getCurrentLevel() + 1);
				
				if(GameData::getInstance() -> getCurrentLevel() > GameData::getInstance() -> getNumberOfUnlockedLevels())
				{
					GameData::getInstance() -> setNumberOfUnlockedLevels(GameData::getInstance() -> getCurrentLevel());
				}

				ScreenManager::getInstance() -> switchScreen(LEVEL_COMPLETE_SCREEN_NAME);
			}
			else
			{
				ScreenManager::getInstance() -> switchScreen(GAME_COMPLETE_SCREEN_NAME);
			}
		}
		else
		{
			ScreenManager::getInstance() -> switchScreen(GAME_OVER_SCREEN_NAME);
		}
	}
}

void Game::paint()
{
    if(m_Level != NULL)
    {
        m_Level->paint();
    }
    
	// Display HUD
	if(m_UIFont != NULL)
	{
		float x = 0.0f;
		float y = 0.0f;
        
		float width = getWidth();
		float height = getHeight();
        
		char buffer[20];
        
		std::string text = std::string("Score: ");
		sprintf(buffer, "%u", GameData::getInstance() -> getScore());
		text += buffer;
		m_UIFont -> setText(text.c_str());
		x = width * SCORE_PERCENTAGE_X;
		y = height * HUD_PERCENTAGE_Y;
		m_UIFont -> draw(x, y);
        
		text = std::string("Gold: ");
		sprintf(buffer, "%u", GameData::getInstance() -> getGoldReserve());
		text += buffer;
		m_UIFont -> setText(text.c_str());
		x = width * GOLD_PERCENTAGE_X - m_UIFont -> getWidth();
		m_UIFont -> draw(x, y);
        
		unsigned int minutes = (int)m_LevelTimer / 60;
		unsigned int seconds = (int)m_LevelTimer % 60;
        
		sprintf(buffer, "%u", minutes);
		text = std::string(buffer) + " : ";
        
		if(seconds < 10)
		{
			text += "0";
		}
        
		sprintf(buffer, "%u", seconds);
		text += buffer;
		m_UIFont -> setText(text.c_str());
		x = width * TIME_PERCENTAGE_X - m_UIFont -> getWidth() / 2;
		m_UIFont -> draw(x, y);
        
		text = "Level: ";
		sprintf(buffer, "%u", GameData::getInstance() -> getCurrentLevel());
		text += buffer;
		m_UIFont -> setText(text.c_str());
		x = width * LEVEL_PERCENTAGE_X;
		y = height * (1 - HUD_PERCENTAGE_Y) - m_UIFont -> getHeight();
		m_UIFont -> draw(x, y);
        
		if(m_BetweenWaveTimer > 0.0)
		{
			text = "Next Wave in: ";
			sprintf(buffer, "%u", (unsigned int)m_BetweenWaveTimer + 1);
			text += buffer;
			m_UIFont -> setText(text.c_str());
			x = width * TIME_PERCENTAGE_X - m_UIFont -> getWidth() / 2;
			y = height * (1 - HUD_PERCENTAGE_Y) - m_UIFont -> getHeight();
			m_UIFont -> draw(x, y);
		}
        else
        {
            text = "Ammo: ";
            sprintf(buffer, "%u", GameData::getInstance() -> getInstance() -> getAmmo());
            text += buffer;
            m_UIFont -> setText(text.c_str());
			x = width * TIME_PERCENTAGE_X - m_UIFont -> getWidth() / 2;
			y = height * (1 - HUD_PERCENTAGE_Y) - m_UIFont -> getHeight();
            m_UIFont -> draw(x, y);
        }
        
		text = "Wave: ";
		sprintf(buffer, "%u", GameData::getInstance() -> getCurrentWave());
		text += buffer;
		m_UIFont -> setText(text.c_str());
		x = width * WAVE_PERCENTAGE_X - m_UIFont -> getWidth();
		y = height * (1 - HUD_PERCENTAGE_Y) - m_UIFont -> getHeight();
		m_UIFont -> draw(x, y);
        
        if(m_PauseMenu -> isShowing())
        {
            text = "Paused";
            m_UIFont -> setText(text.c_str());
            x = (width - m_UIFont -> getWidth()) * 0.5f;
            y = (height - m_UIFont -> getHeight()) * 0.5f;
            m_UIFont -> draw(x, y);
        }
	}
    
	if(m_TowerMenu != NULL)
	{
		m_TowerMenu -> paint();

		if(m_UIFont != NULL && m_TowerMenu -> isShowing())
        {
            float x = 0.0f;
            
            float y = 0.0f;
            
            char buffer[20];

            sprintf(buffer, "%uG", MACHINE_GUN_PRICE);
            m_UIFont -> setText(buffer);
            x = m_TowerMenu -> getButtonForIndex(0) -> getCenterX() - m_UIFont -> getWidth() * 0.5f;
			clampX(m_TowerMenu, x);
            y = m_TowerMenu -> getButtonForIndex(0) -> getCenterY() - m_TowerMenu -> getButtonForIndex(0) -> getHeight() / 2 - m_UIFont -> getHeight() * 0.3f;
            m_UIFont -> draw(x, y);
                
			if(GameData::getInstance() -> getOfficerTiersUnlocked() >= 2)
			{
				sprintf(buffer, "%uG", SNIPER_PRICE);				
			}
			else
			{
				sprintf(buffer, "%uG", SNIPER_UNLOCK_PRICE);
			}

			m_UIFont -> setText(buffer);
			x = m_TowerMenu -> getButtonForIndex(1) -> getCenterX() - m_UIFont -> getWidth() * 0.5f;
			clampX(m_TowerMenu, x);
			y = m_TowerMenu -> getButtonForIndex(1) -> getCenterY() - m_TowerMenu -> getButtonForIndex(1) -> getHeight() / 2 - m_UIFont -> getHeight() * 0.3f;
			m_UIFont -> draw(x, y);
                
			if(GameData::getInstance() -> getOfficerTiersUnlocked() >= 3)
			{
				sprintf(buffer, "%uG", ROCKET_LAUNCHER_PRICE);				
			}
			else
			{
				sprintf(buffer, "%uG", ROCKET_LAUNCHER_UNLOCK_PRICE);
			}

            m_UIFont -> setText(buffer);
            x = m_TowerMenu -> getButtonForIndex(2) -> getCenterX() - m_UIFont -> getWidth() * 0.5f;
			clampX(m_TowerMenu, x);
            y = m_TowerMenu -> getButtonForIndex(2) -> getCenterY() - m_TowerMenu -> getButtonForIndex(2) -> getHeight() / 2 - m_UIFont -> getHeight() * 0.3f;
            m_UIFont -> draw(x, y);

			sprintf(buffer, "%uG", TOWER_SNIPER_PRICE);
            m_UIFont -> setText(buffer);
            x = m_TowerMenu -> getButtonForIndex(3) -> getCenterX() - m_UIFont -> getWidth() * 0.5f;
			clampX(m_TowerMenu, x);
            y = m_TowerMenu -> getButtonForIndex(3) -> getCenterY() - m_TowerMenu -> getButtonForIndex(3) -> getHeight() / 2 - m_UIFont -> getHeight() * 0.5f;
            m_UIFont -> draw(x, y);
                
			if(GameData::getInstance() -> getTowerTiersUnlocked() >= 2)
			{
				sprintf(buffer, "%uG", TOWER_GATLING_GUN_PRICE);				
			}
			else
			{
				sprintf(buffer, "%uG", TOWER_GATLING_GUN_UNLOCK_PRICE);
			}

            m_UIFont -> setText(buffer);
            x = m_TowerMenu -> getButtonForIndex(4) -> getCenterX() - m_UIFont -> getWidth() * 0.5f;
			clampX(m_TowerMenu, x);
            y = m_TowerMenu -> getButtonForIndex(4) -> getCenterY() - m_TowerMenu -> getButtonForIndex(4) -> getHeight() / 2 - m_UIFont -> getHeight() * 0.5f;
            m_UIFont -> draw(x, y);
               
			if(GameData::getInstance() -> getTowerTiersUnlocked() >= 3)
			{
				sprintf(buffer, "%uG", TOWER_CARPET_BOMBING_PRICE);				
			}
			else
			{
				sprintf(buffer, "%uG", TOWER_CARPET_BOMBING_UNLOCK_PRICE);
			}

            sprintf(buffer, "%uG", TOWER_CARPET_BOMBING_PRICE);
            m_UIFont -> setText(buffer);
            x = m_TowerMenu -> getButtonForIndex(5) -> getCenterX() - m_UIFont -> getWidth() * 0.5f;
			clampX(m_TowerMenu, x);
            y = m_TowerMenu -> getButtonForIndex(5) -> getCenterY() - m_TowerMenu -> getButtonForIndex(5) -> getHeight() / 2 - m_UIFont -> getHeight() * 0.5f;
            m_UIFont -> draw(x, y);
        }
	}
    
	if(m_PauseMenu != NULL)
	{
		m_PauseMenu -> paint();
	}
    
    if(m_UpgradeMenu != NULL)
	{
		m_UpgradeMenu -> paint();
        
        if(m_UIFont != NULL && m_UpgradeMenu -> isShowing())
        {
            float x = 0.0f;
            
            float y = 0.0f;
            
            char buffer[20];
            
            if(m_UpgradingOfficer)
            {
                sprintf(buffer, "%uG", OFFICER_RANGE_UPGRADE_PRICE);
                m_UIFont -> setText(buffer);
                x = m_UpgradeMenu -> getButtonForIndex(0) -> getCenterX() - m_UIFont -> getWidth() * 0.5f;
				clampX(m_UpgradeMenu, x);
                y = m_UpgradeMenu -> getButtonForIndex(0) -> getCenterY() - m_UpgradeMenu -> getButtonForIndex(0) -> getHeight() / 2 - m_UIFont -> getHeight() * 0.5f;
                m_UIFont -> draw(x, y);
                
                sprintf(buffer, "%u", GameData::getInstance() -> getOfficerRangeUpgrade());
                m_UIFont -> setText(buffer);
                x = m_UpgradeMenu -> getButtonForIndex(0) -> getCenterX() - m_UIFont -> getWidth() * 0.5f;
				clampX(m_UpgradeMenu, x);
                y = m_UpgradeMenu -> getButtonForIndex(0) -> getCenterY() - m_UpgradeMenu -> getButtonForIndex(0) -> getHeight() / 6 - m_UIFont -> getHeight() * 0.5f;
                m_UIFont -> draw(x, y);
                
                sprintf(buffer, "%uG", OFFICER_DAMAGE_UPGRADE_PRICE);
                m_UIFont -> setText(buffer);
                x = m_UpgradeMenu -> getButtonForIndex(1) -> getCenterX() - m_UIFont -> getWidth() * 0.5f;
				clampX(m_UpgradeMenu, x);
                y = m_UpgradeMenu -> getButtonForIndex(1) -> getCenterY() - m_UpgradeMenu -> getButtonForIndex(1) -> getHeight() / 2 - m_UIFont -> getHeight() * 0.5f;
                m_UIFont -> draw(x, y);
                
                sprintf(buffer, "%u", GameData::getInstance() -> getOfficerDamageUpgrade());
                m_UIFont -> setText(buffer);
                x = m_UpgradeMenu -> getButtonForIndex(1) -> getCenterX() - m_UIFont -> getWidth() * 0.5f;
				clampX(m_UpgradeMenu, x);
                y = m_UpgradeMenu -> getButtonForIndex(1) -> getCenterY() - m_UpgradeMenu -> getButtonForIndex(1) -> getHeight() / 6 - m_UIFont -> getHeight() * 0.5f;
                m_UIFont -> draw(x, y);
                
                sprintf(buffer, "%uG", OFFICER_FIRING_RATE_UPGRADE_PRICE);
                m_UIFont -> setText(buffer);
                x = m_UpgradeMenu -> getButtonForIndex(2) -> getCenterX() - m_UIFont -> getWidth() * 0.5f;
				clampX(m_UpgradeMenu, x);
                y = m_UpgradeMenu -> getButtonForIndex(2) -> getCenterY() - m_UpgradeMenu -> getButtonForIndex(2) -> getHeight() / 2 - m_UIFont -> getHeight() * 0.5f;
                m_UIFont -> draw(x, y);
                
                sprintf(buffer, "%u", GameData::getInstance() -> getOfficerFiringRateUpgrade());
                m_UIFont -> setText(buffer);
                x = m_UpgradeMenu -> getButtonForIndex(2) -> getCenterX() - m_UIFont -> getWidth() * 0.5f;
				clampX(m_UpgradeMenu, x);
                y = m_UpgradeMenu -> getButtonForIndex(2) -> getCenterY() - m_UpgradeMenu -> getButtonForIndex(2) -> getHeight() / 6 - m_UIFont -> getHeight() * 0.5f;
                m_UIFont -> draw(x, y);
            }
            else
            {
                sprintf(buffer, "%uG", TOWER_RANGE_UPGRADE_PRICE);
                m_UIFont -> setText(buffer);
                x = m_UpgradeMenu -> getButtonForIndex(0) -> getCenterX() - m_UIFont -> getWidth() * 0.5f;
				clampX(m_UpgradeMenu, x);
                y = m_UpgradeMenu -> getButtonForIndex(0) -> getCenterY() - m_UpgradeMenu -> getButtonForIndex(0) -> getHeight() / 2 - m_UIFont -> getHeight() * 0.5f;
                m_UIFont -> draw(x, y);
                
                sprintf(buffer, "%u", GameData::getInstance() -> getTowerRangeUpgrade());
                m_UIFont -> setText(buffer);
                x = m_UpgradeMenu -> getButtonForIndex(0) -> getCenterX() - m_UIFont -> getWidth() * 0.5f;
				clampX(m_UpgradeMenu, x);
                y = m_UpgradeMenu -> getButtonForIndex(0) -> getCenterY() - m_UpgradeMenu -> getButtonForIndex(0) -> getHeight() / 6 - m_UIFont -> getHeight() * 0.5f;
                m_UIFont -> draw(x, y);
                
                sprintf(buffer, "%uG", TOWER_DAMAGE_UPGRADE_PRICE);
                m_UIFont -> setText(buffer);
                x = m_UpgradeMenu -> getButtonForIndex(1) -> getCenterX() - m_UIFont -> getWidth() * 0.5f;
				clampX(m_UpgradeMenu, x);
                y = m_UpgradeMenu -> getButtonForIndex(1) -> getCenterY() - m_UpgradeMenu -> getButtonForIndex(1) -> getHeight() / 2 - m_UIFont -> getHeight() * 0.5f;
                m_UIFont -> draw(x, y);
                
                sprintf(buffer, "%u", GameData::getInstance() -> getTowerDamageUpgrade());
                m_UIFont -> setText(buffer);
                x = m_UpgradeMenu -> getButtonForIndex(1) -> getCenterX() - m_UIFont -> getWidth() * 0.5f;
				clampX(m_UpgradeMenu, x);
                y = m_UpgradeMenu -> getButtonForIndex(1) -> getCenterY() - m_UpgradeMenu -> getButtonForIndex(1) -> getHeight() / 6 - m_UIFont -> getHeight() * 0.5f;
                m_UIFont -> draw(x, y);
                
                sprintf(buffer, "%uG", TOWER_FIRING_RATE_UPGRADE_PRICE);
                m_UIFont -> setText(buffer);
                x = m_UpgradeMenu -> getButtonForIndex(2) -> getCenterX() - m_UIFont -> getWidth() * 0.5f;
				clampX(m_UpgradeMenu, x);
                y = m_UpgradeMenu -> getButtonForIndex(2) -> getCenterY() - m_UpgradeMenu -> getButtonForIndex(2) -> getHeight() / 2 - m_UIFont -> getHeight() * 0.5f;
                m_UIFont -> draw(x, y);
                
                sprintf(buffer, "%u", GameData::getInstance() -> getTowerFiringRateUpgrade());
                m_UIFont -> setText(buffer);
                x = m_UpgradeMenu -> getButtonForIndex(2) -> getCenterX() - m_UIFont -> getWidth() * 0.5f;
				clampX(m_UpgradeMenu, x);
                y = m_UpgradeMenu -> getButtonForIndex(2) -> getCenterY() - m_UpgradeMenu -> getButtonForIndex(2) -> getHeight() / 6 - m_UIFont -> getHeight() * 0.5f;
                m_UIFont -> draw(x, y);
            }
        }
	}
    
    if(m_UpgradeChoiceMenu != NULL)
	{
		m_UpgradeChoiceMenu -> paint();
	}
    
	if(GameData::getInstance() -> getSpeedMultiplier() == SPEED_MULTIPLIER_SLOW)
	{
		OpenGLRenderer::getInstance() -> drawTexture(m_SpeedMultiplierSlow, getWidth() * 0.48f, 0.0f);
	}
	else if(GameData::getInstance() -> getSpeedMultiplier() == SPEED_MULTIPLIER_MEDIUM)
	{
		OpenGLRenderer::getInstance() -> drawTexture(m_SpeedMultiplierMedium, getWidth() * 0.48f, 0.0f);
	}
	else if(GameData::getInstance() -> getSpeedMultiplier() == SPEED_MULTIPLIER_FAST)
	{
		OpenGLRenderer::getInstance() -> drawTexture(m_SpeedMultiplierFast, getWidth() * 0.48f, 0.0f);
	}
}

void Game::reset()
{
    if(m_Level != NULL)
    {
        m_Level->reset();
    }
    
	GameData::getInstance() -> reset();
}

const char* Game::getName()
{
	return GAME_SCREEN_NAME;
}

Level* Game::getLevel()
{
    return m_Level;
}

void Game::setLevelTimer(double timer)
{
	m_LevelTimer = timer;
}

void Game::mouseMovementEvent(float deltaX, float deltaY, float positionX, float positionY)
{
	if(m_SelectedTowerType == -1)
	{
		m_Level -> mouseMovementEvent(deltaX, deltaY, positionX, positionY);
	}
	else
	{
		if(std::find(m_AllowedTilesForTower.begin(), m_AllowedTilesForTower.end(), m_Level -> getTileForPosition(positionX, positionY) -> getTileType()) != m_AllowedTilesForTower.end())
		{
			m_Level -> setSelectedTileIndex(m_Level -> getTileIndexForPosition(positionX, positionY));
		}
		else
		{
			m_Level -> setSelectedTileIndex(-1);
		}
	}
    
	if(m_TowerMenu != NULL)
	{
		m_TowerMenu -> mouseMovementEvent(deltaX, deltaY, positionX, positionY);
	}
    
	if(m_PauseMenu != NULL)
	{
		m_PauseMenu -> mouseMovementEvent(deltaX, deltaY, positionX, positionY);
	}
    
    if(m_UpgradeMenu != NULL)
	{
		m_UpgradeMenu -> mouseMovementEvent(deltaX, deltaY, positionX, positionY);
	}
    
    if(m_UpgradeChoiceMenu != NULL)
	{
		m_UpgradeChoiceMenu -> mouseMovementEvent(deltaX, deltaY, positionX, positionY);
	}
}

void Game::mouseLeftClickUpEvent(float positionX, float positionY)
{
	bool clickInMenu = false;
    
	if(m_TowerMenu != NULL)
	{
		clickInMenu = m_TowerMenu -> mouseLeftClickUpEvent(positionX, positionY);
	}
    
	if(!clickInMenu && m_PauseMenu != NULL)
	{
		clickInMenu = m_PauseMenu -> mouseLeftClickUpEvent(positionX, positionY);
	}    
    
    if(!clickInMenu && m_UpgradeMenu != NULL)
	{
		clickInMenu = m_UpgradeMenu -> mouseLeftClickUpEvent(positionX, positionY);
	}
    
    if(!clickInMenu && m_UpgradeChoiceMenu != NULL)
	{
		clickInMenu = m_UpgradeChoiceMenu -> mouseLeftClickUpEvent(positionX, positionY);
	}
    
    if(!clickInMenu && m_Level != NULL)
    {
		if(m_SelectedTowerType == -1)
		{
			m_Level->mouseLeftClickUpEvent(positionX, positionY);
		}
		else
		{
            if(std::find(m_AllowedTilesForTower.begin(), m_AllowedTilesForTower.end(), m_Level -> getTileForPosition(positionX, positionY) -> getTileType()) != m_AllowedTilesForTower.end())
            {
                m_Level -> setTowerTypeAtPosition((TowerType)m_SelectedTowerType, positionX, positionY);
            }
		}
    }
}

void Game::mouseRightClickUpEvent(float positionX, float positionY)
{
	if(m_Level != NULL)
    {
        m_Level->mouseRightClickUpEvent(positionX, positionY);
    }
}

void Game::keyUpEvent(int keyCode)
{
	if(keyCode == KEYCODE_1)
	{
		GameData::getInstance() -> setSpeedMultiplier(SPEED_MULTIPLIER_SLOW);
	}
	else if(keyCode == KEYCODE_2)
	{
		GameData::getInstance() -> setSpeedMultiplier(SPEED_MULTIPLIER_MEDIUM);
	}
	else if(keyCode == KEYCODE_3)
	{
		GameData::getInstance() -> setSpeedMultiplier(SPEED_MULTIPLIER_FAST);
	}
    else if(keyCode == KEYCODE_ESCAPE)
    {
        if(m_PauseMenu != NULL)
        {
            m_PauseMenu -> isShowing() ? m_PauseMenu -> hide(): m_PauseMenu -> show();
        }
    }
	else if(keyCode == KEYCODE_TAB)
	{
		if(m_TowerMenu != NULL)
		{
			m_TowerMenu -> isShowing() ? m_TowerMenu -> hide(): m_TowerMenu -> show();
		}

		if(m_UpgradeChoiceMenu != NULL)
		{
            m_UpgradeChoiceMenu -> hide();
		}

		if(m_UpgradeMenu != NULL)
        {
            m_UpgradeMenu -> hide();
        }
	}
    else if(keyCode == KEYCODE_CONTROL)
    {
        if(m_UpgradeChoiceMenu != NULL)
		{
            if(m_UpgradeMenu != NULL && m_UpgradeMenu -> isShowing() == false)
            {
                m_UpgradeChoiceMenu -> isShowing() ? m_UpgradeChoiceMenu -> hide(): m_UpgradeChoiceMenu -> show();
            }
            else
            {
                m_UpgradeMenu -> hide();
            }
		}

		if(m_TowerMenu != NULL)
		{
			m_TowerMenu -> hide();
		}
    }
	else
	{
		if(m_Level != NULL)
		{
			m_Level->keyUpEvent(keyCode);
		}
	}
}

void Game::sideMenuButtonAction(UISideMenu* sideMenu, UIButton* button, int buttonIndex)
{
    if(sideMenu == m_PauseMenu)
    {
        if(buttonIndex == 0)
        {
            
        }
        else if(buttonIndex == 1)
        {
            ((MainMenu*)(ScreenManager::getInstance() -> getScreenForName(MAIN_MENU_SCREEN_NAME))) -> setIsPlaying(true);
            
            ScreenManager::getInstance() -> switchScreen(MAIN_MENU_SCREEN_NAME);
        }
        
        m_PauseMenu -> hide();
    }
    else if(sideMenu == m_UpgradeChoiceMenu)
    {
        if(buttonIndex == 0)
        {
            m_UpgradingOfficer = false;
        }
        else if(buttonIndex == 1)
        {
            m_UpgradingOfficer = true;
        }
        
        m_UpgradeMenu -> show();
        m_UpgradeChoiceMenu -> hide();
    }
    else if(sideMenu == m_UpgradeMenu)
    {
        int priceToPay = -1;
        
        if(m_UpgradingOfficer)
        {
            switch(buttonIndex)
            {
                case 0:
                    priceToPay = OFFICER_RANGE_UPGRADE_PRICE;
                    break;
                    
                case 1:
                    priceToPay = OFFICER_DAMAGE_UPGRADE_PRICE;
                    break;
                    
                case 2:
                    priceToPay = OFFICER_FIRING_RATE_UPGRADE_PRICE;
                    break;
                    
                default:
                    break;
            }
            
            if(priceToPay <= GameData::getInstance() -> getGoldReserve())
            {
                switch(buttonIndex)
                {
                    case 0:
                        GameData::getInstance() -> setOfficerRangeUpgrade(GameData::getInstance() -> getOfficerRangeUpgrade() + 1);
                        break;
                        
                    case 1:
                        GameData::getInstance() -> setOfficerDamageUpgrade(GameData::getInstance() -> getOfficerDamageUpgrade() + 1);
                        break;
                        
                    case 2:
                        GameData::getInstance() -> setOfficerFiringRateUpgrade(GameData::getInstance() -> getOfficerFiringRateUpgrade() + 1);
                        break;
                        
                    default:
                        break;
                }
                
                GameData::getInstance() -> setGoldReserve(GameData::getInstance() -> getGoldReserve() - priceToPay);
            }
        }
        else
        {
            switch(buttonIndex)
            {
                case 0:
                    priceToPay = TOWER_RANGE_UPGRADE_PRICE;
                    break;
                    
                case 1:
                    priceToPay = TOWER_DAMAGE_UPGRADE_PRICE;
                    break;
                    
                case 2:
                    priceToPay = TOWER_FIRING_RATE_UPGRADE_PRICE;
                    break;
                    
                default:
                    break;
            }
            
            if(priceToPay <= GameData::getInstance() -> getGoldReserve())
            {
                switch(buttonIndex)
                {
                    case 0:
                        GameData::getInstance() -> setTowerRangeUpgrade(GameData::getInstance() -> getTowerRangeUpgrade() + 1);
                        break;
                        
                    case 1:
                        GameData::getInstance() -> setTowerDamageUpgrade(GameData::getInstance() -> getTowerDamageUpgrade() + 1);
                        break;
                        
                    case 2:
                        GameData::getInstance() -> setTowerFiringRateUpgrade(GameData::getInstance() -> getTowerFiringRateUpgrade() + 1);
                        break;
                        
                    default:
                        break;
                }
                
                GameData::getInstance() -> setGoldReserve(GameData::getInstance() -> getGoldReserve() - priceToPay);
            }
        }
    }
}

void Game::sideMenuToggleAction(UISideMenu* sideMenu, UIToggle* toggle, int toggleIndex)
{
	if(sideMenu == m_TowerMenu)
	{
		//Un-toggled the previously selected toggle
        UIToggle* previousToggle = (UIToggle*)m_TowerMenu->getButtonForIndex(m_SelectedTowerType);
        if(previousToggle != NULL)
        {
            previousToggle->setIsToggled(false);
			m_AllowedTilesForTower.clear();
        }
        
		if(((toggleIndex < 3) && (toggleIndex < GameData::getInstance() -> getOfficerTiersUnlocked()))
           || ((toggleIndex >= 3) && (toggleIndex < 3 + GameData::getInstance() -> getTowerTiersUnlocked())))
		{
			//Set the selected tile index
			m_SelectedTowerType = toggle->isToggled() == true ? toggleIndex : -1;
            
			switch((TowerType)m_SelectedTowerType)
			{
                case OfficerMachineGunType:
                case OfficerSniperType:
                case OfficerRocketLauncherType:
                    Officer::getBuildableTiles(m_AllowedTilesForTower);
                    break;
                    
                case TowerSniperType:
                case TowerGatlingGunType:
                case TowerCarpetBombingType:
                    WatchTower::getBuildableTiles(m_AllowedTilesForTower);
                    break;
                    
                case TowerTypeUnknown:
                default:
                    break;
			}
            
			//Hide the options and tiles menus
			m_TowerMenu->hide();
		}
		else if((toggleIndex == GameData::getInstance() -> getOfficerTiersUnlocked()) || (toggleIndex == 3 + GameData::getInstance() -> getTowerTiersUnlocked()))
		{
			UIToggle* currentToggle = (UIToggle*)m_TowerMenu->getButtonForIndex(toggleIndex);
			if(currentToggle != NULL)
			{
				currentToggle->setIsToggled(false);
			}

			m_SelectedTowerType = -1;
            
			int priceToPay = -1;
            
			switch((TowerType)toggleIndex)
			{
                case OfficerMachineGunType:
                    break;
                    
                case OfficerSniperType:
                    priceToPay = SNIPER_UNLOCK_PRICE;
                    break;
                    
                case OfficerRocketLauncherType:
                    priceToPay = ROCKET_LAUNCHER_UNLOCK_PRICE;
                    break;
                    
                case TowerSniperType:
                    break;
                    
                case TowerGatlingGunType:
					priceToPay = TOWER_GATLING_GUN_UNLOCK_PRICE;
                    break;
                    
                case TowerCarpetBombingType:
					priceToPay = TOWER_CARPET_BOMBING_UNLOCK_PRICE;
                    break;
                    
                case TowerTypeUnknown:
                default:
                    break;
			}
            
			if(priceToPay != -1 && priceToPay <= GameData::getInstance() -> getGoldReserve())
			{
				GameData::getInstance() -> setGoldReserve(GameData::getInstance() -> getGoldReserve() - priceToPay);
                
				switch((TowerType)toggleIndex)
				{
                    case OfficerMachineGunType:
                    case OfficerSniperType:
                    case OfficerRocketLauncherType:
                        GameData::getInstance() -> setOfficerTiersUnlocked(GameData::getInstance() -> getOfficerTiersUnlocked() + 1);
                        break;
                        
                    case TowerSniperType:
                    case TowerGatlingGunType:
                    case TowerCarpetBombingType:
                        GameData::getInstance() -> setTowerTiersUnlocked(GameData::getInstance() -> getTowerTiersUnlocked() + 1);
                        break;
                        
                    case TowerTypeUnknown:
                    default:
                        break;
				}
			}
		}
		else
		{
			m_SelectedTowerType = -1;

			UIToggle* currentToggle = (UIToggle*)m_TowerMenu->getButtonForIndex(toggleIndex);
			if(currentToggle != NULL)
			{
				currentToggle->setIsToggled(false);
			}
		}
	}
}

void Game::clampX(UISideMenu* menu, float &x)
{
	if(menu -> getState() == SideMenuOpen && x + m_UIFont -> getWidth() > getWidth())
	{
		x = getWidth() - m_UIFont -> getWidth();
	}
}
