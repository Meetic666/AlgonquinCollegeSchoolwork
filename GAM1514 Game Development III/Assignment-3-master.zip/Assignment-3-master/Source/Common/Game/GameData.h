//
//  Student:        Quentin Bellay
//  Creation Date:  November 24th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the game data
//  Modified:       
//

#ifndef GAME_DATA_H
#define GAME_DATA_H

#include <string>
#include <vector>

// Class representing the game data, storing every relevant information
class GameData
{
public:
	static GameData* getInstance();
	static void cleanUpInstance();

	void reset();

	void saveGame();
	void loadGame();

	void saveHighScores();
	void loadHighScores();

	void setSaveFileName(std::string saveFileName);

	void setDifficulty(unsigned char difficulty);
	void setScore(unsigned int score);
	void setStartingGold(unsigned int startingGold);
	void setHighScore();	
	void setTimeLimit(double timeLimit);
	void setGoldReserve(unsigned int goldReserve);
	void setCurrentLevel(unsigned char currentLevel);
	void setCurrentWave(unsigned char currentWave);
	void setNumberOfUnlockedLevels(unsigned char numberOfUnlockedLevels);
	void setOfficerTiersUnlocked(unsigned char numberOfTiersUnlocked);
	void setOfficerRangeUpgrade(unsigned char officerRangeUpgrade);
	void setOfficerFiringRateUpgrade(unsigned char officerFiringRateUpgrade);
	void setOfficerDamageUpgrade(unsigned char officerDamageUpgrade);
	void setTowerTiersUnlocked(unsigned char numberOfTiersUnlocked);
	void setTowerRangeUpgrade(unsigned char officerRangeUpgrade);
	void setTowerFiringRateUpgrade(unsigned char officerFiringRateUpgrade);
	void setTowerDamageUpgrade(unsigned char officerDamageUpgrade);
	void setSpeedMultiplier(unsigned char multiplier);
    void setAmmo(unsigned int ammo);
	void setProfileName(const char* profileName);

	unsigned char getDifficulty();
	unsigned int getScore();
	unsigned int getStartingGold();
	std::vector<unsigned int> getHighScore();
	std::vector<std::string> getNames();
	unsigned char getNumberOfHighScores();
	double getTimeLimit();
	unsigned int getGoldReserve();
	unsigned char getCurrentLevel();
	unsigned char getCurrentWave();
	unsigned char getNumberOfUnlockedLevels();
	unsigned char getOfficerTiersUnlocked();
	unsigned char getOfficerRangeUpgrade();
	unsigned char getOfficerFiringRateUpgrade();
	unsigned char getOfficerDamageUpgrade();
	unsigned char getTowerTiersUnlocked();
	unsigned char getTowerRangeUpgrade();
	unsigned char getTowerFiringRateUpgrade();
	unsigned char getTowerDamageUpgrade();
	unsigned char getSpeedMultiplier();
    unsigned int getAmmo();
	const char* getProfileName();

	void stealGold(int amount);

private:
	GameData();
	~GameData();

	static GameData* s_Instance;

	unsigned char m_Difficulty;
	unsigned int m_Score;
	unsigned int m_StartingGold;
	std::vector<unsigned int> m_HighScores;
	std::vector<std::string> m_HighScoreNames;
	unsigned char m_NumberOfHighScores;
	double m_TimeLimit;
	unsigned int m_GoldReserve;
	unsigned char m_CurrentLevel;
	unsigned char m_CurrentWave;
	unsigned char m_NumberOfUnlockedLevels;
	unsigned char m_OfficerTiersUnlocked;
	unsigned char m_OfficerRangeUpgrade;
	unsigned char m_OfficerFiringRateUpgrade;
	unsigned char m_OfficerDamageUpgrade;
	unsigned char m_TowerTiersUnlocked;
	unsigned char m_TowerRangeUpgrade;
	unsigned char m_TowerFiringRateUpgrade;
	unsigned char m_TowerDamageUpgrade;
	unsigned char m_SpeedMultiplier;
	std::string m_CurrentSaveGame;
    unsigned int m_Ammo;
	std::string m_ProfileName;
};

#endif