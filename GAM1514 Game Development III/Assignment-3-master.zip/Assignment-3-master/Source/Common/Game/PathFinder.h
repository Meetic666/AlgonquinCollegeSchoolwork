//
//  Student:        Quentin Bellay
//  Creation Date:  November 8th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing a path finding object
//  Modified:		November 10th 2013: Added values to tiles so that some are faster
//

#ifndef PATH_FINDER_H
#define PATH_FINDER_H

#include <vector>
#include "../Constants/Constants.h"

#define PATH_FINDING_DELAY 1.0

class Level;
class Tile;
class PathNode;
class Player;
class PathFinderListener;

class PathFinder
{
public:
    PathFinder(Level* level, Player* player);
    ~PathFinder();
    
    void findPath(int currentTileIndex, int destinationTileIndex, bool affectedByTileSpeed);
    
    void update(double delta);
    void paint(); //Only paint in debug mode, draws the G, H and F scores
    void reset();
    
    bool isSearchingPath();
    
    int getPathSize();
    PathNode* getPathNodeAtIndex(int index);
    
    void togglePathFindingDelay();

	void setWalkableTiles(Player* player);
    
private:
    void addAdjacentTile(std::vector<int>& adjacentTiles, int currentTileIndex, int deltaX, int deltaY);
    
    bool doesTileExistInClosedList(int tileIndex);
    bool doesTileExistInOpenList(int tileIndex);
    
    PathNode* getOpenPathNodeForTileIndex(int tileIndex);
    
    void sortOpenList();
    void addPathNodeToOpenList(PathNode* pathNode);
    
	void buildFinalNodePath(PathNode* pathNode);
    void clearPathNodes();
    
	int getManhattanDistanceCost(int startTileIndex, int destinationTileIndex);

	bool isTileWalkable(Tile* tile);
    
    //Enum to keep track of the internal state of the path finder
    enum PathFinderState
    {
        StateIdle = 0,
        StateSearchingPath,
        StateFoundPath,
        StateError
    };
    
    //Member variables
    Level* m_Level;
	Player* m_Player;
    PathFinderListener* m_Listener;
    PathFinderState m_State;
    int m_DestinationTileIndex;
    double m_SearchDelay;
    bool m_EnableSearchDelay;
	std::vector<TileType> m_WalkableTiles;
	std::vector<PathNode*> m_PathNodeOpen;
	std::vector<PathNode*> m_PathNodeClosed;
	std::vector<PathNode*> m_PathNodeFinal;
    bool m_AffectedByTileSpeed;
};

class PathFinderListener
{
public:
    virtual void pathFinderFinishedSearching(PathFinder* pathFinder, bool pathWasFound) = 0;
};


#endif