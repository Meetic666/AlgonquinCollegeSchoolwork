//
//  Student:        Quentin Bellay
//  Creation Date:  November 22nd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the hero
//  Modified:       
//

#ifndef __GAM_1514_OSX_Game__Hero__
#define __GAM_1514_OSX_Game__Hero__

#include "Player.h"

// Class representing the hero
class Hero : public Player
{
public:
    Hero(Level* aLevel);
    ~Hero();
    
    const char* getType();
    
    void mouseMovementEvent(float deltaX, float deltaY, float positionX, float positionY);
    void mouseLeftClickUpEvent(float positionX, float positionY);
    void keyUpEvent(int keyCode);
    
protected:
    void handlePlayerCollision(Projectile* projectile);

	bool handlePickUp(PickUp* pickUp);
};

#endif /* defined(__GAM_1514_OSX_Game__Hero__) */
