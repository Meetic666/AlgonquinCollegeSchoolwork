//
//  Student:        Quentin Bellay
//  Creation Date:  December 10th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the explosion particle
//  Modified:       
//

#include "Explosion.h"
#include "../../Constants/Constants.h"

Explosion::Explosion() : Particle()
{
	m_AnimatedTexture = new OpenGLAnimatedTexture(RES_EXPLOSION, false);
	m_AnimatedTexture -> setListener(this);
}

Explosion::~Explosion()
{

}