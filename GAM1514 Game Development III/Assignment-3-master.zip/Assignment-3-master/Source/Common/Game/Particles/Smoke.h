//
//  Student:        Quentin Bellay
//  Creation Date:  December 10th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the smoke particle
//  Modified:       
//

#ifndef SMOKE_H
#define SMOKE_H

#include "Particle.h"

// Class representing the smoke particle, inherits Particle
class Smoke : public Particle
{
public:
	Smoke();
	~Smoke();
};

#endif