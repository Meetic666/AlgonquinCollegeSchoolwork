//
//  Student:        Quentin Bellay
//  Creation Date:  December 10th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the particle base class
//  Modified:       
//

#ifndef PARTICLE_H
#define PARTICLE_H

#include "../GameObject.h"
#include "../../OpenGL/OpenGL.h"

// Class representing the particle base class
class Particle : public GameObject, public OpenGLAnimatedTextureListener
{
public:
	Particle();
	virtual ~Particle();

	//Game lifecycle methods
	void update(double delta);
	void paint();
	void reset();

	//Pure virtual method to easily determine type of object
	const char* getType();

protected:
	void animatedTextureDidFinishAnimating(OpenGLAnimatedTexture* animatedTexture);

	OpenGLAnimatedTexture* m_AnimatedTexture;
};

#endif