//
//  Student:        Quentin Bellay
//  Creation Date:  December 10th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the smoke particle
//  Modified:       
//

#include "Smoke.h"
#include "../../Constants/Constants.h"

Smoke::Smoke() : Particle()
{
	m_AnimatedTexture = new OpenGLAnimatedTexture(RES_SMOKE, false, 4.0f);
	m_AnimatedTexture -> setListener(this);
}

Smoke::~Smoke()
{

}