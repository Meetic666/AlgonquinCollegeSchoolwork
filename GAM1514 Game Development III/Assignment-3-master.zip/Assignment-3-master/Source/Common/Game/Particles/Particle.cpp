//
//  Student:        Quentin Bellay
//  Creation Date:  December 10th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the particle base class
//  Modified:       
//

#include "Particle.h"
#include "../../Constants/Constants.h"

Particle::Particle() : GameObject(),
	m_AnimatedTexture(NULL)
{
	setIsActive(false);
}

Particle::~Particle()
{
	if(m_AnimatedTexture != NULL)
	{
		delete m_AnimatedTexture;
		m_AnimatedTexture = NULL;
	}
}

void Particle::update(double delta)
{
	if(getIsActive() && m_AnimatedTexture != NULL)
	{
		m_AnimatedTexture -> update(delta);
	}
}

void Particle::paint()
{
	if(getIsActive() && m_AnimatedTexture != NULL)
	{
		OpenGLRenderer::getInstance() -> drawTexture(m_AnimatedTexture, getX(), getY(), getWidth(), getHeight());
	}
}

void Particle::reset()
{
	if(m_AnimatedTexture != NULL)
	{
		m_AnimatedTexture -> reset();

		setIsActive(true);
	}
}

const char* Particle::getType()
{
	return PARTICLE_TYPE;
}

void Particle::animatedTextureDidFinishAnimating(OpenGLAnimatedTexture* animatedTexture)
{
	setIsActive(false);
}