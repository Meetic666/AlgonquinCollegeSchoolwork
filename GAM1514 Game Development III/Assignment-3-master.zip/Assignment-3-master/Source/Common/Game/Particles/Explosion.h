//
//  Student:        Quentin Bellay
//  Creation Date:  December 10th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the explosion particle
//  Modified:       
//

#ifndef EXPLOSION_H
#define EXPLOSION_H

#include "Particle.h"

// Class representing the explosion particle, inherits Particle
class Explosion : public Particle
{
public:
	Explosion();
	~Explosion();
};

#endif