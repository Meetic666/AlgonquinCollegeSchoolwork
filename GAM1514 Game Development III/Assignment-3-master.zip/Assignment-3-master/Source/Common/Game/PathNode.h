//
//  Student:        Quentin Bellay
//  Creation Date:  November 8th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing a path node
//  Modified:
//

#ifndef __GAM_1514_OSX_Game__PathNode__
#define __GAM_1514_OSX_Game__PathNode__

#include "../OpenGL/OpenGL.h"

class Tile;

// Class representing a path node
class PathNode
{
public:
    PathNode(int tileIndex);
    ~PathNode();
    
    float getGScore();
    float getHScore();
    float getFinalScore();
    
    void setGScore(float gScore);
    void setHScore(float hScore);
    
    void setParentNode(PathNode* parentNode);
    PathNode* getParentNode();
    
    int getTileIndex();
    
    static bool compareNodes(PathNode* nodeA, PathNode* nodeB);
    
private:
    float m_GScore;
    float m_HScore;
    PathNode* m_ParentNode;
    int m_TileIndex;
};

#endif /* defined(__GAM_1514_OSX_Game__PathNode__) */
