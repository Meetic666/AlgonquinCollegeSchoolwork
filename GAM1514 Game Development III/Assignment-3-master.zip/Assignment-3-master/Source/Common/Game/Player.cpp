//
//  Player.cpp
//  GAM-1532 OSX Game
//
//  Created by Bradley Flood on 2013-03-07.
//  Copyright (c) 2013 Algonquin College. All rights reserved.
//

#include "Player.h"
#include "Level.h"
#include "Tiles/Tile.h"
#include "../OpenGL/OpenGL.h"
#include "../Constants/Constants.h"
#include <stdlib.h>
#include <algorithm>
#include <math.h>
#include "PathFinder.h"
#include "PathNode.h"
#include "Pick Ups/PickUps.h"
#include "../Utils/Utils.h"

Player::Player(Level* aLevel, int maxHealth) :
m_PathFinder(NULL),
m_Speed(PLAYER_SPEED),
m_Level(aLevel),
m_Health(0),
m_MaxHealth(maxHealth),
m_MaxDamage(BASIC_DAMAGE),
m_DamageUpgrade(0),
m_ProjectileSpeed(BASIC_PROJECTILE_SPEED),
m_DestroyTower(false),
m_FiringParticle(NULL),
m_IsEnemy(false)
{
    //Initialize the current and destination tiles to NULL
    m_CurrentTileIndex = -1;
    m_DestinationTileIndex = -1;
    
    //Initialize the animation member variables
    m_CanAnimate = false;
    m_AbortAnimation = false;
    m_AnimationPathNodeIndex = -1;
    
    //Initialize the player's size
    setSize(PLAYER_SIZE, PLAYER_SIZE);
    
    m_PathFinder = new PathFinder(aLevel, this);

	m_WalkableTiles.push_back(TileTypeDesert);
	m_WalkableTiles.push_back(TileTypeBush);
	m_WalkableTiles.push_back(TileTypeBridge);
	m_WalkableTiles.push_back(TileTypeRoad);
	m_WalkableTiles.push_back(TileTypeExploded);
	m_WalkableTiles.push_back(TileTypeReserve);
}

Player::~Player()
{    
    if(m_PathFinder != NULL)
    {
        delete m_PathFinder;
        m_PathFinder = NULL;
    }

	if(m_FiringParticle != NULL)
	{
		delete m_FiringParticle;
		m_FiringParticle = NULL;
	}
}

void Player::update(double aDelta)
{
	if(getIsActive())
	{
		for(int i = 0; i < m_Projectiles.size(); i++)
		{
			if(m_Projectiles.at(i) -> getIsActive())
			{
				m_Projectiles.at(i) -> update(aDelta);
			}
		}
    
		int index = 0;
		while(index != m_Projectiles.size())
		{
			if(m_Projectiles.at(index) -> getIsActive() == false)
			{            
				delete m_Projectiles.at(index);
				m_Projectiles.erase(m_Projectiles.begin() + index);
			}
			else
			{
				index++;
			}
		}
    
		if(m_PathFinder->isSearchingPath())
		{
			m_PathFinder->update(aDelta);
		}
    
		if(isAnimating() && m_AnimationPathNodeIndex > -1)
		{
			PathNode* pathNode = m_PathFinder->getPathNodeAtIndex(m_AnimationPathNodeIndex);
			Tile* tile = pathNode != NULL ? m_Level->getTileForIndex(pathNode->getTileIndex()) : NULL;
        
			if(tile != NULL)
			{
				float centerX = tile->getX() + (tile->getWidth() - getWidth()) / 2.0f;
				float centerY = tile->getY() + (tile->getHeight() - getHeight()) / 2.0f;
            
				float playerX = animate(getX(), centerX, aDelta);
				float playerY = animate(getY(), centerY, aDelta);
				setPosition(playerX, playerY);
                
                if(centerX > getX())
                {
                    m_Rotation = -90;
                }
                else if(centerX < getX())
                {
                    m_Rotation = 90;
                }
                else if(centerY > getY())
                {
                    m_Rotation = 0;
                }
                else if(centerY < getY())
                {
                    m_Rotation = -180;
                }
            
				if(playerX == centerX && playerY == centerY)
				{
					m_AnimationPathNodeIndex++;
                
					m_Level -> getTileForIndex(m_CurrentTileIndex) -> setIsPath(false);
                
					setCurrentTileIndex(m_Level -> getTileIndexForTile(tile));
                
					std::vector<PickUp*> tilePickUps = tile -> getPickUps();
					bool pickUpsHandled = false;

					for(int i = 0; i < tilePickUps.size(); i++)
					{
						if(tilePickUps.at(i) != NULL)
						{
							pickUpsHandled = handlePickUp(tilePickUps.at(i));
						}
					}

					if(pickUpsHandled)
					{
						tile -> clearPickUps();
					}
                
					if(m_AnimationPathNodeIndex >= m_PathFinder->getPathSize())
					{
						stopAnimating();
						m_Level -> getTileForIndex(m_CurrentTileIndex)->setIsPath(false);
					}
                
					if(m_AbortAnimation)
					{
						m_AbortAnimation = false;
                    
						findPath();
					}
				}
			}
		}

		if(m_FiringParticle != NULL)
		{
			m_FiringParticle -> update(aDelta);
		}
	}
}

void Player::paint()
{    
    if(m_Texture != NULL)
    {
        OpenGLRenderer::getInstance() -> drawTexture(m_Texture, getX(), getY(), getWidth(), getHeight(), getRotation());
    }

	if(m_FiringParticle != NULL)
	{
		m_FiringParticle -> paint();
	}
	
	for(int i = 0; i < m_Projectiles.size(); i++)
    {
        if(m_Projectiles.at(i) -> getIsActive())
        {
            m_Projectiles.at(i) -> paint();
        }
    }
}

void Player::reset()
{
	m_Health = m_MaxHealth;

    m_DestinationTileIndex = -1;
    
    stopAnimating();
    
    m_PathFinder->reset();
    
    setIsActive(true);
}

void Player::setCurrentTileIndex(int tileIndex)
{
	//Set the current tile pointer
	m_CurrentTileIndex = tileIndex;
    
	Tile* tile = m_Level -> getTileForIndex(tileIndex);

	//Center the player's position on the tile
	setPosition(tile->getX() + ((tile->getWidth() - getWidth()) / 2), tile->getY() + ((tile->getHeight() - getHeight()) / 2));
}

void Player::setDestinationTileIndex(int tileIndex)
{
    m_DestinationTileIndex = tileIndex;
    
    if(isAnimating())
    {
        m_AbortAnimation = true;        
    }
    else
    {
        findPath();
    }
}


void Player::recalculatePath()
{
	if(isAnimating())
    {
        m_AbortAnimation = true;        
    }
    else
    {
        findPath();
    }
}

bool Player::isAffectedByTileSpeed()
{
    return true;
}

void Player::getWalkableTiles(std::vector<TileType> &walkableTiles)
{
	for(int i = 0; i < m_WalkableTiles.size(); i++)
	{
		walkableTiles.push_back(m_WalkableTiles[i]);
	}
}

int Player::getHealth()
{
	return m_Health;
}

void Player::setHealth(int health)
{
	m_Health = health;

	if(m_Health == 0)
	{
		kill();
	}
}

void Player::kill()
{
	setIsActive(false);
}

void Player::fireProjectile(float x, float y)
{
	if(GameData::getInstance() -> getAmmo() > 0)
    {
        GameData::getInstance() -> setAmmo(GameData::getInstance() -> getAmmo() - 1);
        
        Projectile* projectile = new Projectile(this, (m_MaxDamage + m_DamageUpgrade) / GameData::getInstance() -> getDifficulty(), m_ProjectileSpeed);
        projectile -> setPosition(getX() + getWidth() / 2.0f, getY() + getHeight() / 2.0f);
        projectile -> setTarget(x, y);
		projectile -> setPreviousTile(m_Level -> getTileForPosition(getX() + getWidth() / 2.0f, getY() + getHeight() / 2.0f));
        m_Projectiles.push_back(projectile);

		if(m_FiringParticle != NULL)
		{
			m_FiringParticle ->setPosition(getX(), getY());
			m_FiringParticle ->setSize(getWidth(), getHeight());

			m_FiringParticle -> reset();
		}
    }
}

void Player::applyDamage(int damage)
{
    if(damage <= getHealth())
	{
		setHealth(getHealth() - damage);
	}
	else
	{
		setHealth(0);
	}
}

bool Player::getDestroyTower()
{
	return m_DestroyTower;
}


void Player::handleBoundsCollision(Projectile* projectile)
{
    Tile* tile = m_Level -> getTileForPosition(projectile -> getX(), projectile -> getY());
    
	if(tile != projectile -> getPreviousTile())
	{
		if(tile == NULL || tile -> getTileType() == TileTypeFence)
		{
			projectile -> setIsActive(false);
		}

		projectile -> setPreviousTile(tile);
	}
}

bool Player::handlePickUp(PickUp* pickUp)
{
    return false;
}

void Player::pathFinderFinishedSearching(PathFinder* pathFinder, bool pathWasFound)
{    
    if(pathFinder == m_PathFinder)
    {
        if(pathWasFound)
        {
            startAnimating();
        }
        else
        {
			if(!m_DestroyTower)
			{
				stopAnimating();
				m_DestroyTower = true;
				findPath();
			}
			else if(m_IsEnemy)
			{
				stopAnimating();
				m_WalkableTiles.push_back(TileTypeFence);
				findPath();
			}
        }
    }
}

PathFinder* Player::getPathFinder()
{
    return m_PathFinder;
}
 
void Player::findPath()
{
    m_PathFinder->reset();

	if(m_DestinationTileIndex >= 0 && m_DestinationTileIndex < m_Level ->getNumberOfTiles())
	{
		m_PathFinder->findPath(m_CurrentTileIndex, m_DestinationTileIndex, isAffectedByTileSpeed());
	}
}


float Player::animate(float aCurrent, float aTarget, double aDelta)
{
    float multiplier = isAffectedByTileSpeed() ? m_Level->getTileForPosition(getX() + getWidth() / 2.0f, getY() + getHeight() / 2.0f)->getTileSpeed() : 1.0f;
    
    float increment = aDelta * (m_Speed * multiplier) * (aTarget < aCurrent ? -1 : 1);
    if(fabs(increment) > fabs(aTarget - aCurrent))
    {
        return aTarget;
    }
    else
    {
        aCurrent += increment;
    }
    return aCurrent;
}

void Player::startAnimating()
{
	m_CanAnimate = true;
	m_AnimationPathNodeIndex = 0;
}

void Player::stopAnimating()
{
	m_CanAnimate = false;
	m_AnimationPathNodeIndex = -1;
}

bool Player::isAnimating()
{
    return m_CanAnimate;
}
