//
//  Student:        Quentin Bellay
//  Creation Date:  November 1st 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the desert tile
//  Modified:       
//

#include "DesertTile.h"
#include "../../OpenGL/OpenGL.h"
#include "../../Constants/Constants.h"


DesertTile::DesertTile(const char* textureName) : Tile(TileTypeDesert, textureName, true)
{

}

DesertTile::~DesertTile()
{

}

const char* DesertTile::getType()
{
    return TILE_DESERT_TYPE;
}

float DesertTile::getTileSpeed()
{
	return 1.0f;
}
