//
//  Student:        Quentin Bellay
//  Creation Date:  November 5th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the bush tile
//  Modified:       
//

#include "BushTile.h"
#include "../../OpenGL/OpenGL.h"
#include "../../Constants/Constants.h"


BushTile::BushTile(const char* textureName) : Tile(TileTypeBush, textureName, true)
{

}

BushTile::~BushTile()
{

}

const char* BushTile::getType()
{
    return TILE_BUSH_TYPE;
}

float BushTile::getTileSpeed()
{
	return 0.5f;
}
