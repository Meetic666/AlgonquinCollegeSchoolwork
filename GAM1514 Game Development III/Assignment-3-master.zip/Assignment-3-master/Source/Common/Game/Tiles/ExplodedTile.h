//
//  Student:        Quentin Bellay
//  Creation Date:  November 24th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the exploded tile
//  Modified:       
//

#ifndef EXPLODED_TILE_H
#define EXPLODED_TILE_H

#include "Tile.h"

// Class representing the exploded tile
class ExplodedTile : public Tile
{
public:
	ExplodedTile(const char* textureName = RES_TILE_EXPLODED);
	virtual ~ExplodedTile();
  
    //Return the type of the tile
    const char* getType();

	float getTileSpeed();
};

#endif
