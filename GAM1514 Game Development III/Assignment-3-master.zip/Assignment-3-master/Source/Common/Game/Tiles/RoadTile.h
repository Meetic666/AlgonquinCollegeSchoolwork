//
//  Student:        Quentin Bellay
//  Creation Date:  November 5th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the road tile
//  Modified:       
//

#ifndef ROAD_TILE_H
#define ROAD_TILE_H

#include "Tile.h"

// Class representing the road tile
class RoadTile : public Tile
{
public:
	RoadTile(const char* textureName = RES_TILE_ROAD);
	virtual ~RoadTile();
  
    //Return the type of the tile
    const char* getType();

	void connectsWith(std::vector<int> *connectsWith);
    
    float getTileSpeed();
};

#endif
