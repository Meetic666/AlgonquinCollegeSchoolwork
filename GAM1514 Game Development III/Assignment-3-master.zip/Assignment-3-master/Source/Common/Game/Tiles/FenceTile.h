//
//  Student:        Quentin Bellay
//  Creation Date:  November 5th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the fence tile
//  Modified:       
//

#ifndef FENCE_TILE_H
#define FENCE_TILE_H

#include "Tile.h"

// Class representing the fence tile
class FenceTile : public Tile
{
public:
	FenceTile(const char* textureName = RES_TILE_FENCE);
	virtual ~FenceTile();
  
    //Return the type of the tile
    const char* getType();

	void connectsWith(std::vector<int> *connectsWith);
};

#endif
