//
//  Student:        Quentin Bellay
//  Creation Date:  November 5th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the road tile
//  Modified:       
//

#include "RoadTile.h"
#include "../../OpenGL/OpenGL.h"
#include "../../Constants/Constants.h"


RoadTile::RoadTile(const char* textureName) : Tile(TileTypeRoad, textureName, true)
{

}

RoadTile::~RoadTile()
{

}

const char* RoadTile::getType()
{
    return TILE_ROAD_TYPE;
}

void RoadTile::connectsWith(std::vector<int> *connectsWith)
{
	connectsWith -> push_back((int)TileTypeRoad);
	connectsWith -> push_back((int)TileTypeBridge);
}

float RoadTile::getTileSpeed()
{
    return 2.0f;
}
