//
//  Student:        Quentin Bellay
//  Creation Date:  November 5th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the fence tile
//  Modified:       
//

#include "FenceTile.h"
#include "../../OpenGL/OpenGL.h"
#include "../../Constants/Constants.h"


FenceTile::FenceTile(const char* textureName) : Tile(TileTypeFence, textureName, false)
{

}

FenceTile::~FenceTile()
{

}

const char* FenceTile::getType()
{
    return TILE_FENCE_TYPE;
}

void FenceTile::connectsWith(std::vector<int> *connectsWith)
{
	connectsWith -> push_back((int)TileTypeFence);
}