//
//  Student:        Quentin Bellay
//  Creation Date:  November 24th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the reserve tile (the tile to defend)
//  Modified:       
//

#include "ReserveTile.h"
#include "../../OpenGL/OpenGL.h"
#include "../../Constants/Constants.h"


ReserveTile::ReserveTile(const char* textureName) : Tile(TileTypeReserve, textureName, true)
{

}

ReserveTile::~ReserveTile()
{

}

const char* ReserveTile::getType()
{
    return TILE_RESERVE_TYPE;
}

float ReserveTile::getTileSpeed()
{
	return 1.0f;
}