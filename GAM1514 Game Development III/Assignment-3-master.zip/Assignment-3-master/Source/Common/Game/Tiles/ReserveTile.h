//
//  Student:        Quentin Bellay
//  Creation Date:  November 24th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the reserve tile (the tile to defend)
//  Modified:       
//

#ifndef RESERVE_TILE_H
#define RESERVE_TILE_H

#include "Tile.h"

// Class representing the reserve tile (the tile to defend)
class ReserveTile : public Tile
{
public:
	ReserveTile(const char* textureName = RES_TILE_RESERVE);
	virtual ~ReserveTile();
  
    //Return the type of the tile
    const char* getType();

float getTileSpeed();
};

#endif