//
//  Student:        Quentin Bellay
//  Creation Date:  March 7th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the basic tile
//  Modified:       November 7th 2013: - Added "connectsWith", function that returns what tiletype 
//										the tile should connect with in the level
//

#ifndef TILE_H
#define TILE_H

#include "../GameObject.h"
#include "../../Constants/Constants.h"
#include <stdlib.h>
#include <vector>
#include "../Particles/Particle.h"


class OpenGLTexture;
class PickUp;
class Tower;

// Class representing the basic tile
class Tile : public GameObject
{
public:
    //Tile takes on parameter, whether it can be walked on or not
	Tile(TileType tileType, const char* tileTexture, bool isWalkableTile);
	virtual ~Tile();
    
    //Update, Paint and reset methods
	virtual void update(double delta);
	virtual void paint();
    virtual void reset();
    
    //Paint methods to draw the tile score, drawn from the PathFinding class
    virtual void paintScoreG(int scoreG);
    virtual void paintScoreH(int scoreH);
    virtual void paintScoreF(int scoreF);
    
    virtual void paintListColor(OpenGLColor color);
    
    //Paint method to draw the tile's index, drawn from the Level class
    virtual void paintIndex(int index);
    
    //Pure virtual method inerited from GameObject
    virtual const char* getType() = 0;
    
    //
    virtual TileType getTileType();
    
    //Is this a walkable tile, can the user walk on the tile
    virtual bool isWalkableTile();
    
    //Sets wether the tile is selected or not
    virtual void setIsSelected(bool isSelected);
	virtual bool isSelected();
    
    //Sets wether the tile is a path or not
	virtual void setIsPath(bool isPath);
	virtual bool isPath();

	virtual void setTileStyle(TileStyle tileStyle);
	virtual TileStyle getTileStyle();
	virtual void setIsTileStyleSet(bool isStyleSet);
	virtual bool getIsTileStyleSet();

	virtual void connectsWith(std::vector<int> *connectsWith);

	virtual float getPathValue();
    virtual float getTileSpeed();
    
    virtual bool isSpawnPoint();
    virtual void setIsSpawnPoint(bool aIsSpawnPoint);
    
    virtual void setPickUp(PickUp* pickUp);
    virtual std::vector<PickUp*> getPickUps();
	virtual void clearPickUps();

	virtual void setTower(Tower* tower);
	virtual Tower* getTower();

	virtual void setParticle(Particle* particle);
	virtual Particle* getParticle();
    
protected:
    //Conveniance method to paint a score number and a certain position
    void paintScoreNumber(int number, float x, float y);
    
    //Member variables
    TileType m_TileType;
    bool m_IsWalkableTile;
    bool m_IsSelected;
	bool m_IsPath;
    OpenGLTexture* m_SelectedTile;
    OpenGLTexture** m_TileIndexNumbers;
    OpenGLTexture** m_TileScoreNumbers;
	OpenGLTexture* m_AngledTexture;
	OpenGLTexture* m_TShapedTexture;
	OpenGLTexture* m_CrossTexture;

	TileStyle m_TileStyle;
	bool m_IsTileStyleSet;
    bool m_IsSpawnPoint;
    
    std::vector<PickUp*> m_PickUps;

	Tower* m_Tower;

	Particle* m_Particle;
};

#endif
