//
//  Student:        Quentin Bellay
//  Creation Date:  November 5th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the bridge tile
//  Modified:       
//

#ifndef BRIDGE_TILE_H
#define BRIDGE_TILE_H

#include "Tile.h"

// Class representing the bridge tile
class BridgeTile : public Tile
{
public:
	BridgeTile(const char* textureName = RES_TILE_BRIDGE);
	virtual ~BridgeTile();
  
    //Return the type of the tile
    const char* getType();

	void connectsWith(std::vector<int> *connectsWith);
    
    float getTileSpeed();
};

#endif
