//
//  Student:        Quentin Bellay
//  Creation Date:  November 5th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the bush tile
//  Modified:       
//

#ifndef BUSH_TILE_H
#define BUSH_TILE_H

#include "Tile.h"

// Class representing the bush tile
class BushTile : public Tile
{
public:
	BushTile(const char* textureName = RES_TILE_BUSH);
	virtual ~BushTile();
  
    //Return the type of the tile
    const char* getType();

	float getTileSpeed();
};

#endif
