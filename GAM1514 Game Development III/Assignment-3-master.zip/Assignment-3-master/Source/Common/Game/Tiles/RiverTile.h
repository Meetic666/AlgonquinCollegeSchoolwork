//
//  Student:        Quentin Bellay
//  Creation Date:  November 1st 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the river tile
//  Modified:       
//

#ifndef RIVER_TILE_H
#define RIVER_TILE_H

#include "Tile.h"

// Class representing the river tile
class RiverTile : public Tile
{
public:
	RiverTile(const char* textureName = RES_TILE_RIVER);
	virtual ~RiverTile();
  
    //Return the type of the tile
    const char* getType();

	void connectsWith(std::vector<int> *connectsWith);
};

#endif
