//
//  Student:        Quentin Bellay
//  Creation Date:  November 1st 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the river tile
//  Modified:       
//

#include "RiverTile.h"
#include "../../OpenGL/OpenGL.h"
#include "../../Constants/Constants.h"


RiverTile::RiverTile(const char* textureName) : Tile(TileTypeRiver, textureName, false)
{

}

RiverTile::~RiverTile()
{

}

const char* RiverTile::getType()
{
    return TILE_RIVER_TYPE;
}

void RiverTile::connectsWith(std::vector<int> *connectsWith)
{
	connectsWith -> push_back((int)TileTypeRiver);
	connectsWith -> push_back((int)TileTypeBridge);
}