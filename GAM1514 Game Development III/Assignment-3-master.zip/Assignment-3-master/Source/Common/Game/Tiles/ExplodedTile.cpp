//
//  Student:        Quentin Bellay
//  Creation Date:  November 24th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the exploded tile
//  Modified:       
//

#include "ExplodedTile.h"
#include "../../OpenGL/OpenGL.h"
#include "../../Constants/Constants.h"


ExplodedTile::ExplodedTile(const char* textureName) : Tile(TileTypeExploded, textureName, true)
{

}

ExplodedTile::~ExplodedTile()
{

}

const char* ExplodedTile::getType()
{
    return TILE_EXPLODED_TYPE;
}

float ExplodedTile::getTileSpeed()
{
	return 0.5f;
}
