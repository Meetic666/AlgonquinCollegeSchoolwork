//
//  Student:        Quentin Bellay
//  Creation Date:  November 5th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the bridge tile
//  Modified:       
//

#include "BridgeTile.h"
#include "../../OpenGL/OpenGL.h"
#include "../../Constants/Constants.h"


BridgeTile::BridgeTile(const char* textureName) : Tile(TileTypeBridge, textureName, true)
{

}

BridgeTile::~BridgeTile()
{

}

const char* BridgeTile::getType()
{
    return TILE_BRIDGE_TYPE;
}

void BridgeTile::connectsWith(std::vector<int> *connectsWith)
{
	connectsWith -> push_back((int)TileTypeRiver);
}

float BridgeTile::getTileSpeed()
{
    return 2.0f;
}