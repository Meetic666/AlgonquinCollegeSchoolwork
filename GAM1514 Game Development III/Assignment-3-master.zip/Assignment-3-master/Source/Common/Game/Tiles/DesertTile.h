//
//  Student:        Quentin Bellay
//  Creation Date:  November 1st 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the desert tile
//  Modified:       
//

#ifndef DESERT_TILE_H
#define DESERT_TILE_H

#include "Tile.h"

// Class representing the desert tile
class DesertTile : public Tile
{
public:
	DesertTile(const char* textureName = RES_TILE_DESERT);
	virtual ~DesertTile();
  
    //Return the type of the tile
    const char* getType();

float getTileSpeed();
};

#endif
