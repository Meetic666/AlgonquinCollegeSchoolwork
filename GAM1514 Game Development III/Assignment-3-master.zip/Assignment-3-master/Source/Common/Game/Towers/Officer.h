//
//  Student:        Quentin Bellay
//  Creation Date:  December 2nd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the officer base class
//  Modified:       
//

#ifndef OFFICER_H
#define OFFICER_H

#include "Tower.h"

// Class representing the officer base class, can be set everywhere but on fence, river and roads
class Officer : public Tower
{
public:
	Officer(TowerType towerType, Level* level, int maxHealth = PLAYER_HEALTH);
	virtual ~Officer();

	void update(double delta);

	//Keep it pure virtual to make it easier to know what function is left to implement
    virtual const char* getType() = 0;

	// Used to limit the tile type towers can be set on
	static void getBuildableTiles(std::vector<TileType> &walkableTiles);
};

#endif