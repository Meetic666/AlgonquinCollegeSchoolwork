//
//  Student:        Quentin Bellay
//  Creation Date:  December 2nd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the rocket launcher officer
//  Modified:       
//

#ifndef OFFICER_ROCKET_LAUNCHER_H
#define OFFICER_ROCKET_LAUNCHER_H

#include "Officer.h"

// Class representing the rocket launcher officer
class OfficerRocketLauncher : public Officer
{
public:
	OfficerRocketLauncher(Level* level, int maxHealth = PLAYER_HEALTH);
	~OfficerRocketLauncher();

	//Keep it pure virtual to make it easier to know what function is left to implement
    const char* getType();

	int getPrice();

protected:
	void handlePlayerCollision(Projectile* projectile);
};

#endif