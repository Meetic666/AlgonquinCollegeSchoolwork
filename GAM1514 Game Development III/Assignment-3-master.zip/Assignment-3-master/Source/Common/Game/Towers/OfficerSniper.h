//
//  Student:        Quentin Bellay
//  Creation Date:  December 2nd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the sniper officer
//  Modified:       
//

#ifndef OFFICER_SNIPER_H
#define OFFICER_SNIPER_H

#include "Officer.h"

// Class representing the sniper officer
class OfficerSniper : public Officer
{
public:
	OfficerSniper(Level* level, int maxHealth = PLAYER_HEALTH);
	~OfficerSniper();

	//Keep it pure virtual to make it easier to know what function is left to implement
    const char* getType();

	int getPrice();
};

#endif