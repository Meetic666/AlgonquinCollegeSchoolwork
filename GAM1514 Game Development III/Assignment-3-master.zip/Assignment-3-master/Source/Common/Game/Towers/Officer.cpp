//
//  Student:        Quentin Bellay
//  Creation Date:  December 2nd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the officer base class
//  Modified:       
//

#include "Officer.h"

Officer::Officer(TowerType towerType, Level* level, int maxHealth) : Tower(towerType, level, maxHealth)
{

}

Officer::~Officer()
{

}

void Officer::update(double delta)
{
	Tower::update(delta);

	m_DamageUpgrade = GameData::getInstance() -> getOfficerDamageUpgrade() * OFFICER_DAMAGE_UPGRADE;
	m_FiringRateMultiplier = 1.0f + GameData::getInstance() -> getOfficerFiringRateUpgrade() * OFFICER_FIRING_RATE_UPGRADE;
	m_RangeUpgrade = GameData::getInstance() -> getOfficerRangeUpgrade() * OFFICER_RANGE_UPGRADE;
}

// Used to limit the tile type towers can be set on
void Officer::getBuildableTiles(std::vector<TileType> &walkableTiles)
{
	walkableTiles.push_back(TileTypeDesert);
	walkableTiles.push_back(TileTypeBush);
	walkableTiles.push_back(TileTypeExploded);
}