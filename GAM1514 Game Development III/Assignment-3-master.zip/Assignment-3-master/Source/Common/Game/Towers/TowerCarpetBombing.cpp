//
//  Student:        Quentin Bellay
//  Creation Date:  December 2nd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the bombing watch tower
//  Modified:       
//

#include "TowerCarpetBombing.h"
#include "../Particles/Particles.h"
#include "../Level.h"
#include "../Enemies/Enemies.h"

TowerCarpetBombing::TowerCarpetBombing(Level* level, int maxHealth) : WatchTower(TowerCarpetBombingType, level, maxHealth)
{
	m_Texture = OpenGLTextureCache::getInstance() -> getTexture(RES_TOWER_CARPET_BOMBING);

	m_FiringParticle = new Smoke();
}

TowerCarpetBombing::~TowerCarpetBombing()
{
	
}

//Keep it pure virtual to make it easier to know what function is left to implement
const char* TowerCarpetBombing::getType()
{
	return TOWER_CARPET_BOMBING_TYPE;
}

int TowerCarpetBombing::getPrice()
{
	return TOWER_CARPET_BOMBING_PRICE;
}

void TowerCarpetBombing::handlePlayerCollision(Projectile* projectile)
{
	Tile* tile = m_Level -> getTileForPosition(projectile -> getX(), projectile -> getY());
	std::vector<Enemy*> enemies = m_Level -> getEnemies();

	bool tileExploding = false;
    
    for(int i = 0; i < enemies.size(); i++)
    {
        Enemy* enemy = enemies.at(i);
        
        if(enemy != NULL && enemy -> getIsActive())
        {
            Tile* enemyTile = m_Level -> getTileForPlayer(enemy);
            
            if(tile == enemyTile)
            {
                enemy -> applyDamage(projectile -> getDamage());
                projectile -> setIsActive(false);

				tileExploding = true;
            }
        }
    }

	if(tileExploding)
	{
		m_Level -> setTileTypeAtPosition(TileTypeExploded, projectile -> getX(), projectile -> getY());
	}
}