//
//  Student:        Quentin Bellay
//  Creation Date:  December 2nd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the gatling gun watch tower
//  Modified:       
//

#include "TowerGatlingGun.h"

TowerGatlingGun::TowerGatlingGun(Level* level, int maxHealth) : WatchTower(TowerGatlingGunType, level, maxHealth)
{
	m_Texture = OpenGLTextureCache::getInstance() -> getTexture(RES_TOWER_GATLING_GUN);
}

TowerGatlingGun::~TowerGatlingGun()
{

}

//Keep it pure virtual to make it easier to know what function is left to implement
const char* TowerGatlingGun::getType()
{
	return TOWER_GATLING_GUN_TYPE;
}

int TowerGatlingGun::getPrice()
{
	return TOWER_GATLING_GUN_PRICE;
}