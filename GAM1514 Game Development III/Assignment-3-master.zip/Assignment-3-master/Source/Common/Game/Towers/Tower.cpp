//
//  Student:        Quentin Bellay
//  Creation Date:  December 2nd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the basic tower unit (can only shoot)
//  Modified:       
//

#include "Tower.h"
#include "../Enemies/Enemies.h"
#include "../Level.h"
#include <cmath>
#include "../../Utils/Logger/Logger.h"
#include "../../Utils/Math/MathUtils.h"
#include "../Particles/Particles.h"

Tower::Tower(TowerType towerType, Level* level, int maxHealth) : Player(level, maxHealth),
	m_FiringTimer(0.0),
	m_TowerType(towerType),
	m_FiringRateMultiplier(1.0f),
	m_RangeUpgrade(0),
	m_Target(NULL)
{
	switch(towerType)
	{
	case OfficerMachineGunType:
		m_FiringRate = MACHINE_GUN_FIRING_RATE;
		m_MaxDamage = MACHINE_GUN_DAMAGE;
		m_ProjectileSpeed = MACHINE_GUN_PROJECTILE_SPEED;
		m_Range = MACHINE_GUN_RANGE;
		break;

	case OfficerSniperType:
		m_FiringRate = SNIPER_FIRING_RATE;
		m_MaxDamage = SNIPER_DAMAGE;
		m_ProjectileSpeed = SNIPER_PROJECTILE_SPEED;
		m_Range = SNIPER_RANGE;
		break;

	case OfficerRocketLauncherType:
		m_FiringRate = ROCKET_LAUNCHER_FIRING_RATE;
		m_MaxDamage = ROCKET_LAUNCHER_DAMAGE;
		m_ProjectileSpeed = ROCKET_LAUNCHER_PROJECTILE_SPEED;
		m_Range = ROCKET_LAUNCHER_RANGE;
		break;

	case TowerSniperType:
		m_FiringRate = TOWER_SNIPER_FIRING_RATE;
		m_MaxDamage = TOWER_SNIPER_DAMAGE;
		m_ProjectileSpeed = TOWER_SNIPER_PROJECTILE_SPEED;
		m_Range = TOWER_SNIPER_RANGE;
		break;

	case TowerGatlingGunType:
		m_FiringRate = TOWER_GATLING_GUN_FIRING_RATE;
		m_MaxDamage = TOWER_GATLING_GUN_DAMAGE;
		m_ProjectileSpeed = TOWER_GATLING_GUN_PROJECTILE_SPEED;
		m_Range = TOWER_GATLING_GUN_RANGE;
		break;

	case TowerCarpetBombingType:
		m_FiringRate = TOWER_CARPET_BOMBING_FIRING_RATE;
		m_MaxDamage = TOWER_CARPET_BOMBING_DAMAGE;
		m_ProjectileSpeed = TOWER_CARPET_BOMBING_PROJECTILE_SPEED;
		m_Range = TOWER_CARPET_BOMBING_RANGE;
		break;
            
    default:
        m_FiringRate = 0.0f;
        m_MaxDamage = 0;
        m_ProjectileSpeed = 0.0f;
        m_Range = 0;
        break;
	}
}

Tower::~Tower()
{
	
}

void Tower::update(double delta)
{
	if(m_Level != NULL)
	{
        if(m_FiringTimer > 0.0)
        {
            m_FiringTimer -= delta;
        }
        
		if(m_Target == NULL)
		{		
			std::vector<Enemy*> enemies = m_Level -> getEnemies();

			for(int i = 0; i < enemies.size(); i++)
			{
				if(enemies.at(i) -> getIsActive() && distance(enemies.at(i)) <= m_Range + m_RangeUpgrade)
				{
					m_Target = enemies.at(i);						
                    
					break;
				}
			}
		}
		else
		{			
			if(m_FiringTimer <= 0.0)
			{
				fireProjectile(m_Target -> getX() + m_Target -> getWidth() / 2.0f, m_Target -> getY() + m_Target -> getHeight() / 2.0f);

				m_FiringTimer = 1.0f / (m_FiringRate * m_FiringRateMultiplier);
                
                m_Rotation = MathUtils::radiansToDegrees(atan2f(m_Target -> getY() - getY(), m_Target -> getX() - getX())) - 90;
			}

			if(m_Target -> getIsActive() == false || distance(m_Target) > m_Range + m_RangeUpgrade)
			{
				m_Target = NULL;
			}
		}	
    
		for(int i = 0; i < m_Projectiles.size(); i++)
		{
			if(m_Projectiles.at(i) -> getIsActive())
			{
				m_Projectiles.at(i) -> update(delta);
			}
		}

		if(m_FiringParticle != NULL)
		{
			m_FiringParticle -> update(delta);
		}
	}
}

void Tower::paint()
{
	Player::paint();
}

TowerType Tower::getTowerType()
{
	return m_TowerType;
}

int Tower::getPrice()
{
	return -1;
}

void Tower::handlePlayerCollision(Projectile* projectile)
{
	Tile* tile = m_Level -> getTileForPosition(projectile -> getX(), projectile -> getY());
	std::vector<Enemy*> enemies = m_Level -> getEnemies();
    
    for(int i = 0; i < enemies.size(); i++)
    {
        Enemy* enemy = enemies.at(i);
        
        if(enemy != NULL && enemy -> getIsActive())
        {
            Tile* enemyTile = m_Level -> getTileForPlayer(enemy);
            
            if(tile == enemyTile)
            {
                enemy -> applyDamage(projectile -> getDamage());
                projectile -> setIsActive(false);
                
                return;
            }
        }
    }
}

float Tower::distance(Player* other)
{
	return sqrt((getX() - other -> getX()) * (getX() - other -> getX()) + (getY() - other -> getY()) * (getY() - other -> getY()));
}