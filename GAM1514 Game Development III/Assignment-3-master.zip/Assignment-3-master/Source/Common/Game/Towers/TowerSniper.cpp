//
//  Student:        Quentin Bellay
//  Creation Date:  December 2nd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the sniper watch tower
//  Modified:       
//

#include "TowerSniper.h"

TowerSniper::TowerSniper(Level* level, int maxHealth) : WatchTower(TowerSniperType, level, maxHealth)
{
	m_Texture = OpenGLTextureCache::getInstance() -> getTexture(RES_TOWER_SNIPER);
}

TowerSniper::~TowerSniper()
{

}

void TowerSniper::update(double delta)
{
	Tower::update(delta);

	m_Rotation = 0.0f;
}

//Keep it pure virtual to make it easier to know what function is left to implement
const char* TowerSniper::getType()
{
	return TOWER_SNIPER_TYPE;
}

int TowerSniper::getPrice()
{
	return TOWER_SNIPER_PRICE;
}