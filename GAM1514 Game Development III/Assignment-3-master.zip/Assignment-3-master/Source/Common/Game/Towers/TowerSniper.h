//
//  Student:        Quentin Bellay
//  Creation Date:  December 2nd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the sniper watch tower
//  Modified:       
//

#ifndef TOWER_SNIPER_H
#define TOWER_SNIPER_H

#include "WatchTower.h"

// Class representing the sniper watch tower, inherits from WatchTower
class TowerSniper : public WatchTower
{
public:
	TowerSniper(Level* level, int maxHealth = PLAYER_HEALTH);
	~TowerSniper();

	void update(double delta);

	//Keep it pure virtual to make it easier to know what function is left to implement
    const char* getType();

	int getPrice();
};

#endif