//
//  Student:        Quentin Bellay
//  Creation Date:  December 2nd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the gatling gun watch tower
//  Modified:       
//

#ifndef TOWER_GATLING_GUN_H
#define TOWER_GATLING_GUN_H

#include "WatchTower.h"

// Class representing the gatling gun watch tower, inherits WatchTower
class TowerGatlingGun : public WatchTower
{
public:
	TowerGatlingGun(Level* level, int maxHealth = PLAYER_HEALTH);
	~TowerGatlingGun();

	//Keep it pure virtual to make it easier to know what function is left to implement
    const char* getType();

	int getPrice();
};

#endif