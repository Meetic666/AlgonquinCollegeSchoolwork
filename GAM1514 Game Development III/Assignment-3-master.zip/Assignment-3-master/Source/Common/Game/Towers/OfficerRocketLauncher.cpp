//
//  Student:        Quentin Bellay
//  Creation Date:  December 2nd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the rocket launcher officer
//  Modified:       
//

#include "OfficerRocketLauncher.h"
#include "../Particles/Particles.h"
#include "../Level.h"
#include "../Enemies/Enemies.h"
#include "../Tiles/Tiles.h"

OfficerRocketLauncher::OfficerRocketLauncher(Level* level, int maxHealth) : Officer(OfficerRocketLauncherType, level, maxHealth)
{
    m_Texture = OpenGLTextureCache::getInstance() -> getTexture(RES_OFFICER_ROCKET_LAUNCHER);

	m_FiringParticle = new Smoke();
}

OfficerRocketLauncher::~OfficerRocketLauncher()
{
	
}

//Keep it pure virtual to make it easier to know what function is left to implement
const char* OfficerRocketLauncher::getType()
{
	return ROCKET_LAUNCHER_TYPE;
}

int OfficerRocketLauncher::getPrice()
{
	return ROCKET_LAUNCHER_PRICE;
}

void OfficerRocketLauncher::handlePlayerCollision(Projectile* projectile)
{
	Tile* tile = m_Level -> getTileForPosition(projectile -> getX(), projectile -> getY());
	std::vector<Enemy*> enemies = m_Level -> getEnemies();

	bool tileExploding = false;
    
    for(int i = 0; i < enemies.size(); i++)
    {
        Enemy* enemy = enemies.at(i);
        
        if(enemy != NULL && enemy -> getIsActive())
        {
            Tile* enemyTile = m_Level -> getTileForPlayer(enemy);
            
            if(tile == enemyTile)
            {
                enemy -> applyDamage(projectile -> getDamage());
                projectile -> setIsActive(false);

				tileExploding = true;
            }
        }
    }

	if(tileExploding)
	{
		TileType previousTileType = tile -> getTileType();

		m_Level -> setTileTypeAtPosition(TileTypeExploded, projectile -> getX(), projectile -> getY());

		if(previousTileType == TileTypeReserve)
		{
			m_Level -> setTileTypeAtPosition(TileTypeReserve, projectile -> getX(), projectile -> getY());
		}
		else if(previousTileType == TileTypeBridge)
		{
			m_Level -> setTileTypeAtPosition(TileTypeBridge, projectile -> getX(), projectile -> getY());
		}
	}
}