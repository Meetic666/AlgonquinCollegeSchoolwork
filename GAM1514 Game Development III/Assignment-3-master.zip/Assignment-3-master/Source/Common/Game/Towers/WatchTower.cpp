//
//  Student:        Quentin Bellay
//  Creation Date:  December 2nd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the watch tower
//  Modified:       
//

#include "WatchTower.h"

WatchTower::WatchTower(TowerType towerType, Level* level, int maxHealth) : Tower(towerType, level, maxHealth)
{

}

WatchTower::~WatchTower()
{

}

void WatchTower::update(double delta)
{
	Tower::update(delta);

	m_DamageUpgrade = GameData::getInstance() -> getTowerDamageUpgrade() * TOWER_DAMAGE_UPGRADE;
	m_FiringRateMultiplier = 1.0f + GameData::getInstance() -> getTowerFiringRateUpgrade() * TOWER_FIRING_RATE_UPGRADE;
	m_RangeUpgrade = GameData::getInstance() -> getTowerRangeUpgrade() * TOWER_RANGE_UPGRADE;
}

// Used to limit the tile type towers can be set on
void WatchTower::getBuildableTiles(std::vector<TileType> &walkableTiles)
{
	walkableTiles.push_back(TileTypeFence);
}