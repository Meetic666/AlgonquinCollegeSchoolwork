//
//  Student:        Quentin Bellay
//  Creation Date:  December 2nd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the bombing watch tower
//  Modified:       
//

#ifndef TOWER_CARPET_BOMBING_H
#define TOWER_CARPET_BOMBING_H

#include "WatchTower.h"

// Class representing the bombing watch tower, inherits WatchTower
class TowerCarpetBombing : public WatchTower
{
public:
	TowerCarpetBombing(Level* level, int maxHealth = PLAYER_HEALTH);
	~TowerCarpetBombing();

	//Keep it pure virtual to make it easier to know what function is left to implement
    const char* getType();

	int getPrice();

protected:
	void handlePlayerCollision(Projectile* projectile);
};

#endif