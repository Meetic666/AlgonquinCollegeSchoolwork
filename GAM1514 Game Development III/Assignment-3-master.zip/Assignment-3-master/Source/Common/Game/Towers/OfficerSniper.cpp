//
//  Student:        Quentin Bellay
//  Creation Date:  December 2nd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the sniper officer
//  Modified:       
//

#include "OfficerSniper.h"

OfficerSniper::OfficerSniper(Level* level, int maxHealth) : Officer(OfficerSniperType, level, maxHealth)
{
    m_Texture = OpenGLTextureCache::getInstance() -> getTexture(RES_OFFICER_SNIPER);
}

OfficerSniper::~OfficerSniper()
{

}

//Keep it pure virtual to make it easier to know what function is left to implement
const char* OfficerSniper::getType()
{
	return SNIPER_TYPE;
}

int OfficerSniper::getPrice()
{
	return SNIPER_PRICE;
}