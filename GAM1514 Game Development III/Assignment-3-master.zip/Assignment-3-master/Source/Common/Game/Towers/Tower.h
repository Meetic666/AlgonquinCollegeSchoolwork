//
//  Student:        Quentin Bellay
//  Creation Date:  December 2nd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the basic tower unit (can only shoot)
//  Modified:       
//

#ifndef TOWER_H
#define TOWER_H

#include "../Player.h"
#include "../../Constants/Constants.h"

// Class representing the basic tower unit (can only shoot)
class Tower : public Player
{
public:
	Tower(TowerType towerType, Level* level, int maxHealth = PLAYER_HEALTH);
	virtual ~Tower();

	virtual void update(double delta);
	void paint();

	TowerType getTowerType();
    
    //Keep it pure virtual to make it easier to know what function is left to implement
    virtual const char* getType() = 0;

	virtual int getPrice();

protected:
	virtual void handlePlayerCollision(Projectile* projectile);

	float distance(Player* other);

	float m_FiringRate;
	float m_FiringRateMultiplier;
	int m_Range;
	int m_RangeUpgrade;
	double m_FiringTimer;

	TowerType m_TowerType;

	Player* m_Target;
};

#endif