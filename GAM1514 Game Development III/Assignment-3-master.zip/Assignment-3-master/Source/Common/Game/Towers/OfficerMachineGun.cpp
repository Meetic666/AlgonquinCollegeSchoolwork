//
//  Student:        Quentin Bellay
//  Creation Date:  December 2nd 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the machine gun officer
//  Modified:       
//

#include "OfficerMachineGun.h"

OfficerMachineGun::OfficerMachineGun(Level* level, int maxHealth) : Officer(OfficerMachineGunType, level, maxHealth)
{
    m_Texture = OpenGLTextureCache::getInstance() -> getTexture(RES_HERO);
}

OfficerMachineGun::~OfficerMachineGun()
{

}

//Keep it pure virtual to make it easier to know what function is left to implement
const char* OfficerMachineGun::getType()
{
	return MACHINE_GUN_TYPE;
}

int OfficerMachineGun::getPrice()
{
	return MACHINE_GUN_PRICE;
}