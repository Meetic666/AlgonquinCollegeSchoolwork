//
//  InputEvent.cpp
//  GAM-1532 OSX Game
//
//  Created by Bradley Flood on 2013-08-21.
//  Copyright (c) 2013 Algonquin College. All rights reserved.
//

#include "InputEvent.h"


InputEvent::InputEvent()
{

}

InputEvent::~InputEvent()
{

}