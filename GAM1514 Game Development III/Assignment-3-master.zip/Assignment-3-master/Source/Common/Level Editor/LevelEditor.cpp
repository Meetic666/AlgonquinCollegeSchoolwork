//
//  Student:        Quentin Bellay
//  Creation Date:  October 25th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the level editor
//  Modified:       November 2013: - Added options/saving/loading menus
//								   - Quick save/load using CTRL+S/L
//								   - Display of the current level and if it was modified
//								   - Ask for confirmation if quitting a modified level
//

#include "LevelEditor.h"
#include "../Game/Tiles/Tile.h"
#include "../Constants/Constants.h"
#include "../Game/Level.h"
#include "../Screen Manager/ScreenManager.h"
#include "../UI/UIButton.h"
#include "../UI/UIToggle.h"
#include "../Libraries/jsoncpp/json.h"
#include <fstream>
#include <stdlib.h>


LevelEditor::LevelEditor() :
    m_TilesMenu(NULL),
    m_OptionsMenu(NULL),
	m_SlotsMenu(NULL),
    m_Level(NULL),
	m_SaveModificationsMenu(NULL),
    m_IsMouseDown(false),
	m_IsControlDown(false),
    m_SelectedTileIndex(-1),
	m_IsSaving(false),
	m_IsLoading(false),
	m_IsQuitting(false),
	m_IsClearing(false),
	m_CurrentFileName(""),
	m_CurrentLevel(0)
{
    //Create the Tiles menu items
    m_TilesMenu = new UISideMenu(this, SideMenuRight);
	m_TilesMenu->addButton(new UIToggle(MENU_TILE_DESERT));
	m_TilesMenu->addButton(new UIToggle(MENU_TILE_BUSH));
	m_TilesMenu->addButton(new UIToggle(MENU_TILE_RIVER));
    m_TilesMenu->addButton(new UIToggle(MENU_TILE_BRIDGE));
    m_TilesMenu->addButton(new UIToggle(MENU_TILE_ROAD));
	m_TilesMenu->addButton(new UIToggle(MENU_TILE_FENCE));
    
    m_OptionsMenu = new UISideMenu(this, SideMenuLeft);
    m_OptionsMenu->addButton(new UIButton(MENU_CLEAR_BUTTON));
    m_OptionsMenu->addButton(new UIButton(MENU_LOAD_BUTTON));
    m_OptionsMenu->addButton(new UIButton(MENU_SAVE_BUTTON));
    m_OptionsMenu->addButton(new UIButton(MENU_EXIT_BUTTON));

	m_SlotsMenu = new UISideMenu(this, SideMenuLeft);
    m_SlotsMenu->addButton(new UIButton(MENU_SLOT1_BUTTON));
    m_SlotsMenu->addButton(new UIButton(MENU_SLOT2_BUTTON));
    m_SlotsMenu->addButton(new UIButton(MENU_SLOT3_BUTTON));
    m_SlotsMenu->addButton(new UIButton(MENU_SLOT4_BUTTON));
    m_SlotsMenu->addButton(new UIButton(MENU_SLOT5_BUTTON));
    m_SlotsMenu->addButton(new UIButton(MENU_SLOT6_BUTTON));

	m_SaveModificationsMenu = new UISideMenu(this, SideMenuLeft);
    m_SaveModificationsMenu->addButton(new UIButton(MENU_SAVE_LABEL));
    m_SaveModificationsMenu->addButton(new UIButton(MENU_YES_BUTTON));
    m_SaveModificationsMenu->addButton(new UIButton(MENU_NO_BUTTON));
    m_SaveModificationsMenu->addButton(new UIButton(MENU_BACK_BUTTON));
	
	m_LevelLabels.push_back(OpenGLTextureCache::getInstance()->getTexture(RES_UNTITLED_LABEL));
	m_LevelLabels.push_back(OpenGLTextureCache::getInstance()->getTexture(RES_LEVEL1_LABEL));
	m_LevelLabels.push_back(OpenGLTextureCache::getInstance()->getTexture(RES_LEVEL2_LABEL));
	m_LevelLabels.push_back(OpenGLTextureCache::getInstance()->getTexture(RES_LEVEL3_LABEL));
	m_LevelLabels.push_back(OpenGLTextureCache::getInstance()->getTexture(RES_LEVEL4_LABEL));
	m_LevelLabels.push_back(OpenGLTextureCache::getInstance()->getTexture(RES_LEVEL5_LABEL));
	m_LevelLabels.push_back(OpenGLTextureCache::getInstance()->getTexture(RES_LEVEL6_LABEL));
	m_LevelLabels.push_back(OpenGLTextureCache::getInstance()->getTexture(RES_ASTERISK_LABEL));
    
    //Create the level object
    m_Level = new Level(true);
    
    //Reset everything
    reset();
}

LevelEditor::~LevelEditor()
{
    if(m_Level != NULL)
    {
        delete m_Level;
        m_Level = NULL;
    }
    
    if(m_TilesMenu != NULL)
    {
        delete m_TilesMenu;
        m_TilesMenu = NULL;
    }
    
    if(m_OptionsMenu != NULL)
    {
        delete m_OptionsMenu;
        m_OptionsMenu = NULL;
    }

	if(m_SlotsMenu != NULL)
    {
        delete m_SlotsMenu;
        m_SlotsMenu = NULL;
    }

	if(m_SaveModificationsMenu != NULL)
    {
        delete m_SaveModificationsMenu;
        m_SaveModificationsMenu = NULL;
    }

	m_LevelLabels.clear();
}

const char* LevelEditor::getName()
{
    return LEVEL_EDITOR_SCREEN_NAME;
}

void LevelEditor::update(double delta)
{
    if(m_Level != NULL)
    {
        m_Level->update(delta);
    }

    if(m_TilesMenu != NULL)
    {
        m_TilesMenu->update(delta);
    }
    
    if(m_OptionsMenu != NULL)
    {
        m_OptionsMenu->update(delta);
    }

	if(m_SlotsMenu != NULL)
    {
        m_SlotsMenu -> update(delta);
    }

	if(m_SaveModificationsMenu != NULL)
    {
        m_SaveModificationsMenu ->update(delta);
    }


}

void LevelEditor::paint()
{
    if(m_Level != NULL)
    {
        m_Level->paint();
    }

    if(m_TilesMenu != NULL)
    {
        m_TilesMenu->paint();
    }
    
    if(m_OptionsMenu != NULL)
    {
        m_OptionsMenu -> paint();
    }

	if(m_SlotsMenu != NULL)
    {
        m_SlotsMenu -> paint();
    }

	if(m_SaveModificationsMenu != NULL)
    {
        m_SaveModificationsMenu ->paint();
    }

	float width = m_LevelLabels.at(m_CurrentLevel)->getSourceWidth();
	float x = getWidth() * LEVEL_LABEL_PERCENTAGE_X - width / 2.0f;
	float y = getHeight() * LEVEL_LABEL_PERCENTAGE_Y;

	OpenGLRenderer::getInstance()->drawTexture(m_LevelLabels.at(m_CurrentLevel), x, y);

	if(m_Level->isModified())
	{
		x += width;

		OpenGLRenderer::getInstance()->drawTexture(m_LevelLabels.at(m_LevelLabels.size() - 1), x, y);
	}

}

void LevelEditor::reset()
{
    if(m_Level != NULL)
    {
        m_Level->reset();
    }
}

void LevelEditor::mouseMovementEvent(float deltaX, float deltaY, float positionX, float positionY)
{    
    if(m_TilesMenu != NULL)
    {
        m_TilesMenu->mouseMovementEvent(deltaX, deltaY, positionX, positionY);
    }
    
    if(m_OptionsMenu != NULL)
    {
        m_OptionsMenu->mouseMovementEvent(deltaX, deltaY, positionX, positionY);
    }

	if(m_SlotsMenu != NULL)
    {
        m_SlotsMenu->mouseMovementEvent(deltaX, deltaY, positionX, positionY);
    }

	if(m_SaveModificationsMenu != NULL)
    {
        m_SaveModificationsMenu ->mouseMovementEvent(deltaX, deltaY, positionX, positionY);
    }
    
    if(m_Level != NULL)
    {        
        if(m_SelectedTileIndex != -1 && m_IsMouseDown == true)
        {
            m_Level->setTileTypeAtPosition((TileType)(1 << m_SelectedTileIndex), positionX, positionY);
        }
    }
}

void LevelEditor::mouseLeftClickDownEvent(float positionX, float positionY)
{
	bool clickInMenu = false;
    
    //Notify the tiles menu of the mouse event
    if(m_TilesMenu != NULL)
    {
        clickInMenu = m_TilesMenu->mouseLeftClickDownEvent(positionX, positionY);
    }
    
    if(!clickInMenu && m_OptionsMenu != NULL)
    {
        clickInMenu = m_OptionsMenu->mouseLeftClickDownEvent(positionX, positionY);
    }

	if(!clickInMenu && m_SlotsMenu != NULL)
    {
        clickInMenu = m_SlotsMenu->mouseLeftClickDownEvent(positionX, positionY);
    }

	if(!clickInMenu && m_SaveModificationsMenu != NULL)
	{
		clickInMenu = m_SaveModificationsMenu->mouseLeftClickDownEvent(positionX, positionY);
	}

	if(!clickInMenu)
	{
		//Set the mouse down flag
		m_IsMouseDown = true;
	}
}

void LevelEditor::mouseLeftClickUpEvent(float positionX, float positionY)
{
    //Set the mouse up flag
    m_IsMouseDown = false;

	bool clickInMenu = false;
    
    //Notify the tiles menu of the mouse event
    if(m_TilesMenu != NULL)
    {
        clickInMenu = m_TilesMenu->mouseLeftClickUpEvent(positionX, positionY);
    }
    
    if(!clickInMenu && m_OptionsMenu != NULL)
    {
        clickInMenu = m_OptionsMenu->mouseLeftClickUpEvent(positionX, positionY);
    }

	if(!clickInMenu && m_SlotsMenu != NULL)
    {
        clickInMenu = m_SlotsMenu->mouseLeftClickUpEvent(positionX, positionY);
    }

	if(!clickInMenu && m_SaveModificationsMenu != NULL)
	{
		clickInMenu = m_SaveModificationsMenu->mouseLeftClickUpEvent(positionX, positionY);
	}

	//Safety check the level pointer, then set the new tile type in the index
    if(!clickInMenu && m_Level != NULL)
    {
        if(m_SelectedTileIndex != -1 && m_TilesMenu->isShowing() == false && m_OptionsMenu->isShowing() == false)
        {
            m_Level->setTileTypeAtPosition((TileType)(1 << m_SelectedTileIndex), positionX, positionY);
        }
        
        m_Level -> mouseLeftClickUpEvent(positionX, positionY);
        
        m_Level -> setSelectedTileIndex(m_Level -> getTileIndexForPosition(positionX, positionY));
    }
}

void LevelEditor::mouseRightClickUpEvent(float positionX, float positionY)
{
    m_Level -> setSpawnPointAtPosition(positionX, positionY);
}

void LevelEditor::keyUpEvent(int keyCode)
{
    if(keyCode == KEYCODE_TAB)
    {
        if(m_TilesMenu != NULL)
        {
            m_TilesMenu->isShowing() == true ? m_TilesMenu->hide() : m_TilesMenu->show();
        }
    }
    else if(keyCode == KEYCODE_ESCAPE)
    {
        if(m_OptionsMenu != NULL)
        {
            m_OptionsMenu->isShowing() == true ? m_OptionsMenu->hide() : m_OptionsMenu->show();
        }

		if(m_SlotsMenu != NULL)
        {
            m_SlotsMenu->hide();
        }

		if(m_SaveModificationsMenu != NULL)
        {
            m_SaveModificationsMenu->hide();
        }
    }
    else
    {
        if(m_Level != NULL)
        {
            m_Level->keyUpEvent(keyCode);
        }
    }
    
	if(keyCode == KEYCODE_LEFT_CONTROL)
	{
		m_IsControlDown = false;
	}
}

void LevelEditor::keyDownEvent(int keyCode)
{
	if(keyCode == KEYCODE_CONTROL || keyCode == KEYCODE_LEFT_CONTROL || keyCode == KEYCODE_RIGHT_CONTROL)
	{
		m_IsControlDown = true;
	}
	
	if(m_IsControlDown)
	{
		if(keyCode == KEYCODE_S)
		{
			if(m_CurrentFileName != "")
			{
				m_Level -> saveJSON(m_CurrentFileName.c_str());
			}
			else
			{
				if(m_SlotsMenu!= NULL)
				{
					m_SlotsMenu ->show();
				}

				m_IsSaving = true;
				m_IsLoading = false;
			}
		}
		else if(keyCode == KEYCODE_L)
		{
			if(m_CurrentFileName != "")
			{
				m_Level -> loadJSON(m_CurrentFileName.c_str());
			}
			else
			{
				if(m_SlotsMenu!= NULL)
				{
					m_SlotsMenu ->show();
				}

				m_IsSaving = false;
				m_IsLoading = true;
			}
		}
	}
}

void LevelEditor::openLatestLevel()
{
	std::string jsonFile = "EditorData.json";

    std::ifstream inputStream;
    inputStream.open(jsonFile.c_str());

    if(inputStream.is_open())
    {
        Json::Value root;
        Json::Reader reader;
        
        if(reader.parse(inputStream, root) == true)
        {
            m_CurrentFileName = root["LastEditedLevel"].asString();

			m_CurrentLevel = root["LevelNumber"].asInt();
        }
        
        inputStream.close();

		m_Level->loadJSON(m_CurrentFileName.c_str());
    }
}

void LevelEditor::saveLatestLevel()
{
	std::string jsonFile = "EditorData.json";
    
    Json::Value root;
    root["LastEditedLevel"] = m_CurrentFileName;
    root["LevelNumber"] = m_CurrentLevel;

    std::ofstream outputStream;
    outputStream.open(jsonFile.c_str(), std::ofstream::out);
    
    if(outputStream.is_open())
    {
        Json::StyledStreamWriter writer;
        writer.write(outputStream, root);
        
        outputStream.close();
    }
}

void LevelEditor::sideMenuButtonAction(UISideMenu* sideMenu, UIButton* button, int buttonIndex)
{
    if(sideMenu == m_OptionsMenu)
    {        
        m_OptionsMenu -> hide();
        
        if(buttonIndex == 0)
        {
			if(m_Level ->isModified())
			{
				m_SaveModificationsMenu->show();

				m_IsClearing = true;
			}
			else
			{
				clearLevel();
			}
        }
        else if(buttonIndex == 1)
        {
			if(m_SlotsMenu != NULL)
			{
				m_SlotsMenu -> show();
			}

			m_IsLoading = true;
			m_IsSaving = false;
        }
        else if(buttonIndex == 2)
        {
            if(m_SlotsMenu != NULL)
			{
				m_SlotsMenu -> show();
			}

			m_IsLoading = false;
			m_IsSaving = true;
        }
        else if(buttonIndex == 3)
        {
			if(m_Level ->isModified())
			{
				m_SaveModificationsMenu->show();

				m_IsQuitting = true;
			}
			else
			{
				exitEditor();
			}
        }        
    }
	else if(sideMenu == m_SlotsMenu)
	{
		m_CurrentFileName = LEVEL_SLOTS[buttonIndex];

		m_CurrentLevel = buttonIndex + 1;

		if(m_IsSaving)
		{
			m_Level -> saveJSON(m_CurrentFileName.c_str());

			if(m_IsClearing)
			{
				clearLevel();
			}
			else if(m_IsQuitting)
			{
				exitEditor();
			}
		}
		else if(m_IsLoading)
		{
			m_Level -> loadJSON(m_CurrentFileName.c_str());
		}

		if(m_SlotsMenu != NULL)
		{
			m_SlotsMenu -> hide();
		}
	}
	else if(sideMenu == m_SaveModificationsMenu)
	{
		m_SaveModificationsMenu -> hide();

		if(buttonIndex == 1)
		{
			if(m_CurrentFileName != "")
			{
				m_Level -> saveJSON(m_CurrentFileName.c_str());

				if(m_IsClearing)
				{
					clearLevel();
				}
				else if(m_IsQuitting)
				{
					exitEditor();
				}
			}
			else
			{
				if(m_SlotsMenu != NULL)
				{
					m_SlotsMenu->show();

					m_IsSaving = true;
					m_IsLoading = false;
				}
			}
		}
		else if(buttonIndex == 2)
		{
			if(m_IsClearing)
			{
				clearLevel();
			}
			else if(m_IsQuitting)
			{
				exitEditor();
			}
		}
		else if(buttonIndex == 3)
		{
			m_IsClearing = false;
			m_IsQuitting = false;

			if(m_OptionsMenu != NULL)
			{
				m_OptionsMenu -> show();
			}
		}
	}
}

void LevelEditor::sideMenuToggleAction(UISideMenu* sideMenu, UIToggle* toggle, int toggleIndex)
{
    if(sideMenu == m_TilesMenu)
    {
        //Un-toggled the previously selected toggle
        UIToggle* previousToggle = (UIToggle*)m_TilesMenu->getButtonForIndex(m_SelectedTileIndex);
        if(previousToggle != NULL)
        {
            previousToggle->setIsToggled(false);
        }
    
        //Set the selected tile index
        m_SelectedTileIndex = toggle->isToggled() == true ? toggleIndex : -1;
        
        //Hide the options and tiles menus
        m_TilesMenu->hide();
    }
}

void LevelEditor::exitEditor()
{
	saveLatestLevel();

	ScreenManager::getInstance() -> switchScreen(MAIN_MENU_SCREEN_NAME);
	m_IsQuitting = false;
}

void LevelEditor::clearLevel()
{
	m_Level -> load(NULL);
	m_IsClearing = false;

	m_CurrentLevel = 0;
	m_CurrentFileName = "";
}
