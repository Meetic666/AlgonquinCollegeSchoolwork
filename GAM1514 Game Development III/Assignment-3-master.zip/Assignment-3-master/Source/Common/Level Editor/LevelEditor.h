//
//  Student:        Quentin Bellay
//  Creation Date:  October 25th 2013
//  Course Number:  GAM 1514
//  Professor:      Bradley Flood
//  Purpose:        Class representing the level editor
//  Modified:       November 2013: - Added options/saving/loading menus
//								   - Quick save/load using CTRL+S/L
//								   - Display of the current level and if it was modified
//								   - Ask for confirmation if quitting a modified level
//

#ifndef __GAM_1514_OSX_Game__LevelEditor__
#define __GAM_1514_OSX_Game__LevelEditor__

#include "../Screen Manager/Screen.h"
#include "../UI/UISideMenu.h"

class UISideMenu;
class Level;

// Class representing the level editor
class LevelEditor : public Screen, public UISideMenuListener
{
public:
    LevelEditor();
    ~LevelEditor();
    
    const char* getName();

    void update(double delta);
    void paint();
    void reset();
    
    void mouseMovementEvent(float deltaX, float deltaY, float positionX, float positionY);
    void mouseLeftClickDownEvent(float positionX, float positionY);
    void mouseLeftClickUpEvent(float positionX, float positionY);
    void mouseRightClickUpEvent(float positionX, float positionY);
    void keyUpEvent(int keyCode);
	void keyDownEvent(int keyCode);

	void openLatestLevel();
    
private:
	void saveLatestLevel();

    void sideMenuButtonAction(UISideMenu* sideMenu, UIButton* button, int buttonIndex);
    void sideMenuToggleAction(UISideMenu* sideMenu, UIToggle* toggle, int toggleIndex);

	void exitEditor();

	void clearLevel();
    
    UISideMenu* m_TilesMenu;
    UISideMenu* m_OptionsMenu;
	UISideMenu* m_SlotsMenu;
	UISideMenu* m_SaveModificationsMenu;
    Level* m_Level;
    
    bool m_IsMouseDown;
	bool m_IsControlDown;
    int m_SelectedTileIndex;

	bool m_IsSaving;
	bool m_IsLoading;
	bool m_IsQuitting;
	bool m_IsClearing;

	std::string m_CurrentFileName;

	std::vector<OpenGLTexture*> m_LevelLabels;
	int m_CurrentLevel;
};

#endif /* defined(__GAM_1514_OSX_Game__LevelEditor__) */
