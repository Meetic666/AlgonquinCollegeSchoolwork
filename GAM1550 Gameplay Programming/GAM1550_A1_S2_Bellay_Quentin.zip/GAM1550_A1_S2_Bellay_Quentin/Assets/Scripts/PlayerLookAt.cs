﻿using UnityEngine;
using System.Collections;

public class PlayerLookAt : MonoBehaviour 
{
	public float m_LookSpeed = 5.0f;

	Vector3 m_LookDirection = Vector3.forward;

	public Vector3 LookDirection
	{
		get
		{
			return m_LookDirection;
		}
	}

	public Vector3 m_LookOffset;

	public float m_MaxHorizontalAngle = 45.0f;
	public float m_MaxVerticalAngle = 30.0f;

	Vector3 m_LookEulerAngles = Vector3.zero;

	public Vector3 LookEulerAngles
	{
		get
		{
			return m_LookEulerAngles;
		}
	}

	public float m_TargettingDistance = 10.0f;

	public Vector3 TargetPosition
	{
		get
		{
			return transform.position + m_LookOffset + transform.TransformDirection(m_LookDirection) * m_TargettingDistance;
		}
	}

	CustomInput m_Input;

	void Start()
	{
		m_Input = (CustomInput) GetComponent (typeof(CustomInput));
	}

	// Update is called once per frame
	void Update () 
	{
		// Look direction is updated using the input from CustomInput component attached

		float horizontal = m_Input.m_LookX;
		float vertical = m_Input.m_LookY;

		m_LookEulerAngles.x -= vertical * m_LookSpeed * Time.deltaTime;
		m_LookEulerAngles.y += horizontal * m_LookSpeed * Time.deltaTime;

		// Look angles are limited vertically and horizontally
		m_LookEulerAngles.x = Mathf.Clamp (m_LookEulerAngles.x, - m_MaxVerticalAngle, m_MaxVerticalAngle);
		m_LookEulerAngles.y = Mathf.Clamp (m_LookEulerAngles.y, - m_MaxHorizontalAngle, m_MaxHorizontalAngle);

		m_LookDirection = Quaternion.Euler (m_LookEulerAngles) * Vector3.forward;
	}

	public void ResetLookDirection()
	{
		m_LookEulerAngles.y = 0.0f;

		m_LookDirection = Quaternion.Euler (m_LookEulerAngles) * Vector3.forward;
	}
}
