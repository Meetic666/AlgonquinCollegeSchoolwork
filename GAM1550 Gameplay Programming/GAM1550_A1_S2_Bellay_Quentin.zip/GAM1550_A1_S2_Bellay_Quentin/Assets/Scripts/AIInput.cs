﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class AIInput : CustomInput
{
	enum AIState
	{
		e_Idle,
		e_Patrolling,
		e_TargettingPlayer,
		e_ShootingAtPlayer
	}

	AIState m_CurrentState = AIState.e_Idle;

	Health m_PlayerHealth;

	public List<Transform> m_WayPoints = new List<Transform>();
	int m_CurrentWayPoint = 0;

	public float m_PlayerDetectionRange = 10.0f;
	public float m_WayPointAttainedRange = 0.5f;
	public float m_PlayerTargettedAngle = 25.0f;

	public float m_WaypointTargettedAngle = 10.0f;

	PlayerLookAt m_LookAt;

	// Use this for initialization
	void Start () 
	{
		m_PlayerHealth = GameObject.Find ("Player").GetComponent<Health> ();

		m_LookAt = GetComponent<PlayerLookAt> ();
	}
	
	// Update is called once per frame
	void Update () 
	{
		switch(m_CurrentState)
		{
		case AIState.e_Idle:

			if(CheckForPlayerInSight())
			{
				m_CurrentState = AIState.e_TargettingPlayer;
			}
			else
			{
				m_CurrentState = AIState.e_Patrolling;
			}

			break;

		case AIState.e_Patrolling:

			Patrol();

			if(CheckForPlayerInSight())
			{
				EndPatrol ();
				m_CurrentState = AIState.e_TargettingPlayer;
			}

			break;

		case AIState.e_ShootingAtPlayer:

			ShootAtPlayer();

			if(!CheckForPlayerInSight())
			{
				EndShooting ();
				m_CurrentState = AIState.e_Idle;
			}
			else if(!CheckForPlayerTargetted())
			{
				EndShooting ();
				m_CurrentState = AIState.e_TargettingPlayer;
			}


			break;

		case AIState.e_TargettingPlayer:

			TargetPlayer();

			if(!CheckForPlayerInSight())
			{
				EndTargetting();
				m_CurrentState = AIState.e_Idle;
			}
			else if(CheckForPlayerTargetted())
			{
				EndTargetting();
				m_CurrentState = AIState.e_ShootingAtPlayer;
			}

			break;
		}
	}

	bool CheckForPlayerInSight()
	{
		RaycastHit hitInfo;

		if(Physics.Raycast(transform.position, m_PlayerHealth.transform.position - transform.position, out hitInfo, m_PlayerDetectionRange))
		{
			if(hitInfo.collider.tag == "Player")
			{
				return true;
			}
		}

		return false;
	}

	void Patrol()
	{
		m_Vertical = 1.0f;

		Vector3 targetPosition = m_WayPoints [m_CurrentWayPoint].position;
		targetPosition.y = transform.position.y;

		Vector3 lookDirection = transform.TransformDirection(m_LookAt.LookDirection);
		lookDirection.y = 0.0f;

		// Calculates the direction to rotate to in order to face the waypoint
		float direction = Vector3.Dot (transform.up, Vector3.Cross (lookDirection, targetPosition - transform.position));

		// Calculates the angle between the current look direction and the waypoint's direction
		// in order to limit turning when the angle is big enough
		float angle = Vector3.Angle (lookDirection, targetPosition - transform.position);
		
		m_LookX = (angle >= m_WaypointTargettedAngle && direction != 0.0f) ? Mathf.Sign (direction) : 0.0f;

		if(Vector3.Distance(targetPosition, transform.position) <= m_WayPointAttainedRange)
		{
			m_CurrentWayPoint++;

			if(m_CurrentWayPoint >= m_WayPoints.Count)
			{
				m_CurrentWayPoint = 0;
			}
		}
	}

	void EndPatrol()
	{
		m_Vertical = 0.0f;
		m_LookX = 0.0f;
	}

	void ShootAtPlayer()
	{
		m_Fire = true;
	}

	void EndShooting()
	{
		m_Fire = false;
	}

	void TargetPlayer()
	{		
		m_Vertical = 0.1f;

		Vector3 targetPosition = m_PlayerHealth.transform.position;
		Vector3 targetPositionForX = targetPosition;
		targetPositionForX.y = transform.position.y;
		
		Vector3 targetPositionForY = targetPosition;
		targetPositionForY.x = transform.position.x;
		targetPositionForY.z = transform.position.z;
		
		Vector3 lookDirection = transform.TransformDirection(m_LookAt.LookDirection);
		Vector3 lookDirectionForX = lookDirection;
		lookDirectionForX.y = 0.0f;
		
		Vector3 lookDirectionForY = lookDirection;
		lookDirectionForY.x = 0.0f;
		lookDirectionForY.z = 0.0f;

		// Gets the direction to rotate to in order to face the player
		float direction = Vector3.Dot (transform.up, Vector3.Cross (lookDirection, targetPosition - transform.position));
		
		m_LookX = direction != 0.0f ? Mathf.Sign (direction) : 0.0f;
	}

	void EndTargetting()
	{		
		m_Vertical = 0.0f;

		m_LookX = 0.0f;
	}

	bool CheckForPlayerTargetted()
	{
		// Checks if the angle between look direction and player direction is small enough
		return Vector3.Angle (transform.TransformDirection(m_LookAt.LookDirection), m_PlayerHealth.transform.position - transform.position) <= m_PlayerTargettedAngle;
	}
}
