﻿using UnityEngine;
using System.Collections;

public class ShootAtTarget : MonoBehaviour 
{
	public GameObject m_ProjectilePrefab;

	public float m_ProjectileSpeed = 100.0f;

	PlayerLookAt m_LookAt;
	
	public float m_FiringTime = 0.2f;
	float m_FiringTimer;

	public float m_HorizontalOffset = 0.5f;

	void Start()
	{
		m_LookAt = GetComponent<PlayerLookAt> ();
	}

	void Update()
	{
		m_FiringTimer -= Time.deltaTime;
	}

	public void Shoot()
	{
		if(m_FiringTimer <= 0.0f)
		{
			GameObject newBullet = (GameObject) GameObject.Instantiate (m_ProjectilePrefab, transform.position + m_LookAt.m_LookOffset + m_HorizontalOffset * transform.forward, Quaternion.identity);

			// Targets the new projectile at the target position given by the LookAt component attached
			newBullet.rigidbody.velocity = (m_LookAt.TargetPosition - newBullet.transform.position).normalized * m_ProjectileSpeed;

			m_FiringTimer = m_FiringTime;
		}
	}
}
