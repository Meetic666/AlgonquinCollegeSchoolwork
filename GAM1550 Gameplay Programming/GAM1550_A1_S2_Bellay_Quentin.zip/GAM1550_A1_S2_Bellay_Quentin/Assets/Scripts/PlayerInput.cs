﻿using UnityEngine;
using System.Collections;

public class PlayerInput : CustomInput
{	
	// Update is called once per frame
	void Update () 
	{
		m_Fire = Input.GetButton ("Fire");
		m_Horizontal = Input.GetAxis ("Horizontal");
		m_Vertical = Input.GetAxis ("Vertical");
		m_Jump = Input.GetButton ("Jump");
		m_LookX = Input.GetAxis ("Mouse X");
		m_LookY = Input.GetAxis ("Mouse Y");
	}
}
