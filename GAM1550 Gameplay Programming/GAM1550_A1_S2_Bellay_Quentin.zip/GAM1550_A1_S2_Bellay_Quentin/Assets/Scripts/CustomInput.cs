﻿using UnityEngine;
using System.Collections;

public class CustomInput : MonoBehaviour 
{
	public float m_Horizontal;
	public float m_Vertical;
	public bool m_Fire;
	public bool m_Jump;
	public float m_LookX;
	public float m_LookY;
}
