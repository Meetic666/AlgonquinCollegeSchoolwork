﻿using UnityEngine;
using System.Collections;

public class Projectile : MonoBehaviour 
{
	public float m_LifeTime = 5.0f;

	public float m_Damage = 10.0f;

	public LayerMask m_LayersToTarget;
	public LayerMask m_LayersToAvoid;

	// Use this for initialization
	void Start () 
	{
	
	}
	
	// Update is called once per frame
	void Update () 
	{
		m_LifeTime -= Time.deltaTime;

		if(m_LifeTime <= 0.0f)
		{
			Destroy(gameObject);
		}
	}

	void OnCollisionEnter(Collision other)
	{
		// Checks that the projectile is colliding with the proper layers
		if((1 << other.gameObject.layer & m_LayersToTarget.value) != 0)
		{
			other.gameObject.GetComponent<Health>().Damage(m_Damage);
		}

		// And avoiding the proper ones
		if((1 << other.gameObject.layer & m_LayersToAvoid) == 0)
		{
			Destroy (gameObject);
		}
	}
}
