﻿using UnityEngine;
using System.Collections;

public class Health : MonoBehaviour 
{
	public float m_StartHealth = 100.0f;

	float m_CurrentHealth;

	public enum ZeroHealthAction
	{
		e_Destroy,
		e_ReloadScene
	}

	public ZeroHealthAction m_ZeroHealthAction = ZeroHealthAction.e_Destroy;

	// Use this for initialization
	void Start () 
	{
		m_CurrentHealth = m_StartHealth;
	}

	public void Damage(float damageAmount)
	{
		m_CurrentHealth -= damageAmount;

		if(m_CurrentHealth <= 0.0f)
		{
			m_CurrentHealth = 0.0f;

			DoZeroHealthAction ();
		}
	}

	void DoZeroHealthAction()
	{
		switch(m_ZeroHealthAction)
		{
		case ZeroHealthAction.e_Destroy:
			Destroy (gameObject);
			break;

		case ZeroHealthAction.e_ReloadScene:
			Application.LoadLevel(Application.loadedLevel);
			break;
		}
	}
}
