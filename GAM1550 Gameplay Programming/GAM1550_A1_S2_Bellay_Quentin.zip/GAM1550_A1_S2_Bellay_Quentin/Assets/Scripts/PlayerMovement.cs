﻿using UnityEngine;
using System.Collections;

public class PlayerMovement : MonoBehaviour 
{
	public float m_MoveSpeed = 5.0f;
	public float m_StrafeSpeed = 3.0f;
	public float m_JumpSpeed = 2.0f;

	bool m_IsGrounded = false;

	CharacterController m_Controller;

	Vector3 m_CurrentSpeed;

	PlayerLookAt m_LookAt;

	CustomInput m_Input;

	ShootAtTarget m_ShootManager;

	void Start()
	{
		m_Controller = GetComponent<CharacterController> ();

		m_LookAt = GetComponent<PlayerLookAt> ();

		m_Input = (CustomInput) GetComponent (typeof(CustomInput));

		m_ShootManager = GetComponent<ShootAtTarget> ();
	}
	
	// Update is called once per frame
	void Update () 
	{
		if(m_IsGrounded)
		{
			float horizontal = m_Input.m_Horizontal;
			float vertical = m_Input.m_Vertical;

			m_CurrentSpeed.x = horizontal * m_StrafeSpeed;
			m_CurrentSpeed.y = 0.0f;
			m_CurrentSpeed.z = vertical * m_MoveSpeed;

			if(m_Input.m_Jump)
			{
				m_CurrentSpeed.y = m_JumpSpeed;
			}

			if(vertical != 0.0f || horizontal != 0.0f)
			{
				Vector3 newForward = transform.TransformDirection(m_LookAt.LookDirection);
				newForward.y = 0.0f;
				transform.forward = newForward;

				m_LookAt.ResetLookDirection();
			}
		}
		else
		{
			m_CurrentSpeed.y += Physics.gravity.y * Time.deltaTime;
		}
		
		if(m_Input.m_Fire)
		{
			m_ShootManager.Shoot ();
		}

		Vector3 currentSpeed = transform.TransformDirection (m_CurrentSpeed);

		m_IsGrounded = (m_Controller.Move (currentSpeed * Time.deltaTime) & CollisionFlags.Below) != 0;
	}
}
