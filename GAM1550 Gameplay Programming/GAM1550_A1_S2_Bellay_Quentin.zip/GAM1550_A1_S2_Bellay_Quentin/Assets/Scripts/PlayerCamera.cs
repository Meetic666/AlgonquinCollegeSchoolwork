﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PlayerCamera : MonoBehaviour 
{
	public PlayerLookAt m_Player;
	public Vector3 m_CameraOffset;
	public float m_CameraSpeed = 5.0f;

	Vector3 m_TargetOffset;

	public float m_SkinSize = 0.1f;

	public float m_MinOffsetMagnitude = 0.2f;

	Texture m_ReticleTexture;

	Rect m_ReticleRectangle;

	public float m_ReticleSizePercentage = 0.1f;

	void Start()
	{
		m_TargetOffset = m_CameraOffset;

		m_ReticleTexture = Resources.Load<Texture> ("Reticle");

		float screenWidth = camera.pixelWidth;
		float screenHeight = camera.pixelHeight;
		float reticleSize = screenHeight * m_ReticleSizePercentage;

		m_ReticleRectangle.xMin = (screenWidth - reticleSize) * 0.5f;
		m_ReticleRectangle.yMin = (screenHeight - reticleSize) * 0.5f;
		m_ReticleRectangle.height = reticleSize;
		m_ReticleRectangle.width = reticleSize;
	}

	// Update is called once per frame
	void Update () 
	{
		// Orients the camera at the vector that the player is looking at
		transform.forward = m_Player.transform.TransformDirection(m_Player.LookDirection);

		CheckCollisions ();
		
		Vector3 targetPosition = m_Player.transform.position + m_Player.m_LookOffset + transform.TransformDirection (m_TargetOffset);
		
		Vector3 displacement = targetPosition - transform.position;

		transform.position += displacement;
	}

	void CheckCollisions()
	{
		// Raycast the four corners of the near clip plane so that none collides with anything
		// therefore ensuring no clipping

		float frustumHeight = camera.nearClipPlane * Mathf.Tan(camera.fieldOfView * 0.5f * Mathf.Deg2Rad);
		float frustumWidth = camera.aspect * frustumHeight;

		Vector3 playerPosition = m_Player.transform.position + m_Player.m_LookOffset;

		// We start the raycasts from the player's position and raycast over the wanted offset for the camera

		Vector3 topLeftFrustumCornerPlayer = playerPosition + transform.up * frustumHeight + transform.forward * camera.nearClipPlane - transform.right * frustumWidth;
		Vector3 topRightFrustumCornerPlayer = playerPosition + transform.up * frustumHeight + transform.forward * camera.nearClipPlane + transform.right * frustumWidth;
		Vector3 bottomLeftFrustumCornerPlayer = playerPosition - transform.up * frustumHeight + transform.forward * camera.nearClipPlane - transform.right * frustumWidth;
		Vector3 bottomRightFrustumCornerPlayer = playerPosition - transform.up * frustumHeight + transform.forward * camera.nearClipPlane + transform.right * frustumWidth;

		List<Vector3> frustumCornersPlayer = new List<Vector3> ();
		frustumCornersPlayer.Add (topLeftFrustumCornerPlayer);
		frustumCornersPlayer.Add (topRightFrustumCornerPlayer);
		frustumCornersPlayer.Add (bottomLeftFrustumCornerPlayer);
		frustumCornersPlayer.Add (bottomRightFrustumCornerPlayer);

		float minOffsetDistance = m_CameraOffset.magnitude + m_SkinSize;

		RaycastHit hitInfo;

		foreach(Vector3 corner in frustumCornersPlayer)
		{
			if(Physics.Raycast (corner, transform.TransformDirection (m_CameraOffset), out hitInfo, minOffsetDistance))
			{
				// If the corner is colliding and the collision distance is smaller than the previous distance
				// The distance is updated
				if(hitInfo.collider.gameObject.layer != LayerMask.NameToLayer ("Player") && hitInfo.distance < minOffsetDistance)
				{
					minOffsetDistance = hitInfo.distance;
				}
			}
		}

		// The offset is modified to have the magnitude defined by the minimum collision distance (if any)
		m_TargetOffset = m_CameraOffset.normalized * (minOffsetDistance - m_SkinSize);
	}

	void OnDrawGizmos()
	{
		float frustumHeight = camera.nearClipPlane * Mathf.Tan(camera.fieldOfView * 0.5f * Mathf.Deg2Rad);
		float frustumWidth = camera.aspect * frustumHeight;
		
		Vector3 topLeftFrustumCorner = transform.position + transform.up * frustumHeight + transform.forward * camera.nearClipPlane - transform.right * frustumWidth;
		Vector3 topRightFrustumCorner = transform.position + transform.up * frustumHeight + transform.forward * camera.nearClipPlane + transform.right * frustumWidth;
		Vector3 bottomLeftFrustumCorner = transform.position - transform.up * frustumHeight + transform.forward * camera.nearClipPlane - transform.right * frustumWidth;
		Vector3 bottomRightFrustumCorner = transform.position - transform.up * frustumHeight + transform.forward * camera.nearClipPlane + transform.right * frustumWidth;

		Gizmos.DrawSphere (topLeftFrustumCorner, 0.05f);
		Gizmos.DrawSphere (topRightFrustumCorner, 0.05f);
		Gizmos.DrawSphere (bottomLeftFrustumCorner, 0.05f);
		Gizmos.DrawSphere (bottomRightFrustumCorner, 0.05f);
	}

	void OnGUI()
	{
		GUI.DrawTexture (m_ReticleRectangle, m_ReticleTexture);
	}
}
