﻿using UnityEngine;
using System.Collections;

public class PlayerShootProjectile : MonoBehaviour 
{
	public float m_ProjectileSpeed = 5.0f;

	public Transform m_ShootPoint;
	public GameObject m_ProjectilePrefab;
	GameObject m_CurrentProjectileGameObject;

	PlayerInput m_Input;
	ProjectileManager m_ProjectileManager;

	public float m_TimeBeforeNextProjectileCreation = 1.0f;
	float m_Timer;

	bool m_ProjectileCreated = false;

	// Use this for initialization
	void Start () 
	{
		m_Input = GetComponent<PlayerInput> ();
		m_ProjectileManager = GetComponent<ProjectileManager> ();
	}
	
	// Update is called once per frame
	void Update () 
	{
		if(!m_ProjectileCreated)
		{
			m_ProjectileCreated = true;			
			
			CreateCurrentProjectile ();
		}

		if(m_Timer > 0.0f)
		{
			m_Timer -= Time.deltaTime;

			if(m_Timer <= 0.0f)
			{
				CreateCurrentProjectile();
			}
		}
		else
		{
			if(m_Input.Shoot)
			{
				ShootProjectile ();
			}
		}
	}

	void ShootProjectile()
	{
		m_CurrentProjectileGameObject.GetComponent<Projectile> ().ProjectileSpeed = m_ProjectileSpeed;
		m_CurrentProjectileGameObject.transform.parent = null;
		m_CurrentProjectileGameObject.collider.isTrigger = false;

		m_Timer = m_TimeBeforeNextProjectileCreation;
	}

	void CreateCurrentProjectile()
	{
		m_CurrentProjectileGameObject = (GameObject)Instantiate (m_ProjectilePrefab, m_ShootPoint.position, m_ShootPoint.rotation);
		m_CurrentProjectileGameObject.transform.parent = m_ShootPoint;
		m_CurrentProjectileGameObject.GetComponent<Ball> ().BallColor = m_ProjectileManager.GetNextProjectileColor ();
		
		m_ProjectileManager.UpdateNextProjectileColor ();
	}
}
		                                                        