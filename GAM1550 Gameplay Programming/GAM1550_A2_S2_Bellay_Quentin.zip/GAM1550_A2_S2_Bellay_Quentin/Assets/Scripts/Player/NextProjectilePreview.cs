﻿using UnityEngine;
using System.Collections;

public class NextProjectilePreview : MonoBehaviour 
{
	public ProjectileManager m_ProjectileManager;
	
	// Update is called once per frame
	void Update () 
	{
		renderer.material.color = m_ProjectileManager.GetNextProjectileColor ();
	}
}
