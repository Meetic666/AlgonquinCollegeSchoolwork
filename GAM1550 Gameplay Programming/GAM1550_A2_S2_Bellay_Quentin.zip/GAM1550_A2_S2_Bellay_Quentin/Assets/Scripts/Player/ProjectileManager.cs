﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ProjectileManager : MonoBehaviour 
{
	public List<Color> m_ColorsAvailable;

	int m_NextProjectileColorIndex = 0;

	// Use this for initialization
	void Start () 
	{
		UpdateNextProjectileColor ();
	}

	public Color GetNextProjectileColor()
	{
		if(m_ColorsAvailable.Count >= 1)
		{
			return m_ColorsAvailable[Mathf.Min (m_NextProjectileColorIndex, m_ColorsAvailable.Count -1)];
		}
		else
		{
			return Color.white;
		}
	}

	public void UpdateNextProjectileColor()
	{
		m_NextProjectileColorIndex = Random.Range (0, m_ColorsAvailable.Count);
	}

	public void RemoveColor(Color color)
	{
		m_ColorsAvailable.Remove (color);
	}
}
