﻿using UnityEngine;
using System.Collections;

public class PlayerRotation : MonoBehaviour 
{
	public float m_MaxRotationAngleInDegrees = 45.0f;
	public float m_RotationSpeedInDegrees = 5.0f;

	float m_CurrentAngle = 0.0f;

	PlayerInput m_Input;

	// Use this for initialization
	void Start () 
	{
		m_Input = GetComponent<PlayerInput> ();
	}
	
	// Update is called once per frame
	void Update () 
	{
		Vector3 newEulerAngles = transform.localEulerAngles;
		m_CurrentAngle -= m_RotationSpeedInDegrees * m_Input.HorizontalMovement * Time.deltaTime;

		m_CurrentAngle = Mathf.Clamp (m_CurrentAngle, - m_MaxRotationAngleInDegrees, m_MaxRotationAngleInDegrees);

		newEulerAngles.z = m_CurrentAngle;

		transform.localEulerAngles = newEulerAngles;
	}
}
