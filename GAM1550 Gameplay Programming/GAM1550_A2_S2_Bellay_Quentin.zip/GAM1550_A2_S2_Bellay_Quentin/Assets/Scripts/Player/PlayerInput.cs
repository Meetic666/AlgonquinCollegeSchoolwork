﻿using UnityEngine;
using System.Collections;

public class PlayerInput : MonoBehaviour 
{
	public float HorizontalMovement 
	{
		get; set;
	}

	public bool Shoot
	{
		get; set;
	}
	
	// Update is called once per frame
	void Update () 
	{
		HorizontalMovement = Input.GetAxis ("Horizontal");

		Shoot = Input.GetButtonDown ("Fire");
	}
}
