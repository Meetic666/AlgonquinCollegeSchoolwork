﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Ball : GridElement 
{
	Color m_BallColor;

	List<Ball> m_ConnectingBalls = new List<Ball>();

	public bool IsStable 
	{
		get; set;
	}

	public Color BallColor 
	{
		get
		{
			return m_BallColor;
		}

		set
		{
			m_BallColor = value;

			SetRenderer ();
		}
	}

	public List<Ball> ConnectingBalls
	{
		get
		{
			return m_ConnectingBalls;
		}
	}

	void SetRenderer()
	{
		renderer.material.color = m_BallColor;
	}

	public void Fall()
	{
		rigidbody.isKinematic = false;
		rigidbody.useGravity = true;
	}

	public void Destroy()
	{
		Destroy (gameObject);
	}

	public void AddConnectingBall(Ball connectingBall)
	{
		m_ConnectingBalls.Add (connectingBall);
	}

	public void RemoveConnectingBall(Ball connectingBall)
	{
		m_ConnectingBalls.Remove (connectingBall);
	}

	public void CheckForConnectingBalls()
	{
		float raycastLength = GetComponent<SphereCollider> ().radius * 1.1f;

		Collider[] ballColliders = Physics.OverlapSphere (transform.position, raycastLength);

		foreach(Collider collider in ballColliders)
		{
			if(collider.tag == "Ball")
			{
				collider.GetComponent<Ball>().AddConnectingBall(this);
				AddConnectingBall(collider.GetComponent<Ball>());
			}
		}
	}
}
