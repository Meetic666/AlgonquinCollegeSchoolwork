﻿using UnityEngine;
using System.Collections;

public class GridElement : MonoBehaviour 
{
	public GridManager GridManager 
	{
		get; set;
	}
}
