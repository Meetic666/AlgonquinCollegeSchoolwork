﻿using UnityEngine;
using System.Collections;

public class GridPoint : MonoBehaviour 
{
	public bool m_IsStable = false;
	public bool m_HasBall = false;

	public GridManager m_GridManager;

	void Start()
	{
		m_GridManager.AddGridPoint (this);
	}
}
