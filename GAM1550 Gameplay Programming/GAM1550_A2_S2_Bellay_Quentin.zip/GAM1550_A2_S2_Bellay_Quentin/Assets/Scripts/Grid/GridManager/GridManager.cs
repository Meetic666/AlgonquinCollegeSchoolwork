﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class GridManager : MonoBehaviour 
{
	public List<Color> m_GridColors = new List<Color> ();
	List<GridPoint> m_GridPoints = new List<GridPoint>();
	public ProjectileManager m_ProjectileManager;
	public GridElement m_UpperWall;
	public GameObject m_BallPrefab;

	public float m_VerticalOffsetWhenMoving = 0.1f;
	public float m_TimeBeforeNextStep = 1.0f;
	float m_Timer = 0.0f;

	List<Ball> m_BallsToCheckForStability = new List<Ball>();
	List<Ball> m_BallsTraversedForStabilityCheck = new List<Ball> ();
	List<Ball> m_MatchingBalls = new List<Ball>();

	Dictionary<Color, bool> m_ColorExistsInGrid = new Dictionary<Color, bool> ();

	public List<GameObject> m_GridRowsForCreation;

	public Transform m_LoseConditionPoint;
	public PlayerShootProjectile m_Player;
	public NextProjectilePreview m_ProjectilePreview;
	public EndgameManager m_EndgameManager;

	bool m_GridCreated = false;

	// Use this for initialization
	void Start ()
	{
		foreach(Color color in m_GridColors)
		{
			m_ProjectileManager.m_ColorsAvailable.Add (color);
		}

		m_UpperWall.GridManager = this;

		foreach(Color color in m_GridColors)
		{
			m_ColorExistsInGrid.Add (color, false);
		}
	}
	
	// Update is called once per frame
	void Update () 
	{
		if(!m_GridCreated)
		{
			m_GridCreated = true;

			CreateGrid();
		}

		if(m_Timer > 0.0f)
		{
			m_Timer -= Time.deltaTime;

			if(m_Timer <= 0.0f)
			{
				MoveGridDown ();
			}
		}
	}

	public void AttachBallToGrid(Ball ballToAttach)
	{
		GridPoint parentGridPoint = FindClosestGridPoint (ballToAttach.transform.position);

		ballToAttach.rigidbody.isKinematic = true;
		ballToAttach.transform.parent = parentGridPoint.transform;
		ballToAttach.transform.localPosition = Vector3.zero;
		ballToAttach.IsStable = parentGridPoint.m_IsStable;
		ballToAttach.GridManager = this;
		ballToAttach.CheckForConnectingBalls ();

		parentGridPoint.m_HasBall = true;
		
		m_BallsToCheckForStability.Clear ();
		m_MatchingBalls.Clear ();

		CheckForColorMatch (ballToAttach);

		if(m_MatchingBalls.Count >= 3)
		{
			RemoveMatchingBalls();
			
			foreach(GridPoint gridPoint in m_GridPoints)
			{
				if(gridPoint.m_HasBall)
				{
					Ball gridPointBall = gridPoint.GetComponentInChildren<Ball>();

					m_BallsToCheckForStability.Add (gridPointBall);
				}
			}
			
			foreach(Ball ball in m_BallsToCheckForStability)
			{
				m_BallsTraversedForStabilityCheck.Clear ();
				
				bool isStable = CheckForStability (ball);
				
				if(!isStable)
				{
					ball.transform.parent.GetComponent<GridPoint>().m_HasBall = false;
					ball.Fall();
					ball.transform.parent = null;
				}
			}

			foreach(Color color in m_GridColors)
			{
				m_ColorExistsInGrid[color] = false;
			}

			foreach(GridPoint gridPoint in m_GridPoints)
			{
				if(gridPoint.m_HasBall)
				{	
					Ball gridPointBall = gridPoint.GetComponentInChildren<Ball>();

					m_ColorExistsInGrid[gridPointBall.BallColor] = true;
				}
			}

			bool hasPlayerWon = true;

			foreach(Color color in m_ColorExistsInGrid.Keys)
			{
				if(!m_ColorExistsInGrid[color])
				{
					m_ProjectileManager.RemoveColor(color);
				}
				else
				{
					hasPlayerWon = false;
				}
			}

			if(hasPlayerWon)
			{
				m_EndgameManager.m_HasPlayerWon = true;
			}
		}

		m_Timer = m_TimeBeforeNextStep;
	}

	void MoveGridDown()
	{
		transform.position -= transform.up * m_VerticalOffsetWhenMoving;
		
		CheckLosingCondition ();
	}

	GridPoint FindClosestGridPoint(Vector3 ballPosition)
	{
		GridPoint result = null;
		float minDistance = Mathf.Infinity;
		float distance = 0.0f;

		foreach(GridPoint gridPoint in m_GridPoints)
		{
			if(!gridPoint.m_HasBall 
			   && (distance = Vector3.Distance (ballPosition, gridPoint.transform.position)) < minDistance)
			{
				minDistance = distance;

				result = gridPoint;
			}
		}

		return result;
	}

	void CheckForColorMatch(Ball ball)
	{
		m_MatchingBalls.Add (ball);

		foreach(Ball connectingBall in ball.ConnectingBalls)
		{
			if(!m_MatchingBalls.Contains(connectingBall)
			   && connectingBall.BallColor == ball.BallColor)
			{
				CheckForColorMatch (connectingBall);
			}
		}
	}

	void RemoveMatchingBalls()
	{
		foreach(Ball ball in m_MatchingBalls)
		{	
			foreach(Ball connectingBall in ball.ConnectingBalls.ToArray())
			{
				connectingBall.RemoveConnectingBall(ball);
			}

			ball.transform.parent.GetComponent<GridPoint>().m_HasBall = false;

			ball.Destroy();
		}
	}

	bool CheckForStability(Ball ball)
	{
		bool result = ball.IsStable;

		m_BallsTraversedForStabilityCheck.Add (ball);

		if(!result)
		{
			foreach(Ball connectingBall in ball.ConnectingBalls)
			{
				if(!result && !m_BallsTraversedForStabilityCheck.Contains(connectingBall))
				{
					result = CheckForStability (connectingBall);
				}
			}
		}

		return result;
	}

	public void AddGridPoint(GridPoint point)
	{
		m_GridPoints.Add (point);
	}

	void CreateGrid()
	{
		foreach(GameObject gridRow in m_GridRowsForCreation)
		{
			foreach(GridPoint parentGridPoint in gridRow.GetComponentsInChildren<GridPoint>())
			{
				GameObject newBall = (GameObject) Instantiate(m_BallPrefab, parentGridPoint.transform.position, Quaternion.identity);

				newBall.transform.parent = parentGridPoint.transform;
				newBall.GetComponent<Ball>().IsStable = parentGridPoint.m_IsStable;
				newBall.GetComponent<Ball>().BallColor = GetBallColor();
				newBall.GetComponent<Ball>().GridManager = this;
				newBall.GetComponent<Ball>().CheckForConnectingBalls();

				parentGridPoint.m_HasBall = true;
			}
		}
	}

	Color GetBallColor()
	{
		return m_GridColors[Random.Range(0, m_GridColors.Count)];
	}

	void CheckLosingCondition()
	{
		bool hasLost = false;

		foreach(GridPoint gridPoint in m_GridPoints)
		{
			if(!hasLost && gridPoint.m_HasBall)
			{	
				Ball gridPointBall = gridPoint.GetComponentInChildren<Ball>();
				
				if(gridPointBall.transform.position.y < m_LoseConditionPoint.position.y)
				{
					hasLost = true;
				}
			}
		}

		if(hasLost)
		{
			foreach(GridPoint gridPoint in m_GridPoints)
			{
				if(gridPoint.m_HasBall)
				{	
					Ball gridPointBall = gridPoint.GetComponentInChildren<Ball>();
					
					gridPointBall.Fall ();
				}
			}

			m_Player.enabled = false;
			m_ProjectilePreview.enabled = false;
			m_EndgameManager.m_HasPlayerLost = true;
		}
	}
}
