﻿using UnityEngine;
using System.Collections;

public class Projectile : MonoBehaviour 
{
	bool m_IsAttached = false;

	public float ProjectileSpeed 
	{
		get; set;
	}
	
	// Update is called once per frame
	void Update () 
	{
		transform.position += transform.up * ProjectileSpeed;
	}

	void OnCollisionEnter(Collision collisionInfo)
	{
		string otherTag = collisionInfo.gameObject.tag;

		if(otherTag == "Ball"
		   || otherTag == "UpperWall")
		{
			if(!m_IsAttached)
			{
				m_IsAttached = true;

				collisionInfo.gameObject.GetComponent<GridElement>().GridManager.AttachBallToGrid(GetComponent<Ball>());

				Destroy (this);
			}
		}
		else if(otherTag == "Wall")
		{
			transform.up += 2.0f * collisionInfo.contacts[0].normal;
		}
	}
}
