﻿using UnityEngine;
using System.Collections;

public class EndgameManager : MonoBehaviour 
{
	public Texture m_LostTexture;
	public Texture m_WinTexture;
	public Texture m_PressSpaceTexture;

	float m_PressSpaceAlpha = 1.0f;

	public float m_AlphaChangeSpeed = 1.0f;

	bool m_AlphaIncreasing = false;

	public bool m_HasPlayerWon = false;
	public bool m_HasPlayerLost = false;

	void Update()
	{
		float actualAlphaChange = m_AlphaChangeSpeed;

		if(!m_AlphaIncreasing)
		{
			actualAlphaChange *= -1.0f;
		}

		m_PressSpaceAlpha += actualAlphaChange * Time.deltaTime;

		if(m_PressSpaceAlpha < 0.0f || m_PressSpaceAlpha > 1.0f)
		{
			m_AlphaIncreasing = !m_AlphaIncreasing;
		}

		if(m_HasPlayerWon || m_HasPlayerLost)
		{
			if(Input.GetKeyDown(KeyCode.Space))
			{
				Application.LoadLevel (Application.loadedLevel);
			}
		}
	}

	void OnGUI()
	{
		if(m_HasPlayerWon || m_HasPlayerLost)
		{
			Rect screenRectangle = new Rect (0.0f, 0.0f, Screen.width, Screen.height);

			GUI.color = new Color(1.0f, 1.0f, 1.0f, m_PressSpaceAlpha);
			GUI.DrawTexture(screenRectangle, m_PressSpaceTexture, ScaleMode.ScaleToFit, true);
			GUI.color = Color.white;

			if(m_HasPlayerWon)
			{
				GUI.DrawTexture(screenRectangle, m_WinTexture);
			}
			else if(m_HasPlayerLost)
			{
				GUI.DrawTexture(screenRectangle, m_LostTexture);
			}
		}
	}
}
