﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class GuardMovement: MonoBehaviour
{
	public List<Transform> m_WayPoints = new List<Transform>();
	public float m_WayPointThreshold;

	int m_CurrentWayPoint = 0;

	NavMeshAgent m_Agent;

	PlayerAnimation m_Animation;

	void Start()
	{
		m_Agent = GetComponent<NavMeshAgent> ();

		m_Animation = GetComponentInChildren<PlayerAnimation> ();
	}
	
	// Update is called once per frame
	void Update () 
	{
		if (m_WayPoints.Count > 0)
		{
			if(m_Agent.remainingDistance <= m_WayPointThreshold)
			{
				m_Agent.SetDestination (m_WayPoints [m_CurrentWayPoint].position);

				m_CurrentWayPoint++;

				if(m_CurrentWayPoint == m_WayPoints.Count)
				{
					m_CurrentWayPoint = 0;
				}
			}

			m_Animation.SetState(PlayerAnimation.PlayerState.e_Walking);
		}
		else
		{
			m_Animation.SetState(PlayerAnimation.PlayerState.e_Idle);
		}
	}
}
