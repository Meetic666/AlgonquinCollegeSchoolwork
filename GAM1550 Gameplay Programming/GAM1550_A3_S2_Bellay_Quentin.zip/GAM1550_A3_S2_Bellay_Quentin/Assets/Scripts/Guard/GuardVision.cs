﻿using UnityEngine;
using System.Collections;

public class GuardVision : MonoBehaviour 
{
	public float m_LookRotationSpeed;
	public float m_LookMaxAngle;
	public float m_DetectionRange;
	public float m_DetectionAngle;
	public GameObject m_DetectionSpot;
	public Color m_AlertColor = Color.red;
	public Color m_RestColor = Color.green;

	float m_DetectionDotProduct;

	Vector3 m_LookDirection;
	float m_LookAngle;
	int m_LookRotationDirection = 1;

	// Use this for initialization
	void Start () 
	{
		m_DetectionDotProduct = Mathf.Cos (m_DetectionAngle * Mathf.Deg2Rad);

		m_LookDirection = transform.forward;
	}
	
	// Update is called once per frame
	void Update () 
	{
		m_LookAngle += m_LookRotationDirection * m_LookRotationSpeed * Time.deltaTime;

		if(Mathf.Sign (m_LookAngle - m_LookRotationDirection * m_LookMaxAngle) == Mathf.Sign (m_LookRotationDirection))
		{
			m_LookRotationDirection *= -1;
		}

		m_LookDirection = Quaternion.Euler (0.0f, m_LookAngle, 0.0f) * transform.forward;

		Vector3 newLocalEulerAngles = m_DetectionSpot.transform.localEulerAngles;
		newLocalEulerAngles.y = m_LookAngle;
		m_DetectionSpot.transform.localEulerAngles = newLocalEulerAngles;

		CheckPlayerDetection ();

		if(GameData.Instance.IsAlertState)
		{
			m_DetectionSpot.GetComponent<Light>().color = m_AlertColor;
		}
		else
		{
			m_DetectionSpot.GetComponent<Light>().color = m_RestColor;
		}
	}

	void CheckPlayerDetection()
	{
		Collider[] colliders = Physics.OverlapSphere (transform.position, m_DetectionRange);
		
		Vector3 colliderDirection;
		
		float colliderDotProduct;
		
		RaycastHit hitInfo;
		
		foreach(Collider interactionCollider in colliders)
		{
			PlayerDetectionBox playerDetection = interactionCollider.GetComponent<PlayerDetectionBox>();

			if(playerDetection != null)
			{
				colliderDirection = (playerDetection.Center - collider.bounds.center).normalized;
				
				colliderDotProduct = Vector3.Dot(colliderDirection, m_LookDirection);
				
				if(colliderDotProduct >= m_DetectionDotProduct &&
				   Physics.Raycast (collider.bounds.center, colliderDirection, out hitInfo, m_DetectionRange));
				{
					if(hitInfo.collider == interactionCollider)
					{
						interactionCollider.GetComponent<PlayerDetectionBox>().Respawn ();
					}
				}
			}
		}
	}
}
