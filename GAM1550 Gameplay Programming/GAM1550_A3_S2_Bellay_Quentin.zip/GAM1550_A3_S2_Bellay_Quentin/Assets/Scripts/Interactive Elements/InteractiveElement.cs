﻿using UnityEngine;
using System.Collections;

public interface InteractiveElement
{
	void Activate (GameObject player);
}
