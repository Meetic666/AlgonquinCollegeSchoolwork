﻿using UnityEngine;
using System.Collections;

public class Switch : MonoBehaviour, InteractiveElement 
{	
	public Color m_OpenColor = Color.green;
	public Color m_CloseColor = Color.red;

	public float m_TimeBeforeClose;
	float m_Timer;

	public bool IsOpen 
	{
		get;
		set;
	}

	public void SetEverActivated()
	{
		m_Timer = 0.0f;
		IsOpen = true;
		
		renderer.material.color = m_OpenColor;
	}
	
	public void Activate(GameObject player)
	{
		if(!IsOpen)
		{
			IsOpen = true;

			renderer.material.color = m_OpenColor;

			m_Timer = m_TimeBeforeClose;
		}
	}

	void Start()
	{
		renderer.material.color = m_CloseColor;
	}

	void Update()
	{
		if(m_Timer > 0.0f)
		{
			m_Timer -= Time.deltaTime;

			if(m_Timer <= 0.0f)
			{
				IsOpen = false;

				renderer.material.color = m_CloseColor;
			}
		}
	}
}
