﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Door : MonoBehaviour
{
	public List<Switch> m_Switches;

	public Vector3 m_OpenOffset;
	public float m_Speed;

	public Color m_OpenColor = Color.green;

	bool m_IsOpen;

	Vector3 m_OpenPosition;

	void Start()
	{
		m_OpenPosition = transform.position + m_OpenOffset;
	}
	
	// Update is called once per frame
	void Update () 
	{
		if(!m_IsOpen)
		{
			bool isOpen = true;

			foreach(Switch doorSwitch in m_Switches)
			{
				isOpen &= doorSwitch.IsOpen;
			}

			m_IsOpen = isOpen;

			if(m_IsOpen)
			{
				renderer.material.color = m_OpenColor;

				foreach(Switch doorSwitch in m_Switches)
				{
					doorSwitch.SetEverActivated();
				}
			}
		}
		else
		{			
			transform.position = Vector3.Lerp (transform.position, m_OpenPosition, m_Speed * Time.deltaTime);
		}
	}
}
