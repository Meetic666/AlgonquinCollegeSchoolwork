﻿using UnityEngine;
using System.Collections;

public class PlayerDetectionBox : MonoBehaviour 
{
	Vector3 m_Center;
	PlayerMovement m_Movement;

	public GameObject ConnectingPlayer 
	{
		get;
		set;
	}

	public Vector3 Center
	{
		get
		{
			Vector3 result = collider.bounds.center;

			if(m_Movement.IsCrouching)
			{
				result.y *= 0.5f;
			}

			return result;
		}
	}

	void Start()
	{
		m_Movement = GetComponent<PlayerMovement> ();
	}
	
	public void Respawn()
	{
		if(ConnectingPlayer != null)
		{
			VIPMovement vip = GetComponent<VIPMovement> ();

			if(vip == null)
			{
				vip = ConnectingPlayer.GetComponent<VIPMovement>();
			}

			if(vip != null)
			{
				vip.Respawn ();
			}
		}
	}
}
