﻿using UnityEngine;
using System.Collections;

public class PlayerMovement : MonoBehaviour 
{
	public float m_MoveSpeed;
	public float m_RotationSpeed;
	public float m_InteractionRange;
	public LayerMask m_LayersToInteractWith;

	protected GameObject m_InteractiveObject;

	CharacterController m_Controller;
	PlayerInput m_Input;

	protected Vector3 m_TargetDirection = Vector3.zero;

	PlayerAnimation m_Animation;

	bool m_IsCrouching = false;

	public bool IsCrouching
	{
		get
		{
			return m_IsCrouching;
		}
	}

	void Start()
	{
		m_Controller = GetComponent<CharacterController> ();
		m_Input = GetComponent<PlayerInput> ();
		m_Animation = GetComponentInChildren<PlayerAnimation> ();
	}

	// Update is called once per frame
	void Update () 
	{		
		if(m_TargetDirection != Vector3.zero)
		{
			if(!m_IsCrouching)
			{
				m_Animation.SetState(PlayerAnimation.PlayerState.e_Walking);
			}
			else
			{
				m_Animation.SetState (PlayerAnimation.PlayerState.e_CrouchWalking);
			}
		}
		else
		{
			if(!m_IsCrouching)
			{
				m_Animation.SetState (PlayerAnimation.PlayerState.e_Idle);
			}
			else
			{
				m_Animation.SetState (PlayerAnimation.PlayerState.e_CrouchIdle);
			}
		}

		CheckInput ();
		CheckInteractiveObject ();

		if(m_TargetDirection != Vector3.zero)
		{
			transform.forward = Vector3.Slerp (transform.forward, m_TargetDirection, m_RotationSpeed * Time.deltaTime);
		}

		m_Controller.Move (m_TargetDirection * m_MoveSpeed * Time.deltaTime);
	}

	void CheckInput()
	{
		if(m_Input)
		{
			m_TargetDirection.x = m_Input.HorizontalMove;
			m_TargetDirection.z = m_Input.VerticalMove;

			m_IsCrouching = m_Input.Crouching;

			if(m_InteractiveObject != null)
			{
				if((m_Input.Interaction && m_InteractiveObject.GetComponent<VIPMovement>() == null)
				   || (m_Input.VIPLead && m_InteractiveObject.GetComponent<VIPMovement>() != null))
				{
					((InteractiveElement)m_InteractiveObject.GetComponent(typeof(InteractiveElement))).Activate(gameObject);

					if(m_InteractiveObject.GetComponent<VIPMovement>() != null)
					{
						GetComponent<PlayerDetectionBox> ().ConnectingPlayer = m_InteractiveObject;
						// TODO: Interaction text
					}
					else
					{
						m_Animation.SetState(PlayerAnimation.PlayerState.e_Interacting);
					}
				}
			}

		}
	}

	void CheckInteractiveObject()
	{
		Collider[] colliders = Physics.OverlapSphere (transform.position, m_InteractionRange, m_LayersToInteractWith.value);

		Vector3 colliderDirection;
		
		float colliderDotProduct;
		
		RaycastHit hitInfo;

		float minDistance = m_InteractionRange;

		foreach(Collider interactionCollider in colliders)
		{
			float distance = Vector3.Distance(transform.position, interactionCollider.transform.position);

			if(distance < minDistance)
			{
				colliderDirection = (interactionCollider.transform.position - transform.position).normalized;

				if(Physics.Raycast (collider.bounds.center, colliderDirection, out hitInfo, m_InteractionRange));
				{
					if(hitInfo.collider == interactionCollider)
					{
						m_InteractiveObject = hitInfo.collider.gameObject;
						minDistance = distance;
					}
				}
			}
		}

		if(minDistance == m_InteractionRange)
		{
			m_InteractiveObject = null;
		}
	}
}
