﻿using UnityEngine;
using System.Collections;

public class PlayerInput : MonoBehaviour 
{
	public float HorizontalMove 
	{
		get;
		set;
	}

	public float VerticalMove 
	{
		get;
		set;
	}

	public bool Interaction
	{
		get;
		set;
	}

	public bool VIPLead
	{
		get;
		set;
	}

	public bool Crouching
	{
		get;
		set;
	}

	// Update is called once per frame
	void Update () 
	{
		HorizontalMove = Input.GetAxis ("Horizontal");
		VerticalMove = Input.GetAxis ("Vertical");
		Interaction = Input.GetKeyDown (KeyCode.E);
		Crouching = Input.GetKey (KeyCode.LeftShift);
		VIPLead = Input.GetKey (KeyCode.Space);
	}
}
