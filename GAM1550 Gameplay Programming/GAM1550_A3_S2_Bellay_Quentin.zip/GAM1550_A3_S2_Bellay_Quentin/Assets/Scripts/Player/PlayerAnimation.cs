﻿using UnityEngine;
using System.Collections;

public class PlayerAnimation : MonoBehaviour 
{

	public enum PlayerState
	{
		e_Idle,
		e_Walking,
		e_CrouchWalking,
		e_CrouchIdle,
		e_LyingDown,
		e_Interacting
	}

	PlayerState m_CurrentState = PlayerState.e_Idle;

	// Use this for initialization
	void Start () 
	{
		animation.CrossFade("Idle");
	}

	public void SetState(PlayerState state)
	{
		if(state != m_CurrentState)
		{
			switch(state)
			{
			case PlayerState.e_CrouchIdle:
			{
				bool queue = false;

				if(m_CurrentState != PlayerState.e_CrouchIdle && m_CurrentState != PlayerState.e_CrouchWalking)
				{
					animation.CrossFade("Duck");
					queue = true;
				}

				if(queue)
				{
					animation.CrossFadeQueued("CrouchIdle");
				}
				else
				{
					animation.CrossFade("CrouchIdle");
				}
			}
				break;

			case PlayerState.e_CrouchWalking:
			{
				bool queue = false;

				if(m_CurrentState != PlayerState.e_CrouchIdle && m_CurrentState != PlayerState.e_CrouchWalking)
				{
					animation.CrossFade("Duck");

					queue = true;
				}

				if(queue)
				{
					animation.CrossFadeQueued("CrouchWalk");
				}
				else
				{
					animation.CrossFade("CrouchWalk");
				}
			}
				break;

			case PlayerState.e_Idle:
			{
				bool queue = false;

				if(m_CurrentState == PlayerState.e_LyingDown)
				{
					animation.CrossFade ("GetUp");

					queue = true;
				}

				if(queue)
				{
					animation.CrossFadeQueued("Idle");
				}
				else
				{
					animation.CrossFade("Idle");
				}
			}
				break;

			case PlayerState.e_Walking:
			{
				bool queue = false;
				
				if(m_CurrentState == PlayerState.e_LyingDown)
				{
					animation.CrossFade ("GetUp");
					
					queue = true;
				}
				
				if(queue)
				{
					animation.CrossFadeQueued("Walking");
				}
				else
				{
					animation.CrossFade("Walking");
				}
			}

				break;

			case PlayerState.e_Interacting:

				animation.Play("Interact1");
				animation.CrossFadeQueued("Interact2");

				break;

			case PlayerState.e_LyingDown:
				animation.CrossFade("LieDown");
				animation.CrossFadeQueued ("Prone");
				break;
			}

			m_CurrentState = state;
		}
	}
}
