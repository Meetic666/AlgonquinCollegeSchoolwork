﻿using UnityEngine;
using System.Collections;

public class VIPMovement : MonoBehaviour, InteractiveElement 
{
	public float m_TimeBeforeReturnToStart;
	public ParticleSystem m_DeathParticles;

	float m_Timer = 0.0f;

	PlayerMovement m_Movement;
	NavMeshAgent m_Agent;
	Vector3 m_StartPoint;

	PlayerAnimation m_Animation;

	// Use this for initialization
	void Start () 
	{
		m_Movement = GetComponent<PlayerMovement> ();
		m_Agent = GetComponent<NavMeshAgent> ();

		m_StartPoint = transform.position;

		m_Animation = GetComponentInChildren<PlayerAnimation> ();
	}
	
	// Update is called once per frame
	void Update () 
	{
		if(m_Timer > 0.0f)
		{			
			m_Movement.enabled = true;
			m_Agent.enabled = false;

			m_Timer -= Time.deltaTime;

			if(m_Timer <= 0.0f)
			{
				Respawn ();
			}
		}
		else
		{
			m_Movement.enabled = false;
			m_Agent.enabled = true;

			m_Agent.SetDestination(m_StartPoint);

			if(GetComponent<PlayerDetectionBox> ().ConnectingPlayer != null)
			{
				GetComponent<PlayerDetectionBox> ().ConnectingPlayer.GetComponent<PlayerDetectionBox>().ConnectingPlayer = null;
				GetComponent<PlayerDetectionBox> ().ConnectingPlayer = null;
			}

			GameData.Instance.IsAlertState = false;

			if(m_Agent.velocity == Vector3.zero)
			{
				m_Animation.SetState (PlayerAnimation.PlayerState.e_LyingDown);
			}
			else
			{
				m_Animation.SetState (PlayerAnimation.PlayerState.e_Walking);
			}
		}
	}

	public void Activate(GameObject player)
	{
		m_Timer = m_TimeBeforeReturnToStart;

		GetComponent<PlayerDetectionBox> ().ConnectingPlayer = player;

		GameData.Instance.IsAlertState = true;
	}
	
	public void Respawn()
	{
		m_Timer = 0.0f;

		GameObject newParticles = (GameObject)Instantiate (m_DeathParticles.gameObject, m_DeathParticles.transform.position, Quaternion.identity);
		newParticles.particleSystem.Play ();

		transform.position = m_StartPoint;

		newParticles = (GameObject)Instantiate (m_DeathParticles.gameObject, m_DeathParticles.transform.position, Quaternion.identity);
		newParticles.particleSystem.Play ();
	}
}
