﻿using UnityEngine;
using System.Collections;

public class PlayerCamera : MonoBehaviour 
{
	public PlayerMovement m_Player;
	public VIPMovement m_VIP;
	public float m_CameraSpeed;
	public Vector3 m_Offset;
	public float m_PlayerDistanceHeightRatio;
	
	// Update is called once per frame
	void Update () 
	{
		Vector3 playerAveragePosition = (m_Player.transform.position + m_VIP.transform.position) * 0.5f;

		float playerDistance = Vector3.Distance (m_Player.transform.position, m_VIP.transform.position);

		Vector3 actualOffset = m_Offset;

		actualOffset.y = playerDistance * m_PlayerDistanceHeightRatio;

		if(actualOffset.y < m_Offset.y)
		{
			actualOffset.y = m_Offset.y;
		}

		transform.position = Vector3.Lerp (transform.position, playerAveragePosition + actualOffset, m_CameraSpeed * Time.deltaTime);
	}
}
