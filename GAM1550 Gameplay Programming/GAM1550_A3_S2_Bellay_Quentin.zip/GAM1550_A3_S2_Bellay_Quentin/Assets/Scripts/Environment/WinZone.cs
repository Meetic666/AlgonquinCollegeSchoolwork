﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class WinZone : MonoBehaviour 
{
	public string m_LevelToLoad;

	List<PlayerMovement> m_Players = new List<PlayerMovement>();

	void OnTriggerEnter(Collider collider)
	{
		PlayerMovement player = collider.GetComponent<PlayerMovement> ();

		if(player != null)
		{
			m_Players.Add (player);

			if(m_Players.Count == 2)
			{
				Application.LoadLevel (m_LevelToLoad);
			}
		}
	}
}
