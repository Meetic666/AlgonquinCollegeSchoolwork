﻿using UnityEngine;
using System.Collections;

public class GameData
{
	static GameData s_Instance;

	public static GameData Instance
	{
		get
		{
			if(s_Instance == null)
			{
				s_Instance = new GameData();
			}

			return s_Instance;
		}
	}

	public bool IsAlertState
	{
		get;
		set;
	}
}
