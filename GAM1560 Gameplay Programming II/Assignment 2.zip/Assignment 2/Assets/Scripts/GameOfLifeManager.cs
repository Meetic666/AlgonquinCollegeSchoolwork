﻿using UnityEngine;
using System.Collections;

public class GameOfLifeManager : MonoBehaviour 
{
	public ComputeShader m_GameOfLifeShader;

	RenderTexture m_GameOfLifeTexture;

	Texture2D m_Buffer;

	[Range(1, 200)]
	public int m_CyclesPerSeconds;
	float m_TimeBetweenCycles;
	float m_Timer;

	public int m_Width = 1920;
	public int m_Height = 1080;

	int m_KernelIndex;
	int m_NumThreadsX = 32;
	int m_NumThreadsY = 32;

	int m_ShaderThreadsX;
	int m_ShaderThreadsY;

	public bool m_GameOfLifeIsRunning = false;

	public enum Shape
	{
		e_Point,
		e_GliderGun,
		e_Pulsar
	}

	public Shape m_ShapeToAdd = Shape.e_Point;

	// Use this for initialization
	void Start () 
	{
		m_GameOfLifeTexture = new RenderTexture(m_Width, m_Height, 0);
		m_GameOfLifeTexture.enableRandomWrite = true;
		m_GameOfLifeTexture.filterMode = FilterMode.Point;
		m_GameOfLifeTexture.wrapMode = TextureWrapMode.Repeat;
		m_GameOfLifeTexture.Create();

		m_Buffer = new Texture2D (m_Width, m_Height);
		m_Buffer.filterMode = FilterMode.Point;
		RenderTexture.active = m_GameOfLifeTexture;
		m_Buffer.ReadPixels(new Rect(0, 0, m_GameOfLifeTexture.width, m_GameOfLifeTexture.height), 0, 0);
		m_Buffer.Apply();

		m_KernelIndex = m_GameOfLifeShader.FindKernel("GameOfLife");

		m_GameOfLifeShader.SetTexture(m_KernelIndex, "m_Input", m_Buffer);
		m_GameOfLifeShader.SetTexture(m_KernelIndex, "m_Result", m_GameOfLifeTexture);

		m_TimeBetweenCycles = 1.0f / m_CyclesPerSeconds;
		m_Timer = m_TimeBetweenCycles;

		m_ShaderThreadsX = (m_Width > m_NumThreadsX) ? m_Width / m_NumThreadsX : m_Width;
		m_ShaderThreadsY = (m_Height > m_NumThreadsY) ? m_Height / m_NumThreadsY : m_Height;
	}
	
	// Update is called once per frame
	void Update () 
	{
		if(m_GameOfLifeIsRunning)
		{
			m_TimeBetweenCycles = 1.0f / m_CyclesPerSeconds;

			if(m_Timer > 0.0f)
			{
				m_Timer -= Time.deltaTime;

				if(m_Timer <= 0.0f)
				{
					m_Timer = m_TimeBetweenCycles;

					m_GameOfLifeShader.Dispatch (m_KernelIndex, m_ShaderThreadsX, m_ShaderThreadsY, 1);

					RenderTexture.active = m_GameOfLifeTexture;
					m_Buffer.ReadPixels(new Rect(0, 0, m_GameOfLifeTexture.width, m_GameOfLifeTexture.height), 0, 0);
					m_Buffer.Apply();
				}
			}
		}
	}

	void OnGUI()
	{
		if(Event.current.type == EventType.Repaint)
		{
			GUI.DrawTexture (Camera.main.pixelRect, m_Buffer);
		}
		else if(Event.current.type == EventType.MouseDown)
		{
			int x = (int) ((Input.mousePosition.x / Camera.main.pixelWidth) * m_Width);
			int y = (int) ((Input.mousePosition.y / Camera.main.pixelHeight) * m_Height);

			switch(m_ShapeToAdd)
			{
				case Shape.e_Point:
				{				
					Color bufferColor = m_Buffer.GetPixel(x, y);
					
					bufferColor = (bufferColor.r == 1.0f) ? Color.black : Color.white;
					
					m_Buffer.SetPixel(x, y, bufferColor);
				}
					break;

				case Shape.e_GliderGun:
				{
				for(int i = -19; i <= 18; i++)
				{
					for(int j = -5; j <= 5; j++)
					{
						int tempX = (x + i) % m_Width;
						int tempY = (y + j) % m_Height;
						
						if(((i == -18 || i == -17) && (j == 1 || j == 2))
						   || ((i == 17 || i == 16) && (j == -1 || j == -2))
						   || ((i == 2 || i == 3) && (j == 0 || j == -1 || j == -2))
						   || ((i == 4) && (j == -3 || j == 1))
						   || ((i == 6) && (j == -3 || j == 1 || j == -4 || j == 2))
						   || ((i == -1 || i == -4) && (j == 1))
						   || ((i == -2 || i == -8) && (j == 0 || j == 1 || j ==2))
						   || ((i == -3 || i == -7) && (j == -1 || j == 3))
						   || ((i == -5 || i == -6) && (j == -2 || j == 4))
						   )
						{
							m_Buffer.SetPixel (tempX, tempY, Color.white);
						}
						else
						{
							m_Buffer.SetPixel (tempX, tempY, Color.black);
						}
					}
				}
				}
					break;

				case Shape.e_Pulsar:
				{
					for(int i = -8; i <= 8; i++)
					{
						for(int j = -8; j <= 8; j++)
						{
							int tempX = (x + i) % m_Width;
							int tempY = (y + j) % m_Height;

							if(((Mathf.Abs (i) == 1 || Mathf.Abs (i) == 6) && (Mathf.Abs (j) == 2 || Mathf.Abs (j) == 3 || Mathf.Abs (j) == 4))
							   || ((Mathf.Abs (i) == 2 || Mathf.Abs (i) == 3 || Mathf.Abs (i) == 4) && (Mathf.Abs (j) == 1 || Mathf.Abs (j) == 6)))
							{
								m_Buffer.SetPixel (tempX, tempY, Color.white);
							}
							else
							{
								m_Buffer.SetPixel (tempX, tempY, Color.black);
							}
						}
					}
				}
					break;
			}
			
			m_Buffer.Apply ();
		}
	}

	void OnDestroy()
	{
		m_GameOfLifeTexture.Release ();
	}
}
