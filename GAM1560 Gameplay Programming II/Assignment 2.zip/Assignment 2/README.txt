The game of life can be started by checking the checkbox in the editor for the main camera's component.

The size of the texture as well as the rate of cycles can be set in that same component.

You can choose what to add to the texture when you click by using the drop down list in the component.