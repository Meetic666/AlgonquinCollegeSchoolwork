//
//  PauseViewController.m
//  Assignment1
//
//  Created by Quentin Bellay on 2014-01-27.
//  Copyright (c) 2014 Chris and Quentin. All rights reserved.
//

#import "PauseViewController.h"

@interface PauseViewController ()

@end

@implementation PauseViewController

@synthesize cylinder = m_Cylinder;
@synthesize bullet1 = m_Bullet1;
@synthesize bullet2 = m_Bullet2;
@synthesize bullet3 = m_Bullet3;
@synthesize resumeButton = m_ResumeButton;
@synthesize menuButton = m_MenuButton;
@synthesize restartButton = m_RestartButton;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [self setImages:self];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
    
-(void)setImages:(id)sender
{
    NSDictionary* infoDictionary = [[NSBundle mainBundle] infoDictionary];
    
    NSArray* translation = [infoDictionary objectForKey:@"CylinderTranslation"];
    
    m_TranslationX = m_Cylinder.frame.size.width * [[translation objectAtIndex:0] floatValue];
    m_TranslationY = m_Cylinder.frame.size.height * [[translation objectAtIndex:1] floatValue];
    
    [self translateImagesByX:m_TranslationX Y:m_TranslationY];
}

-(void)resetImages:(id)sender
{
    [self translateImagesByX:-m_TranslationX Y:-m_TranslationY];
}

-(void)translateImagesByX:(int)x Y:(int)y
{
    m_Cylinder.layer.transform = CATransform3DConcat(m_Cylinder.layer.transform, CATransform3DMakeTranslation(x, y, 0.0f));
    m_Bullet1.layer.transform = CATransform3DConcat(m_Bullet1.layer.transform, CATransform3DMakeTranslation(x, y, 0.0f));
    m_Bullet2.layer.transform = CATransform3DConcat(m_Bullet2.layer.transform, CATransform3DMakeTranslation(x, y, 0.0f));
    m_Bullet3.layer.transform = CATransform3DConcat(m_Bullet3.layer.transform, CATransform3DMakeTranslation(x, y, 0.0f));
}

-(IBAction)resumeButton:(id)sender
{
    [m_Bullet1 setAlpha:1];
    
    m_ResumeButton.selected = YES;
    
    [NSTimer scheduledTimerWithTimeInterval:.5 target:self selector:@selector(resetImages:) userInfo:Nil repeats:NO];
    
    [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(switchToGame:) userInfo:Nil repeats:NO];
}

-(IBAction)mainMenuButton:(id)sender
{
    [m_Bullet2 setAlpha:1];
    
    m_MenuButton.selected = YES;
    
    [NSTimer scheduledTimerWithTimeInterval:.5 target:self selector:@selector(resetImages:) userInfo:Nil repeats:NO];
    
    [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(switchToMainMenu:) userInfo:Nil repeats:NO];
}


-(IBAction)restartButton:(id)sender
{
    [m_Bullet3 setAlpha:1];
    
    m_RestartButton.selected = YES;
    
    [NSTimer scheduledTimerWithTimeInterval:.5 target:self selector:@selector(resetImages:) userInfo:Nil repeats:NO];
    
    [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(switchToLoad:) userInfo:Nil repeats:NO];
}

-(void)switchToGame:(id)sender
{
    [self dismissViewControllerAnimated:NO completion:^{}];
}

-(void)switchToMainMenu:(id)sender
{
    [self performSegueWithIdentifier:@"PauseToMain" sender:self];
}


-(void)switchToLoad:(id)sender
{
    [self performSegueWithIdentifier:@"PauseToLoad" sender:self];
}

@end
