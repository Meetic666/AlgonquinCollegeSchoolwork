//
//  PauseViewController.h
//  Assignment1
//
//  Created by Quentin Bellay on 2014-01-27.
//  Copyright (c) 2014 Chris and Quentin. All rights reserved.
//

#import "BaseViewController.h"
#import <UIKit/UIKit.h>

@interface PauseViewController : BaseViewController
{
@private
    UIImageView* m_Cylinder;
    UIImageView* m_Bullet1;
    UIImageView* m_Bullet2;
    UIImageView* m_Bullet3;
    int m_TranslationX;
    int m_TranslationY;
    
    UIButton* m_ResumeButton;
    UIButton* m_MenuButton;
    UIButton* m_RestartButton;
}

-(void)setImages:(id)sender;
-(void)resetImages:(id)sender;
-(void)translateImagesByX:(int)x Y:(int)y;

-(IBAction)resumeButton:(id)sender;
-(IBAction)mainMenuButton:(id)sender;
-(IBAction)restartButton:(id)sender;

-(void)switchToGame:(id)sender;
-(void)switchToMainMenu:(id)sender;
-(void)switchToLoad:(id)sender;

@property(nonatomic) IBOutlet UIImageView* cylinder;
@property(nonatomic) IBOutlet UIImageView* bullet1;
@property(nonatomic) IBOutlet UIImageView* bullet2;
@property(nonatomic) IBOutlet UIImageView* bullet3;
@property(nonatomic) IBOutlet UIButton* resumeButton;
@property(nonatomic) IBOutlet UIButton* menuButton;
@property(nonatomic) IBOutlet UIButton* restartButton;

@end
