//
//  MainMenuViewController.m
//  Assignment1
//
//  Created by Quentin Bellay on 2014-01-20.
//  Copyright (c) 2014 Chris and Quentin. All rights reserved.
//

#import "MainMenuViewController.h"

@interface MainMenuViewController ()

@end

@implementation MainMenuViewController

@synthesize cylinder = m_Cylinder;
@synthesize bullet1 = m_Bullet1;
@synthesize bullet2 = m_Bullet2;
@synthesize bullet3 = m_Bullet3;
@synthesize bullet4 = m_Bullet4;

@synthesize startButton = m_StartButton;
@synthesize optionsButton = m_OptionsButton;
@synthesize controlsButton = m_ControlsButton;
@synthesize creditsButton = m_CreditsButton;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    m_BulletAlpha = m_Bullet1.alpha;
    
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [self setImages:self];
    
    [self resetButtons:self];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)setImages:(id)sender
{
    NSDictionary* infoDictionary = [[NSBundle mainBundle] infoDictionary];
    
    NSArray* translation = [infoDictionary objectForKey:@"CylinderTranslation"];
    
    m_TranslationX = m_Cylinder.frame.size.width * [[translation objectAtIndex:0] floatValue];
    m_TranslationY = m_Cylinder.frame.size.height * [[translation objectAtIndex:1] floatValue];
    
    [self translateImagesByX:m_TranslationX Y:m_TranslationY];
}

-(void)resetImages:(id)sender
{
    [self translateImagesByX:-m_TranslationX Y:-m_TranslationY];
}

-(void)translateImagesByX:(int)x Y:(int)y
{
    m_Cylinder.layer.transform = CATransform3DConcat(m_Cylinder.layer.transform, CATransform3DMakeTranslation(x, y, 0.0f));
    m_Bullet1.layer.transform = CATransform3DConcat(m_Bullet1.layer.transform, CATransform3DMakeTranslation(x, y, 0.0f));
    m_Bullet2.layer.transform = CATransform3DConcat(m_Bullet2.layer.transform, CATransform3DMakeTranslation(x, y, 0.0f));
    m_Bullet3.layer.transform = CATransform3DConcat(m_Bullet3.layer.transform, CATransform3DMakeTranslation(x, y, 0.0f));
    m_Bullet4.layer.transform = CATransform3DConcat(m_Bullet4.layer.transform, CATransform3DMakeTranslation(x, y, 0.0f));
}

-(void) resetButtons:(id)sender
{
    [m_Bullet1 setAlpha:m_BulletAlpha];
    [m_Bullet2 setAlpha:m_BulletAlpha];
    [m_Bullet3 setAlpha:m_BulletAlpha];
    [m_Bullet4 setAlpha:m_BulletAlpha];
    
    m_StartButton.selected = NO;
    m_OptionsButton.selected = NO;
    m_ControlsButton.selected = NO;
    m_CreditsButton.selected = NO;
}

-(IBAction)startButton:(id)sender
{
    [m_Bullet1 setAlpha:1];
    
    m_StartButton.selected = YES;
    
    [NSTimer scheduledTimerWithTimeInterval:.5 target:self selector:@selector(resetImages:) userInfo:Nil repeats:NO];
    
    [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(switchToGame:) userInfo:Nil repeats:NO];
}

-(IBAction)optionsButton:(id)sender
{
    [m_Bullet2 setAlpha:1];
    
    m_OptionsButton.selected = YES;
    
    [NSTimer scheduledTimerWithTimeInterval:.5 target:self selector:@selector(resetImages:) userInfo:Nil repeats:NO];
    
    [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(switchToOptions:) userInfo:Nil repeats:NO];
}

-(IBAction)controlsButton:(id)sender
{
    [m_Bullet3 setAlpha:1];
    
    m_ControlsButton.selected = YES;
    
    [NSTimer scheduledTimerWithTimeInterval:.5 target:self selector:@selector(resetImages:) userInfo:Nil repeats:NO];
    
    [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(switchToControls:) userInfo:Nil repeats:NO];
}

-(IBAction)creditsButton:(id)sender
{
    [m_Bullet4 setAlpha:1];
    
    m_CreditsButton.selected = YES;
    
    [NSTimer scheduledTimerWithTimeInterval:.5 target:self selector:@selector(resetImages:) userInfo:Nil repeats:NO];
    
    [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(switchToCredits:) userInfo:Nil repeats:NO];
}

-(void)switchToGame:(id)sender
{
    [self performSegueWithIdentifier:@"MainToLoad" sender:self];
}

-(void)switchToOptions:(id)sender
{
    [self performSegueWithIdentifier:@"MainToOptions" sender:self];
}

-(void)switchToControls:(id)sender
{
    [self performSegueWithIdentifier:@"MainToControls" sender:self];
}

-(void)switchToCredits:(id)sender
{
    [self performSegueWithIdentifier:@"MainToCredits" sender:self];
}

@end
