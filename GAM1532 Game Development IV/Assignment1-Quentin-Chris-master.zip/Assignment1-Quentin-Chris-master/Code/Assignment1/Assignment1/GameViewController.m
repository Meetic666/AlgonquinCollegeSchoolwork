//
//  GameViewController.m
//  Assignment1
//
//  Created by Quentin Bellay on 2014-01-27.
//  Copyright (c) 2014 Chris and Quentin. All rights reserved.
//

#import "GameViewController.h"

@interface GameViewController ()

@end

@implementation GameViewController

@synthesize cylinder = m_Cylinder;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    m_Open = NO;    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)cylinderPanned:(id)sender
{
    if(m_Open == NO)
    {
        m_Open = YES;
        
        [self switchToPause:self];
    }
}

-(void)switchToPause:(id)sender
{
    [self performSegueWithIdentifier:@"GameToPause" sender:self];
}

@end
