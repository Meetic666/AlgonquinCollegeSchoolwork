//
//  LoadScreenViewController.m
//  Assignment1
//
//  Created by Quentin Bellay on 2014-01-27.
//  Copyright (c) 2014 Chris and Quentin. All rights reserved.
//

#import "LoadScreenViewController.h"

@interface LoadScreenViewController ()

@end

@implementation LoadScreenViewController

@synthesize bullet1 = m_Bullet1;
@synthesize bullet2 = m_Bullet2;
@synthesize bullet3 = m_Bullet3;
@synthesize bullet4 = m_Bullet4;
@synthesize bullet5 = m_Bullet5;
@synthesize bullet6 = m_Bullet6;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    int i = 0;
    for(i = 1; i < 7; i++)
    {
        NSNumber* userInfo = [NSNumber numberWithInt:i];
        [NSTimer scheduledTimerWithTimeInterval:i * .5 target:self selector:@selector(showImageNumber:) userInfo:userInfo repeats:NO];
    }
    
    [NSTimer scheduledTimerWithTimeInterval:i * .5 target:self selector:@selector(switchToGame:) userInfo:Nil repeats:NO];
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)showImageNumber:(NSTimer*) timer
{
    switch([[timer userInfo] integerValue])
    {
        case 1:
            [m_Bullet1 setHidden:NO];
            break;
            
        case 2:
            [m_Bullet2 setHidden:NO];
            break;
            
        case 3:
            [m_Bullet3 setHidden:NO];
            break;
            
        case 4:
            [m_Bullet4 setHidden:NO];
            break;
            
        case 5:
            [m_Bullet5 setHidden:NO];
            break;
            
        case 6:
            [m_Bullet6 setHidden:NO];
            break;
    }
}

-(void)switchToGame:(id)sender
{
    [self performSegueWithIdentifier:@"LoadToGame" sender:self];
}

@end
