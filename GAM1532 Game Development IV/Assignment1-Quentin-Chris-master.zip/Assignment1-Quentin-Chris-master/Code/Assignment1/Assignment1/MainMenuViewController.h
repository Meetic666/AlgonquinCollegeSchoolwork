//
//  MainMenuViewController.h
//  Assignment1
//
//  Created by Quentin Bellay on 2014-01-20.
//  Copyright (c) 2014 Chris and Quentin. All rights reserved.
//

#import "BaseViewController.h"
#import <UIKit/UIKit.h>

@interface MainMenuViewController : BaseViewController
{
@private
    UIImageView* m_Cylinder;
    UIImageView* m_Bullet1;
    UIImageView* m_Bullet2;
    UIImageView* m_Bullet3;
    UIImageView* m_Bullet4;
    UILabel* m_Label;
    int m_TranslationX;
    int m_TranslationY;
    
    UIButton* m_StartButton;
    UIButton* m_OptionsButton;
    UIButton* m_ControlsButton;
    UIButton* m_CreditsButton;
    
    float m_BulletAlpha;
}

-(void)setImages:(id)sender;
-(void)resetImages:(id)sender;
-(void)translateImagesByX:(int)x Y:(int)y;
-(void) resetButtons:(id)sender;

-(IBAction)startButton:(id)sender;
-(IBAction)optionsButton:(id)sender;
-(IBAction)controlsButton:(id)sender;
-(IBAction)creditsButton:(id)sender;

-(void)switchToGame:(id)sender;
-(void)switchToOptions:(id)sender;
-(void)switchToControls:(id)sender;
-(void)switchToCredits:(id)sender;

@property(nonatomic) IBOutlet UIImageView* cylinder;
@property(nonatomic) IBOutlet UIImageView* bullet1;
@property(nonatomic) IBOutlet UIImageView* bullet2;
@property(nonatomic) IBOutlet UIImageView* bullet3;
@property(nonatomic) IBOutlet UIImageView* bullet4;
@property(nonatomic) IBOutlet UIButton* startButton;
@property(nonatomic) IBOutlet UIButton* optionsButton;
@property(nonatomic) IBOutlet UIButton* controlsButton;
@property(nonatomic) IBOutlet UIButton* creditsButton;


@end


