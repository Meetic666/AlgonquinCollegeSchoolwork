//
//  LoadScreenViewController.h
//  Assignment1
//
//  Created by Quentin Bellay on 2014-01-27.
//  Copyright (c) 2014 Chris and Quentin. All rights reserved.
//

#import "BaseViewController.h"
#import <UIKit/UIKit.h>

@interface LoadScreenViewController : BaseViewController
{
@private
    UIImageView* m_Bullet1;
    UIImageView* m_Bullet2;
    UIImageView* m_Bullet3;
    UIImageView* m_Bullet4;
    UIImageView* m_Bullet5;
    UIImageView* m_Bullet6;
}

@property (nonatomic) IBOutlet UIImageView* bullet1;
@property (nonatomic) IBOutlet UIImageView* bullet2;
@property (nonatomic) IBOutlet UIImageView* bullet3;
@property (nonatomic) IBOutlet UIImageView* bullet4;
@property (nonatomic) IBOutlet UIImageView* bullet5;
@property (nonatomic) IBOutlet UIImageView* bullet6;

-(void)showImageNumber:(NSTimer*) timer;
-(void)switchToGame:(id)sender;

@end
