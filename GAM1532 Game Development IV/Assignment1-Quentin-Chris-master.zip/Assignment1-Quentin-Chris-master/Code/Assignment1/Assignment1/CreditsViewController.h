//
//  CreditsViewController.h
//  Assignment1
//
//  Created by Quentin Bellay on 2014-02-03.
//  Copyright (c) 2014 Chris and Quentin. All rights reserved.
//

#import "BaseViewController.h"

@interface CreditsViewController : BaseViewController
{
@private
    UILabel* m_Label;
}

@property(nonatomic) IBOutlet UILabel* label;

@end
