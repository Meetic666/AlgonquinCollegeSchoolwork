//
//  GameSettings.h
//  Assignment1
//
//  Created by Christopher Nadon on 2014-02-01.
//  Copyright (c) 2014 Chris and Quentin. All rights reserved.
//

#ifndef __Assignment1__GameSettings__
#define __Assignment1__GameSettings__

class GameSettings
{
public:
    static GameSettings* getInstance();
    
    float getBrightnessLevel();
    void setBrightnessLevel(float brightnessLevel);
    
    float getMusicVolume();
    void setMusicVolume(float musicVolume);
    
    int getDifficulty();
    void setDifficulty(int difficulty);
    
    float getVintageLevel();
    void setVintageLevel(float vintageLevel);
    
    
private:
    GameSettings();
    ~GameSettings();
    
    static GameSettings* s_Instance;
    
    float m_BrightnessLevel;
    float m_MusicVolume;
    int m_Difficulty;
    float m_VintageLevel;
    
};

#endif /* defined(__Assignment1__GameSettings__) */
