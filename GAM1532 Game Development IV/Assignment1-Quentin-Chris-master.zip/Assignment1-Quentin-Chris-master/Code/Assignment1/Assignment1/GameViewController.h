//
//  GameViewController.h
//  Assignment1
//
//  Created by Quentin Bellay on 2014-01-27.
//  Copyright (c) 2014 Chris and Quentin. All rights reserved.
//

#import "BaseViewController.h"
#import <UIKit/UIKit.h>

@interface GameViewController : BaseViewController
{
@private
    BOOL m_Open;
    UIImageView* m_Cylinder;
    float m_TranslationX;
    float m_TranslationY;
    
    float m_CylinderX;
    float m_CylinderY;
}

-(IBAction)cylinderPanned:(id)sender;
-(void)switchToPause:(id)sender;

@property (nonatomic) IBOutlet UIImageView* cylinder;

@end
