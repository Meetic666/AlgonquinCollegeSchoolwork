//
//  OptionsMenuViewController.m
//  Assignment1
//
//  Created by Christopher Nadon on 2014-02-01.
//  Copyright (c) 2014 Chris and Quentin. All rights reserved.
//

#import "OptionsMenuViewController.h"
#include "GameSettings.h"

@interface OptionsMenuViewController ()

@end

@implementation OptionsMenuViewController

@synthesize barrel = m_Barrel;
@synthesize barrelEnd = m_BarrelEnd;
@synthesize cylinder1 = m_Cylinder1;
@synthesize cylinder2 = m_Cylinder2;
@synthesize slider = m_Slider;
@synthesize optionLabel = m_OptionLabel;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    m_HasChangedOption = NO;
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    
    m_BarrelBaseLength = m_Barrel.frame.size.width;
    
    m_CurrentOption = BRIGHTNESS;
    
    [self setOption];
    
    [self setBarrel];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)setBarrel
{
    float barrelWidth = m_BarrelBaseLength;
    float sliderValue = 0.0f;
    
    switch (m_CurrentOption) {
        case BRIGHTNESS:
            sliderValue = GameSettings::getInstance() -> getBrightnessLevel();
            break;
            
        case SOUND:
            sliderValue = GameSettings::getInstance() -> getMusicVolume();
            break;
            
        case VINTAGE:
            sliderValue = GameSettings::getInstance() -> getVintageLevel();
            break;
            
        case DIFFICULTY:
            sliderValue = (float)(GameSettings::getInstance() -> getDifficulty()) / 2.0f;
            break;
    }
    
    barrelWidth *= sliderValue;
    
    [m_Slider setValue: sliderValue];
    
    m_Barrel.frame = CGRectMake(m_Barrel.frame.origin.x, m_Barrel.frame.origin.y, barrelWidth, m_Barrel.frame.size.height);
    
    m_BarrelEnd.frame = CGRectMake(m_Barrel.frame.origin.x + m_Barrel.frame.size.width - 2.0f, m_BarrelEnd.frame.origin.y, m_BarrelEnd.frame.size.width, m_BarrelEnd.frame.size.height);
}

-(void)setOption
{
    NSString* label;
    
    switch (m_CurrentOption) {
        case BRIGHTNESS:
            label = @"Brightness";
            m_Cylinder2.hidden = YES;
            break;
            
        case SOUND:
            label = @"Music";
            m_Cylinder2.hidden = NO;
            break;
            
        case VINTAGE:
            label = @"Vintage";
            m_Cylinder2.hidden = YES;
            break;
            
        case DIFFICULTY:
            label = @"Difficulty";
            m_Cylinder2.hidden = NO;
            break;
    }
    
    m_OptionLabel.text = label;
    
    [self setBarrel];
}

-(IBAction)sliderEvent:(id)sender
{
    switch (m_CurrentOption) {
        case BRIGHTNESS:
            GameSettings::getInstance() -> setBrightnessLevel(m_Slider.value);
            break;
            
        case SOUND:
            GameSettings::getInstance() -> setMusicVolume(m_Slider.value);
            break;
            
        case VINTAGE:
            GameSettings::getInstance() -> setVintageLevel(m_Slider.value);
            break;
            
        case DIFFICULTY:
            int difficultyValue = 0;
            
            if(m_Slider.value > 0.66f)
            {
                difficultyValue = 2;
            }
            else if(m_Slider.value > 0.33f)
            {
                difficultyValue = 1;
            }
            
            GameSettings::getInstance() -> setDifficulty(difficultyValue);
            break;
    }
    
    [self setBarrel];
}


-(IBAction)cylinderPanEvent:(id)sender
{
    UIPanGestureRecognizer* recognizer = sender;
    
    if(recognizer.state != UIGestureRecognizerStateEnded)
    {
        if(m_HasChangedOption == NO)
        {
            m_HasChangedOption = YES;
            
            switch (m_CurrentOption) {
                case BRIGHTNESS:
                    m_CurrentOption = SOUND;
                    break;
                    
                case SOUND:
                    m_CurrentOption = VINTAGE;
                    break;
                    
                case VINTAGE:
                    m_CurrentOption = DIFFICULTY;
                    break;
                    
                case DIFFICULTY:
                    m_CurrentOption = BRIGHTNESS;
                    break;
            }
            
            [self setOption];
        }
    }
    else
    {
        m_HasChangedOption = NO;
    }
}

@end
