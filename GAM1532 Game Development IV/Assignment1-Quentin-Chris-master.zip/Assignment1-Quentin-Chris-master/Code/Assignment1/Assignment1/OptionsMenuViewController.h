//
//  OptionsMenuViewController.h
//  Assignment1
//
//  Created by Christopher Nadon on 2014-02-01.
//  Copyright (c) 2014 Chris and Quentin. All rights reserved.
//

#import "BaseViewController.h"
#import <UIKit/UIKit.h>

enum Option
{
    BRIGHTNESS,
    SOUND,
    VINTAGE,
    DIFFICULTY
};

@interface OptionsMenuViewController : BaseViewController
{
@private
    UIImageView* m_Barrel;
    UIImageView* m_BarrelEnd;
    UIImageView* m_Cylinder1;
    UIImageView* m_Cylinder2;
    UISlider* m_Slider;
    
    UILabel* m_OptionLabel;
    
    float m_BarrelBaseLength;
    
    Option m_CurrentOption;
    
    BOOL m_HasChangedOption;
}

-(void)setBarrel;
-(void)setOption;

-(IBAction)sliderEvent:(id)sender;
-(IBAction)cylinderPanEvent:(id)sender;

@property (nonatomic) IBOutlet UIImageView* barrel;
@property (nonatomic) IBOutlet UIImageView* barrelEnd;
@property (nonatomic) IBOutlet UIImageView* cylinder1;
@property (nonatomic) IBOutlet UIImageView* cylinder2;
@property (nonatomic) IBOutlet UISlider* slider;
@property (nonatomic) IBOutlet UILabel* optionLabel;


@end
