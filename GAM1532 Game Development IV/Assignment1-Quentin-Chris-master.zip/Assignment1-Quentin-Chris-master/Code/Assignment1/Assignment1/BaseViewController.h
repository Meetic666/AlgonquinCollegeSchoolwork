//
//  BaseViewController.h
//  Assignment1
//
//  Created by Christopher Nadon on 2014-02-01.
//  Copyright (c) 2014 Chris and Quentin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController

-(IBAction)backButtonEvent:(id)sender;

@end
