//
//  GameSettings.cpp
//  Assignment1
//
//  Created by Christopher Nadon on 2014-02-01.
//  Copyright (c) 2014 Chris and Quentin. All rights reserved.
//

#include "GameSettings.h"
#include <stdlib.h>

GameSettings* GameSettings::s_Instance = NULL;

GameSettings* GameSettings::getInstance()
{
    if(s_Instance == NULL)
    {
        s_Instance = new GameSettings();
    }
    return s_Instance;
}

GameSettings::GameSettings() :
    m_BrightnessLevel(0.0f),
    m_MusicVolume(0.0f),
    m_Difficulty(0),
    m_VintageLevel(0.0f)
{
    
}

GameSettings::~GameSettings()
{
    
}

float GameSettings::getBrightnessLevel()
{
    return m_BrightnessLevel;
}

void GameSettings::setBrightnessLevel(float brightnessLevel)
{
    m_BrightnessLevel = brightnessLevel;
}

float GameSettings::getMusicVolume()
{
    return m_MusicVolume;
}

void GameSettings::setMusicVolume(float musicVolume)
{
    m_MusicVolume = musicVolume;
}

int GameSettings::getDifficulty()
{
    return m_Difficulty;
}

void GameSettings::setDifficulty(int difficulty)
{
    m_Difficulty = difficulty;
}

float GameSettings::getVintageLevel()
{
    return m_VintageLevel;
}

void GameSettings::setVintageLevel(float vintageLevel)
{
    m_VintageLevel = vintageLevel;
}