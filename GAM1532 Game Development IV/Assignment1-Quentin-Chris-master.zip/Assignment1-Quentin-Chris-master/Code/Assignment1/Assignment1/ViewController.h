//
//  ViewController.h
//  Assignment1
//
//  Created by Quentin Bellay on 2014-01-18.
//  Copyright (c) 2014 Chris and Quentin. All rights reserved.
//

#import "BaseViewController.h"
#import <UIKit/UIKit.h>

@interface ViewController : BaseViewController
{
@private
    BOOL m_Open;
    UIImageView* m_Image;
}

@property (nonatomic) IBOutlet UIImageView* image;

-(IBAction)panEvent:(UIPanGestureRecognizer*)recognizer;

-(void)switchToMain:(id)sender;

@end
