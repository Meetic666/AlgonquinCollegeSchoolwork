//
//  main.m
//  Assignment1
//
//  Created by Quentin Bellay on 2014-01-18.
//  Copyright (c) 2014 Chris and Quentin. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
