//
//  ViewController.m
//  Assignment1
//
//  Created by Quentin Bellay on 2014-01-18.
//  Copyright (c) 2014 Chris and Quentin. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize image = m_Image;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    m_Open = NO;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)panEvent:(UIPanGestureRecognizer*)recognizer
{
    if(m_Open == NO)
    {        
        NSDictionary* infoDictionary = [[NSBundle mainBundle] infoDictionary];
        
        NSArray* translation = [infoDictionary objectForKey:@"CylinderTranslation"];
        
        int x = m_Image.frame.size.width * [[translation objectAtIndex:0] floatValue];
        int y = m_Image.frame.size.height * [[translation objectAtIndex:1] floatValue];
        
        m_Image.layer.transform = CATransform3DConcat(m_Image.layer.transform, CATransform3DMakeTranslation(x, y, 0.0f));
        
        m_Open = YES;
        
        [NSTimer scheduledTimerWithTimeInterval:.5 target:self selector:@selector(switchToMain:) userInfo:Nil repeats:NO];
    }
}

-(void)switchToMain:(id)sender
{
    [self performSegueWithIdentifier:@"SplashToMain" sender:self];
}

@end
