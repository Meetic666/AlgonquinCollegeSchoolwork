GAM1532-Assignment3
===================
