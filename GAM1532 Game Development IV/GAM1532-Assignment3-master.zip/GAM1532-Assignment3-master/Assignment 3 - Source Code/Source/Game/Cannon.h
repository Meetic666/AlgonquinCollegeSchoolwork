//
//  Student:        Quentin Bellay
//  Creation Date:  March 10th 2014
//  Course Number:  GAM1532
//  Professor:      Bradley Flood
//  Purpose:        Cannon class
//  Modified:
//

#ifndef __GameDevFramework__Cannon__
#define __GameDevFramework__Cannon__

#include <iostream>

#include "Box2D.h"

// Class representing the cannon (implements b2ContactListener for the explosion when hit by a fast enough cannonball)
class Cannon: public b2ContactListener
{
    
public:
    Cannon(); ///< Constructor.
    ~Cannon();
    
    void create(); ///< Create a cannon.
    void explode(); ///< Make cannon explode.
    
    void update(double deltaTime);
    
    //user control over cannon
    bool fire(); ///< Fire the cannon.
    void barrelUp(float angle); ///< Rotate the cannon barrel.
    void startMoving(float speed); ///< Start the cannon moving.
    void stopMoving(); ///< Stop the cannon moving under its own power.
    
    float getTemperature();
    int ballsFired(); ///< Get number of cannonballs fired in this level.
    bool isDead(); ///< Whether cannon has exploded.
    void coolDown(double deltaTime); ///< Cannon temperature drops over time.
    void reset(); ///< Reset cannon to initial conditions.
    
    float getX();
    
    bool isOnBarrel(b2Vec2 position);
    
    b2Vec2 getBarrelCenter();
    
    virtual void BeginContact(b2Contact* contact); // To check when a cannonball hits the cannon
    virtual void PostSolve(b2Contact* contact, const b2ContactImpulse* impulse);
    
private:
    b2WheelJoint* m_CannonWheelJoint1; ///< Pointer to cannon wheel joint in Physics World.
    b2WheelJoint* m_CannonWheelJoint2;  ///< Pointer to cannon wheel joint in Physics World.
    b2RevoluteJoint* m_CannonBarrelJoint;  ///< Pointer to cannon barrel body in Physics World.
    
    b2Body* m_CannonBarrel;
    b2Body* m_CannonBase;
    b2Body* m_Wheel1;
    b2Body* m_Wheel2;
    
    float m_CannonTemp; ///< Cannon temperature.
    float m_CannonMaxTemp; ///< Cannon maximum allowable temperature.
    int m_CannonBallsFired; ///< Number of cannonballs fired in current level.
    bool m_CannonExploded; ///< Whether cannon has exploded.
    
    b2Body* createCannonMount(int x, int y, int nIndex); ///< Create a cannon mount in Physics World.
    b2Body* createCannonBarrel(int x, int y, int nIndex);  ///< Create a cannon barrel in Physics World.
    b2Body* createWheel(int x, int y, int nIndex);  ///< Create a cannon wheel in Physics World.
    
    void impulse(b2Body* body, b2Vec2& impulse, b2Vec2& offset); ///< Apply an impulse in Physics World.
    void resetCollisionGroupIndex(b2Body* b); ///< Make cannon parts collide-able in Physics World
    
    float m_FireTimer;
    float m_FireTime;
    
    bool m_MustExplode;
};

#endif /* defined(__GameDevFramework__Cannon__) */
