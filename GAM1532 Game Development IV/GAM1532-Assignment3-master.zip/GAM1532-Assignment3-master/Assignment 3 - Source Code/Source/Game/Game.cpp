//
//  Student:        Quentin Bellay
//  Creation Date:  Once upon a time...
//  Course Number:  GAM1532
//  Professor:      Bradley Flood
//  Purpose:        Main Game class
//  Modified:
//

#include "Game.h"
#include "GameObject.h"
#include "DeviceUtils.h"
#include "MathUtils.h"
#include "PhysicsEditorWrapper.h"
#include <vector>
#include "Cannon.h"


Game* Game::m_Instance = NULL;

Game* Game::getInstance()
{
    //Singleton design pattern ensures that there is only 1 instance of the game
    if(m_Instance == NULL)
    {
        m_Instance = new Game();
    }
    return m_Instance;
}

Game::Game() :
m_LoadStep(0),
m_World(NULL),
m_DebugDraw(NULL),
m_Cannon(NULL),
m_State(Idle)
{
    
}

Game::~Game()
{
    //Delete the debug draw instance
    if(m_DebugDraw != NULL)
    {
        delete m_DebugDraw;
        m_DebugDraw = NULL;
    }
    
    //Delete the Box2D world instance, MAKES SURE this is the last object deleted
    if(m_World != NULL)
    {
        //Destroy all the bodies in the world
        b2Body* body = m_World->GetBodyList();
        while(body != NULL)
        {
            //Destroy the body and get the next body (if there is one)
            b2Body* nextBody = body->GetNext();
            destroyPhysicsBody(body);
            body = nextBody;
        }
        
        //Finally delete the world
        delete m_World;
        m_World = NULL;
    }
}

void Game::load()
{
    switch(m_LoadStep)
    {
        case GameLoadStepInitial:
        {
            //TODO: Load game content required for future load steps here
        }
            break;
            
        case GameLoadStepWorld:
        {
            //Define the gravity vector.
            b2Vec2 gravity;
            gravity.Set(GAME_GRAVITY_X, GAME_GRAVITY_Y);
            
            //Construct the Box2d world object, which will
            //holds and simulates the rigid bodies
            m_World = new b2World(gravity);
            m_World->SetContinuousPhysics(GAME_PHYSICS_CONTINUOUS_SIMULATION);
            
#if DEBUG
            //Create the debug draw for Box2d
            m_DebugDraw = new b2DebugDraw(b2Helper::box2dRatio());
            
            //Set the debug draw flags
            uint32 flags = 0;
            flags += b2Draw::e_shapeBit;
            flags += b2Draw::e_jointBit;
            flags += b2Draw::e_centerOfMassBit;
            m_DebugDraw->SetFlags(flags);
            
            //Set the Box2d world debug draw instance
            m_World->SetDebugDraw(m_DebugDraw);
#endif
            
            //Define the ground body.
            b2BodyDef groundBodyDef;
            groundBodyDef.position.Set(0.0f, 0.0f); // bottom-left corner
            
            //Call the body factory which allocates memory for the ground body
            //from a pool and creates the ground box shape (also from a pool).
            //The body is also added to the world.
            b2Body* groundBody = createPhysicsBody(&groundBodyDef);
            
            //Convert the screen width and height to meters
            float width = b2Helper::screenSpaceToBox2dSpace(DeviceUtils::getScreenResolutionWidth());
            float height = b2Helper::screenSpaceToBox2dSpace(DeviceUtils::getScreenResolutionHeight());
            
            //Define the ground box shape.
            b2EdgeShape groundShape;
            groundShape.Set(b2Vec2(0.0f, 0.0f), b2Vec2(width, 0.0f));
            groundBody->CreateFixture(&groundShape, 0.0f);
            
            groundShape.Set(b2Vec2(0.0f, 0.0f), b2Vec2(0.0f, height));
            groundBody->CreateFixture(&groundShape, 0.0f);
            
            groundShape.Set(b2Vec2(width, 0.0f), b2Vec2(width, height));
            groundBody->CreateFixture(&groundShape, 0.0f);
        }
            break;
            
            
            //TODO: Load additional game content here, add additional steps in the GameConstants.h enum
            
        case GameLoadStepCannon:
        {
            m_Cannon = new Cannon();
            
            m_Cannon -> create();
        }
            break;
            
        case GameLoadStepTower:
        {
            float size = Game::getInstance() -> getScale() / 2 * b2Helper::screenSpaceToBox2dSpace(BOX_SIZE);
            
            b2Vec2 initialPosition = b2Vec2(b2Helper::screenSpaceToBox2dSpace(getScreenWidth() * 0.8f), size);
            
            for (int i = 0; i < 10; i++)
            {
                createBox(initialPosition + i * b2Vec2(0, 2 * size), b2Vec2(size,size), b2_dynamicBody);
            }
        }
            break;
            
        GameLoadStepFinal:
        {
            reset();
        }
            break;
            
        default:
            break;
    }
    
    //Increment the load step
    m_LoadStep++;
}

void Game::update(double aDelta)
{
    //While the game is loading, the load method will be called once per update
    if(isLoading() == true)
    {
        load();
        return;
    }
    
    //Step the Box2D world this update cycle
    if(m_World != NULL)
    {
        m_World->Step(aDelta, GAME_PHYSICS_VELOCITY_ITERATIONS, GAME_PHYSICS_POSITION_ITERATIONS);
    }
    
    if(m_Cannon != NULL)
    {
        m_Cannon -> update(aDelta);
    }
}

void Game::paint()
{
    //While the game is loading, the load method will be called once per update
    if(isLoading() == true)
    {
        paintLoading();
        return;
    }
    
#if DEBUG
    if(m_World != NULL)
    {
        m_World->DrawDebugData();
    }
#endif
}

void Game::paintLoading()
{
    //Cache the screen width and height
    float screenWidth = getScreenWidth();
    float screenHeight = getScreenHeight();
    
    //Draw a black background, you could replace this
    //in the future with a full screen background texture
    OpenGLRenderer::getInstance()->setForegroundColor(OpenGLColorBlack());
    OpenGLRenderer::getInstance()->drawRectangle(0.0f, 0.0f, screenWidth, screenHeight);
    
    //Calculate the bar width and height, don't actually hard-code these
    float barWidth = 200.0f * getScale();
    float barHeight = 40.0f * getScale();
    float barX = (screenWidth - barWidth) / 2.0f;
    float barY = (screenHeight - barHeight) / 2.0f;
    
    float percentageLoaded = (float)m_LoadStep / (float)(GameLoadStepCount - 1);
    float loadedWidth = barWidth * percentageLoaded;
    OpenGLRenderer::getInstance()->setForegroundColor(OpenGLColorYellow());
    OpenGLRenderer::getInstance()->drawRectangle(barX, barY, loadedWidth, barHeight);
    
    OpenGLRenderer::getInstance()->setForegroundColor(OpenGLColorWhite());
    OpenGLRenderer::getInstance()->drawRectangle(barX, barY, barWidth, barHeight, false);
}

void Game::touchEvent(TouchEvent touchEvent, float locationX, float locationY, float previousX, float previousY)
{
    if(m_Cannon != NULL)
    {
        switch(touchEvent)
        {
            case TouchEventBegan:
            {
                if(m_State == Idle)
                {
                    if(m_Cannon -> isOnBarrel(b2Helper::screenSpaceToBox2dSpace(locationX, locationY)))
                    {
                        m_State = Rotating_cannon;
                    }
                    else
                    {
                        m_State = Moving_cannon;
                        
                        int deltaX = b2Helper::screenSpaceToBox2dSpace(locationX) - m_Cannon -> getX();
                        
                        if(deltaX != 0)
                        {
                            m_Cannon -> startMoving(-CANNON_SPEED * MathUtils::sign(deltaX));
                        }
                    }
                }
            }
                break;
                
            case TouchEventMoved:
            {
                switch(m_State)
                {
                    case Moving_cannon:
                    {
                        int deltaX = b2Helper::screenSpaceToBox2dSpace(locationX) - m_Cannon -> getX();
                        
                        if(deltaX != 0)
                        {
                            m_Cannon -> startMoving(-CANNON_SPEED * MathUtils::sign(deltaX));
                        }
                    }
                        break;
                        
                    case Rotating_cannon:
                    {
                        int deltaX = locationX - b2Helper::box2dSpaceToScreenSpace(m_Cannon -> getBarrelCenter().x);
                        int deltaY = locationY - b2Helper::box2dSpaceToScreenSpace(m_Cannon -> getBarrelCenter().y);
                        
                        if(deltaX < 0.0f)
                        {
                            deltaX *= -1;
                            deltaY *= -1;
                        }
                        
                        float angle = atan2f(deltaY, deltaX);
                        
                        m_Cannon -> barrelUp(angle);
                    }
                        break;
                        
                    default:
                        // Do nothing
                        break;
                }
            }
                break;
                
            case TouchEventEnded:
            {
                switch (m_State)
                {
                    case Moving_cannon:
                        m_Cannon -> stopMoving();
                        m_State = Idle;
                        break;
                        
                    case Rotating_cannon:
                        m_State = Idle;
                        break;
                        
                    default:
                        break;
                }
            }
                break;
                
            case TouchEventCancelled:
            {
                switch (m_State)
                {
                    case Moving_cannon:
                        m_Cannon -> stopMoving();
                        m_State = Idle;
                        break;
                        
                    case Rotating_cannon:
                        m_State = Idle;
                        break;
                        
                    default:
                        break;
                }
            }
                break;
        }
    }
}

void Game::reset()
{
    //TODO: Reset all game content here
    m_State = Idle;
}

void Game::fire()
{
    m_Cannon -> fire();
}

int Game::getNumberOfBallsFired()
{
    return m_Cannon -> ballsFired();
}

float Game::getTemperature()
{
    return m_Cannon -> getTemperature();
}

bool Game::isGameOver()
{
    return m_Cannon -> isDead();
}

b2Body* Game::createPhysicsBody(const b2BodyDef* bodyDef, const b2FixtureDef* fixtureDef)
{
    if(bodyDef != NULL)
    {
        b2Body* body = m_World->CreateBody(bodyDef);
        
        if(fixtureDef != NULL)
        {
            body->CreateFixture(fixtureDef);
        }
        
        return body;
    }
    return NULL;
}

void Game::destroyPhysicsBody(b2Body* body)
{
    //Safety check that aBody isn't NULL
    if(body != NULL)
    {
        //Destroy all the fixtures attached to the body
        b2Fixture* fixture = body->GetFixtureList();
        while(fixture != NULL)
        {
            b2Fixture* nextFixture = fixture->GetNext();
            body->DestroyFixture(fixture);
            fixture = nextFixture;
        }
        
        //Destroy the body
        m_World->DestroyBody(body);
    }
}

b2Joint* Game::createJoint(const b2JointDef* jointDef)
{
    if(jointDef != NULL)
    {
        return m_World->CreateJoint(jointDef);
    }
    return NULL;
}

void Game::destroyJoint(b2Joint* joint)
{
    if(joint != NULL)
    {
        m_World->DestroyJoint(joint);
    }
}

b2Body* Game::createBox(b2Vec2 position, b2Vec2 size, b2BodyType bodyType)
{
    b2BodyDef bodyDef;
    bodyDef.type = bodyType;
    bodyDef.position = position;
    bodyDef.angle = 0.0f;
    
    b2PolygonShape boxShape;
    boxShape.SetAsBox(size.x, size.y);
    
    b2FixtureDef fixtureDef;
    fixtureDef.shape = &boxShape;
    fixtureDef.density = 1.0f;
    
    b2Body* body = createPhysicsBody(&bodyDef, &fixtureDef);
    return body;
}

b2Body* Game::createCircle(b2Vec2 position, float radius, b2BodyType bodyType)
{
    b2BodyDef bodyDef;
    bodyDef.type = bodyType;
    bodyDef.position = position;
    bodyDef.angle = 0.0f;
    
    b2CircleShape circleShape;
    circleShape.m_radius = radius;
    
    b2FixtureDef fixtureDef;
    fixtureDef.shape = &circleShape;
    fixtureDef.density = 1.0f;
    
    b2Body* body = createPhysicsBody(&bodyDef, &fixtureDef);
    return body;
}

void Game::setContactListener(b2ContactListener* listener)
{
    m_World -> SetContactListener(listener);
}

float Game::getScreenWidth()
{
    return DeviceUtils::getScreenResolutionWidth();
}

float Game::getScreenHeight()
{
    return DeviceUtils::getScreenResolutionHeight();
}

float Game::getScale()
{
    return DeviceUtils::getContentScaleFactor();
}

bool Game::isLoading()
{
    return m_LoadStep < GameLoadStepCount;
}
