//
//  Student:        Quentin Bellay
//  Creation Date:  March 10th 2014
//  Course Number:  GAM1532
//  Professor:      Bradley Flood
//  Purpose:        Cannon class
//  Modified:
//

#include "Cannon.h"
#include "Game.h"
#include "MathUtils.h"

Cannon::Cannon() :
m_CannonWheelJoint1(NULL),
m_CannonWheelJoint2(NULL),
m_CannonBarrelJoint(NULL),
m_CannonTemp(0.0f),
m_CannonMaxTemp(100.0f),
m_CannonBallsFired(0.0f),
m_CannonExploded(false),
m_CannonBarrel(NULL),
m_CannonBase(NULL),
m_Wheel1(NULL),
m_Wheel2(NULL),
m_FireTimer(0.0f),
m_FireTime(2.5f),
m_MustExplode(false)
{
    reset();
}

Cannon::~Cannon()
{
    
}

void Cannon::create()
{
    const int nIndex = CANNON_GROUP_INDEX; //Collision index. Negative means don't collide.
    const int nX = Game::getInstance() -> getScreenWidth() * 0.25f;
    const int nY = Game::getInstance() -> getScreenHeight() * 0.25f;
    
    //Create cannon parts in Physics World
    
    //base, barrel, and wheels
    m_CannonBase = createCannonMount(nX, nY + 84, nIndex);
    m_CannonBarrel = createCannonBarrel(nX, nY + 72, nIndex);
    m_Wheel1 = createWheel(nX - 30, nY + 16, nIndex);
    m_Wheel2 = createWheel(nX + 30, nY + 16, nIndex);
    
    //wheel joint definition
    b2WheelJointDef wd;
    b2Vec2 axis(0.0f, 1.0f); //vertical axis for wheel suspension
    wd.Initialize(m_CannonBase, m_Wheel1, m_Wheel1->GetPosition(), axis);
    wd.dampingRatio = 0.9f;
    wd.motorSpeed = 0.0f;
    wd.maxMotorTorque = 1000.0f;
    wd.enableMotor = true;
    
    //create wheel joint for wheel 1
    m_CannonWheelJoint1 = (b2WheelJoint*)Game::getInstance() -> createJoint(&wd);
    
    //create wheel joint for wheel 2
    wd.Initialize(m_CannonBase, m_Wheel2, m_Wheel2->GetPosition(), axis);
    m_CannonWheelJoint2 = (b2WheelJoint*)Game::getInstance() -> createJoint(&wd);
    
    //revolute joint definition
    b2RevoluteJointDef jointDef;
    jointDef.Initialize(m_CannonBarrel, m_CannonBase, m_CannonBarrel->GetWorldCenter());
    jointDef.maxMotorTorque = 1000.0f;
    jointDef.motorSpeed = 0.0f;
    jointDef.enableMotor = true;
    jointDef.lowerAngle = -b2_pi/4.0f;
    jointDef.upperAngle = 0.0f;
    jointDef.enableLimit = true;
    
    //create revolute joint
    m_CannonBarrelJoint = (b2RevoluteJoint*)Game::getInstance() -> createJoint(&jointDef);
    
    Game::getInstance() -> setContactListener(this);
}

void Cannon::explode()
{
    //break joints
    if(m_CannonWheelJoint1){
        Game::getInstance() -> destroyJoint(m_CannonWheelJoint1);
        m_CannonWheelJoint1 = NULL;
    }
    if(m_CannonWheelJoint2){
        Game::getInstance() -> destroyJoint(m_CannonWheelJoint2);
        m_CannonWheelJoint2 = NULL;
    }
    if(m_CannonBarrelJoint){
        Game::getInstance() -> destroyJoint(m_CannonBarrelJoint);
        m_CannonBarrelJoint = NULL;
    }
    
    //apply impulses to cannon parts so that they fly apart
    b2Vec2 impulseVector = b2Vec2(0,50);
    b2Vec2 offset = b2Vec2(80, 80);
    impulse(m_CannonBase, impulseVector, offset);
    
    impulseVector = b2Vec2(0,100);
    offset = b2Vec2(40, 40);
    impulse(m_CannonBarrel, impulseVector, offset);
    
    impulseVector = b2Vec2(-50,200);
    offset = b2Vec2(1, 1);
    impulse(m_Wheel1, impulseVector, offset);
    
    impulseVector = b2Vec2(50,220);
    offset = b2Vec2(-1, -1);
    impulse(m_Wheel2, impulseVector, offset);
    
    //allow cannon components to collide with each other
    resetCollisionGroupIndex(m_CannonBase);
    resetCollisionGroupIndex(m_CannonBarrel);
    resetCollisionGroupIndex(m_Wheel1);
    resetCollisionGroupIndex(m_Wheel2);
    
    m_CannonExploded = true;
}

void Cannon::update(double deltaTime)
{
    if(m_FireTimer >= 0.0f)
    {
        m_FireTimer -= (float)deltaTime;
    }
    
    coolDown(deltaTime);
    
    if(m_MustExplode)
    {
        explode();
    }
}

bool Cannon::fire()
{
    if(!m_CannonExploded && m_FireTimer <= 0.0f)
    {
        m_FireTimer = m_FireTime;
        
        m_CannonTemp += 50.0f;
        
        //shape
        b2CircleShape ballshape;
        ballshape.m_radius = Game::getInstance() -> getScale() / 2 * b2Helper::screenSpaceToBox2dSpace(CANNON_BALL_RADIUS);
        
        //fixture
        b2FixtureDef ballfd;
        ballfd.shape = &ballshape;
        ballfd.density = 0.5f;
        ballfd.restitution = 0.3f;
        ballfd.filter.groupIndex = CANNON_BALL_GROUP_INDEX;
        
        //body definition
        b2BodyDef bd;
        bd.type = b2_dynamicBody;
        b2Vec2 v = m_CannonBarrel->GetPosition() +
        b2Mul(b2Rot(m_CannonBarrel->GetAngle()), b2Vec2(b2Helper::screenSpaceToBox2dSpace(85),0));
        bd.position.Set(v.x, v.y);
        
        if(v.y < 0.0f) //cannon is barrel-to-ground
            explode(); //B O O M. Bad news.
        else
        {
            //Physics World body for cannonball
            b2Body* cannonball = Game::getInstance() -> createPhysicsBody(&bd);
            cannonball->CreateFixture(&ballfd);
            
            //apply impulses to ball and cannon barrel
            stopMoving();
            b2Vec2 impulseVector = b2Mul( //impulse vector
                                    b2Rot(m_CannonBarrel->GetAngle()),
                                    b2Vec2(200, 0)); //200 kluged for fPhysicsRescaleValue=10
            
            b2Vec2 offset = b2Vec2(0,0);
            
            impulse(cannonball, impulseVector, offset); //fire ball
            
            impulseVector *= -0.5f;
            impulse(m_CannonBarrel, impulseVector, offset); //recoil
            m_CannonBallsFired++;
            return true;
        }
    }
    
    return false;
}

void Cannon::barrelUp(float angle)
{
    if(angle > MathUtils::degressToRadians(CANNON_BARREL_MIN_ANGLE) && angle < MathUtils::degressToRadians(CANNON_BARREL_MAX_ANGLE))
    {
        m_CannonBarrel->SetTransform(m_CannonBarrel->GetPosition(), angle);
    }
}

void Cannon::startMoving(float speed)
{
    if(m_CannonWheelJoint1)
    {
        m_CannonWheelJoint1->SetMotorSpeed(speed);
        m_CannonWheelJoint1->EnableMotor(true);
    }
    
    if(m_CannonWheelJoint2)
    {
        m_CannonWheelJoint2->SetMotorSpeed(speed);
        m_CannonWheelJoint2->EnableMotor(true);
    }
}

float Cannon::getTemperature()
{
    return m_CannonTemp;
}

int Cannon::ballsFired()
{
    return m_CannonBallsFired;
}

bool Cannon::isDead()
{
    return m_CannonExploded;
}

void Cannon::coolDown(double deltaTime)
{
    if(m_CannonTemp > m_CannonMaxTemp) //recompute max temp
        m_CannonMaxTemp = m_CannonTemp;
    
    if(m_CannonTemp > 0) //cool off
        m_CannonTemp -= m_CannonTemp/32.0f * deltaTime;
    
    if(m_CannonTemp >= CANNON_EXPLODE_TEMP && !m_CannonExploded) //too hot
        explode();
}

void Cannon::reset()
{
    m_CannonTemp = m_CannonMaxTemp = 0.0f;
    m_CannonBallsFired = 0;
    m_CannonExploded = false;
    m_MustExplode = false;
}

float Cannon::getX()
{
    return m_CannonBase -> GetPosition().x;
}

bool Cannon::isOnBarrel(b2Vec2 position)
{
    bool result = false;
    
    b2Fixture* fixture = m_CannonBarrel -> GetFixtureList();
    
    while(fixture != NULL && !result)
    {
        result = fixture -> TestPoint(position);
        
        fixture = fixture -> GetNext();
    }
    
    return result;
}


b2Vec2 Cannon::getBarrelCenter()
{
    return m_CannonBarrel -> GetPosition();
}

void Cannon::BeginContact(b2Contact* contact)
{
    
}

void Cannon::PostSolve(b2Contact* contact, const b2ContactImpulse* impulse)
{
    if((contact -> GetFixtureA() -> GetFilterData().groupIndex == CANNON_GROUP_INDEX && contact -> GetFixtureB() -> GetFilterData().groupIndex == CANNON_BALL_GROUP_INDEX) || (contact -> GetFixtureB() -> GetFilterData().groupIndex == CANNON_GROUP_INDEX && contact -> GetFixtureA() -> GetFilterData().groupIndex == CANNON_BALL_GROUP_INDEX))
    {
        if(impulse ->normalImpulses[0] > CANNON_EXPLOSION_IMPULSE )
        {
            m_MustExplode = true;
        }
    }
}

b2Body* Cannon::createCannonMount(int x, int y, int nIndex)
{
    //shape
    b2PolygonShape shape;
    b2Vec2 vertices[3];
    const float s = b2Helper::screenSpaceToBox2dSpace(CANNON_MOUNT_SIZE) * Game::getInstance() -> getScale() / 2;
    vertices[0].Set(-s, -s);
    vertices[1].Set(s, -s);
    vertices[2].Set(0.0f, 0.0f);
    shape.Set(vertices, 3);
    
    //fixture
    b2FixtureDef fd;
	fd.shape = &shape;
	fd.density = 1.0f;
	fd.restitution = 0.4f;
    fd.filter.groupIndex = nIndex;
    
    //body definition
    b2BodyDef bd;
	bd.type = b2_dynamicBody;
    bd.position.Set(b2Helper::screenSpaceToBox2dSpace(x) * Game::getInstance() -> getScale() / 2, b2Helper::screenSpaceToBox2dSpace(y) * Game::getInstance() -> getScale() / 2);
    
    //body
    b2Body* body = Game::getInstance() -> createPhysicsBody(&bd, &fd);
    return body;
}

b2Body* Cannon::createCannonBarrel(int x, int y, int nIndex)
{
    //body
    b2Body* body = Game::getInstance() -> createBox(Game::getInstance() -> getScale() / 2 * b2Helper::screenSpaceToBox2dSpace(x,y), Game::getInstance() -> getScale() / 2 * b2Helper::screenSpaceToBox2dSpace(CANNON_BARREL_WIDTH, CANNON_BARREL_HEIGHT), b2_dynamicBody);
    
    body -> GetFixtureList() -> SetRestitution(0.2f);
    
    b2Filter filter;
    filter.groupIndex = nIndex;
    
    body -> GetFixtureList() -> SetFilterData(filter);
    
    return body;
}

b2Body* Cannon::createWheel(int x, int y, int nIndex)
{
    //body
    b2Body* body = Game::getInstance() -> createCircle( Game::getInstance() -> getScale() / 2 * b2Helper::screenSpaceToBox2dSpace(x, y), Game::getInstance() -> getScale() / 2 * b2Helper::screenSpaceToBox2dSpace(CANNON_WHEEL_RADIUS), b2_dynamicBody);
    
    body -> GetFixtureList() -> SetDensity(0.8f);
    body -> GetFixtureList() -> SetRestitution(0.6f);
    
    b2Filter filter;
    filter.groupIndex = nIndex;
    
    body -> GetFixtureList() -> SetFilterData(filter);
    
    return body;
}

void Cannon::impulse(b2Body* body, b2Vec2& impulse, b2Vec2& offset)
{
    body ->ApplyLinearImpulse(impulse , body->GetPosition() + offset);
}

void Cannon::resetCollisionGroupIndex(b2Body* body)
{
    b2Filter filter = body->GetFixtureList()->GetFilterData();
    filter.groupIndex = 0;
    body->GetFixtureList()->SetFilterData(filter);
}

void Cannon::stopMoving()
{
    if(m_CannonWheelJoint1)
    {
        m_CannonWheelJoint1->SetMotorSpeed(0.0f);
        m_CannonWheelJoint1->EnableMotor(false);
    }
    
    if(m_CannonWheelJoint2)
    {
        m_CannonWheelJoint2->SetMotorSpeed(0.0f);
        m_CannonWheelJoint2->EnableMotor(false);
    }
}