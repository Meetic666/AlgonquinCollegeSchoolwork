//
//  Projectile.cpp
//  GameDevFramework
//
//  Created by Thomas Pryde on 2014-04-14.
//  Copyright (c) 2014 Algonquin College. All rights reserved.
//

#include "Projectile.h"
#include "PhysicsEditorWrapper.h"

Projectile::Projectile(OpenGLTexture* texture, const char* fileName, int x, int y, b2BodyType bodyType) : GameObject()
{
    m_Texture = texture;
    
    b2BodyDef bodyDef;
    bodyDef.type = bodyType;
    bodyDef.position = b2Vec2(x, y);
    bodyDef.userData = this;
    if( strcmp(fileName, "Arrow") == 0)
    {
        bodyDef.angularDamping = 100.0f;
    }
    
    m_Body = Game::getInstance() -> createPhysicsBody(&bodyDef);
    
    m_Body -> SetBullet(true);
    
    PhysicsEditorCpp::addFixturesToBody(m_Body, fileName);
    
    float anchorX;
    float anchorY;
    PhysicsEditorCpp::anchorPointForShape(anchorX, anchorY, fileName);
    
    m_Texture -> setAnchorPoint(anchorX, anchorY);
    
    Game::getInstance() -> addGameObject(this);
    
    m_HasHit = false;
    
    m_Timer = GAME_PROJECTILE_LIFE_TIME;
}

Projectile::~Projectile()
{
    
}

const char* Projectile::getType()
{
    return "Projectile";
}

bool Projectile::hasHit()
{
    return m_HasHit;
}

void Projectile::setHit(bool hasHit)
{
    m_HasHit = hasHit;
}

b2Body* Projectile::getBody()
{
    return m_Body;
}

void Projectile::update(double deltaTime)
{
    GameObject::update(deltaTime);
    
    if(m_Body->GetType() == b2_dynamicBody && m_Timer > 0)
    {
        m_Timer -= deltaTime;
        
        if(m_Timer <= 0)
        {
            Game::getInstance() -> removeGameObject(this);
        }
    }
}