//
//  Player.h
//  GameDevFramework
//
//  Created by Thomas Pryde on 2014-04-07.
//  Copyright (c) 2014 Algonquin College. All rights reserved.
//

#ifndef __GameDevFramework__Player__
#define __GameDevFramework__Player__

#include "Constants.h"
#include "Box2D.h"
#include "GameObject.h"

enum Weapons // Easier to make more weapons when using enum.
{
    BOW = 0,
    TOMAHAWK,
    COUNT
};

class Limb;
class Projectile;
class Bow;

class Player : public GameObject
{
public:
    Player(int x, int y);
    ~Player();
    
    const char* getType();
    
    Limb* getLeftArm();
    Limb* getTorso();
    Limb* getRightForeArm();
    Limb* getRightBicep();
    
    void createWeapon();
    void switchWeapons();
    
    void prepShot(float deltaX, float angle);
    void fireProjectile(float angularVelocity);
    
    void reload();
    
    bool testPoint(float x, float y);
    
    b2Vec2 getTrajectoryPoint(float step);
    
    void paint();
    void update(float deltaTime);
    
private:
    Projectile* m_Projectile;
    Bow* m_Bow;
    std::vector<Limb*> m_PlayerLimbs;
    Weapons m_ActiveWeapon;
    
    std::vector<b2Vec2> m_TrajectoryPoints;
    
    b2Vec2 m_Impulse;
};

class TrajectoryRayCastCallBack : public b2RayCastCallback
{
public:
    TrajectoryRayCastCallBack() : didHit(false) {}
    
    virtual float32 ReportFixture(	b2Fixture* fixture, const b2Vec2& point, const b2Vec2& normal, float32 fraction)
    {
        didHit = true;
        return fraction;
    }
    
    bool didHit;
};

#endif /* defined(__GameDevFramework__Player__) */
