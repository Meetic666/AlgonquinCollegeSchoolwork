//
//  BloodParticles.h
//  GameDevFramework
//
//  Created by Quentin Bellay on 2014-04-16.
//  Copyright (c) 2014 Algonquin College. All rights reserved.
//

#ifndef __GameDevFramework__BloodParticles__
#define __GameDevFramework__BloodParticles__

#include "GameObject.h"

class GDRandom;
class BloodParticle;

class BloodParticles: public GameObject
{
public:
    BloodParticles(b2Body* body, b2Vec2 offset, int numberOfSplatter);
    ~BloodParticles();
    
    const char* getType();
    
    void update(double deltaTime);
    void paint();
    
private:
    GDRandom* m_Randomizer;
    std::vector<BloodParticle*> m_BloodParticles;
    b2Vec2 m_Offset;
    b2Body* m_Body;
    
    int m_NumberOfSplatterLeft;
    
    float m_SplatterTimer;
    float m_SplatterTime;
    
    float m_LifeTime;
    float m_LifeTimer;
};

#endif /* defined(__GameDevFramework__BloodParticles__) */
