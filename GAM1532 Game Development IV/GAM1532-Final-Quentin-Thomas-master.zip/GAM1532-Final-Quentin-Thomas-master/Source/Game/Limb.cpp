//
//  Limb.cpp
//  GameDevFramework
//
//  Created by Quentin Bellay on 2014-04-07.
//  Copyright (c) 2014 Algonquin College. All rights reserved.
//

#include "Limb.h"
#include "PhysicsEditorWrapper.h"
#include "BloodParticles.h"

Limb::Limb(OpenGLTexture* texture, const char* fileName, float x, float y, b2BodyType bodyType) : GameObject(),
m_ParentJoint(NULL),
m_DestroyJoint(false),
m_IsPilgrim(true)
{
    //std::string fullFileName = std::string("Images/") + std::string(fileName);
    
    m_Texture = texture;
    
    b2BodyDef bodyDef;
    bodyDef.type = bodyType;
    bodyDef.position = b2Vec2(x, y);
    bodyDef.userData = this;
    
    m_Body = Game::getInstance() -> createPhysicsBody(&bodyDef);
    
    PhysicsEditorCpp::addFixturesToBody(m_Body, fileName);
    
    float anchorX;
    float anchorY;
    PhysicsEditorCpp::anchorPointForShape(anchorX, anchorY, fileName);
    
    m_Texture -> setAnchorPoint(anchorX, anchorY);
    
    Game::getInstance() -> addGameObject(this);
}

Limb::~Limb()
{
    
}

void Limb::attachTo(Limb* parentLimb, b2Vec2 parentOffset, b2Vec2 limbOffset)
{
    b2RevoluteJointDef jointDef;
    jointDef.bodyA = m_Body;
    jointDef.bodyB = parentLimb -> getBody();
    
    jointDef.localAnchorA = limbOffset;
    jointDef.localAnchorB = parentOffset;
    
    jointDef.enableLimit = true;
    jointDef.lowerAngle = -45.0f * 3.14f / 180.0f;
    jointDef.upperAngle = 45.0f * 3.14f / 180.0f;
    
    m_ParentJoint = (b2RevoluteJoint*) Game::getInstance() -> createJoint(&jointDef);
    
    m_ParentLimb = parentLimb;
}

void Limb::tieTo(b2Body* parentBody)
{
    b2RevoluteJointDef jointDef;
    jointDef.bodyA = m_Body;
    jointDef.bodyB =parentBody;
    
    Game::getInstance() -> createJoint(&jointDef);
}

void Limb::detach()
{
    m_DestroyJoint = true;
    
    if(m_ParentJoint != NULL)
    {        
        Game::getInstance() -> jointCut();
    }
}

const char* Limb::getType()
{
    return "Limb";
}

void Limb::update(double deltaTime)
{
    GameObject::update(deltaTime);
    
    if(m_DestroyJoint)
    {
        if(m_ParentJoint != NULL)
        {
            BloodParticles* newParticles = NULL;
            
            if(m_ParentJoint -> GetBodyA() != NULL)
            {
                newParticles = new BloodParticles(m_ParentJoint -> GetBodyA(), m_ParentJoint -> GetAnchorA() - m_ParentJoint -> GetBodyA() -> GetWorldCenter(), GAME_BLOOD_AMOUNT);
                Game::getInstance() -> addBloodParticles(newParticles);
            }
            
            if(m_ParentJoint -> GetBodyB() != NULL)
            {
                newParticles = new BloodParticles(m_ParentJoint -> GetBodyB(), m_ParentJoint -> GetAnchorB() - m_ParentJoint -> GetBodyB() -> GetWorldCenter(), GAME_BLOOD_AMOUNT);
                Game::getInstance() -> addBloodParticles(newParticles);
            }
            
            Game::getInstance() -> destroyJoint(m_ParentJoint);
        }
        else
        {
            BloodParticles* newParticles = new BloodParticles(m_Body, b2Vec2(0,0), GAME_BLOOD_AMOUNT);
            Game::getInstance() -> addBloodParticles(newParticles);
        }
        
        m_ParentJoint = NULL;        
        m_DestroyJoint = false;
    }
}

float Limb::getWidth()
{
    return b2Helper::screenSpaceToBox2dSpace(m_Texture -> getSourceWidth());
}

float Limb::getHeight()
{
    return b2Helper::screenSpaceToBox2dSpace(m_Texture -> getSourceHeight());
}

b2RevoluteJoint* Limb::getParentJoint()
{
    return m_ParentJoint;
}

bool Limb::isPilgrim()
{
    return m_IsPilgrim;
}

void Limb::setIsPilgrim(bool isPilgrim)
{
    m_IsPilgrim = isPilgrim;
}