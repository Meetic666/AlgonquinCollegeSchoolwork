//
//  Game.cpp
//  GameDevFramework
//
//  Created by Bradley Flood on 12-08-30.
//  Copyright (c) 2012 Algonquin College. All rights reserved.
//

#include "Game.h"
#include "GameObject.h"
#include "DeviceUtils.h"
#include "MathUtils.h"
#include "PhysicsEditorWrapper.h"
#include "Body.h"
#include "Limb.h"
#include "Rope.h"
#include "Projectile.h"
#include "Player.h"
#include "BloodParticles.h"
#include "Log.h"
#include "GDRandom.h"
#include "Bow.h"
#include "Pickups.h"


Game* Game::m_Instance = NULL;

Game* Game::getInstance()
{
    //Singleton design pattern ensures that there is only 1 instance of the game
    if(m_Instance == NULL)
    {
        m_Instance = new Game();
    }
    return m_Instance;
}

void Game::cleanUpInstance()
{
    delete m_Instance;
    m_Instance = NULL;
}

Game::Game() :
m_LoadStep(0),
m_World(NULL),
m_DebugDraw(NULL),
m_Body(NULL),
m_Background(NULL),
m_Randomizer(NULL),
m_BodyExploded(false),
m_Log(NULL),
m_CreateJoint(false),
m_ReloadTimer(GAME_RELOAD_DELAY),
m_PickupTimer(GAME_PICKUP_DELAY),
m_HasFired(true),
m_JointsToCut(0),
m_WinScreenTexture(NULL),
m_GameWon(false),
m_PreppingShot(false),
m_Reset(false),
m_Bush(NULL),
m_TargettingTimer(0.0f),
m_TargettingTime(10.0f)
{
    
}

Game::~Game()
{
    //Delete the game objects
    for(int i = 0; i < m_GameObjects.size(); i++)
    {
        delete m_GameObjects.at(i);
        m_GameObjects.at(i) = NULL;
    }
    m_GameObjects.clear();
    
    //Delete the debug draw instance
    if(m_DebugDraw != NULL)
    {
        delete m_DebugDraw;
        m_DebugDraw = NULL;
    }
    
    delete m_Body;
    m_Body = NULL;
    
    delete m_Player;
    m_Player = NULL;
    
    m_Log = NULL;
    
    delete m_Background;
    m_Background = NULL;
    
    delete m_WinScreenTexture;
    m_WinScreenTexture = NULL;
    
    delete m_Bush;
    m_Bush = NULL;
    
    //Delete the Box2D world instance, MAKES SURE this is the last object deleted
    if(m_World != NULL)
    {
        //Destroy all the bodies in the world
        b2Body* body = m_World->GetBodyList();
        while(body != NULL)
        {
            //Destroy the body and get the next body (if there is one)
            b2Body* nextBody = body->GetNext();
            destroyPhysicsBody(body);
            body = nextBody;
        }
        
        //Finally delete the world
        delete m_World;
        m_World = NULL;
    }
}

void Game::load()
{
    switch(m_LoadStep)
    {
        case GameLoadStepInitial:
        {
            //TODO: Load game content required for future load steps here
        }
            break;
            
        case GameLoadStepWorld:
        {
            //Define the gravity vector.
            b2Vec2 gravity;
            gravity.Set(GAME_GRAVITY_X, GAME_GRAVITY_Y);
            
            //Construct the Box2d world object, which will
            //holds and simulates the rigid bodies
            m_World = new b2World(gravity);
            m_World->SetContinuousPhysics(GAME_PHYSICS_CONTINUOUS_SIMULATION);
            m_World->SetContactListener(this);
            
#if DEBUG
            //Create the debug draw for Box2d
            m_DebugDraw = new b2DebugDraw(b2Helper::box2dRatio());
            
            //Set the debug draw flags
            uint32 flags = 0;
            flags += b2Draw::e_shapeBit;
            flags += b2Draw::e_jointBit;
            flags += b2Draw::e_centerOfMassBit;
            m_DebugDraw->SetFlags(flags);
            
            //Set the Box2d world debug draw instance
            m_World->SetDebugDraw(m_DebugDraw);
#endif
            
            //Define the ground body.
            b2BodyDef groundBodyDef;
            groundBodyDef.position.Set(0.0f, 0.0f); // bottom-left corner
            
            //Call the body factory which allocates memory for the ground body
            //from a pool and creates the ground box shape (also from a pool).
            //The body is also added to the world.
            b2Body* groundBody = createPhysicsBody(&groundBodyDef);
            
            //Convert the screen width and height to meters
            float width = b2Helper::screenSpaceToBox2dSpace(DeviceUtils::getScreenResolutionWidth());
            float height = b2Helper::screenSpaceToBox2dSpace(DeviceUtils::getScreenResolutionHeight());
            
            //Define the ground box shape.
            b2EdgeShape groundShape;
            groundShape.Set(b2Vec2(0.0f, 0.0f), b2Vec2(width, 0.0f));
            groundBody->CreateFixture(&groundShape, 0.0f);
            
            //Define the wall body.
            b2BodyDef wallBodyDef;
            wallBodyDef.position.Set(0.0f, 0.0f); // bottom-left corner
            
            //Call the body factory which allocates memory for the ground body
            //from a pool and creates the ground box shape (also from a pool).
            //The body is also added to the world.
            b2Body* wallBody = createPhysicsBody(&wallBodyDef);
            
            //Define the ground box shape.
            b2EdgeShape wallShape;
            wallShape.Set(b2Vec2(0.0f, 0.0f), b2Vec2(0.0f, height));
            wallBody->CreateFixture(&wallShape, 0.0f);
            
            //Define the wall body.
            b2BodyDef wallBodyDef2;
            wallBodyDef2.position.Set(width, 0.0f); // bottom-right corner
            
            //Call the body factory which allocates memory for the ground body
            //from a pool and creates the ground box shape (also from a pool).
            //The body is also added to the world.
            b2Body* wallBody2 = createPhysicsBody(&wallBodyDef2);
            
            //Define the ground box shape.
            b2EdgeShape wallShape2;
            wallShape2.Set(b2Vec2(0.0f, 0.0f), b2Vec2(0.0f, height));
            wallBody2->CreateFixture(&wallShape2, 0.0f);
            
            
            //Define the wall body.
            b2BodyDef ceilingBodyDef;
            ceilingBodyDef.position.Set(0.0f, height); // bottom-right corner
            
            //Call the body factory which allocates memory for the ground body
            //from a pool and creates the ground box shape (also from a pool).
            //The body is also added to the world.
            b2Body* ceilingBody = createPhysicsBody(&ceilingBodyDef);
            
            //Define the ground box shape.
            b2EdgeShape ceilingShape;
            ceilingShape.Set(b2Vec2(0.0f, 0.0f), b2Vec2(width, 0.0f));
            ceilingBody->CreateFixture(&ceilingShape, 0.0f);
            
            
            //Load the box2d shape definitions
            PhysicsEditorCpp::addShapesFromPlist("shapedefs.plist");
            
            m_Background = new OpenGLTexture("Images/Background");
            
            m_WinScreenTexture = new OpenGLTexture("Images/WinScreen");
            
            m_Bush = new OpenGLTexture("Images/Bush");
            
            m_Randomizer = new GDRandom();
        }
            break;
            
            
        case GameLoadStepPlayer:
        {
            m_Player = new Player(b2Helper::screenSpaceToBox2dSpace(getScreenWidth() * GAME_INDIAN_POSITION_X),
                                  b2Helper::screenSpaceToBox2dSpace(getScreenHeight() * GAME_INDIAN_POSITION_Y));
        }
            break;
            
        case GameLoadStepPilgrim:
        {
            Rope* newRope1 = new Rope(b2Helper::screenSpaceToBox2dSpace(getScreenWidth() * (GAME_BODY_POSITION_X - GAME_ROPE_BODY_OFFSET), getScreenHeight()), b2Helper::screenSpaceToBox2dSpace(5.0f, 10.0f), GAME_ROPE_NUMBER_OF_SEGMENTS);
            
            m_GameObjects.push_back(newRope1);
            
            
            Rope* newRope2 = new Rope(b2Helper::screenSpaceToBox2dSpace(getScreenWidth() * (GAME_BODY_POSITION_X + GAME_ROPE_BODY_OFFSET), getScreenHeight()), b2Helper::screenSpaceToBox2dSpace(5.0f, 10.0f), GAME_ROPE_NUMBER_OF_SEGMENTS);
            
            m_GameObjects.push_back(newRope2);
            
            
            Rope* newRope3 = new Rope(b2Helper::screenSpaceToBox2dSpace(getScreenWidth() * GAME_BODY_POSITION_X, getScreenHeight()), b2Helper::screenSpaceToBox2dSpace(5.0f, 10.0f), GAME_ROPE_NUMBER_OF_SEGMENTS * 1.5f, false);
            
            m_GameObjects.push_back(newRope3);
            
            m_Body = new Body(b2Helper::screenSpaceToBox2dSpace(getScreenWidth() * GAME_BODY_POSITION_X),
                              b2Helper::screenSpaceToBox2dSpace(getScreenHeight() * GAME_BODY_POSITION_Y));
            
            newRope1 -> tieLimb(m_Body -> getLeftHand());
            newRope2 -> tieLimb(m_Body -> getRightHand());
            newRope3 -> tieLimb(m_Body -> getHead());
        }
            break;
            
        case GameLoadStepWeapon:
        {
            m_Player->createWeapon();
        }
            break;
            
        case GameLoadStepLog:
        {
            m_Log = new Log(b2Helper::screenSpaceToBox2dSpace(getScreenWidth()) * 0.25f, b2Helper::screenSpaceToBox2dSpace(getScreenHeight()) * 0.85f);
            
            Rope* newRope1 = new Rope(b2Helper::screenSpaceToBox2dSpace(getScreenWidth() * 0.05f, getScreenHeight()), b2Helper::screenSpaceToBox2dSpace(5.0f, 10.0f), GAME_ROPE_NUMBER_OF_SEGMENTS);
            
            newRope1 -> setLogRope(true);
            
            m_GameObjects.push_back(newRope1);
            
            Rope* newRope2 = new Rope(b2Helper::screenSpaceToBox2dSpace(getScreenWidth() * 0.4f, getScreenHeight()), b2Helper::screenSpaceToBox2dSpace(5.0f, 10.0f), GAME_ROPE_NUMBER_OF_SEGMENTS * 1.5f, false);
            
            m_GameObjects.push_back(newRope2);
            
            Rope* newRope3 = new Rope(b2Helper::screenSpaceToBox2dSpace(getScreenWidth() * 0.6f, getScreenHeight()), b2Helper::screenSpaceToBox2dSpace(5.0f, 10.0f), GAME_ROPE_NUMBER_OF_SEGMENTS * 1.5f, false);
            
            m_GameObjects.push_back(newRope3);
            
            newRope1 -> attachToLog(m_Log, -1);
            newRope2 -> attachToLog(m_Log, -1);
            newRope3 -> attachToLog(m_Log, 1);
            
            m_GameObjects.push_back(m_Log);
        }
            break;
            
            
        case GameLoadStepFinal:
        {
            reset();
        }
            break;
            
        default:
            break;
    }
    
    //Increment the load step
    m_LoadStep++;
}

void Game::update(double aDelta)
{
    //While the game is loading, the load method will be called once per update
    if(isLoading() == true)
    {
        load();
        return;
    }
    
    //Step the Box2D world this update cycle
    if(m_World != NULL)
    {
        m_World->Step(aDelta, GAME_PHYSICS_VELOCITY_ITERATIONS, GAME_PHYSICS_POSITION_ITERATIONS);
    }
    
    //Update the game's game objects
    for(int i = 0; i < m_GameObjects.size(); i++)
    {
        if(m_GameObjects.at(i) != NULL)
        {
            m_GameObjects.at(i)->update(aDelta);
        }
    }
    
    if(m_Player != NULL)
    {
        m_Player -> update(aDelta);
    }
    
    if(m_CreateJoint)
    {
        m_CreateJoint = false;
        
        createJoint(&m_JointToCreate);
    }
    
    if(!m_HasFired)
    {
        m_ReloadTimer -= aDelta;
        if(m_ReloadTimer <= 0)
        {
            m_Player->reload();
            m_ReloadTimer = GAME_RELOAD_DELAY;
            m_HasFired = true;
        }
    }
    if(!m_GameWon)
    {
        m_PickupTimer -= aDelta;
        if(m_PickupTimer <= 0)
        {
            Pickups* pickups = new Pickups();
            pickups->spawnPickup();
            m_PickupTimer = GAME_PICKUP_DELAY;
        }
    
        if(m_TargettingTimer > 0.0f)
        {
            m_TargettingTimer -= aDelta;
        }
    }
}

void Game::paint()
{
    //While the game is loading, the load method will be called once per update
    if(isLoading() == true)
    {
        paintLoading();
        return;
    }
    
    if(m_Background != NULL)
    {
        OpenGLRenderer::getInstance() -> drawTexture(m_Background, 0.0f, 0.0f);
    }
    
    //Paint the game's game objects
    for(int i = 0; i < m_GameObjects.size(); i++)
    {
        if(m_GameObjects.at(i) != NULL)
        {
            m_GameObjects.at(i)->paint();
        }
    }
    
    if(m_Player != NULL)
    {
        m_Player -> paint();
    }
    
    if(m_Bush != NULL)
    {
        OpenGLRenderer::getInstance() -> drawTexture(m_Bush, getScreenWidth() / 2.0f, 0.0f);
    }
    
#if DEBUG && BOX2D_DRAW_DEBUG_DATA
    if(m_World != NULL)
    {
        m_World->DrawDebugData();
    }
#endif
    
    if(m_GameWon && m_WinScreenTexture != NULL)
    {
        OpenGLRenderer::getInstance() -> drawTexture(m_WinScreenTexture, 0.0f, 0.0f);
    }
}

void Game::paintLoading()
{
    //Cache the screen width and height
    float screenWidth = getScreenWidth();
    float screenHeight = getScreenHeight();
    
    //Draw a black background, you could replace this
    //in the future with a full screen background texture
    OpenGLRenderer::getInstance()->setForegroundColor(OpenGLColorBlack());
    OpenGLRenderer::getInstance()->drawRectangle(0.0f, 0.0f, screenWidth, screenHeight);
    
    //Calculate the bar width and height, don't actually hard-code these
    float barWidth = 200.0f * getScale();
    float barHeight = 40.0f * getScale();
    float barX = (screenWidth - barWidth) / 2.0f;
    float barY = (screenHeight - barHeight) / 2.0f;
    
    float percentageLoaded = (float)m_LoadStep / (float)(GameLoadStepCount - 1);
    float loadedWidth = barWidth * percentageLoaded;
    OpenGLRenderer::getInstance()->setForegroundColor(OpenGLColorYellow());
    OpenGLRenderer::getInstance()->drawRectangle(barX, barY, loadedWidth, barHeight);
    
    OpenGLRenderer::getInstance()->setForegroundColor(OpenGLColorWhite());
    OpenGLRenderer::getInstance()->drawRectangle(barX, barY, barWidth, barHeight, false);
}

void Game::touchEvent(TouchEvent touchEvent, float locationX, float locationY, float previousX, float previousY)
{
    if(!m_GameWon)
    {
        float angle;
        
        float deltaX = abs(locationX - m_CenterPoint[0]);
        
        if(touchEvent == TouchEventBegan)
        {
            if(m_Player -> testPoint(locationX, locationY))
            {
                m_CenterPoint[0] = locationX;
                m_CenterPoint[1] = locationY;
                
                m_PreppingShot = true;
            }
        }
        else if(touchEvent == TouchEventMoved)
        {
            if(m_PreppingShot)
            {
                angle = atan2(locationY - m_CenterPoint[1], locationX - m_CenterPoint[0]);
                angle = MathUtils::radiansToDegrees(angle + b2_pi);
                m_Player->prepShot(deltaX, angle);
            }
        }
        else if(touchEvent == TouchEventEnded)
        {
            if(m_PreppingShot)
            {
                if(!m_Player -> testPoint(locationX, locationY))
                {
                    m_Player->fireProjectile(0);
                    m_HasFired = false;
                }
                else
                {
                    m_Player -> switchWeapons();
                }
                
                m_PreppingShot = false;
            }
        }
    }
    else
    {
        if(touchEvent == TouchEventEnded)
        {
            m_Reset = true;
        }
    }
}

void Game::reset()
{
    //Reset the game's game objects
    for(int i = 0; i < m_GameObjects.size(); i++)
    {
        m_GameObjects.at(i)->reset();
    }
}

b2Body* Game::createPhysicsBody(const b2BodyDef* bodyDef, const b2FixtureDef* fixtureDef)
{
    if(bodyDef != NULL)
    {
        b2Body* body = m_World->CreateBody(bodyDef);
        
        if(fixtureDef != NULL)
        {
            body->CreateFixture(fixtureDef);
        }
        
        return body;
    }
    return NULL;
}

void Game::destroyPhysicsBody(b2Body* body)
{
    //Safety check that aBody isn't NULL
    if(body != NULL)
    {
        //Destroy all the fixtures attached to the body
        b2Fixture* fixture = body->GetFixtureList();
        while(fixture != NULL)
        {
            b2Fixture* nextFixture = fixture->GetNext();
            body->DestroyFixture(fixture);
            fixture = nextFixture;
        }
        
        //Destroy the body
        m_World->DestroyBody(body);
    }
}

b2Joint* Game::createJoint(const b2JointDef* jointDef)
{
    if(jointDef != NULL)
    {
        return m_World->CreateJoint(jointDef);
    }
    return NULL;
}

void Game::destroyJoint(b2Joint* joint)
{
    if(joint != NULL)
    {
        m_World->DestroyJoint(joint);
    }
}

b2Body* Game::createBox(b2Vec2 position, b2Vec2 size, b2BodyType bodyType, unsigned short category, unsigned short mask)
{
    b2BodyDef bodyDef;
    bodyDef.type = bodyType;
    bodyDef.position = position;
    bodyDef.angle = 0.0f;
    
    b2PolygonShape boxShape;
    boxShape.SetAsBox(size.x, size.y);
    
    b2FixtureDef fixtureDef;
    fixtureDef.shape = &boxShape;
    fixtureDef.density = 1.0f;
    fixtureDef.filter.categoryBits = category;
    fixtureDef.filter.maskBits = mask;
    
    b2Body* body = createPhysicsBody(&bodyDef, &fixtureDef);
    return body;
}

b2Body* Game::createCircle(b2Vec2 position, float radius, b2BodyType bodyType, unsigned short category, unsigned short mask)
{
    b2BodyDef bodyDef;
    bodyDef.type = bodyType;
    bodyDef.position = position;
    bodyDef.angle = 0.0f;
    
    b2CircleShape circleShape;
    circleShape.m_radius = radius;
    
    b2FixtureDef fixtureDef;
    fixtureDef.shape = &circleShape;
    fixtureDef.density = 1.0f;
    fixtureDef.filter.categoryBits = category;
    fixtureDef.filter.maskBits = mask;
    
    b2Body* body = createPhysicsBody(&bodyDef, &fixtureDef);
    return body;
}

void Game::rayCast(b2RayCastCallback* rayCastCallback, b2Vec2 point1, b2Vec2 point2)
{
    if(m_World != NULL)
    {
        m_World->RayCast(rayCastCallback, point1, point2);
    }
}

b2Vec2 Game::getGravity()
{
    return m_World -> GetGravity();
}

void Game::BeginContact(b2Contact* contact)
{
    b2Fixture* fixtureA = contact -> GetFixtureA();
    b2Fixture* fixtureB = contact -> GetFixtureB();
    
    b2Body* bodyA = fixtureA -> GetBody();
    b2Body* bodyB = fixtureB -> GetBody();
    
    GameObject* objectA = (GameObject*) bodyA -> GetUserData();
    GameObject* objectB = (GameObject*) bodyB -> GetUserData();
    
    if(objectA != NULL && objectB != NULL)
    {
        bool hit = false;
        Projectile* projectile = NULL;
        Limb* limb = NULL;
        
        if(strcmp(objectA -> getType(), "Projectile") == 0 && strcmp(objectB -> getType(), "Limb") == 0)
        {
            projectile = (Projectile*) objectA;
            
            limb = (Limb*) objectB;
            
            if(limb -> isPilgrim())
            {
                hit = true;
            }
        }
        else if(strcmp(objectA -> getType(), "Limb") == 0 && strcmp(objectB -> getType(), "Projectile") == 0)
        {
            projectile = (Projectile*) objectB;
            
            limb = (Limb*) objectA;
            
            if(limb -> isPilgrim())
            {
                hit = true;
            }
            
        }
        else if(!m_BodyExploded && ((strcmp(objectA -> getType(), "Log") == 0 && strcmp(objectB -> getType(), "Limb") == 0)
                                    || (strcmp(objectA -> getType(), "Limb") == 0 && strcmp(objectB -> getType(), "Log") == 0)))
        {
            m_BodyExploded = true;
            
            for(int i = 0; i < m_GameObjects.size(); i++)
            {
                if(m_JointsToCut > 0 && strcmp(m_GameObjects.at(i) -> getType(), "Limb") == 0)
                {
                    b2Vec2 impulse = b2Mul(b2Rot(m_Randomizer -> random() * 3.14f), b2Vec2(0.0f, 500.0f));
                    
                    Limb* limb = (Limb*) m_GameObjects.at(i);
                    
                    limb -> detach();
                    
                    limb -> applyForce(impulse, b2Vec2(0,0));
                }
            }
        }
        else if(strcmp(objectA -> getType(), "Projectile") == 0 && strcmp(objectB -> getType(), "Rope") == 0)
        {
            Rope* rope = (Rope*) objectB;
            
            projectile = (Projectile*) objectA;
            
            if(!projectile -> hasHit())
            {
                projectile -> setHit(true);
                
                if(rope -> isDestructible())
                {
                    rope -> detach();
                    
                    if(rope -> isLogRope())
                    {
                        m_Log -> setBodyType(b2_dynamicBody);
                    }
                }
            }
        }
        else if(strcmp(objectA -> getType(), "Rope") == 0 && strcmp(objectB -> getType(), "Projectile") == 0)
        {
            Rope* rope = (Rope*) objectA;
            
            projectile = (Projectile*) objectB;
            
            if(!projectile -> hasHit())
            {
                projectile -> setHit(true);
                
                if(rope -> isDestructible())
                {
                    rope -> detach();
                    
                    if(rope -> isLogRope())
                    {
                        m_Log -> setBodyType(b2_dynamicBody);
                    }
                }
            }
        }
        if(strcmp(objectA -> getType(), "Projectile") == 0 && strcmp(objectB -> getType(), "Pickup") == 0)
        {
            Pickups* pickup = (Pickups*) objectB;
            
            pickup->activate((Projectile*)objectA);
        }
        else if(strcmp(objectA -> getType(), "Pickup") == 0 && strcmp(objectB -> getType(), "Projectile") == 0)
        {
            Pickups* pickup = (Pickups*) objectA;
            
            pickup->activate((Projectile*)objectB);
        }
        
        if(hit)
        {
            projectile -> setHit(true);
            
            limb -> detach();
        }
    }
}

void Game::EndContact(b2Contact* contact)
{
    //Handle contacts here
}

void Game::addGameObject(GameObject* gameObject)
{
    m_GameObjects.push_back(gameObject);
}

void Game::removeGameObject(GameObject* gameObject)
{
    if(gameObject != NULL)
    {
        int i = 0;
        
        for( i = 0; i < m_GameObjects.size(); i++)
        {
            if(m_GameObjects.at(i) == gameObject)
            {
                m_GameObjects.at(i) = NULL;
                break;
            }
        }
        
        destroyPhysicsBody(gameObject -> getBody());
        delete gameObject;
        
        m_GameObjects.erase(m_GameObjects.begin() + i);
    }
}

void Game::addBloodParticles(BloodParticles* particles)
{
    m_GameObjects.push_back(particles);
}

void Game::setJointsToCut(int joints)
{
    m_JointsToCut = joints;
}

void Game::jointCut()
{
    m_JointsToCut--;
    
    if(m_JointsToCut <= 0)
    {
        m_GameWon = true;
    }
}

float Game::getScreenWidth()
{
    return DeviceUtils::getScreenResolutionWidth();
}

float Game::getScreenHeight()
{
    return DeviceUtils::getScreenResolutionHeight();
}

float Game::getScale()
{
    return DeviceUtils::getContentScaleFactor();
}

bool Game::isLoading()
{
    return m_LoadStep < GameLoadStepCount;
}

bool Game::needsResetting()
{
    return m_Reset;
}

GDRandom* Game::getRandomizer()
{
    return m_Randomizer;
}

void Game::enableTargetting()
{
    m_TargettingTimer = m_TargettingTime;
}

bool Game::isTargettingEnabled()
{
    return (m_TargettingTimer > 0.0f);
}
