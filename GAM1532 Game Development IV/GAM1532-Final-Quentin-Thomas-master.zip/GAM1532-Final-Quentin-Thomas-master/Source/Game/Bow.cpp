//
//  Bow.cpp
//  GameDevFramework
//
//  Created by Thomas Pryde on 2014-04-19.
//  Copyright (c) 2014 Algonquin College. All rights reserved.
//

#include "Bow.h"
#include "PhysicsEditorWrapper.h"

Bow::Bow(int x, int y)
{
    m_Texture = new OpenGLTexture("Images/Bow");
    
    b2BodyDef bodyDef;
    bodyDef.type = b2_staticBody;
    bodyDef.position = b2Vec2(x, y);
    bodyDef.userData = this;
    
    m_Body = Game::getInstance() -> createPhysicsBody(&bodyDef);
    
    PhysicsEditorCpp::addFixturesToBody(m_Body, "Bow");
    
    float anchorX;
    float anchorY;
    PhysicsEditorCpp::anchorPointForShape(anchorX, anchorY, "Bow");
    
    m_Texture -> setAnchorPoint(anchorX, anchorY);
    
    Game::getInstance() -> addGameObject(this);
}

Bow::~Bow()
{
    
}

const char* Bow::getType()
{
    return "Bow";
}

float Bow::getWidth()
{
    return m_Texture -> getSourceWidth();
}

float Bow::getHeight()
{
    return m_Texture -> getSourceHeight();
}