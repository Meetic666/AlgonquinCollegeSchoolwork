//
//  Projectile.h
//  GameDevFramework
//
//  Created by Thomas Pryde on 2014-04-14.
//  Copyright (c) 2014 Algonquin College. All rights reserved.
//

#ifndef __GameDevFramework__Projectile__
#define __GameDevFramework__Projectile__

#include "GameObject.h"

class Projectile : public GameObject
{
public:
    Projectile(OpenGLTexture* texture, const char* fileName, int x, int y, b2BodyType bodyType = b2_dynamicBody);
    ~Projectile();
    
    b2BodyDef* getTomaHawk();
    b2BodyDef* getBowStaff();

    const char* getType();
    void fireProjectile();
    
    bool hasHit();
    void setHit(bool hasHit);
    
    b2Body* getBody();
    
    void update(double deltaTime);
    
private:
    std::vector<b2BodyDef> m_Projectiles;
    bool m_HasHit;
    float m_Timer;
};

#endif /* defined(__GameDevFramework__Projectile__) */
