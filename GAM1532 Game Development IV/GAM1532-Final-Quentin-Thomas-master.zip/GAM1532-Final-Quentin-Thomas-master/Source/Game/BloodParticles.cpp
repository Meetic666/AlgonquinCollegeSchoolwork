//
//  BloodParticles.cpp
//  GameDevFramework
//
//  Created by Quentin Bellay on 2014-04-16.
//  Copyright (c) 2014 Algonquin College. All rights reserved.
//

#include "BloodParticles.h"
#include "GDRandom.h"
#include "MathUtils.h"
#include "BloodParticle.h"
#include "Limb.h"

BloodParticles::BloodParticles(b2Body* body, b2Vec2 offset, int numberOfSplatter) :
m_Randomizer(NULL),
m_SplatterTime(0.01f),
m_SplatterTimer(0.1f),
m_NumberOfSplatterLeft(numberOfSplatter),
m_Offset(offset),
m_Body(body),
m_LifeTime(1.0f),
m_LifeTimer(0.0f)
{
    m_Randomizer = new GDRandom();
    
    m_Texture = new OpenGLTexture("Images/Blood");
}

BloodParticles::~BloodParticles()
{
    delete m_Randomizer;
    m_Randomizer = NULL;
    
    for(int i = 0; i < m_BloodParticles.size(); i++)
    {
        m_BloodParticles[i] -> destroyTexture();
    }
    
    m_BloodParticles.clear();
}

const char* BloodParticles::getType()
{
    return "BloodParticles";
}

void BloodParticles::paint()
{
    for(int i = 0; i < m_BloodParticles.size(); i++)
    {
        m_BloodParticles[i] -> paint();
    }
}

void BloodParticles::update(double deltaTime)
{    
    if(m_SplatterTimer > 0.0f)
    {
        m_SplatterTimer -= deltaTime;
        
        if(m_SplatterTimer <= 0.0f)
        {
            Limb* limb = (Limb*) m_Body -> GetUserData();
            
            b2Vec2 position = b2Helper::screenSpaceToBox2dSpace(limb -> getX(), limb -> getY()) + b2Mul(b2Rot(MathUtils::degressToRadians(limb -> getAngle())), m_Offset);
            b2Vec2 impulse = b2Mul(b2Rot(m_Randomizer -> random() * 3.14f), b2Vec2(0.0f, 10.0f));
            
            m_BloodParticles.push_back(new BloodParticle(m_Texture, position, impulse));
            
            m_NumberOfSplatterLeft--;
            
            if(m_NumberOfSplatterLeft > 0)
            {
                m_SplatterTimer = m_SplatterTime;
                
                m_LifeTimer = m_LifeTime;
            }
        }
    }
    
    if(m_LifeTimer > 0.0f)
    {
        m_LifeTimer -= deltaTime;
        
        if(m_LifeTimer <= 0.0f)
        {
            for(int i = 0; i < m_BloodParticles.size(); i++)
            {
                m_BloodParticles[i] -> destroyTexture();
                Game::getInstance() -> removeGameObject(m_BloodParticles.at(i));
            }
            
            m_BloodParticles.clear();
            
            Game::getInstance() -> removeGameObject(this);            
        }
    }
}