//
//  Pickups.h
//  GameDevFramework
//
//  Created by Thomas Pryde on 2014-04-19.
//  Copyright (c) 2014 Algonquin College. All rights reserved.
//

#ifndef __GameDevFramework__Pickups__
#define __GameDevFramework__Pickups__

#include "GameObject.h"

class Game;
class Projectile;

class Pickups : public GameObject
{
public:
    Pickups();
    ~Pickups();
    
    const char* getType();
    
    void activate(Projectile* projectile);
    void spawnPickup();
    
    void update(double deltaTime);
    
private:
    short m_Type;
    
    bool m_Remove;
};

#endif /* defined(__GameDevFramework__Pickups__) */
