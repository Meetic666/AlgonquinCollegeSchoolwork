//
//  Bow.h
//  GameDevFramework
//
//  Created by Thomas Pryde on 2014-04-19.
//  Copyright (c) 2014 Algonquin College. All rights reserved.
//

#ifndef __GameDevFramework__Bow__
#define __GameDevFramework__Bow__

#include "GameObject.h"

class Bow : public GameObject
{
public:
    Bow(int x, int y);
    ~Bow();
    
    const char* getType();
    
    float getWidth();
    float getHeight();
};

#endif /* defined(__GameDevFramework__Bow__) */
