//
//  Log.h
//  GameDevFramework
//
//  Created by Quentin Bellay on 2014-04-18.
//  Copyright (c) 2014 Algonquin College. All rights reserved.
//

#ifndef __GameDevFramework__Log__
#define __GameDevFramework__Log__

#include "GameObject.h"

class Log: public GameObject
{
public:
    Log(float x, float y);
    ~Log();
    
    const char* getType();
    
    float getWidth();
    float getHeight();
};

#endif /* defined(__GameDevFramework__Log__) */
