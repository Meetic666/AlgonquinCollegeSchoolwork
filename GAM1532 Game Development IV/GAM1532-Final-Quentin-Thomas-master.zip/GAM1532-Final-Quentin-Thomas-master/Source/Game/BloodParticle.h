//
//  BloodParticle.h
//  GameDevFramework
//
//  Created by Quentin Bellay on 2014-04-18.
//  Copyright (c) 2014 Algonquin College. All rights reserved.
//

#ifndef __GameDevFramework__BloodParticle__
#define __GameDevFramework__BloodParticle__

#include "GameObject.h"

class BloodParticle : public GameObject
{
public:
    BloodParticle(OpenGLTexture* texture, b2Vec2 position, b2Vec2 impulse);
    ~BloodParticle();
    
    const char* getType();
    
    void destroyTexture();
};

#endif /* defined(__GameDevFramework__BloodParticle__) */
