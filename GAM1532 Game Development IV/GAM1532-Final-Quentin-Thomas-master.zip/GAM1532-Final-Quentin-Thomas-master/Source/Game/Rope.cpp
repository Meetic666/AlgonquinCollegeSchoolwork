//
//  Rope.cpp
//  GameDevFramework
//
//  Created by Quentin Bellay on 2014-04-14.
//  Copyright (c) 2014 Algonquin College. All rights reserved.
//

#include "Rope.h"
#include "Limb.h"
#include "MathUtils.h"
#include "Log.h"


Rope::Rope(b2Vec2 position, b2Vec2 sizeOfSegment, int numberOfSegments, bool destructible) : GameObject(),
m_RopeJoint(NULL),
m_Length(sizeOfSegment.y),
m_Destructible(destructible),
m_LogRope(false),
m_DestroyJoint(false)
{
    if(destructible)
    {
        m_Texture = new OpenGLTexture("Images/Rope");
    }
    else
    {
        m_Texture = new OpenGLTexture("Images/RopeIndestructible");
    }
    
    m_Texture -> setAnchorPoint(0.5f, 0.5f);
    
    
    for(int i = 0; i < numberOfSegments; i++)
    {
        b2Body* segment;
        
        if(i != 0)
        {
            segment = Game::getInstance() -> createBox(position + b2Vec2(0,- i * m_Length), sizeOfSegment, b2_dynamicBody, 0x0001, 0xFFFF ^ 0x0001);
        }
        else
        {
            segment = Game::getInstance() -> createBox(position, sizeOfSegment, b2_staticBody, 0x0001, 0xFFFF ^ 0x0001);
        }
        
        segment -> SetUserData(this);
        
        m_Segments.push_back(segment);
    }
}

Rope::~Rope()
{
    for(int i = 0; i < m_Segments.size(); i++)
    {
        Game::getInstance() -> destroyPhysicsBody( m_Segments[i] );
    }
    
    m_Segments.clear();
}

const char* Rope::getType()
{
    return "Rope";
}

void Rope::tieLimb(Limb* limb)
{
    b2RevoluteJointDef revoluteJointDef;
    revoluteJointDef.bodyA = limb -> getBody();
    revoluteJointDef.bodyB = m_Segments[m_Segments.size() - 1];
    
    revoluteJointDef.localAnchorA = b2Vec2(0.0f, m_Length);
    revoluteJointDef.localAnchorB = b2Vec2(0.0f, -m_Length);
    
    Game::getInstance() -> createJoint(&revoluteJointDef);
    
    setParentPosition();
}

void Rope::detach()
{
    if(m_Destructible)
    {
        m_DestroyJoint = true;
    }
}

void Rope::update(double deltaTime)
{
    GameObject::update(deltaTime);
    
    if(m_DestroyJoint && m_RopeJoint != NULL)
    {
        Game::getInstance() -> destroyJoint(m_RopeJoint);
        
        m_DestroyJoint = false;
        
        m_RopeJoint = NULL;
    }
}

void Rope::paint()
{
    if(m_Texture != NULL)
    {
        for(int i = 0; i < m_Segments.size(); i++)
        {
            if(!m_Destructible)
            {
                OpenGLRenderer::getInstance() -> setForegroundColor(OpenGLColorRed());
            }
            
            OpenGLRenderer::getInstance()->drawTexture(m_Texture, b2Helper::box2dSpaceToScreenSpace( m_Segments[i] ->GetWorldCenter().x ), b2Helper::box2dSpaceToScreenSpace( m_Segments[i] ->GetWorldCenter().y ), MathUtils::radiansToDegrees( m_Segments[i] -> GetAngle()));
            
            OpenGLRenderer::getInstance() -> setForegroundColor(OpenGLColorWhite());
        }
    }
}

bool Rope::isDestructible()
{
    return m_Destructible;
}

std::vector<b2Body*> Rope::getSegments()
{
    return m_Segments;
}

void Rope::attachToLog(Log* log, int index)
{
    b2RevoluteJointDef revoluteJointDef;
    revoluteJointDef.bodyA = log -> getBody();
    revoluteJointDef.bodyB = m_Segments[m_Segments.size() - 1];
    
    revoluteJointDef.localAnchorA = b2Vec2(index * b2Helper::screenSpaceToBox2dSpace(log -> getWidth()) / 3.0f, b2Helper::screenSpaceToBox2dSpace(log -> getHeight()) / 2.0f);
    revoluteJointDef.localAnchorB = b2Vec2(0.0f, -m_Length);
    
    m_Segments[m_Segments.size() - 1] -> SetTransform(log -> getBody() -> GetPosition() + revoluteJointDef.localAnchorA - revoluteJointDef.localAnchorB, 0);
    
    Game::getInstance() -> createJoint(&revoluteJointDef);
    
    setParentPosition();
}

void Rope::setLogRope(bool logRope)
{
    m_LogRope = logRope;
}

bool Rope::isLogRope()
{
    return m_LogRope;
}

void Rope::setParentPosition()
{
    b2Vec2 offset = m_Segments.at(m_Segments.size() - 1) -> GetPosition() - m_Segments.at(0) -> GetPosition();
    offset.x /= m_Segments.size() - 1;
    offset.y /= m_Segments.size() - 1;
    
    for(int i = 1; i < m_Segments.size(); i++)
    {
        m_Segments.at(i) -> SetTransform(m_Segments.at(0) -> GetPosition() + i * offset, m_Segments.at(i) -> GetAngle());
        
        b2RopeJointDef ropeJointDef;
        ropeJointDef.bodyA = m_Segments[i-1];
        ropeJointDef.bodyB = m_Segments[i];
        
        ropeJointDef.localAnchorA = b2Vec2(0,m_Length / 2.0f);
        ropeJointDef.localAnchorB = b2Vec2(0,-m_Length / 2.0f);
        
        ropeJointDef.maxLength = m_Length;
        
        b2WeldJointDef weldJointDef;
        
        /*weldJointDef.bodyA = m_Segments[i-1];
        weldJointDef.bodyB = m_Segments[i];
        
        Game::getInstance() -> createJoint(&weldJointDef);*/
        
        if(i != 1)
        {
            Game::getInstance() -> createJoint(&ropeJointDef);
        }
        else
        {
            m_RopeJoint = (b2RopeJoint*) Game::getInstance() -> createJoint(&ropeJointDef);
        }
    }
}