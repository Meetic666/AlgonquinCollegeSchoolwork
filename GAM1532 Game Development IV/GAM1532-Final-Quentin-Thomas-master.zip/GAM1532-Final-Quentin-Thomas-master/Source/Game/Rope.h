//
//  Rope.h
//  GameDevFramework
//
//  Created by Quentin Bellay on 2014-04-14.
//  Copyright (c) 2014 Algonquin College. All rights reserved.
//

#ifndef __GameDevFramework__Rope__
#define __GameDevFramework__Rope__

#include "GameObject.h"

class Limb;
class Log;

class Rope: public GameObject
{
public:
    Rope(b2Vec2 position, b2Vec2 sizeOfSegment, int numberOfSegments, bool destructible = true);
    ~Rope();
    
    const char* getType();
    
    void tieLimb(Limb* limb);
    void detach();
    
    void update(double deltaTime);
    void paint();
    
    bool isDestructible();
    
    std::vector<b2Body*> getSegments();
    
    void attachToLog(Log* log, int index); // index decides whether it's the right or left side of the log
    
    void setLogRope(bool isLogrope);
    bool isLogRope();
    
    void setParentPosition();
    
private:
    b2RopeJoint* m_RopeJoint;
    
    bool m_DestroyJoint;
    
    std::vector<b2Body*> m_Segments;
    
    float m_Length;
    
    bool m_Destructible;
    
    bool m_LogRope;
};

#endif /* defined(__GameDevFramework__Rope__) */
