//
//  Pickups.cpp
//  GameDevFramework
//
//  Created by Thomas Pryde on 2014-04-19.
//  Copyright (c) 2014 Algonquin College. All rights reserved.
//

#include "Pickups.h"
#include "PhysicsEditorWrapper.h"
#include "GDRandom.h"
#include "Projectile.h"

Pickups::Pickups() :
m_Remove(false)
{
    
}

Pickups::~Pickups()
{
    
}

const char* Pickups::getType()
{
    return "Pickup";
}

void Pickups::spawnPickup()
{
    
    m_Type = Game::getInstance()->getRandomizer()->random(3);
    
    if(m_Type > 2 || m_Type < 0)
    {
        m_Type = Game::getInstance()->getRandomizer()->random(3);
    }
    
    int x = Game::getInstance()->getRandomizer()->random(GAME_SPAWN_AREA_WIDTH) + GAME_LEFT_X_COORDINATE;
    int y = Game::getInstance()->getRandomizer()->random(GAME_SPAWN_AREA_HIEGHT) + GAME_BOTTOM_Y_COORDINATE;
    
    switch(m_Type)
    {
        case 0:
        {
            m_Texture = new OpenGLTexture("Images/Bounciness Pickup");
            
            b2BodyDef bodyDef;
            bodyDef.type = b2_staticBody;
            bodyDef.position = b2Vec2(b2Helper::screenSpaceToBox2dSpace(x, y));
            bodyDef.userData = this;
            
            m_Body = Game::getInstance() -> createPhysicsBody(&bodyDef);
            
            PhysicsEditorCpp::addFixturesToBody(m_Body, "Bounciness Pickup");
            
            float anchorX;
            float anchorY;
            PhysicsEditorCpp::anchorPointForShape(anchorX, anchorY, "Bounciness Pickup");
            
            m_Texture -> setAnchorPoint(anchorX, anchorY);
            
            Game::getInstance() -> addGameObject(this);
            
            break;
        }
        case 1:
        {
            m_Texture = new OpenGLTexture("Images/Speed Pickup");
            
            b2BodyDef bodyDef;
            bodyDef.type = b2_staticBody;
            bodyDef.position = b2Vec2(b2Helper::screenSpaceToBox2dSpace(x, y));
            bodyDef.userData = this;
            
            m_Body = Game::getInstance() -> createPhysicsBody(&bodyDef);
            
            PhysicsEditorCpp::addFixturesToBody(m_Body, "Speed Pickup");
            
            float anchorX;
            float anchorY;
            PhysicsEditorCpp::anchorPointForShape(anchorX, anchorY, "Speed Pickup");
            
            m_Texture -> setAnchorPoint(anchorX, anchorY);
            
            Game::getInstance() -> addGameObject(this);
            
            break;
        }
        case 2:
        {
            m_Texture = new OpenGLTexture("Images/Targetting Pickup");
            
            b2BodyDef bodyDef;
            bodyDef.type = b2_staticBody;
            bodyDef.position = b2Vec2(b2Helper::screenSpaceToBox2dSpace(x, y));
            bodyDef.userData = this;
            
            m_Body = Game::getInstance() -> createPhysicsBody(&bodyDef);
            
            PhysicsEditorCpp::addFixturesToBody(m_Body, "Targetting Pickup");
            
            float anchorX;
            float anchorY;
            PhysicsEditorCpp::anchorPointForShape(anchorX, anchorY, "Targetting Pickup");
            
            m_Texture -> setAnchorPoint(anchorX, anchorY);
            
            Game::getInstance() -> addGameObject(this);
            
            break;
        }
        default:
            break;
    }
}

void Pickups::activate(Projectile* projectile)
{
    switch(m_Type)
    {
        case 0:
        {
            b2Fixture * fixture = projectile -> getBody() -> GetFixtureList();
            
            while(fixture != NULL)
            {
                projectile->getBody()->GetFixtureList()->SetRestitution(projectile->getBody()->GetFixtureList()->GetRestitution() + 10);
                
                fixture = fixture -> GetNext();
            }
            break;
        }
        case 1:
        {
            b2Vec2 impulse = b2Vec2(GAME_BASE_IMPULSE * 100000.0f / GAME_BOW_DRAWBACK_RANGE, 0);
            impulse = b2Mul(b2Rot(projectile->getBody()->GetAngle()), impulse);
            
            projectile -> setLinearVelocity(projectile->getLinearVelocity() + b2Vec2(50,0));
            
            break;
        }
        case 2:
        {
            Game::getInstance() -> enableTargetting();
            
            break;
        }
        default:
            break;
    }
    
    m_Remove = true;
}

void Pickups::update(double deltaTime)
{
    GameObject::update(deltaTime);
    
    if(m_Remove)
    {
        m_Remove = false;
        
        Game::getInstance() -> removeGameObject(this);
    }
}