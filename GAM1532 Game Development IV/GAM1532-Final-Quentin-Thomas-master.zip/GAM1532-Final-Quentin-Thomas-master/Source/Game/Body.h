//
//  Body.h
//  GameDevFramework
//
//  Created by Quentin Bellay on 2014-04-07.
//  Copyright (c) 2014 Algonquin College. All rights reserved.
//

#ifndef __GameDevFramework__Body__
#define __GameDevFramework__Body__

#include <vector>

class Limb;

class Body
{
public:
    Body(float x, float y);
    ~Body();
    
    Limb* getLeftHand();
    Limb* getRightHand();
    Limb* getLeftFoot();
    Limb* getRightFoot();
    Limb* getHead();
    
private:
    std::vector<Limb*> m_Limbs;
};

#endif /* defined(__GameDevFramework__Body__) */
