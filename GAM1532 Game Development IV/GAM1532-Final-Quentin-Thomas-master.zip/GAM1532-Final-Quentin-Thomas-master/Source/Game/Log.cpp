//
//  Log.cpp
//  GameDevFramework
//
//  Created by Quentin Bellay on 2014-04-18.
//  Copyright (c) 2014 Algonquin College. All rights reserved.
//

#include "Log.h"
#include "PhysicsEditorWrapper.h"

Log::Log(float x, float y)
{
    m_Texture = new OpenGLTexture("Images/Log");
    
    b2BodyDef bodyDef;
    bodyDef.type = b2_staticBody;
    bodyDef.position = b2Vec2(x, y);
    bodyDef.userData = this;
    
    m_Body = Game::getInstance() -> createPhysicsBody(&bodyDef);
    
    PhysicsEditorCpp::addFixturesToBody(m_Body, "Log");
    
    float anchorX;
    float anchorY;
    PhysicsEditorCpp::anchorPointForShape(anchorX, anchorY, "Log");
    
    m_Texture -> setAnchorPoint(anchorX, anchorY);
}

Log::~Log()
{
    
}

const char* Log::getType()
{
    return "Log";
}

float Log::getWidth()
{
    return m_Texture -> getSourceWidth();
}

float Log::getHeight()
{
    return m_Texture -> getSourceHeight();
}