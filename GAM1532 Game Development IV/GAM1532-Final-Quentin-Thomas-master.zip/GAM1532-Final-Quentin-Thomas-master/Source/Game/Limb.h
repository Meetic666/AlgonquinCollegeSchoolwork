//
//  Limb.h
//  GameDevFramework
//
//  Created by Quentin Bellay on 2014-04-07.
//  Copyright (c) 2014 Algonquin College. All rights reserved.
//

#ifndef __GameDevFramework__Limb__
#define __GameDevFramework__Limb__

#include "GameObject.h"

class Limb : public GameObject
{
public:
    Limb(OpenGLTexture* texture, const char* fileName, float x, float y, b2BodyType bodyType = b2_dynamicBody);
    ~Limb();
    
    void attachTo(Limb* parentLimb, b2Vec2 parentOffset, b2Vec2 limbOffset);
    void tieTo(b2Body* parentBody);
    void detach();
    
    const char* getType();
    
    void update(double deltaTime);
    
    float getWidth();
    float getHeight();
    
    b2RevoluteJoint* getParentJoint();
    
    bool isSevered();
    
    bool isPilgrim();
    void setIsPilgrim(bool isPilgrim);
    
private:
    b2RevoluteJoint* m_ParentJoint;
    Limb* m_ParentLimb;
    
    bool m_DestroyJoint;
    
    bool m_IsPilgrim;
};

#endif /* defined(__GameDevFramework__Limb__) */
