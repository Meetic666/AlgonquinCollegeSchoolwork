//
//  BloodParticle.cpp
//  GameDevFramework
//
//  Created by Quentin Bellay on 2014-04-18.
//  Copyright (c) 2014 Algonquin College. All rights reserved.
//

#include "BloodParticle.h"

BloodParticle::BloodParticle(OpenGLTexture* texture, b2Vec2 position, b2Vec2 impulse)
{
    m_Texture = texture;
    
    m_Texture -> setAnchorPoint(0.5f, 0.5f);
    
    b2Vec2 size = b2Helper::screenSpaceToBox2dSpace(m_Texture -> getSourceWidth() / 2.0f, m_Texture -> getSourceHeight() / 2.0f);
    
    m_Body = Game::getInstance() -> createBox(position, size, b2_dynamicBody, 0x0001, 0xFFFF ^ 0x0001);
    
    m_Body -> SetUserData(this);
    
    m_Body -> ApplyForce(impulse, b2Vec2(0.0f,0.0f));
    
    Game::getInstance() -> addGameObject(this);
}

BloodParticle::~BloodParticle()
{
    
}

const char* BloodParticle::getType()
{
    return "BloodParticle";
}

void BloodParticle::destroyTexture()
{
    m_Texture = NULL;
}