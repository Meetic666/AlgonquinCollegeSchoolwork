//
//  Body.cpp
//  GameDevFramework
//
//  Created by Quentin Bellay on 2014-04-07.
//  Copyright (c) 2014 Algonquin College. All rights reserved.
//

#include "Body.h"
#include "Limb.h"

Body::Body(float x, float y)
{
    m_Limbs.clear();
    
    Limb* torso = new Limb(new OpenGLTexture("Images/Torso"), "Torso", x,y);
    
    Limb* leftThigh = new Limb(new OpenGLTexture("Images/LeftThigh"), "LeftThigh", x - torso -> getWidth() /3.5f, y - torso -> getHeight() * 3.0f / 4.0f);
    
    Limb* rightThigh = new Limb(new OpenGLTexture("Images/RightThigh"), "RightThigh", x + torso -> getWidth() / 3.5f, y - torso -> getHeight() * 3.0f/4.0f);

    Limb* leftCalf = new Limb(new OpenGLTexture("Images/LeftCalf"), "LeftCalf", b2Helper::screenSpaceToBox2dSpace(leftThigh -> getX()), b2Helper::screenSpaceToBox2dSpace(leftThigh -> getY()) - leftThigh -> getHeight() / 1.5f);
    
    Limb* rightCalf = new Limb(new OpenGLTexture("Images/RightCalf"), "RightCalf", b2Helper::screenSpaceToBox2dSpace(rightThigh -> getX()), b2Helper::screenSpaceToBox2dSpace(rightThigh -> getY()) - rightThigh -> getHeight() / 1.5f);
    
    Limb* leftFoot = new Limb(new OpenGLTexture("Images/LeftFoot"), "LeftFoot", b2Helper::screenSpaceToBox2dSpace(leftCalf -> getX()) - leftCalf -> getWidth() / 2.0f, b2Helper::screenSpaceToBox2dSpace(leftCalf -> getY()) - leftCalf -> getHeight() / 2.0f);
    
    Limb* rightFoot = new Limb(new OpenGLTexture("Images/RightFoot"), "RightFoot", b2Helper::screenSpaceToBox2dSpace(rightCalf -> getX()) + rightCalf -> getWidth() / 2.0f, b2Helper::screenSpaceToBox2dSpace(rightCalf -> getY()) - rightCalf -> getHeight() / 2.0f);
    
    Limb* leftArm = new Limb(new OpenGLTexture("Images/LeftArm"), "LeftArm", x - torso -> getWidth() / 1.5f, y + torso -> getHeight() / 4.0f);
    
    Limb* rightArm = new Limb(new OpenGLTexture("Images/RightArm"), "RightArm", x + torso -> getWidth() / 1.5f, y + torso -> getHeight() / 7.0f);
    
    Limb* leftForearm = new Limb(new OpenGLTexture("Images/LeftForearm"), "LeftForearm", b2Helper::screenSpaceToBox2dSpace(leftArm -> getX()) - leftArm -> getWidth() / 1.5f, b2Helper::screenSpaceToBox2dSpace(leftArm -> getY()));
    
    Limb* rightForearm = new Limb(new OpenGLTexture("Images/RightForearm"), "RightForearm", b2Helper::screenSpaceToBox2dSpace(rightArm -> getX()) + rightArm -> getWidth() / 1.5f, b2Helper::screenSpaceToBox2dSpace(rightArm -> getY()));
    
    Limb* leftHand = new Limb(new OpenGLTexture("Images/LeftHand"), "LeftHand", b2Helper::screenSpaceToBox2dSpace(leftForearm -> getX()) - leftForearm -> getWidth() / 1.25f, b2Helper::screenSpaceToBox2dSpace(leftForearm -> getY()) + leftForearm -> getHeight() / 3.0f);
    
    Limb* rightHand = new Limb(new OpenGLTexture("Images/RightHand"), "RightHand", b2Helper::screenSpaceToBox2dSpace(rightForearm -> getX()) + rightForearm -> getWidth() / 1.25f, b2Helper::screenSpaceToBox2dSpace(rightForearm -> getY()) + rightForearm -> getHeight() / 3.0f);
    
    Limb* head = new Limb(new OpenGLTexture("Images/Head"), "Head", x, y + torso -> getHeight() / 1.5f);
    
    
    leftThigh -> attachTo(torso, b2Vec2(-torso -> getWidth() / 6.0f, -torso -> getHeight() / 2.5f), b2Vec2(leftThigh -> getWidth() / 4.0f,leftThigh -> getHeight() / 2.5f));
    rightThigh -> attachTo(torso, b2Vec2(torso -> getWidth() / 6.0f, -torso -> getHeight() / 2.5f), b2Vec2(-rightThigh -> getWidth() / 4.0f, rightThigh -> getHeight() / 2.5f));
    
    leftCalf -> attachTo(leftThigh, b2Vec2(-leftThigh -> getWidth() / 4.0f, -leftThigh -> getHeight() / 3.0f), b2Vec2(-leftCalf -> getWidth() / 4.0f, leftCalf -> getHeight() / 2.5f));
    rightCalf -> attachTo(rightThigh, b2Vec2(rightThigh -> getWidth() / 4.0f, -rightThigh -> getHeight() / 3.0f), b2Vec2(rightCalf -> getWidth() / 4.0f, rightCalf -> getHeight() / 2.5f));
    
    leftFoot -> attachTo(leftCalf, b2Vec2(0, -leftCalf -> getHeight() / 3.0f), b2Vec2(leftFoot -> getWidth() / 4.0f, leftFoot -> getHeight() / 2.0f));
    rightFoot -> attachTo(rightCalf, b2Vec2(0, -rightCalf -> getHeight() / 3.0f), b2Vec2(-rightFoot -> getWidth() / 4.0f, rightFoot -> getHeight() / 2.0f));
    
    leftArm -> attachTo(torso, b2Vec2(-torso -> getWidth() / 2.5f, torso -> getHeight() / 4.0f), b2Vec2(leftArm -> getWidth() / 3.0f, leftArm -> getHeight() / 4.0f));
    rightArm -> attachTo(torso, b2Vec2(torso -> getWidth() / 2.5f, torso -> getHeight() / 4.0f), b2Vec2(-rightArm -> getWidth() / 3.0f, rightArm -> getHeight() / 4.0f));
    
    leftForearm -> attachTo(leftArm, b2Vec2(-leftArm -> getWidth() / 2.5f, 0), b2Vec2(leftForearm -> getWidth() / 2.0f,0));
    rightForearm -> attachTo(rightArm, b2Vec2(rightArm -> getWidth() / 2.5f, 0), b2Vec2(-rightForearm -> getWidth() / 2.0f,0));
    
    leftHand -> attachTo(leftForearm, b2Vec2(-leftForearm -> getWidth() / 2.5f,0), b2Vec2(leftHand -> getWidth() / 2.5f, 0));
    rightHand -> attachTo(rightForearm, b2Vec2(rightForearm -> getWidth() / 2.5f,0), b2Vec2(-rightHand -> getWidth() / 2.5f, 0));
    
    head -> attachTo(torso, b2Vec2(0, torso -> getHeight() / 2.0f), b2Vec2(0, -head -> getHeight() / 3.0f));
    
    m_Limbs.push_back(leftThigh);
    m_Limbs.push_back(rightThigh);
    m_Limbs.push_back(leftCalf);
    m_Limbs.push_back(rightCalf);
    m_Limbs.push_back(leftFoot);
    m_Limbs.push_back(rightFoot);
    m_Limbs.push_back(leftArm);
    m_Limbs.push_back(rightArm);
    m_Limbs.push_back(leftForearm);
    m_Limbs.push_back(rightForearm);
    m_Limbs.push_back(leftHand);
    m_Limbs.push_back(rightHand);
    m_Limbs.push_back(head);
    m_Limbs.push_back(torso);
    
    Game::getInstance() -> setJointsToCut(13);
}

Body::~Body()
{
    m_Limbs.clear();
}

Limb* Body::getLeftHand()
{
    return m_Limbs[10];
}

Limb* Body::getRightHand()
{
    return m_Limbs[11];
}

Limb* Body::getLeftFoot()
{
    return m_Limbs[4];
}

Limb* Body::getRightFoot()
{
    return m_Limbs[5];
}

Limb* Body::getHead()
{
    return m_Limbs[m_Limbs.size() - 2];
}