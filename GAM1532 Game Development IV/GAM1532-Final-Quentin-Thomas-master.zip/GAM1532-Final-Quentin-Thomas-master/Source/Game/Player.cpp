//
//  Player.cpp
//  GameDevFramework
//
//  Created by Thomas Pryde on 2014-04-07.
//  Copyright (c) 2014 Algonquin College. All rights reserved.
//

#include "Player.h"
#include "Projectile.h"
#include "Limb.h"
#include "Bow.h"
#include "PhysicsEditorWrapper.h"

Player::Player(int x, int y)
{
    m_ActiveWeapon = BOW;
    
    //TODO: Change magic placement numbers.
    
    m_PlayerLimbs.clear();
    
    Limb* body = new Limb(new OpenGLTexture("Images/IndianBody"), "IndianBody", x,y, b2_staticBody);
    
    Limb* rightArm = new Limb(new OpenGLTexture("Images/IndianRightBicep"), "IndianRightBicep", x - 0.5f, y + 0.6f, b2_staticBody);
    
    Limb* leftArm = new Limb(new OpenGLTexture("Images/IndianLeftArm"), "IndianLeftArm", x, y + body -> getHeight() / 7.0f, b2_staticBody);
    
    Limb* rightForearm = new Limb(new OpenGLTexture("Images/IndianRightForearm"), "IndianRightForearm", x - 1.0f, y + 0.45f, b2_staticBody);
    
    leftArm -> attachTo(body, b2Vec2(-body -> getWidth() / 2.5f, body -> getHeight() / 4.0f), b2Vec2(leftArm -> getWidth() / 3.0f, leftArm -> getHeight() / 4.0f));
    rightArm -> attachTo(body, b2Vec2(body -> getWidth() / 2.5f, body -> getHeight() / 4.0f), b2Vec2(-rightArm -> getWidth() / 3.0f, rightArm -> getHeight() / 4.0f));
    
    rightForearm -> attachTo(rightArm, b2Vec2(rightArm -> getWidth() / 2.5f, 0), b2Vec2(-rightForearm -> getWidth() / 2.0f,0));
    
    
    m_PlayerLimbs.push_back(leftArm);
    m_PlayerLimbs.push_back(body);
    m_PlayerLimbs.push_back(rightArm);
    m_PlayerLimbs.push_back(rightForearm);
    
    for(int i = 0; i < m_PlayerLimbs.size(); i++)
    {
        m_PlayerLimbs.at(i) -> setIsPilgrim(false);
    }
    
    m_Projectile = NULL;
    m_Bow = NULL;
    
    m_Impulse = b2Vec2(0,0);
    
}

Player::~Player()
{
    m_PlayerLimbs.clear();
}

void Player::paint()
{
    GameObject::paint();
    
    for(int i = 1; i < m_TrajectoryPoints.size(); i++)
    {
        b2Vec2 origin = b2Helper::box2dSpaceToScreenSpace(m_TrajectoryPoints[i-1]);
        b2Vec2 destination = b2Helper::box2dSpaceToScreenSpace(m_TrajectoryPoints[i]);
        
        OpenGLRenderer::getInstance() -> drawLine(origin.x, origin.y, destination.x, destination.y);
    }
}

void Player::update(float deltaTime)
{
    TrajectoryRayCastCallBack rayCastCallBack;
    
    m_TrajectoryPoints.clear();
    
    if(m_Projectile != NULL && m_Impulse.x != 0 && Game::getInstance() -> isTargettingEnabled())
    {
        for(int i = 0; i < GAME_FRAMES_PER_SECOND * 3; i++)
        {
            b2Vec2 trajectoryPoint = getTrajectoryPoint(i);
            
            /*if(i > 0)
            {
                Game::getInstance()->rayCast(&rayCastCallBack, m_TrajectoryPoints.at(i-1), trajectoryPoint);
                
                if(rayCastCallBack.didHit == true)
                {
                    m_TrajectoryPoints.push_back(trajectoryPoint);
                    break;
                }
            }*/
            
            m_TrajectoryPoints.push_back(trajectoryPoint);
        }
    }
    
}

b2Vec2 Player::getTrajectoryPoint(float step)
{
    b2Vec2 position = m_Projectile -> getBody() -> GetPosition();
    float angle = m_Projectile -> getBody() -> GetAngle();
    
    b2Vec2 initialPosition = position + b2Mul(b2Rot(angle), b2Vec2(0.0f, 0.0f));
    b2Vec2 initialVelocity = b2Mul(b2Rot(angle), m_Impulse);
    
    float time = 1.0f / GAME_FRAMES_PER_SECOND;
    b2Vec2 stepVelocity = time * initialVelocity;
    b2Vec2 stepGravity = time * time * Game::getInstance() -> getGravity();
    
    return initialPosition + step * stepVelocity + 0.5f * (step * step + step) * stepGravity;
}

const char* Player::getType()
{
    return "Player";
}

Limb* Player::getTorso()
{
    return m_PlayerLimbs[1];
}

Limb* Player::getLeftArm()
{
    return m_PlayerLimbs[0];
}

Limb* Player::getRightForeArm()
{
    return m_PlayerLimbs[3];
}

Limb* Player::getRightBicep()
{
    return m_PlayerLimbs[2];
}

void Player::createWeapon()
{
    switch(m_ActiveWeapon)
    {
        case BOW:
        {
            if(m_Bow == NULL)
            {
                m_Bow = new Bow(b2Helper::screenSpaceToBox2dSpace(1136/5), b2Helper::screenSpaceToBox2dSpace(640/4));
            }
            
            if(m_Projectile == NULL)
            {
                m_Projectile = new Projectile(new OpenGLTexture("Images/Arrow"), "Arrow", b2Helper::screenSpaceToBox2dSpace(1136/5), b2Helper::screenSpaceToBox2dSpace(640/4), b2_staticBody);
            }
            
            break;
        }
        case TOMAHAWK:
        {
            if(m_Projectile == NULL)
            {
                m_Projectile = new Projectile(new OpenGLTexture("Images/Tomahawk"), "Tomahawk", b2Helper::screenSpaceToBox2dSpace(1136/5) + 1, b2Helper::screenSpaceToBox2dSpace(640/4), b2_staticBody);
            }
            break;
        }
        default:
            break;
    }
}

void Player::switchWeapons()
{
    if(m_Bow != NULL)
    {
        Game::getInstance() -> removeGameObject(m_Bow);
        m_Bow = NULL;
    }
    
    if(m_Projectile != NULL)
    {
        Game::getInstance() -> removeGameObject(m_Projectile);
        m_Projectile = NULL;
    }
    
    m_ActiveWeapon++;
    if(m_ActiveWeapon == COUNT)
    {
        m_ActiveWeapon = BOW;
    }
    createWeapon();
}

void Player::prepShot(float deltaX, float angle)
{
    if(m_Projectile != NULL)
    {
        m_Impulse = b2Vec2(GAME_BASE_IMPULSE * deltaX / GAME_BOW_DRAWBACK_RANGE, 0);
        
        m_Projectile -> setAngle(angle);
        
        m_Projectile -> setX(m_Projectile -> getX());
        m_Projectile -> setY(m_Projectile -> getY());
    }
}

void Player::reload()
{
    createWeapon();
}

void Player::fireProjectile(float angularVelocity)
{
    if(m_Projectile != NULL)
    {
        m_Projectile->setBodyType(b2_dynamicBody);
        
        b2Vec2 impulse = b2Mul(b2Rot(m_Projectile -> getBody() -> GetAngle()), m_Impulse);
        
        m_Projectile->applyLinearImpulse(impulse, b2Vec2(0.0f, 0.0f));
    }
    m_Projectile = NULL;
    m_Impulse = b2Vec2(0,0);
}

bool Player::testPoint(float x, float y)
{
    bool result = false;
    
    for(int i = 0; i < m_PlayerLimbs.size(); i++)
    {
        result = result || m_PlayerLimbs.at(i) -> testPoint(x, y);
    }
    
    return result;
}
