//
//  GameConstants.cpp
//  GameDevFramework
//
//  Created by Bradley Flood on 12-08-30.
//  Copyright (c) 2012 Algonquin College. All rights reserved.
//

#include "GameConstants.h"


const float GAME_GRAVITY_X = 0.0f;
const float GAME_GRAVITY_Y = -10.0f;

const char* GAME_PHYSICS_EDITOR_FILENAME = "shapedefs.plist";
const float GAME_PHYSICS_PIXELS_TO_METERS_RATIO = 16;
const bool GAME_PHYSICS_CONTINUOUS_SIMULATION = true;
const int GAME_PHYSICS_VELOCITY_ITERATIONS = 4;
const int GAME_PHYSICS_POSITION_ITERATIONS = 1;

const int GAME_ROPE_NUMBER_OF_SEGMENTS = 10;
const float GAME_BODY_POSITION_X = 0.85f;
const float GAME_BODY_POSITION_Y = 0.85f;
const float GAME_ROPE_BODY_OFFSET = 0.1f;
const float GAME_BLOOD_AMOUNT = 50.0f;

//Player Constants
const float GAME_BOW_DRAWBACK_RANGE = 125.0f;
const float GAME_BASE_IMPULSE = 50.0f;
const float GAME_INDIAN_POSITION_X = 0.15f;
const float GAME_INDIAN_POSITION_Y = 0.2f;

const float GAME_PROJECTILE_LIFE_TIME = 2.0f;

//Pickup Coordinates
const float GAME_LEFT_X_COORDINATE = 420.0f;
const float GAME_BOTTOM_Y_COORDINATE = 214.0f;
const float GAME_SPAWN_AREA_WIDTH = 374.0f;
const float GAME_SPAWN_AREA_HIEGHT = 207.0f;

//Timers
const int GAME_RELOAD_DELAY = 2.0f;
const int GAME_PICKUP_DELAY = 7.0f;

const int GAME_FRAMES_PER_SECOND = 60;