//
//  GameConstants.h
//  GameDevFramework
//
//  Created by Bradley Flood on 12-08-30.
//  Copyright (c) 2012 Algonquin College. All rights reserved.
//

#ifndef GAME_CONSTANTS_H
#define GAME_CONSTANTS_H

enum
{
    GameLoadStepInitial = 0,
    GameLoadStepWorld,

    GameLoadStepLog,
    GameLoadStepPilgrim,
    GameLoadStepPlayer,
    
    GameLoadStepWeapon,

    GameLoadStepFinal,
	GameLoadStepCount
};
typedef unsigned int GameLoadSteps;


extern const float GAME_GRAVITY_X;
extern const float GAME_GRAVITY_Y;

extern const char* GAME_PHYSICS_EDITOR_FILENAME;
extern const float GAME_PHYSICS_PIXELS_TO_METERS_RATIO;
extern const bool GAME_PHYSICS_CONTINUOUS_SIMULATION;
extern const int GAME_PHYSICS_VELOCITY_ITERATIONS;
extern const int GAME_PHYSICS_POSITION_ITERATIONS;

extern const int GAME_ROPE_NUMBER_OF_SEGMENTS;
extern const float GAME_BODY_POSITION_X;
extern const float GAME_BODY_POSITION_Y;
extern const float GAME_ROPE_BODY_OFFSET;

extern const float GAME_BLOOD_AMOUNT;

//Player Constants
extern const float GAME_BOW_DRAWBACK_RANGE;
extern const float GAME_BASE_IMPULSE;

extern const float GAME_INDIAN_POSITION_X;
extern const float GAME_INDIAN_POSITION_Y;

extern const float GAME_PROJECTILE_LIFE_TIME;

//Pickup Constants
extern const float GAME_LEFT_X_COORDINATE;
extern const float GAME_BOTTOM_Y_COORDINATE;
extern const float GAME_SPAWN_AREA_WIDTH;
extern const float GAME_SPAWN_AREA_HIEGHT;

//Timers
extern const int GAME_RELOAD_DELAY;
extern const int GAME_PICKUP_DELAY;

extern const int GAME_FRAMES_PER_SECOND;


#endif
