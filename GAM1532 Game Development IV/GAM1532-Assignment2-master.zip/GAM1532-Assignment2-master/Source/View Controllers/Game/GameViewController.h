//
//  GameViewController.h
//  GameDevFramework
//
//  Created by Bradley Flood on 12-08-30.
//  Copyright (c) 2012 Algonquin College. All rights reserved.
//


@class EAGLContext;
@class OpenGLView;
@class CADisplayLink;

@interface GameViewController : UIViewController
{
    EAGLContext *m_OpenGLContext;
    OpenGLView *m_OpenGLView;
    CADisplayLink* m_DisplayLink;
}

-(void)invalidateRunLoop;

@property (nonatomic, retain) IBOutlet OpenGLView *openGLView;

@end

