//
//  Student:        Quentin Bellay
//  Creation Date:  February 4th, 2014
//  Course Number:  GAM1532
//  Professor:      Bradley Flood
//  Purpose:        Class representing a parallax background layer (containing multiple segments)
//  Modified:
//

#ifndef __GameDevFramework__ParallaxLayer__
#define __GameDevFramework__ParallaxLayer__

#include <iostream>
#include <vector>

class OpenGLTexture;
class ParallaxSegment;
class GDRandom;

// Class representing a parallax background layer (containing multiple segments)
class ParallaxLayer
{
public:
    ParallaxLayer(std::vector<OpenGLTexture*> &textures, float depth, float movementX, float movementY);
    ~ParallaxLayer();
    
    void moveLayer(float speedX, float speedY);
    void paint();
    
    void reset();
    
    void cycleSegment();
    
    void prepareCycleSegment(float directionX, float directionY);
    
private:
    std::vector<ParallaxSegment*> m_Segments;
    ParallaxSegment* m_ActiveSegments[2];
    float m_Depth; // Used as a multiplier for the speed of movement (must be positive - the closer to 0, the farther the layer)
    GDRandom* m_Randomizer;
    bool m_CycleSegment;
    
    float m_CycleX;
    float m_CycleY;
};

#endif /* defined(__GameDevFramework__ParallaxLayer__) */
