//
//  Game.h
//  GameDevFramework
//
//  Created by Bradley Flood on 12-08-30.
//  Copyright (c) 2012 Algonquin College. All rights reserved.
//

#ifndef GAME_H
#define GAME_H

#include "Constants.h"
#include "OpenGL.h"

class ParallaxLayer;

class Game
{
public:
    //Singleton instance methods
    static Game* getInstance();
    
    //Update, paint and touch event (lifecycle) methods
    void update(double delta);
    void paint();
    void touchEvent(TouchEvent touchEvent, float locationX, float locationY);
    
    //Reset methods
    void reset();
    
    //Conveniance methods to access the screen's width and height
    float getScreenWidth();
    float getScreenHeight();
    float getScale();

    //Loading methods
    bool isLoading();
    
    void paintLoading();
    
private:
    //Private constructor and destructor ensures the singleton instance
    Game();
    ~Game();
    
    //Load method, called once every load step
    void load();
    void loadTextures(std::vector<OpenGLTexture*> &textures, const char** names, int length);
    
    void createLayer(int index, const char** names, int length);
    
    //Singleton instance static member variable
    static Game* m_Instance;
    
    //Load step member variable
    int m_LoadStep;
    
    OpenGLTexture* m_StaticBackground;
    
    std::vector<ParallaxLayer*> m_ParallaxLayers;
    
    float m_SpeedX;
    float m_SpeedY;
    
    float m_DirectionX;
    float m_DirectionY;
};

#endif
