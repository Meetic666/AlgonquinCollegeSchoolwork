//
//  Student:        Quentin Bellay
//  Creation Date:  February 4th, 2014
//  Course Number:  GAM1532
//  Professor:      Bradley Flood
//  Purpose:        Class representing a parallax background segments (in charge of moving and displaying the texture)
//  Modified:
//

#include "ParallaxSegment.h"
#include "ParallaxLayer.h"

#include "../Utils/Utils.h"
#include "Game.h"

ParallaxSegment::ParallaxSegment(ParallaxLayer* parent, OpenGLTexture* texture) :
m_X(0.0f),
m_Y(0.0f),
m_Texture(NULL),
m_Parent(parent)
{    
    m_Texture = texture;
}

ParallaxSegment::~ParallaxSegment()
{
    delete m_Texture;
    m_Texture = NULL;
}

void ParallaxSegment::reset()
{
    m_X = 0.0f;
    m_Y = 0.0f;
}

void ParallaxSegment::moveSegment(float speedX, float speedY)
{
    m_X += speedX;
    m_Y += speedY;
    
    if(speedX < 0.0f && m_X <= - getWidth())
    {
        m_Parent -> prepareCycleSegment(1.0f, 0);
    }
    else if(speedX > 0.0f && m_X >= getWidth())
    {
        m_Parent -> prepareCycleSegment(-1.0f, 0);
    }
    
    if(speedY < 0.0f && m_Y <= - getHeight())
    {
        m_Parent -> prepareCycleSegment(0, 1.0f);
    }
    else if(speedY > 0.0f && m_Y >= getHeight())
    {
        m_Parent -> prepareCycleSegment(0, -1.0f);
    }
}

void ParallaxSegment::paint()
{
    if(m_Texture != NULL)
    {
        OpenGLRenderer::getInstance() -> drawTexture(m_Texture, (int)m_X, (int)m_Y, getWidth(), getHeight());
    }
}

void ParallaxSegment::setPosition(float x, float y)
{
    m_X = x;
    m_Y = y;
}

float ParallaxSegment::getX()
{
    return m_X;
}

float ParallaxSegment::getY()
{
    return m_Y;
}

float ParallaxSegment::getWidth()
{
    return m_Texture -> getSourceWidth() * Game::getInstance() -> getScale() / 2.0f;
}

float ParallaxSegment::getHeight()
{
    return m_Texture -> getSourceHeight() * Game::getInstance() -> getScale() / 2.0f;
}
