//
//  Student:        Quentin Bellay
//  Creation Date:  Once upon a time...
//  Course Number:  GAM1532
//  Professor:      Bradley Flood
//  Purpose:        Main Game class
//  Modified:       February 4th, 2014:     added the parallax layers
//                  February 9th, 2014:     fixed the sharing of textures by having multiple vectors instead of only using the
//                                          one
//                  February 10th, 2014:    got rid of magic numbers (use of constants instead)
//

#include "Game.h"
#include "GameObject.h"
#include "DeviceUtils.h"
#include "MathUtils.h"
#include "PhysicsEditorWrapper.h"
#include "LogUtils.h"

#include "ParallaxLayer.h"


Game* Game::m_Instance = NULL;

Game* Game::getInstance()
{
    //Singleton design pattern ensures that there is only 1 instance of the game
    if(m_Instance == NULL)
    {
        m_Instance = new Game();
    }
    return m_Instance;
}

Game::Game() :
    m_LoadStep(-1),
    m_StaticBackground(NULL),
    m_SpeedX(BACKGROUND_SPEED_X),
    m_SpeedY(BACKGROUND_SPEED_Y),
    m_DirectionX(0),
    m_DirectionY(0)
{
    if(m_SpeedX != 0.0f)
    {
        m_DirectionX = m_SpeedX / fabsf(m_SpeedX);
    }
    
    if(m_SpeedY != 0.0f)
    {
        m_DirectionY = m_SpeedY / fabsf(m_SpeedY);
    }
}

Game::~Game()
{
    //TODO: Delete objects used in game here
    
    for(int i = 0; i < m_ParallaxLayers.size(); i++)
    {
        delete m_ParallaxLayers.at(i);
        m_ParallaxLayers.at(i) = NULL;
    }
    
    m_ParallaxLayers.clear();
    
    delete m_StaticBackground;
    m_StaticBackground = NULL;
}

void Game::load()
{
    switch(m_LoadStep)
    {
        case GameLoadStepInitial:
        {
            
        }
        break;
            
        case GameLoadStepStaticBackground:
        {            
            m_StaticBackground = new OpenGLTexture(STATIC_BACKGROUND);
        }
        break;
            
        case GameLoadStepBackground:
        {
            int numberOfSegments = sizeof(FAR_BACKGROUND) / sizeof(FAR_BACKGROUND[0]);
            
            createLayer(0, FAR_BACKGROUND, numberOfSegments);
        }
        break;
            
        case GameLoadStepMiddleBackground:
        {
            int numberOfSegments = sizeof(BACKGROUND) / sizeof(BACKGROUND[0]);
            
            createLayer(1, BACKGROUND, numberOfSegments);
        }
        break;
            
        case GameLoadStepMiddleground:
        {
            int numberOfSegments = sizeof(MIDDLEGROUND) / sizeof(MIDDLEGROUND[0]);
            
            createLayer(2, MIDDLEGROUND, numberOfSegments);
        }
        break;
            
        case GameLoadStepMiddleForeground:
        {
            int numberOfSegments = sizeof(FOREGROUND) / sizeof(FOREGROUND[0]);
            
            createLayer(3, FOREGROUND, numberOfSegments);
        }
        break;
            
        case GameLoadStepForeground:
        {
            int numberOfSegments = sizeof(CLOSE_FOREGROUND) / sizeof(CLOSE_FOREGROUND[0]);
            
            createLayer(4, CLOSE_FOREGROUND, numberOfSegments);
        }
            
        case GameLoadStepFinal:
        {
            reset();
        }
        break;
            
        default:
            break;
    }
}

void Game::loadTextures(std::vector<OpenGLTexture*> &textures, const char** names, int length)
{
    for(int j = 0; j < length; j++)
    {
        textures.push_back(new OpenGLTexture(names[j]));
    }
}

void Game::createLayer(int index, const char** names, int length)
{
    std::vector<OpenGLTexture*> textures;
    
    loadTextures(textures, names, length);
    
    m_ParallaxLayers.push_back(new ParallaxLayer(textures, DEPTHS[index], m_DirectionX, m_DirectionY));
}

void Game::update(double aDelta)
{
    m_LoadStep++;
    
    if(isLoading())
    {
        load();
        return;
    }
    
    //TODO: Add Game logic here
    
    for(int i = 0; i < m_ParallaxLayers.size(); i++)
    {
        if(m_ParallaxLayers.at(i) != NULL)
        {
            m_ParallaxLayers.at(i) -> moveLayer(m_SpeedX * getScale() * aDelta, m_SpeedY * getScale() * aDelta);
        }
    }
    
}

void Game::paint()
{
    if(isLoading())
    {
        paintLoading();
        return;
    }
    
    //TODO: Render you game logic here
    
    OpenGLRenderer::getInstance() -> drawTexture(m_StaticBackground, 0, 0, m_StaticBackground -> getSourceWidth() * getScale() / 2.0f, m_StaticBackground -> getSourceHeight() * getScale() / 2.0f);
    
    for(int i = 0; i < m_ParallaxLayers.size(); i++)
    {
        if(m_ParallaxLayers.at(i) != NULL)
        {
            m_ParallaxLayers.at(i) -> paint();
        }
    }
}

void Game::paintLoading()
{
    float screenWidth = getScreenWidth();
    float screenHeight = getScreenHeight();
    
    OpenGLRenderer* renderer = OpenGLRenderer::getInstance();
    
    renderer -> setForegroundColor(OpenGLColorBlack());
    renderer -> drawRectangle(0.0f, 0.0f, screenWidth, screenHeight);
    
    // Bar size
    float barWidth = 250.0f * getScale();
    float barHeight = 40.0f* getScale();
    float barX = (screenWidth - barWidth) / 2.0f;
    float barY = (screenHeight - barHeight) / 2.0f;
    
    renderer -> setForegroundColor(OpenGLColorWhite());
    renderer -> drawRectangle(barX, barY, barWidth, barHeight, false);
    
    float percentageLoaded = (float)m_LoadStep / (float)(GameLoadStepCount - 1);
    float loadedWidth = barWidth * percentageLoaded;
    renderer -> setForegroundColor(OpenGLColorYellow());
    renderer -> drawRectangle(barX, barY, loadedWidth, barHeight);
}

void Game::touchEvent(TouchEvent aTouchEvent, float aLocationX, float aLocationY)
{
    //TODO: Handle touch events here
}

void Game::reset()
{
    for(int i = 0; i < m_ParallaxLayers.size(); i++)
    {
        if(m_ParallaxLayers.at(i) != NULL)
        {
            m_ParallaxLayers.at(i) -> reset();
        }
    }
}

float Game::getScreenWidth()
{
    return DeviceUtils::getScreenResolutionWidth();
}

float Game::getScreenHeight()
{
    return DeviceUtils::getScreenResolutionHeight();
}

float Game::getScale()
{
    return DeviceUtils::getContentScaleFactor();
}

bool Game::isLoading()
{
    return m_LoadStep < GameLoadStepCount;
}
