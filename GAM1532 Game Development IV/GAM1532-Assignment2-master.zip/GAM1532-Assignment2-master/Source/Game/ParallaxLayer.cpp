//
//  Student:        Quentin Bellay
//  Creation Date:  February 4th, 2014
//  Course Number:  GAM1532
//  Professor:      Bradley Flood
//  Purpose:        Class representing a parallax background layer (containing multiple segments)
//  Modified:
//

#include "ParallaxLayer.h"
#include "ParallaxSegment.h"
#include "../Math/GDRandom.h"
#include "../OpenGL/OpenGL.h"
#include "LogUtils.h"
#include "Game.h"

ParallaxLayer::ParallaxLayer(std::vector<OpenGLTexture*> &textures, float depth, float movementX, float movementY) :
m_Depth(depth),
m_Randomizer(NULL),
m_CycleSegment(false),
m_CycleX(-movementX),
m_CycleY(-movementY)
{
    m_Segments.clear();
    
    for(int i = 0; i < textures.size(); i++)
    {
        m_Segments.push_back(new ParallaxSegment(this, textures[i]));
    }
    
    int numberOfActiveSegments = sizeof(m_ActiveSegments) / sizeof(m_ActiveSegments[0]);
    
    for(int i = 0; i < numberOfActiveSegments; i++)
    {
        m_ActiveSegments[i] = m_Segments[i];
    }
    
    m_Randomizer = new GDRandom();
    
    m_Randomizer -> randomizeSeed();
}

ParallaxLayer::~ParallaxLayer()
{
    for(int i = 0; i < m_Segments.size(); i++)
    {
        delete m_Segments[i];
        m_Segments[i] = NULL;
    }
    
    m_Segments.clear();
    
    delete m_Randomizer;
    m_Randomizer = NULL;
}

void ParallaxLayer::reset()
{
    int numberOfActiveSegments = sizeof(m_ActiveSegments) / sizeof(m_ActiveSegments[0]);
    
    for(int i = 0; i < numberOfActiveSegments; i++)
    {
        if(m_ActiveSegments[i] != NULL)
        {
            m_ActiveSegments[i] -> reset();
        }
    }
    
    cycleSegment();
}

void ParallaxLayer::moveLayer(float speedX, float speedY)
{
    int numberOfActiveSegments = sizeof(m_ActiveSegments) / sizeof(m_ActiveSegments[0]);
    
    for(int i = 0; i < numberOfActiveSegments; i++)
    {
        if(m_ActiveSegments[i] != NULL)
        {
            m_ActiveSegments[i] -> moveSegment(speedX * m_Depth, speedY * m_Depth);
        }
    }
    
    if(m_CycleSegment)
    {
        cycleSegment();
        
        m_CycleSegment = false;
    }
}

void ParallaxLayer::paint()
{
    for(int i = 0; i < 2; i++)
    {
        if(m_ActiveSegments[i] != NULL)
        {
            m_ActiveSegments[i] -> paint();
        }
    }
}

void ParallaxLayer::cycleSegment()
{
    m_ActiveSegments[0] = m_ActiveSegments[1];
    
    do
    {
        m_ActiveSegments[1] = m_Segments.at(m_Randomizer -> random(m_Segments.size()));
    }
    while(m_ActiveSegments[0] == m_ActiveSegments[1]);
    
    m_ActiveSegments[1] -> setPosition(m_ActiveSegments[0] -> getX() + m_CycleX * (m_ActiveSegments[0] -> getWidth()), m_ActiveSegments[0] -> getY() + m_CycleY * (m_ActiveSegments[0] -> getHeight()));
}

void ParallaxLayer::prepareCycleSegment(float directionX, float directionY)
{
    m_CycleSegment = true;
    
    m_CycleX = directionX;
    m_CycleY = directionY;
}