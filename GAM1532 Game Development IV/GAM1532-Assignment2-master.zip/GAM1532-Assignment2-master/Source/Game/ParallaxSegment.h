//
//  Student:        Quentin Bellay
//  Creation Date:  February 4th, 2014
//  Course Number:  GAM1532
//  Professor:      Bradley Flood
//  Purpose:        Class representing a parallax background segments (in charge of moving and displaying the texture)
//  Modified:
//

#ifndef __GameDevFramework__ParallaxSegment__
#define __GameDevFramework__ParallaxSegment__

#include <iostream>
#include "../OpenGL/OpenGL.h"

class ParallaxLayer;

// Class representing a parallax background segments (in charge of moving and displaying the texture)
class ParallaxSegment
{
public:
    ParallaxSegment(ParallaxLayer* parent, OpenGLTexture* texture);
    ~ParallaxSegment();
    
    void moveSegment(float speedX, float speedY);
    
    void paint();
    
    void reset();
    
    void setPosition(float x, float y);
    
    float getX();
    float getY();
    
    float getWidth();
    float getHeight();
    
private:
    float m_X;
    float m_Y;
    
    OpenGLTexture* m_Texture;
    
    ParallaxLayer* m_Parent;
};

#endif /* defined(__GameDevFramework__ParallaxSegment__) */
