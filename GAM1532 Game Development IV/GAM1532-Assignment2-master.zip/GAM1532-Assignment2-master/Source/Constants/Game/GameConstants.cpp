//
//  GameConstants.cpp
//  GameDevFramework
//
//  Created by Bradley Flood on 12-08-30.
//  Copyright (c) 2012 Algonquin College. All rights reserved.
//

#include "GameConstants.h"


const float GAME_GRAVITY_X = 0.0f;
const float GAME_GRAVITY_Y = -10.0f;

const char* GAME_PHYSICS_EDITOR_FILENAME = "shapedefs.plist";
const float GAME_PHYSICS_PIXELS_TO_METERS_RATIO = 16;
const bool GAME_PHYSICS_CONTINUOUS_SIMULATION = true;
const int GAME_PHYSICS_VELOCITY_ITERATIONS = 4;
const int GAME_PHYSICS_POSITION_ITERATIONS = 1;

const char* STATIC_BACKGROUND = "Images/StaticBackground";

const char* FAR_BACKGROUND[5] = {"Images/MiddleBackground1",
                                "Images/MiddleBackground2",
                                "Images/MiddleBackground3",
                                "Images/MiddleBackground4",
                                "Images/MiddleBackground5"};

const char* BACKGROUND[5] = {"Images/Background1",
                            "Images/Background2",
                            "Images/Background3",
                            "Images/Background4",
                            "Images/Background5"};

const char* MIDDLEGROUND[5] = {"Images/MiddleForeground1",
                              "Images/MiddleForeground2",
                              "Images/MiddleForeground3",
                              "Images/MiddleForeground4",
                              "Images/MiddleForeground5"};

const char* FOREGROUND[5] = {"Images/Foreground1",
                            "Images/Foreground2",
                            "Images/Foreground3",
                            "Images/Foreground4",
                            "Images/Foreground5"};

const char* CLOSE_FOREGROUND[5] = {"Images/ReallyForeground1",
                                  "Images/ReallyForeground2",
                                  "Images/ReallyForeground3",
                                  "Images/ReallyForeground4",
                                  "Images/ReallyForeground5"};

const float DEPTHS[] = {0.1f, 0.2f, 0.4f, 0.7f, 1.0f};

const float BACKGROUND_SPEED_X = 100.0f;
const float BACKGROUND_SPEED_Y = 0.0f;