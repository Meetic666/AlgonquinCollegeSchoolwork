﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;

public class CustomEditBox : EditorWindow 
{
	ColoredCircle m_ColoredCircle;
	
	float m_Radius;

	[Range(3, 45)]
	int m_NumberOfPoints;

	float m_InitialAngleInDegrees;
	
	float m_DeformationSpeed;
	float m_DeformationAmplitude;
	
	[MenuItem("Component/Quentin/ColoredCircleEditBox")]
	public static void ShowWindow()
	{
		if(Selection.activeGameObject && Selection.activeGameObject.GetComponent<ColoredCircle>())
		{
			EditorWindow.GetWindow(typeof(CustomEditBox));
		}
		else
		{
			Debug.Log ("Select a colored circle !!!");
		}
	}
	
	void Update()
	{
		if(m_ColoredCircle != null)
		{
			m_ColoredCircle.m_Radius = m_Radius;
			m_ColoredCircle.m_NumberOfPoints = m_NumberOfPoints;
			m_ColoredCircle.m_InitialAngleInDegrees = m_InitialAngleInDegrees;

			m_ColoredCircle.m_DeformationSpeed = m_DeformationSpeed;
			m_ColoredCircle.m_DeformationAmplitude = m_DeformationAmplitude;
		}
	}
	
	void OnGUI()
	{
		if(Selection.activeGameObject && Selection.activeGameObject.GetComponent<ColoredCircle>())
		{
			m_ColoredCircle = Selection.activeGameObject.GetComponent<ColoredCircle>();
			
			GetValues ();

			GUILayout.Label ("Mesh Editing", EditorStyles.largeLabel);
			
			m_Radius = EditorGUILayout.Slider("Radius", m_Radius, 0.0f, 10.0f);
			m_NumberOfPoints = EditorGUILayout.IntSlider("Number of Points", m_NumberOfPoints, 0, 45);
			m_InitialAngleInDegrees = EditorGUILayout.FloatField("Initial Angle In Degrees", m_InitialAngleInDegrees);

			GUILayout.Space(50.0f);

			GUILayout.Label ("Deformation Editing", EditorStyles.largeLabel);

			m_DeformationSpeed = EditorGUILayout.Slider("Deformation Speed", m_DeformationSpeed, 0.0f, 50.0f);
			m_DeformationAmplitude = EditorGUILayout.Slider("Deformation Amplitude", m_DeformationAmplitude, 0.0f, 10.0f);
		}
	}

	void GetValues()
	{
		m_Radius = m_ColoredCircle.m_Radius;
		m_NumberOfPoints = m_ColoredCircle.m_NumberOfPoints;
		m_InitialAngleInDegrees = m_ColoredCircle.m_InitialAngleInDegrees;
		
		m_DeformationSpeed = m_ColoredCircle.m_DeformationSpeed;
		m_DeformationAmplitude = m_ColoredCircle.m_DeformationAmplitude;
	}
}
