﻿using UnityEngine;
using System.Collections;

public class SkyManager : MonoBehaviour 
{
	public GameObject m_Sky;
	public GameObject m_NightSky;
	public GameObject m_Sun;
	public GameObject m_Moon;
	public GameObject m_Camera;
	public GameObject m_Clouds;

	public float m_SunRotationSpeed = 5.0f;

	public float m_SunObjectMultiplier = 1.0f;

	public Vector2 m_Clouds0Speed;
	public Vector2 m_Clouds1Speed;

	Vector3 m_SunPosition = Vector3.up;

	Vector2 m_Clouds0Position = Vector2.zero;
	Vector2 m_Clouds1Position = Vector2.zero;

	bool m_Night = false;

	void Start()
	{
		SwitchNight ();
	}
	
	// Update is called once per frame
	void Update () 
	{
		m_SunPosition = Quaternion.Euler (m_SunRotationSpeed * Time.deltaTime, 0.0f, 0.0f) * m_SunPosition;

		m_Sun.transform.position = m_SunPosition * m_Sky.transform.lossyScale.x * m_SunObjectMultiplier;
		m_Sun.transform.up = (m_Camera.transform.position - m_Sun.transform.position).normalized;

		m_Moon.transform.position = m_SunPosition * m_Sky.transform.lossyScale.x * m_SunObjectMultiplier;
		m_Moon.transform.up = (m_Camera.transform.position - m_Sun.transform.position).normalized;

		m_Sky.renderer.material.SetFloat ("m_SunPositionX", m_SunPosition.x);
		m_Sky.renderer.material.SetFloat ("m_SunPositionY", m_SunPosition.y);
		m_Sky.renderer.material.SetFloat ("m_SunPositionZ", m_SunPosition.z);


		m_Clouds0Position += m_Clouds0Speed * Time.deltaTime;
		m_Clouds1Position += m_Clouds1Speed * Time.deltaTime;


		m_Clouds.renderer.material.SetFloat ("m_Clouds0PositionX", m_Clouds0Position.x);
		m_Clouds.renderer.material.SetFloat ("m_Clouds0PositionY", m_Clouds0Position.y);

		m_Clouds.renderer.material.SetFloat ("m_Clouds1PositionX", m_Clouds1Position.x);
		m_Clouds.renderer.material.SetFloat ("m_Clouds1PositionY", m_Clouds1Position.y);

		m_Clouds.renderer.material.SetFloat ("m_SunPositionX", m_SunPosition.x);
		m_Clouds.renderer.material.SetFloat ("m_SunPositionY", m_SunPosition.y);
		m_Clouds.renderer.material.SetFloat ("m_SunPositionZ", m_SunPosition.z);
	}

	[ContextMenu("Switch Night Day")]
	void SwitchNight()
	{
		m_Night = !m_Night;

		m_Sky.SetActive (!m_Night);
		m_Sun.SetActive (!m_Night);

		m_NightSky.SetActive (m_Night);
		m_Moon.SetActive (m_Night);
	}
}
