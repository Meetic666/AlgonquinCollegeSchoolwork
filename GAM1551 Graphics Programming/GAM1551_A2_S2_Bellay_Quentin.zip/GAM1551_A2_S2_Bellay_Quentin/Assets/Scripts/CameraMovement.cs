﻿using UnityEngine;
using System.Collections;

public class CameraMovement : MonoBehaviour 
{
	public float m_LookSpeed = 5.0f;

	// Use this for initialization
	void Start () 
	{
	
	}
	
	// Update is called once per frame
	void Update () 
	{
		Vector3 newEulerAngles = transform.eulerAngles;

		newEulerAngles += new Vector3 (- Input.GetAxis ("Mouse Y"), Input.GetAxis ("Mouse X"), 0.0f) * m_LookSpeed * Time.deltaTime;

		transform.eulerAngles = newEulerAngles;
	}
}
