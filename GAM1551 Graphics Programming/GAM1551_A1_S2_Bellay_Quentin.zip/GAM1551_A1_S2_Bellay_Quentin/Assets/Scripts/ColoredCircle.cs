﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[RequireComponent(typeof(MeshFilter))]
[RequireComponent(typeof(MeshRenderer))]

public class ColoredCircle : MonoBehaviour 
{
	List<Vector3> m_Positions;
	List<Color> m_Colors;
	List<int> m_Indices;
	Mesh m_Mesh;
	Vector3 m_Center = Vector3.zero;
	int m_CurrentNumberOfPoints;
	float m_CurrentRadius;
	float m_CurrentInitialAngleInDegrees;

	public float m_Radius = 1.0f;
	public float m_InitialAngleInDegrees = 90.0f;

	[Range(3, 45)]
	public int m_NumberOfPoints = 3;

	[Range(0.0f, 50.0f)]
	public float m_DeformationSpeed;

	[Range(0.0f, 10.0f)]
	public float m_DeformationAmplitude;

	// Use this for initialization
	void Start () 
	{		
		InitializeMesh ();
	}
	
	// Update is called once per frame
	void Update ()
	{
		renderer.material.SetFloat ("m_DeformationSpeed", m_DeformationSpeed);
		renderer.material.SetFloat ("m_DeformationAmplitude", m_DeformationAmplitude);

		if(m_CurrentNumberOfPoints != m_NumberOfPoints || m_CurrentRadius != m_Radius || m_CurrentInitialAngleInDegrees != m_InitialAngleInDegrees)
		{
			InitializeMesh();
		}
		
		GetComponent<MeshFilter> ().mesh = m_Mesh;
	}

	void InitializeMesh()
	{
		m_Positions = new List<Vector3> ();
		m_Colors = new List<Color> ();
		m_Indices = new List<int>();
		
		float angleDelta = 2 * Mathf.PI / m_NumberOfPoints;

		m_Positions.Add (m_Center);
		m_Colors.Add (new Color(.5f, 0.5f, 0.5f, 1.0f));

		int initialIndex = 1;

		float initialAngle = m_InitialAngleInDegrees * Mathf.Deg2Rad;
		
		for(int i = 0; i < m_NumberOfPoints; i++)
		{
			float angle = initialAngle + i * angleDelta;

			m_Positions.Add (new Vector3(Mathf.Cos(angle) * m_Radius, Mathf.Sin (angle) * m_Radius, 0.0f));
			
			m_Colors.Add (new Color(Mathf.Cos(i * angleDelta), Mathf.Sin (i * angleDelta), Mathf.Tan (i * angleDelta), 1.0f));

			if(i >= 1)
			{
				m_Indices.Add (0);
				m_Indices.Add (initialIndex + i);
				m_Indices.Add (initialIndex + i - 1);

				if(i == m_NumberOfPoints - 1)
				{
					m_Indices.Add (0);
					m_Indices.Add (1);
					m_Indices.Add (initialIndex + i);
				}
			}
		}
		
		m_Mesh = new Mesh ();
		m_Mesh.vertices = m_Positions.ToArray();
		m_Mesh.colors = m_Colors.ToArray ();
		m_Mesh.triangles = m_Indices.ToArray (); // Indices always last
		m_Mesh.name = "CircleWith" + m_NumberOfPoints;

		m_CurrentNumberOfPoints = m_NumberOfPoints;
		m_CurrentRadius = m_Radius;
		m_CurrentInitialAngleInDegrees = m_InitialAngleInDegrees;
	}
}
