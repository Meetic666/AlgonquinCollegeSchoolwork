﻿using UnityEngine;
using System.Collections;

public class SpriteSheet : MonoBehaviour 
{
	public int m_TextureResolutionX = 6;
	public int m_TextureResolutionY = 5;

	public float m_AnimationSpeed = 3.0f;

	public Vector2 m_MinInterferenceOffset;
	public Vector2 m_MaxInterferenceOffset;

	float m_Timer = 1.0f;

	int m_TextureX = 0;
	int m_TextureY = 4;

	// Use this for initialization
	void Start () 
	{
		m_TextureY = m_TextureResolutionY - 1;

		renderer.material.SetInt ("m_TextureResolutionX", m_TextureResolutionX);
		renderer.material.SetInt ("m_TextureResolutionY", m_TextureResolutionY);

		renderer.material.SetInt ("m_TextureX", m_TextureX);
		renderer.material.SetInt ("m_TextureY", m_TextureY);
	}
	
	// Update is called once per frame
	void Update () 
	{
		m_Timer -= m_AnimationSpeed * Time.deltaTime;

		if(m_Timer <= 0.0f)
		{
			m_Timer = 1.0f;

			NextFrame();

			renderer.material.SetInt ("m_TextureX", m_TextureX);
			renderer.material.SetInt ("m_TextureY", m_TextureY);
			
			renderer.material.SetFloat ("m_InterferenceOffsetX", Mathf.Lerp(m_MinInterferenceOffset.x, m_MaxInterferenceOffset.x, Random.value));
			renderer.material.SetFloat ("m_InterferenceOffsetY", Mathf.Lerp(m_MinInterferenceOffset.y, m_MaxInterferenceOffset.y, Random.value));
		}
	}

	void NextFrame()
	{
		m_TextureX++;

		if(m_TextureX >= m_TextureResolutionX)
		{
			m_TextureX = 0;

			m_TextureY--;

			if(m_TextureY < 0)
			{
				m_TextureY = m_TextureResolutionY - 1;
			}
		}
	}
}
