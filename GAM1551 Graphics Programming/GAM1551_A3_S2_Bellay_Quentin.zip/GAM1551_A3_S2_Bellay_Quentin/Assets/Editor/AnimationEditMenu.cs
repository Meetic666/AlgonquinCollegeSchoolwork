﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;

public class AnimationEditBox : EditorWindow 
{
	SpriteSheet m_SpriteSheet;

	Vector2 m_InterferenceMinOffset;
	Vector2 m_InterferenceMaxOffset;

	float m_AnimationSpeed;
	
	[MenuItem("Component/Quentin/AnimationEditBox")]
	public static void ShowWindow()
	{
		if(Selection.activeGameObject && Selection.activeGameObject.GetComponent<SpriteSheet>())
		{
			EditorWindow.GetWindow(typeof(AnimationEditBox));
		}
		else
		{
			Debug.Log ("Select a sprite sheet !!!");
		}
	}
	
	void Update()
	{
		if(m_SpriteSheet != null)
		{
			m_SpriteSheet.m_AnimationSpeed = m_AnimationSpeed;

			m_SpriteSheet.m_MinInterferenceOffset = m_InterferenceMinOffset;

			m_SpriteSheet.m_MaxInterferenceOffset = m_InterferenceMaxOffset;
		}
		else
		{
			if(Selection.activeGameObject && Selection.activeGameObject.GetComponent<SpriteSheet>())
			{
				m_SpriteSheet = Selection.activeGameObject.GetComponent<SpriteSheet>();
				
				GetValues ();
			}
		}
	}
	
	void OnGUI()
	{
		if(Selection.activeGameObject && Selection.activeGameObject.GetComponent<SpriteSheet>())
		{
			GUILayout.Label ("Animation Editing", EditorStyles.largeLabel);
			
			m_AnimationSpeed = EditorGUILayout.Slider("Animation Speed", m_AnimationSpeed, 0.0f, 60.0f);

			GUILayout.Space(50.0f);

			GUILayout.Label ("Interference Editing", EditorStyles.largeLabel);

			m_InterferenceMinOffset = EditorGUILayout.Vector2Field("Min Offset", m_InterferenceMinOffset);

			m_InterferenceMaxOffset = EditorGUILayout.Vector2Field("Max Offset", m_InterferenceMaxOffset);
		}
	}

	void GetValues()
	{
		m_AnimationSpeed = m_SpriteSheet.m_AnimationSpeed;

		m_InterferenceMinOffset = m_SpriteSheet.m_MinInterferenceOffset;
		
		m_InterferenceMaxOffset = m_SpriteSheet.m_MaxInterferenceOffset;
	}
}
